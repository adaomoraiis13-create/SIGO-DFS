# Manual de Instalação e Configuração em Produção

### SIGO-DFS — Direção de Facilitação e Segurança
**Aeroporto Internacional Dr. António Agostinho Neto (ATO & OC Angola)**

---

## 📋 Introdução
Este documento fornece as instruções passo a passo para instalar, configurar, proteger e colocar o **SIGO-DFS** em produção num servidor próprio institucional ou em qualquer provedor de nuvem moderno.

A aplicação foi estruturada de forma independente de qualquer ferramenta de desenvolvimento, permitindo que seja executada através do **Docker** ou de uma instalação nativa em **Node.js 22**.

---

## 🏛️ Requisitos de Infraestrutura Mínimos
- **Sistema Operativo:** Ubuntu Server 22.04 LTS ou qualquer distribuição Linux equivalente.
- **Processador:** Mínimo de 2 vCPUs (Recomendado 4 vCPUs para cargas de IA intensivas).
- **Memória RAM:** Mínimo de 4 GB (Recomendado 8 GB).
- **Armazenamento:** Mínimo de 50 GB SSD (dependendo do volume de relatórios PowerPoint e PDF carregados).
- **Portas de Rede Abertas:** `80` (HTTP), `443` (HTTPS), e `22` (SSH para administração).

---

## 🐳 Método 1: Instalação Recomendada via Docker (1 Comando)

Este é o método recomendado, pois instala a aplicação web e o banco de dados PostgreSQL com isolamento total em menos de 2 minutos.

### Passo 1: Instalar o Docker no Servidor
Se ainda não tem o Docker instalado no servidor, execute os comandos:
```bash
sudo apt update
sudo apt install -y docker.io docker-compose
sudo systemctl enable docker
sudo systemctl start docker
```

### Passo 2: Configurar o Ficheiro de Ambiente
Crie a sua cópia segura do ficheiro de variáveis:
```bash
cp .env.example .env
```
Edite o ficheiro `.env` usando o seu editor preferido (ex: `nano .env`) e insira a chave institucional da API Gemini em `GEMINI_API_KEY`.

### Passo 3: Inicializar a Infraestrutura
Execute o comando de orquestração em background:
```bash
docker compose up -d --build
```
Este comando irá:
1. Descarregar a imagem do PostgreSQL 16.
2. Compilar a aplicação React/Vite com otimizações de produção.
3. Compilar o servidor Express utilizando `esbuild` para CommonJS (`dist/server.cjs`).
4. Criar a rede isolada e os volumes persistentes de dados e uploads.
5. Iniciar os serviços com monitorização automática.

---

## 🛠️ Método 2: Instalação Nativa (Sem Docker)

Se preferir não utilizar o Docker e rodar diretamente no sistema operacional do seu servidor:

### Passo 1: Instalar Node.js 22 e PostgreSQL
```bash
# Adicionar repositório do Node.js 22
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt install -y nodejs postgresql postgresql-contrib
```

### Passo 2: Criar Base de Dados PostgreSQL
Aceda ao prompt do Postgres e crie o utilizador e base de dados corporativa:
```bash
sudo -u postgres psql
```
Execute os comandos SQL:
```sql
CREATE USER sigo_admin WITH PASSWORD 'SigoSecurePassword2026!';
CREATE DATABASE sigo_dfs_prod OWNER sigo_admin;
\c sigo_dfs_prod
-- Ativar extensão para geração de UUIDs
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
\q
```
Importe o esquema do banco de dados relacional fornecido no projeto:
```bash
psql -U sigo_admin -d sigo_dfs_prod -h localhost -f database/schema.sql
```

### Passo 3: Configurar Variáveis e Instalar Dependências
Crie o ficheiro `.env` conforme indicado anteriormente. Garanta que a variável `DATABASE_URL` aponta para o servidor local:
```env
DATABASE_URL=postgresql://sigo_admin:SigoSecurePassword2026!@localhost:5432/sigo_dfs_prod
```
Instale as dependências da aplicação:
```bash
npm install
```

### Passo 4: Compilar e Iniciar a Aplicação
Execute a compilação do frontend e backend:
```bash
npm run build
```
Para garantir que a aplicação corre de forma contínua em background (mesmo se fechar o terminal), instale o gestor de processos PM2:
```bash
sudo npm install -g pm2
pm2 start dist/server.cjs --name "sigo-dfs"
pm2 save
pm2 startup
```

---

## 🌐 Configuração de Domínio e HTTPS (Etapas 11 & 12)

Para aceder à aplicação com segurança através do domínio institucional **`https://sigo-dfs.ato.co.ao`**, siga estes passos.

### Passo 1: Configurar Registo DNS
No painel de controlo do domínio da sua entidade (ex: ATO), crie um registo do tipo **A**:
- **Nome/Host:** `sigo-dfs`
- **Valor/Destino:** O IP público do seu servidor Linux.

### Passo 2: Instalar Nginx como Proxy Inverso
O Nginx receberá os acessos externos nas portas padrão e redirecionará internamente para a aplicação.
```bash
sudo apt install -y nginx
```
Crie uma nova configuração:
```bash
sudo nano /etc/nginx/sites-available/sigo-dfs
```
Insira o seguinte bloco de configuração:
```nginx
server {
    listen 80;
    server_name sigo-dfs.ato.co.ao;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```
Ative a configuração e reinicie o Nginx:
```bash
sudo ln -s /etc/nginx/sites-available/sigo-dfs /etc/nginx/sites-enabled/
sudo systemctl restart nginx
```

### Passo 3: Configurar SSL Gratuito Let's Encrypt (HTTPS)
Instale o Certbot para obter certificados SSL válidos automaticamente:
```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d sigo-dfs.ato.co.ao
```
Siga as instruções do Certbot no terminal. Ele irá renovar o certificado automaticamente a cada 90 dias, mantendo a aplicação HTTPS perfeitamente segura.

---

## ☁️ Deploy Rápido em Provedores Cloud (Etapa 10)

O SIGO-DFS é 100% compatível com as seguintes nuvens:

### 1. Google Cloud Run (Recomendado)
Para efetuar deploy serverless altamente escalável, execute o script automatizado fornecido na raiz:
```bash
chmod +x scripts/deploy_cloud_run.sh
./scripts/deploy_cloud_run.sh
```

### 2. Railway / Render / Azure / AWS
Como o projeto contém `docker-compose.yml` e `Dockerfile` otimizados, basta conectar o seu repositório do GitHub a qualquer um destes serviços. O sistema detetará o arquivo Dockerfile e fará a instalação, build e startup do container de forma 100% automatizada e limpa.

---

## 📧 Configuração de Email Institucional SMTP (Etapa 13)
Abra o seu ficheiro `.env` e configure as seguintes credenciais para habilitar o envio automático de notificações por e-mail:
```env
SMTP_HOST=smtp.ato-oc.co.ao
SMTP_PORT=587
SMTP_USER=notificacoes@sigo-dfs.ato.co.ao
SMTP_PASS=SenhaDoSeuServicoSMTP!
```

---

## 🗄️ Cópias de Segurança Automáticas (Etapa 14)
Configure o script de backup fornecido para rodar todas as noites:
```bash
# Dar permissões de execução
chmod +x scripts/backup.sh

# Adicionar ao Crontab do Linux para rodar às 02:00 da manhã diariamente
(crontab -l 2>/dev/null; echo "0 2 * * * /usr/src/app/scripts/backup.sh >> /var/log/sigo_backup.log 2>&1") | crontab -
```
As cópias de segurança serão salvas em `/usr/src/app/backups`, com retenção e limpeza automática de ficheiros com mais de 7 dias para poupar espaço em disco.
