# Relatório de Arquitetura, Engenharia e Modelo de Dados

### SIGO-DFS — Direção de Facilitação e Segurança
**Aeroporto Internacional Dr. António Agostinho Neto (ATO & OC Angola)**

---

## 🏗️ 1. Desenho de Arquitetura do Sistema

O SIGO-DFS utiliza uma arquitetura de **Camadas Desacopladas (Separation of Concerns)**, permitindo alta flexibilidade, facilidade de manutenção e escalabilidade.

### Diagrama de Processo e Fluxo de Trabalho (Flowchart):
```text
[Utilizador Externo] 
         │ (Acede via Dominio https://sigo-dfs.ato.co.ao)
         ▼
 ┌──────────────┐
 │ Nginx Proxy  │ (Terminação SSL / HTTPS Let's Encrypt)
 └──────┬───────┘
        │ (Redirecionamento Porta 3000)
        ▼
 ┌──────────────┐
 │  Express.js  │ (Servidor de Backend / REST API)
 │  Web Server  │ <--- [Multer Engine] <--- (Salva ficheiros em /uploads)
 └──────┬───────┘
        ├─────────────────────────────┐
        ▼                             ▼
 ┌──────────────┐              ┌──────────────┐
 │  PostgreSQL  │              │  Gemini SDK  │ (Google GenAI Engine)
 │  Base Dados  │              │  (Copilot)   │
 └──────────────┘              └──────────────┘
        ▲
        │ (Persistência segura em tabelas relacionais ou JSONB)
        └─────────────────────────────┘
```

---

## 💻 2. Tecnologias Utilizadas (Etapa 1)

O ecossistema de desenvolvimento do SIGO-DFS é composto por:

### Frontend (SPA - Single Page Application)
- **React 19 & TypeScript:** Construção de interfaces de utilizador com tipagem estrita, modular, performante e reativa.
- **Tailwind CSS v4:** Estilização utilitária de alta velocidade, responsiva, com suporte total a temas focados na legibilidade aeroportuária.
- **Lucide React:** Coleção de ícones vetoriais fluidos e padronizados para consistência visual.
- **Recharts:** Biblioteca de gráficos de alta qualidade para Business Intelligence (BI).
- **Motion (motion/react):** Animações e micro-interações elegantes de transição de estados.

### Backend (REST API & Servidor de Aplicação)
- **Node.js 22 & Express.js:** Motor de execução assíncrona rápido para tratamento de rotas API e orquestração de microsserviços.
- **Multer Engine:** Biblioteca para manipulação, validação e gravação física de ficheiros binários em disco no servidor.
- **esbuild & tsx:** Motores de build de altíssimo desempenho para transpilação instantânea e empacotamento em runtime de produção.

### Banco de Dados & Persistência (Etapa 6)
- **PostgreSQL 16:** Banco de dados relacional robusto com suporte total a transações ACID, chaves primárias e estrangeiras, índices de pesquisa e campo híbrido `JSONB` para extensibilidade flexível.
- **In-Memory Write-Behind Cache:** Estrutura concebida para ler e processar os dados em milissegundos a partir da memória, sincronizando alterações de forma assíncrona no banco de dados sem bloquear a thread de execução do Node.js.

### Inteligência Artificial (Etapa 2)
- **@google/genai (Gemini SDK):** Integração com o modelo **Gemini 3.5** para classificação automática de relatórios operacionais, extração inteligente de metas e desvios operacionais, e motor cognitivo do DFS Copilot.

---

## 🗄️ 3. Modelo Físico-Relacional da Base de Dados

O modelo de dados relacional de produção garante total consistência referencial entre as entidades operacionais:

### Entidades e Atributos Críticos:
1. **`utilizadores` (Utilizadores do Sistema):**
   - Atributos para controlo de acesso, incluindo contadores de tentativas de login falhadas e bloqueio temporário contra força bruta.
2. **`balancos_operacionais` (Balanços Diários):**
   - Dados de contribuições de cada divisão salvos de forma independente para auditoria e rastreabilidade individual.
3. **`documentos` (Ficheiros e Relatórios PowerPoint/PDF):**
   - Guarda o registo do caminho real no disco rígido (`/uploads/...`) e o utilizador responsável pelo upload.
4. **`planos_acao` (Ações Corretivas):**
   - Entidade ligada às divisões. Controla a percentagem de progresso real e as evidências fotográficas ou documentais submetidas pelos técnicos.
5. **`audit_logs` (Logs de Auditoria Corporativa):**
   - Tabela isolada para garantir a conformidade normativa e a responsabilização legal por modificações de dados sensíveis.

---

## ⚡ 4. Mecanismos de Otimização Operacional (Etapa 16)

Para garantir carregamentos instantâneos mesmo sob conexões de dados limitadas em terminais aeroportuários:
- **Lazy Loading de Vistas:** Módulos pesados de BI e administração só são descarregados pelo browser no momento exato de utilização.
- **Indexação Inteligente de Consultas SQL:** Índices aplicados em campos de pesquisa e filtragem frequente (como status, divisão e data de eventos).
- **Compressão de Ativos Estáticos:** Configuração do servidor Nginx e do Express para comprimir ficheiros JS, CSS e imagens usando algoritmos **Gzip/Brotli**, reduzindo em até 80% o tráfego de dados.
