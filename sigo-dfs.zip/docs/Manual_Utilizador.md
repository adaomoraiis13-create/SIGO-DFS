# Manual do Utilizador da Plataforma SIGO-DFS

### SIGO-DFS — Direção de Facilitação e Segurança
**Aeroporto Internacional Dr. António Agostinho Neto (ATO & OC Angola)**

---

## 📅 1. Balanço Diário Operacional

O coração do sistema é a elaboração do **Balanço Diário Operacional**. Este módulo consolida as ocorrências do aeroporto de forma harmonizada.

### Como Elaborar um Balanço:
1. **Aceder ao Módulo:** Clique em "Balanço Operacional" no menu lateral.
2. **Criar Novo Balanço:** O Secretariado ou Administração clica em "Criar Novo Balanço" e define o número identificador e a data do relatório.
3. **Contribuição das Divisões:** Cada chefe de divisão (DOS, DFC, FAL, DRCQ) entra na plataforma, clica em "Editar Secção" do balanço ativo, preenche os dados específicos da sua área de atuação e clica em "Submeter Contribuição".
4. **Validação:** O Secretariado revisa as secções individuais e, quando todas estiverem prontas, muda o estado para "Consolidado".
5. **Assinatura e Aprovação:** O Diretor Geral revisa o balanço consolidado e clica em "Aprovar Balanço". O relatório entra no estado "Aprovado" e fica disponível para exportação oficial em PowerPoint (.pptx) ou PDF.

---

## 🗂️ 2. Gestão Inteligente de Documentos (Gemini AI)

O SIGO-DFS integra uma **Engine de Inteligência de Documentos** baseada no **Gemini 3.5**.

### Carregamento de Relatórios:
- Navegue para o "Upload Center" ou para o painel de "Documentos".
- Arraste ou selecione qualquer ficheiro suportado: PowerPoint (.pptx), PDF, Word (.docx), Excel (.xlsx), imagens (.png, .jpg), ou pacotes comprimidos (.zip).
- Ao realizar o upload do ficheiro real, o sistema organiza-o automaticamente por **Ano / Mês / Divisão / Categoria** em pastas internas estruturadas.

### Extração Automatizada por IA:
- O Gemini lê o conteúdo textual e os slides do PowerPoint.
- **Classificação:** Classifica automaticamente o documento numa categoria operacional (ex: Recursos Humanos, Qualidade, Operações).
- **Extração de Campos:** Extrai termos e valores importantes (como datas de incidentes, gravidade, e responsáveis).
- **Geração de Ações:** Sugere automaticamente a criação de planos de ação corretiva a partir de falhas ou avarias identificadas nos slides!

---

## 📈 3. Planos de Ação Corretiva

Os **Planos de Ação** são utilizados para acompanhar a mitigação de falhas e o controlo de qualidade no aeroporto.

### Fluxo de Trabalho de uma Ação:
- **Estado Pendente:** Criado pelo sistema ou por uma divisão operacional.
- **Estado Em Curso:** Atribuído a um técnico específico. O técnico inicia as atividades corretivas.
- **Evidências:** O responsável clica em "Anexar Evidência", carrega um ficheiro real (ex: uma foto do scanner consertado ou uma planilha) e adiciona comentários.
- **Conclusão:** O técnico envia para validação e, após aprovação do Chefe de Divisão ou do Secretariado, a ação entra no estado "Concluída". O progresso e a percentagem de execução do plano sobem para 100%.

---

## 📊 4. Business Intelligence (BI) e Painéis de Indicadores

A plataforma possui um módulo robusto de **Business Intelligence** que processa os dados de todos os balanços e planos de ação:
- **Painel de KPIs:** Exibe de forma visual o tráfego aéreo, tempos médios de espera em filas, incidentes resolvidos e produtividade por divisão.
- **Gráficos Comparativos:** Compara o desempenho entre as divisões, deteta anomalias e exibe tendências históricas.
- **Relatórios Analíticos:** Relatórios gerados automaticamente pelo sistema que ajudam a Direção a tomar decisões estratégicas mais rápidas e precisas.

---

## 🤖 5. DFS Copilot — O Seu Assistente Inteligente

No canto inferior direito de qualquer tela, ou no menu lateral dedicado, pode aceder ao **DFS Copilot**:
- **O que faz:** Responde a perguntas complexas em Português de Angola com base nos dados reais salvos no sistema.
- **Exemplos de Perguntas:**
  - *"Quais foram os principais incidentes relatados pela DOS no balanço de ontem?"*
  - *"Dá-me um resumo de todas as ações corretivas pendentes com prioridade Alta."*
  - *"Gera uma recomendação operacional para reduzir as filas no check-in baseando-te no último balanço."*
- **Garantia de Confidencialidade:** O Copilot usa os dados institucionais contextuais reais no momento da conversa, garantindo precisão absoluta sem inventar factos (redução total de alucinações).
