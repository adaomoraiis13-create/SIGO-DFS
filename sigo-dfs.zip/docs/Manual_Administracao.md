# Manual de Administração e Segurança do Sistema

### SIGO-DFS — Direção de Facilitação e Segurança
**Aeroporto Internacional Dr. António Agostinho Neto (ATO & OC Angola)**

---

## 🔒 1. Segurança da Informação Integrada (Etapas 5 & 15)

O SIGO-DFS foi concebido sob princípios de **Security by Design** e **DevSecOps** corporativos para proteger informações aeroportuárias sensíveis:

### A. Proteção contra Injeção de Código e Ataques (OWASP Top 10)
- **SQL Injection:** Todas as interações com a base de dados relacional e consultas estruturadas são estritamente parametrizadas, utilizando o driver nativo `pg` com consultas preparadas.
- **Cross-Site Scripting (XSS):** O frontend utiliza o React 19, que por padrão realiza o escaping automático de caracteres perigosos na renderização de dados dinâmicos. Os cabeçalhos de segurança barram execuções não autorizadas.
- **Cross-Site Request Forgery (CSRF):** Todas as comunicações API REST exigem cabeçalhos de autenticação explícitos (`Authorization: Bearer <token>`) ou identificação em sessões ativas exclusivas do remetente, prevenindo requisições forjadas via links externos.
- **Mime Sniffing & MIME Validation:** Os uploads passam por um filtro duplo. O Multer valida a extensão e as assinaturas de ficheiro. No servidor, o cabeçalho `X-Content-Type-Options: nosniff` impede que o browser mude o MIME-type de ficheiros perigosos.

### B. Defesa Proativa e Rate Limiting
A aplicação integra um mecanismo de **Rate Limiting** proativo ao nível do servidor que bloqueia automaticamente IPs que realizem requisições excessivas (brute-force ou scraping):
- **Limite:** Máximo de 300 requisições por minuto por endereço de IP único.
- **Bloqueio:** Resposta HTTP `429 Too Many Requests`.

### C. Autenticação JWT & Refresh Token (Fácil Habilitação)
O sistema suporta autenticação híbrida. Para habilitar sessões JWT de longa duração, defina `JWT_SECRET` no seu ficheiro `.env`. O servidor passará a emitir assinaturas de token criptográficas em cada login bem-sucedido.

---

## 👥 2. Gestão de Perfis de Utilizador e Divisões

O sistema possui 5 cargos institucionais com **Matriz de Permissões** e restrições bem definidas:

1. **Super Administrador (ADMIN):**
   - Acesso total e irrestrito a todas as configurações de segurança, backups, e-mails, logs de auditoria e IA.
2. **Diretor (DIRETOR):**
   - Visualização estratégica consolidada de todas as divisões operacionais.
   - Aprovação final de Balanços Diários.
3. **Secretariado (SECRETARIADO):**
   - Criação, edição, bloqueio e ativação de contas de utilizador.
   - Consolidação inicial de relatórios operacionais.
4. **Chefe de Divisão (DOS / DFC / FAL / DRCQ):**
   - Submissão de relatórios PowerPoint operacionais.
   - Visualização limitada de dados, planos de ação e indicadores de desempenho **exclusivos** da sua respetiva divisão.
5. **Técnico (TECNICO):**
   - Leitura de planos de ação, submissão de evidências operacionais, visualização de notificações.

---

## 📈 3. Auditoria Corporativa e Rastreabilidade

Todas as ações administrativas ou críticas efetuadas na plataforma geram uma entrada indelével nos **Logs de Auditoria**:
- **O que é registado:** Data/Hora, Nome do Utilizador, Cargo/Perfil, Ação Executada, e Detalhe Técnico.
- **Como aceder:** Os logs podem ser consultados diretamente pelo painel administrativo de segurança ou na base de dados relacional na tabela `audit_logs`.

---

## 💾 4. Restauro de Cópias de Segurança (Backup Restore)

Caso ocorra um desastre físico ou corrupção de sistema, siga este procedimento para restaurar os dados:

### Passo 1: Restaurar a Base de Dados PostgreSQL
Pare a aplicação, certifique-se de que o banco está vazio e importe o dump:
```bash
# Limpar banco antigo e restaurar
dropdb -U sigo_admin -h localhost sigo_dfs_prod
createdb -U sigo_admin -h localhost -O sigo_admin sigo_dfs_prod
psql -U sigo_admin -d sigo_dfs_prod -h localhost -f /usr/src/app/backups/sigo_dfs_db_backup_XXXXXXXX.sql
```

### Passo 2: Restaurar a Pasta de Uploads de Ficheiros
```bash
# Apagar diretoria atual de uploads e descomprimir o backup
rm -rf /usr/src/app/uploads/*
tar -xzf /usr/src/app/backups/sigo_dfs_uploads_backup_XXXXXXXX.tar.gz -C /usr/src/app/uploads/
```

### Passo 3: Reiniciar o Servidor
```bash
pm2 restart sigo-dfs # ou: docker compose restart
```
O sistema retornará exatamente ao estado em que se encontrava no momento da realização da cópia de segurança.
