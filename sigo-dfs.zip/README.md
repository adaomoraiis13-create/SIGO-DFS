# SIGO-DFS — Sistema Inteligente de Gestão Operacional

### Direção de Facilitação e Segurança (DFS)
**Aeroporto Internacional Dr. António Agostinho Neto (Luanda, Angola)**

[![Docker Multi-Container Build](https://img.shields.io/badge/Docker-Multi--Container-blue?logo=docker)](/docker-compose.yml)
[![Database Support](https://img.shields.io/badge/Database-PostgreSQL%20%7C%20JSON%20File-green?logo=postgresql)](/database/schema.sql)
[![Model Engine](https://img.shields.io/badge/AI%20Engine-Gemini--3.5--Flash-orange?logo=google-gemini)](/server.ts)
[![Code Standard](https://img.shields.io/badge/Stack-Node.js%20%7C%20React%20%7C%20TypeScript-purple?logo=typescript)](/package.json)

---

## 🌟 Visão Geral

O **SIGO-DFS** é uma plataforma web corporativa de nível empresarial concebida especificamente para a **Direção de Facilitação e Segurança (DFS)** no **Aeroporto Internacional Dr. António Agostinho Neto (ATO & OC)** em Luanda, Angola. 

Este sistema automatiza, integra e audita todos os fluxos de trabalho operacionais, facilitando a elaboração do **Balanço Diário Operacional** entre as quatro divisões operacionais críticas:
- **DOS** (Divisão de Operações de Segurança)
- **DFC** (Divisão de Facilitação Comercial)
- **FAL** (Divisão de Facilitação Geral)
- **DRCQ** (Divisão de Regulamentação e Controlo de Qualidade)

A plataforma possui um **DFS Copilot** integrado que utiliza o modelo **Gemini 3.5** para processamento inteligente de documentos PowerPoint (.pptx), PDF, Word, geração de relatórios estratégicos e monitorização em tempo real de planos de ação corretiva.

---

## 📁 Estrutura Profissional de Diretórios (Etapa 3)

O projeto está totalmente estruturado para produção e independente de qualquer IDE ou estúdio externo:

```text
SIGO-DFS/
├── .github/                  # Workflows de CI/CD para GitHub Actions
├── database/                 # Migrações e esquemas relacionais PostgreSQL
│   ├── schema.sql            # Esquema DDL do banco relacional de produção
│   └── seed.sql              # Dados iniciais para inicialização rápida
├── docs/                     # Manuais técnicos e de utilização corporativa
│   ├── Manual_Instalacao.md  # Instruções detalhadas de setup (Docker/Nativo)
│   ├── Manual_Administracao.md # Manual de permissões, logs e backups
│   ├── Manual_Utilizador.md  # Guia operacional ilustrado para operadores
│   └── Arquitetura_Relatorio.md # Relatório técnico de engenharia de software
├── data/                     # Estado persistente local (Fallback de ficheiro)
│   └── sigo-dfs.json         # Base de dados em formato JSON (auto-criada)
├── uploads/                  # Diretório estruturado de armazenamento de ficheiros
│   └── [Ano]/[Mês]/[Divisão]/[Categoria]/v1_[timestamp]_[nome_limpo]
├── scripts/                  # Scripts DevOps automatizados
│   ├── backup.sh             # Backup automático de uploads e base de dados
│   └── deploy_cloud_run.sh   # Script de automação de Deploy no Google Cloud Run
├── tests/                    # Suite de testes corporativos
│   └── test_suite.js         # Testes unitários, de segurança e desempenho
├── src/                      # Código-Fonte da Aplicação (Frontend e Servidor)
│   ├── components/           # Componentes Visuais React 19 / Tailwind CSS
│   ├── services/             # Lógica de integração com APIs e inteligência
│   ├── App.tsx               # Controlador principal de vistas do Frontend
│   └── types.ts              # Definições estritas de interfaces TypeScript
├── Dockerfile                # Dockerfile multistage otimizado
├── docker-compose.yml        # Orquestração local do App + PostgreSQL
├── .env.example              # Modelo de variáveis de ambiente
├── package.json              # Gestor de dependências do ecossistema Node.js
└── vite.config.ts            # Configurações de compilação rápida do Vite
```

---

## 🚀 Instalação Rápida (Apenas 1 Comando)

Garante que tens o **Docker** e o **Docker Compose** instalados na tua máquina/servidor.

1. **Clonar ou Descompactar** o projeto no teu servidor institucional.
2. Criar o ficheiro `.env` a partir do modelo e adicionar a sua chave institucional Gemini:
   ```bash
   cp .env.example .env
   ```
3. Executar o comando mágico de infraestrutura:
   ```bash
   docker compose up -d --build
   ```

A plataforma estará imediatamente disponível e operacional através de:
- **URL:** [http://localhost:3000](http://localhost:3000)
- **Base de Dados:** PostgreSQL a rodar de forma isolada na porta `5432` com persistência de volumes.

---

## 🔐 Contas de Acesso Padrão (Seed)

A base de dados é inicializada automaticamente com as seguintes credenciais institucionais seguras para facilitação de testes corporativos:

| Perfil de Acesso | Nome do Operador | Nome de Utilizador | Palavra-passe |
| :--- | :--- | :--- | :--- |
| **Super Administrador** | Super Administrador | `admin` | `admin123` |
| **Diretor Geral** | Dr. Valdemar Neto | `diretor` | `diretor123` |
| **Secretariado** | Maria Antónia Santos | `secretaria` | `secretaria123` |
| **Chefe de Divisão (DOS)** | Eng. António Bunga | `chefe.dos` | `dos123` |
| **Chefe de Divisão (DFC)** | Dra. Isabel Cassule | `chefe.dfc` | `dfc123` |
| **Chefe de Divisão (FAL)** | Dr. Manuel Mendes | `chefe.fal` | `fal123` |
| **Chefe de Divisão (DRCQ)** | Eng. Sofia Martins | `chefe.drcq` | `drcq123` |

---

## 📚 Documentação Técnica Adicional (Etapa 18)

Para guias profundos sobre o sistema, consulte os manuais dedicados na diretoria `/docs`:
- **[Manual de Instalação e Deploy](/docs/Manual_Instalacao.md)**: Configurações do Google Cloud, Vercel, Railway, HTTPS, Let's Encrypt SSL e DNS institutional.
- **[Manual de Administração](/docs/Manual_Administracao.md)**: Logs de auditoria corporativa, rate-limiting, rate-throttling, controlo de segurança, JWT, e recuperação de dados.
- **[Manual do Utilizador](/docs/Manual_Utilizador.md)**: Processamento de ficheiros PowerPoint, acompanhamento de Planos de Ação, extração por IA e BI integrado.
- **[Relatório de Arquitetura e Engenharia](/docs/Arquitetura_Relatorio.md)**: Modelagem relacional detalhada, fluxograma de processos, e segurança de informação contra injeções.

---

## 📄 Licença e Termos Corporativos
Este software foi desenvolvido de forma independente para utilização institucional pela **Direção de Facilitação e Segurança**. O código é confidencial e propriedade intelectual da organização aeroportuária.
