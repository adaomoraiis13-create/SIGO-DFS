// Compatibility guard to prevent crashes when external/iframe/extension scripts attempt to override window.fetch
try {
  var originalFetch = window.fetch;
  var currentFetch = originalFetch;
  Object.defineProperty(window, 'fetch', {
    configurable: true,
    enumerable: true,
    get: function() {
      return currentFetch;
    },
    set: function(val) {
      currentFetch = val;
    }
  });
} catch (e) {
  console.warn("Fetch compatibility guard: unable to redefine window.fetch in module", e);
}

// Supplementary safety layer for benign WebSocket/Vite errors
try {
  const originalError = console.error;
  console.error = function(...args) {
    const joined = args.map(a => String(a)).join(' ');
    if (joined.includes('failed to connect to websocket') || 
        joined.includes('WebSocket connection') || 
        joined.includes('WebSocket closed') ||
        joined.includes('[vite]')) {
      return;
    }
    originalError.apply(console, args);
  };

  const originalWarn = console.warn;
  console.warn = function(...args) {
    const joined = args.map(a => String(a)).join(' ');
    if (joined.includes('failed to connect to websocket') || 
        joined.includes('WebSocket connection') || 
        joined.includes('WebSocket closed') ||
        joined.includes('[vite]')) {
      return;
    }
    originalWarn.apply(console, args);
  };

  window.addEventListener('unhandledrejection', function(event) {
    const reason = event.reason;
    if (reason) {
      const msg = String(reason.message || reason);
      if (msg.includes('WebSocket') || msg.includes('websocket') || msg.includes('vite') || msg.includes('Vite')) {
        event.preventDefault();
        event.stopImmediatePropagation();
      }
    }
  }, true);

  window.addEventListener('error', function(event) {
    const msg = String(event.message || '');
    if (msg.includes('WebSocket') || msg.includes('websocket') || msg.includes('vite') || msg.includes('Vite')) {
      event.preventDefault();
      event.stopImmediatePropagation();
    }
  }, true);
} catch (e) {
  console.warn("Could not register supplementary error listeners", e);
}

import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
