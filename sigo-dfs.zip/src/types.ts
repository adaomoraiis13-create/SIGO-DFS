/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum UserRole {
  ADMIN = 'ADMIN',
  DIRETOR = 'DIRETOR',
  SECRETARIADO = 'SECRETARIADO',
  CHEFE_DIVISAO = 'CHEFE_DIVISAO',
}

export enum DivisionId {
  DFS = 'DFS', // General DFS
  DOS = 'DOS', // Divisão de Operações e Segurança
  DFC = 'DFC', // Divisão de Facilitação e Controle
  FAL = 'FAL', // Divisão de Facilitação / Regulamentação
  DRCQ = 'DRCQ', // Divisão de Regulação, Conformidade e Qualidade
}

export interface User {
  id: string;
  username: string;
  name: string;
  role: UserRole;
  divisionId: DivisionId;
  email: string;
  phone?: string;
  position?: string;
  status?: 'Pendente de Aprovação' | 'Ativa' | 'Suspensa' | 'Desativada';
}

export enum BalanceStatus {
  EM_ELABORACAO = 'EM_ELABORACAO',
  AGUARDANDO_CONTRIBUICOES = 'AGUARDANDO_CONTRIBUICOES',
  EM_REVISAO = 'EM_REVISAO', // Equates to "Aguardando aprovação / Em revisão"
  APROVADO = 'APROVADO', // Equates to "Concluído / Aprovado"
  CORRECAO_SOLICITADA = 'CORRECAO_SOLICITADA',
  ARQUIVADO = 'ARQUIVADO',
}

export enum DivisionContributionStatus {
  NAO_INICIADO = 'NAO_INICIADO',
  EM_ELABORACAO = 'EM_ELABORACAO',
  DOCUMENTO_ENVIADO = 'DOCUMENTO_ENVIADO',
  EM_VALIDACAO = 'EM_VALIDACAO',
  CORRIGIR_DOCUMENTO = 'CORRIGIR_DOCUMENTO',
  VALIDADO = 'VALIDADO'
}

export interface DivisionContribution {
  id: string;
  balanceId: string;
  divisaoId: DivisionId;
  estado: DivisionContributionStatus;
  observacoes?: string;
  enviadoPor?: string;
  enviadoEm?: string;
}

export interface DosSection {
  ocorrenciasSeguranca: string;
  estadoPistaTaxiways: string;
  atividadesFauna: string;
  statusTerminaisEquipamentos: string;
  incidentesRelatados: string;
}

export interface DfcSection {
  controleFronteiras: string;
  reclamacoesBagagens: string;
  filasCheckIn: string;
  tempoEsperaSeguranca: string;
  incidentesFacilitacao: string;
}

export interface FalSection {
  acessibilidadePMR: string; // Passageiros com Mobilidade Reduzida
  conformidadeNormativa: string;
  assistenciaMedica: string;
  feedbackPassageiros: string;
}

export interface DrcqSection {
  auditoriasInspecoes: string;
  naoConformidadesDetetadas: string;
  avaliacaoRiscoOperacional: string;
  acoesPreventivasRecomendadas: string;
}

export interface OperationalBalance {
  id: string;
  numero: string; // e.g. BAL-2026-0001
  data: string; // YYYY-MM-DD
  hora: string; // HH:MM
  criadoPor: string; // Nome do utilizador
  estado: BalanceStatus;
  resumoGeral: string;
  observacoes: string; // Observações Gerais de criação
  
  // Division-specific data sections
  dos: DosSection;
  dfc: DfcSection;
  fal: FalSection;
  drcq: DrcqSection;
  
  contribuicoes?: DivisionContribution[]; // Four independent areas
  
  dataCriacao: string;
  dataAtualizacao: string;
  revisadoPor?: string;
  aprovadoPor?: string;
  comentariosRevisao?: string;
}

export enum DocType {
  PPTX = 'PPTX',
  PDF = 'PDF',
  DOCX = 'DOCX',
  XLSX = 'XLSX',
  OUTRO = 'OUTRO',
}

export interface Documento {
  id: string;
  nome: string;
  tipo: DocType;
  divisaoId: DivisionId;
  dataCarregamento: string;
  carregadoPor: string;
  tamanho: string; // e.g. "2.4 MB"
  url: string;
  balanceId?: string; // associado a um balanço específico (opcional)
  versao: number; // e.g. 1, 2, 3
  observacoes?: string;
  parentDocId?: string; // pointer for grouping versions
  isCurrent?: boolean; // to filter active vs previous versions
}

export enum ActionPlanStatus {
  PENDENTE = 'Não Iniciada',
  EM_PLANEAMENTO = 'Em Planeamento',
  EM_CURSO = 'Em Curso',
  SUSPENSA = 'Suspensa',
  CONCLUIDO = 'Concluída',
  CANCELADA = 'Cancelada',
  EM_ATRASO = 'Em Atraso',
}

export enum ActionPlanPriority {
  BAIXA = 'Baixa',
  MEDIA = 'Média',
  ALTA = 'Alta',
  CRITICA = 'Crítica',
}

export interface ActionPlanHistory {
  id: string;
  planoId: string;
  campo: string;
  valorAnterior: string;
  valorNovo: string;
  utilizador: string;
  dataHora: string;
}

export interface ActionPlanComment {
  id: string;
  planoId: string;
  comentario: string;
  utilizador: string;
  dataHora: string;
}

export interface ActionPlanEvidence {
  id: string;
  planoId: string;
  ficheiro: string;
  tipo: string;
  utilizador: string;
  dataHora: string;
}

export interface ActionPlanItem {
  id: string;
  codigo?: string;
  titulo: string;
  descricao: string;
  categoria?: string;
  divisaoId: DivisionId;
  responsavel: string;
  prioridade?: ActionPlanPriority;
  estado: ActionPlanStatus;
  progresso?: number; // 0 to 100
  dataCriacao?: string;
  dataInicio?: string;
  dataLimite: string; // prazo
  dataConclusao?: string;
  observacoes?: string;
  notasExecucao?: string; // for backward compatibility
  balanceId?: string;
  percentagemExecucao?: number; // for backward compatibility
  historico?: ActionPlanHistory[];
  comentarios?: ActionPlanComment[];
  evidencias?: ActionPlanEvidence[];
}

export interface WorkflowLog {
  id: string;
  balanceId: string;
  data: string;
  utilizador: string;
  deEstado: BalanceStatus;
  paraEstado: BalanceStatus;
  comentario: string;
}

export interface Notification {
  id: string;
  utilizadorId?: string; // se undefined, é global ou para todos
  divisaoId?: DivisionId; // opcional se para uma divisão específica
  role?: UserRole; // opcional se para um perfil específico
  titulo: string;
  mensagem: string;
  lida: boolean;
  dataCriacao: string;
  link?: string;
}

export interface AuditLog {
  id: string;
  utilizador: string;
  perfil: string;
  acao: string;
  detalhe: string;
  data: string;
}

export enum ProcessStatus {
  PENDENTE = 'PENDENTE',
  EM_PROCESSAMENTO = 'EM_PROCESSAMENTO',
  CONCLUIDO = 'CONCLUIDO',
  ERRO = 'ERRO',
}

export enum DocumentCategory {
  OPERACOES = 'Operações',
  SEGURANCA = 'Segurança',
  FACILITACAO = 'Facilitação',
  RECURSOS_HUMANOS = 'Recursos Humanos',
  RECURSOS_MATERIAIS = 'Recursos Materiais',
  CREDENCIAMENTO = 'Credenciamento',
  FORMACAO = 'Formação',
  PLANO_DE_ACAO = 'Plano de Ação',
  INDICADORES = 'Indicadores',
  CORRESPONDENCIA = 'Correspondência',
  OUTROS = 'Outros',
}

export interface DocumentoProcessado {
  id: string;
  documentoId: string; // Relaciona com Documento
  nomeDocumento: string; // Para busca rápida
  tipo: DocType;
  divisaoId: DivisionId;
  dataProcessamento: string;
  estado: ProcessStatus;
  totalSlides?: number;
  totalPaginas?: number;
  totalFolhas?: number; // Para Excel
  totalLinhas?: number; // Para Excel/Word
  categoria: DocumentCategory;
  erro?: string;
  metadados: {
    autor: string;
    dataCriacao: string;
    dataModificacao: string;
    tamanhoOriginal: string;
  };
  validado: boolean;
  aprovado: boolean;
  validadoPor?: string;
  validadoEm?: string;
}

export interface Slide {
  id: string;
  documentoProcessadoId: string;
  numero: number;
  titulo: string;
  subtitulo: string;
  conteudoTextual: string; // Todo o texto corrido
  temImagens: boolean;
  totalImagens: number;
  temGraficos: boolean;
  totalGraficos: number;
  notasApresentador?: string;
}

export interface CampoExtraido {
  id: string;
  documentoProcessadoId: string;
  slideId?: string; // Se aplicável (PPTX)
  paginaNumero?: number; // Se aplicável (PDF/Word)
  folhaNome?: string; // Se aplicável (Excel)
  nome: string;
  valor: string;
  categoria: string; // Secção reconhecida (ex: "Ocorrências", "Recursos Humanos")
  confianca: number; // 0 a 100
  validado: boolean;
}

export interface CategoriaDocumento {
  id: string;
  nome: DocumentCategory;
  descricao: string;
}

export interface PesquisaIndexada {
  id: string;
  documentoId: string;
  documentoProcessadoId: string;
  palavra: string; // Termo individual ou frase curta
  divisaoId: DivisionId;
  categoria: DocumentCategory;
  tipoDocumento: DocType;
  dataProcessamento: string;
  contexto: string; // Frase onde aparece
}

export interface DuplicateEventItem {
  fieldId: string;
  docId: string;
  divisaoId: DivisionId;
  nome: string;
  valor: string;
}

export interface DuplicateEventGroup {
  id: string;
  balanceId: string;
  campoReferencia: string;
  camposEnvolvidos: DuplicateEventItem[];
  estado: 'PENDENTE' | 'CONFIRMADO' | 'DESCARTADO';
  resolvidoPor?: string;
  resolvidoEm?: string;
}

// Business Intelligence Entities
export interface KPI {
  id: string;
  nome: string;
  categoria: string;
  valor: number;
  unidade: string;
  data: string;
}

export interface DashboardConfig {
  id: string;
  utilizador: string;
  configuracao: string; // JSON configuration
}

export interface RelatorioAnalitico {
  id: string;
  tipo: string; // "Diário" | "Semanal" | "Mensal" | "Trimestral" | "Anual"
  periodo: string; // Ex: "Julho 2026"
  gerado_por: string;
  data: string;
}

export interface Estatistica {
  id: string;
  categoria: string;
  indicador: string;
  valor: number;
  data: string;
}

// AI Copilot Entities
export interface ConversaIA {
  id: string;
  utilizador_id: string;
  data_inicio: string;
  data_fim?: string;
  modelo_utilizado: string;
}

export interface MensagemIA {
  id: string;
  conversa_id: string;
  tipo: 'utilizador' | 'assistente';
  conteudo: string;
  data_hora: string;
  referencias?: {
    documento?: string;
    pagina_slide?: string;
    data?: string;
    relevancia?: number;
  }[];
}

export interface ConfiguracaoIA {
  id: string;
  modelo: string;
  idioma: string;
  temperatura: number;
  limite_tokens: number;
  ativo: boolean;
}

export interface SugestaoIA {
  id: string;
  categoria: string;
  descricao: string;
  prioridade: 'Alta' | 'Média' | 'Baixa';
  data_criacao: string;
}


