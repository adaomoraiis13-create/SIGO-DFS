import { 
  User, 
  OperationalBalance, 
  Documento, 
  ActionPlanItem, 
  WorkflowLog, 
  Notification, 
  AuditLog, 
  BalanceStatus,
  ActionPlanStatus,
  DocumentoProcessado,
  Slide,
  CampoExtraido,
  PesquisaIndexada,
  DocumentCategory,
  DuplicateEventGroup
} from '../types.js';

const BASE_URL = ''; // Relative to support proxying

export async function login(username: string, password: string): Promise<User> {
  const res = await fetch(`${BASE_URL}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password })
  });
  if (!res.ok) {
    const data = await res.json();
    throw new Error(data.error || 'Falha na autenticação.');
  }
  const data = await res.json();
  return data.user;
}

export async function fetchUsers(): Promise<User[]> {
  const res = await fetch(`${BASE_URL}/api/users`);
  if (!res.ok) throw new Error('Falha ao obter utilizadores.');
  return res.json();
}

export async function fetchBalances(): Promise<OperationalBalance[]> {
  const res = await fetch(`${BASE_URL}/api/balances`);
  if (!res.ok) throw new Error('Falha ao obter balanços.');
  return res.json();
}

export async function fetchBalanceById(id: string): Promise<OperationalBalance> {
  const res = await fetch(`${BASE_URL}/api/balances/${id}`);
  if (!res.ok) throw new Error('Falha ao obter balanço operacional.');
  return res.json();
}

export async function createBalance(user: User, balanceData: Partial<OperationalBalance>): Promise<OperationalBalance> {
  const res = await fetch(`${BASE_URL}/api/balances`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ user, balanceData })
  });
  if (!res.ok) throw new Error('Falha ao criar balanço operacional.');
  return res.json();
}

export async function updateBalance(user: User, id: string, updates: Partial<OperationalBalance>): Promise<OperationalBalance> {
  const res = await fetch(`${BASE_URL}/api/balances/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ user, updates })
  });
  if (!res.ok) throw new Error('Falha ao atualizar balanço operacional.');
  return res.json();
}

export async function submitWorkflow(user: User, id: string, nextStatus: BalanceStatus, comment?: string): Promise<OperationalBalance> {
  const res = await fetch(`${BASE_URL}/api/balances/${id}/workflow`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ user, nextStatus, comment })
  });
  if (!res.ok) throw new Error('Falha ao processar fluxo de aprovação.');
  return res.json();
}

export async function fetchActionPlans(): Promise<ActionPlanItem[]> {
  const res = await fetch(`${BASE_URL}/api/action-plans`);
  if (!res.ok) throw new Error('Falha ao obter plano de ação.');
  return res.json();
}

export async function createActionPlan(user: User, item: Partial<ActionPlanItem>): Promise<ActionPlanItem> {
  const res = await fetch(`${BASE_URL}/api/action-plans`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ user, item })
  });
  if (!res.ok) throw new Error('Falha ao registar ação corretiva.');
  return res.json();
}

export async function updateActionPlan(user: User, id: string, updates: Partial<ActionPlanItem>): Promise<ActionPlanItem> {
  const res = await fetch(`${BASE_URL}/api/action-plans/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ user, updates })
  });
  if (!res.ok) throw new Error('Falha ao atualizar ação corretiva.');
  return res.json();
}

export async function deleteActionPlan(user: User, id: string): Promise<boolean> {
  const res = await fetch(`${BASE_URL}/api/action-plans/${id}?user=${encodeURIComponent(JSON.stringify(user))}`, {
    method: 'DELETE',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ user })
  });
  if (!res.ok) throw new Error('Falha ao eliminar ação corretiva.');
  return true;
}

export async function addActionPlanComment(user: User, id: string, comment: string): Promise<ActionPlanItem> {
  const res = await fetch(`${BASE_URL}/api/action-plans/${id}/comments`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ user, comment })
  });
  if (!res.ok) throw new Error('Falha ao adicionar comentário.');
  return res.json();
}

export async function addActionPlanEvidence(user: User, id: string, file: string, type: string): Promise<ActionPlanItem> {
  const res = await fetch(`${BASE_URL}/api/action-plans/${id}/evidences`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ user, file, type })
  });
  if (!res.ok) throw new Error('Falha ao anexar evidência.');
  return res.json();
}

export async function fetchDocuments(): Promise<Documento[]> {
  const res = await fetch(`${BASE_URL}/api/documents`);
  if (!res.ok) throw new Error('Falha ao obter documentos.');
  return res.json();
}

export async function createDocument(user: User, doc: Partial<Documento>): Promise<Documento> {
  const res = await fetch(`${BASE_URL}/api/documents`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ user, doc })
  });
  if (!res.ok) throw new Error('Falha ao registar documento.');
  return res.json();
}

export async function deleteDocument(user: User, id: string): Promise<boolean> {
  const res = await fetch(`${BASE_URL}/api/documents/${id}`, {
    method: 'DELETE',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ user })
  });
  if (!res.ok) throw new Error('Falha ao eliminar documento.');
  return true;
}

export async function fetchWorkflowLogs(balanceId: string): Promise<WorkflowLog[]> {
  const res = await fetch(`${BASE_URL}/api/workflow-logs/${balanceId}`);
  if (!res.ok) throw new Error('Falha ao obter histórico de workflow.');
  return res.json();
}

export async function fetchNotifications(): Promise<Notification[]> {
  const res = await fetch(`${BASE_URL}/api/notifications`);
  if (!res.ok) throw new Error('Falha ao obter notificações.');
  return res.json();
}

export async function markNotificationAsRead(id: string): Promise<boolean> {
  const res = await fetch(`${BASE_URL}/api/notifications/${id}/read`, { method: 'POST' });
  if (!res.ok) throw new Error('Falha ao marcar notificação como lida.');
  return true;
}

export async function markAllNotificationsAsRead(): Promise<boolean> {
  const res = await fetch(`${BASE_URL}/api/notifications/read-all`, { method: 'POST' });
  if (!res.ok) throw new Error('Falha ao marcar notificações como lidas.');
  return true;
}

export async function fetchAuditLogs(): Promise<AuditLog[]> {
  const res = await fetch(`${BASE_URL}/api/audit-logs`);
  if (!res.ok) throw new Error('Falha ao obter registos de auditoria.');
  return res.json();
}

export async function restoreDocumentVersion(user: User, docId: string): Promise<Documento> {
  const res = await fetch(`${BASE_URL}/api/documents/${docId}/restore`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ user })
  });
  if (!res.ok) throw new Error('Falha ao restaurar versão do documento.');
  return res.json();
}

export async function updateContributionStatus(
  user: User,
  balanceId: string,
  divisaoId: string,
  estado: string,
  observacoes?: string
): Promise<OperationalBalance> {
  const res = await fetch(`${BASE_URL}/api/balances/${balanceId}/contribution`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ user, divisaoId, estado, observacoes })
  });
  if (!res.ok) throw new Error('Falha ao atualizar estado da contribuição.');
  return res.json();
}

export async function fetchProcessedDocuments(user: User): Promise<DocumentoProcessado[]> {
  const res = await fetch(`${BASE_URL}/api/processed-documents?role=${user.role}&divisionId=${user.divisionId || ''}`);
  if (!res.ok) throw new Error('Falha ao obter documentos processados.');
  return res.json();
}

export async function fetchProcessedDocumentDetails(id: string): Promise<{
  processedDoc: DocumentoProcessado;
  slides: Slide[];
  extractedFields: CampoExtraido[];
}> {
  const res = await fetch(`${BASE_URL}/api/processed-documents/${id}`);
  if (!res.ok) throw new Error('Falha ao obter detalhes do processamento.');
  return res.json();
}

export async function updateProcessedCategory(user: User, id: string, category: DocumentCategory): Promise<DocumentoProcessado> {
  const res = await fetch(`${BASE_URL}/api/processed-documents/${id}/category`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ user, category })
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Falha ao corrigir classificação.');
  }
  return res.json();
}

export async function approveProcessedDocument(user: User, id: string, approved: boolean): Promise<DocumentoProcessado> {
  const res = await fetch(`${BASE_URL}/api/processed-documents/${id}/approve`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ user, approved })
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Falha ao submeter aprovação de resultados.');
  }
  return res.json();
}

export async function reprocessDocument(user: User, id: string): Promise<DocumentoProcessado> {
  const res = await fetch(`${BASE_URL}/api/processed-documents/${id}/reprocess`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ user })
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Falha ao reprocessar documento.');
  }
  return res.json();
}

export async function validateExtractedField(user: User, id: string, validado: boolean): Promise<CampoExtraido> {
  const res = await fetch(`${BASE_URL}/api/extracted-fields/${id}/validate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ user, validado })
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Falha ao validar campo extraído.');
  }
  return res.json();
}

export async function searchIndexed(
  query: string,
  filters?: { divisaoId?: string; categoria?: string; tipoDoc?: string; balanceId?: string }
): Promise<PesquisaIndexada[]> {
  const params = new URLSearchParams();
  params.append('query', query);
  if (filters?.divisaoId) params.append('divisaoId', filters.divisaoId);
  if (filters?.categoria) params.append('categoria', filters.categoria);
  if (filters?.tipoDoc) params.append('tipoDoc', filters.tipoDoc);
  if (filters?.balanceId) params.append('balanceId', filters.balanceId);

  const res = await fetch(`${BASE_URL}/api/indexed-search?${params.toString()}`);
  if (!res.ok) throw new Error('Falha na pesquisa indexada.');
  return res.json();
}

export async function fetchBalanceDuplicates(balanceId: string): Promise<DuplicateEventGroup[]> {
  const res = await fetch(`${BASE_URL}/api/balances/${balanceId}/duplicates`);
  if (!res.ok) throw new Error('Falha ao obter duplicações.');
  return res.json();
}

export async function resolveDuplicateGroup(user: User, groupId: string, estado: 'CONFIRMADO' | 'DESCARTADO'): Promise<DuplicateEventGroup> {
  const res = await fetch(`${BASE_URL}/api/duplicate-groups/${groupId}/resolve`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ user, estado })
  });
  if (!res.ok) throw new Error('Falha ao resolver duplicação.');
  return res.json();
}

export async function consolidateBalance(user: User, balanceId: string): Promise<OperationalBalance> {
  const res = await fetch(`${BASE_URL}/api/balances/${balanceId}/consolidate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ user })
  });
  if (!res.ok) {
    const data = await res.json();
    throw new Error(data.error || 'Falha ao consolidar balanço.');
  }
  return res.json();
}

export async function signup(userData: any): Promise<{ success: boolean; user: User }> {
  const res = await fetch(`${BASE_URL}/api/auth/signup`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(userData)
  });
  if (!res.ok) {
    const data = await res.json();
    throw new Error(data.error || 'Falha ao criar conta.');
  }
  return res.json();
}

export async function recoverPassword(email: string): Promise<{ success: boolean; message: string }> {
  const res = await fetch(`${BASE_URL}/api/auth/recover`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email })
  });
  if (!res.ok) {
    const data = await res.json();
    throw new Error(data.error || 'Falha ao recuperar palavra-passe.');
  }
  return res.json();
}

export async function resetPassword(email: string, password: string): Promise<{ success: boolean; message: string }> {
  const res = await fetch(`${BASE_URL}/api/auth/reset-password`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password })
  });
  if (!res.ok) {
    const data = await res.json();
    throw new Error(data.error || 'Falha ao redefinir palavra-passe.');
  }
  return res.json();
}

export async function fetchSettings(): Promise<any> {
  const res = await fetch(`${BASE_URL}/api/settings`);
  if (!res.ok) throw new Error('Falha ao obter configurações.');
  return res.json();
}

export async function updateSettings(settings: any): Promise<any> {
  const res = await fetch(`${BASE_URL}/api/settings`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ settings })
  });
  if (!res.ok) throw new Error('Falha ao atualizar configurações.');
  return res.json();
}

export async function fetchSessions(): Promise<any[]> {
  const res = await fetch(`${BASE_URL}/api/sessions`);
  if (!res.ok) throw new Error('Falha ao obter sessões ativas.');
  return res.json();
}

export async function terminateSession(id: string): Promise<boolean> {
  const res = await fetch(`${BASE_URL}/api/sessions/${id}`, {
    method: 'DELETE'
  });
  if (!res.ok) throw new Error('Falha ao encerrar sessão.');
  return true;
}

export async function createUser(userData: any): Promise<User> {
  const res = await fetch(`${BASE_URL}/api/users`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(userData)
  });
  if (!res.ok) {
    const data = await res.json();
    throw new Error(data.error || 'Falha ao criar utilizador.');
  }
  return res.json();
}

export async function updateUser(id: string, updates: any): Promise<User> {
  const res = await fetch(`${BASE_URL}/api/users/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(updates)
  });
  if (!res.ok) {
    const data = await res.json();
    throw new Error(data.error || 'Falha ao atualizar utilizador.');
  }
  return res.json();
}

export async function deleteUser(id: string): Promise<boolean> {
  const res = await fetch(`${BASE_URL}/api/users/${id}`, {
    method: 'DELETE'
  });
  if (!res.ok) throw new Error('Falha ao eliminar utilizador.');
  return true;
}
