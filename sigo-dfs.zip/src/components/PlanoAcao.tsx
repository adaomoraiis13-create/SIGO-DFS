import React, { useState } from 'react';
import { 
  CheckSquare, 
  Plus, 
  Calendar, 
  User, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  Filter, 
  AlertTriangle,
  Play,
  Briefcase,
  FileUp
} from 'lucide-react';
import { 
  User as UserType, 
  UserRole, 
  DivisionId, 
  ActionPlanItem, 
  ActionPlanStatus 
} from '../types.js';
import * as api from '../services/api.js';
import UploadCenterModal from './UploadCenterModal.js';

interface PlanoAcaoProps {
  user: UserType;
  actionPlans: ActionPlanItem[];
  onRefresh: () => void;
}

export default function PlanoAcao({ user, actionPlans, onRefresh }: PlanoAcaoProps) {
  const [isCreating, setIsCreating] = useState(false);
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [divisionFilter, setDivisionFilter] = useState<string>('ALL');

  // Form state
  const [titulo, setTitulo] = useState('');
  const [descricao, setDescricao] = useState('');
  const [divisaoId, setDivisaoId] = useState<DivisionId>(DivisionId.DOS);
  const [responsavel, setResponsavel] = useState('');
  const [dataLimite, setDataLimite] = useState('');

  const filteredItems = actionPlans.filter(item => {
    const matchesStatus = statusFilter === 'ALL' || item.estado === statusFilter;
    const matchesDivision = divisionFilter === 'ALL' || item.divisaoId === divisionFilter;
    return matchesStatus && matchesDivision;
  });

  const handleCreateAction = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    try {
      await api.createActionPlan(user, {
        titulo,
        descricao,
        divisaoId,
        responsavel,
        dataLimite,
        estado: ActionPlanStatus.PENDENTE
      });

      setSuccess('Nova ação corretiva registada com sucesso!');
      setIsCreating(false);
      setTitulo('');
      setDescricao('');
      setResponsavel('');
      setDataLimite('');
      onRefresh();
    } catch (err: any) {
      setError(err.message || 'Erro ao registar a ação.');
    }
  };

  const handleUpdateStatus = async (id: string, newStatus: ActionPlanStatus) => {
    setError(null);
    setSuccess(null);

    try {
      await api.updateActionPlan(user, id, { estado: newStatus });
      setSuccess('Estado da ação corretiva atualizado!');
      onRefresh();
    } catch (err: any) {
      setError(err.message || 'Erro ao atualizar a ação.');
    }
  };

  // Check if current user is authorized to manage the status of a specific item (either Admin, Secretariat, or the Chief of that specific division)
  const canUpdateItemStatus = (item: ActionPlanItem) => {
    if (user.role === UserRole.ADMIN || user.role === UserRole.SECRETARIADO) return true;
    if (user.role === UserRole.CHEFE_DIVISAO && user.divisionId === item.divisaoId) return true;
    return false;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="space-y-1">
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Plano de Ações Corretivas DFS</h1>
          <p className="text-slate-500 text-sm">Monitore, atribua e resolva as pendências de conformidade e segurança da Direção.</p>
        </div>

        {/* Actions Button Group */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Permanent Upload Button */}
          <button
            onClick={() => setIsUploadOpen(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-black text-slate-800 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg shadow-xs transition-colors uppercase tracking-wider cursor-pointer"
          >
            <FileUp className="w-4 h-4 text-orange-600" /> Carregar Documento
          </button>

          {/* Create action plan button (Secretariat & Admin only) */}
          {(user.role === UserRole.SECRETARIADO || user.role === UserRole.ADMIN) && (
            <button
              onClick={() => setIsCreating(!isCreating)}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-lg shadow-sm border border-sky-700 transition-colors"
            >
              <Plus className="w-4 h-4" /> Registar Nova Ação
            </button>
          )}
        </div>
      </div>

      {/* FEEDBACK FEED */}
      {error && (
        <div className="bg-rose-50 border border-rose-200 text-rose-800 p-4 rounded-xl flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
          <div className="text-sm">
            <span className="font-bold">Aviso:</span> {error}
          </div>
        </div>
      )}

      {success && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded-xl flex items-start gap-3">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
          <div className="text-sm">
            <span className="font-bold">Sucesso:</span> {success}
          </div>
        </div>
      )}

      {/* ACTION CREATION CARD */}
      {isCreating && (
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-md space-y-4">
          <h3 className="font-bold text-slate-800 text-sm border-b border-slate-50 pb-2.5 flex items-center gap-2">
            <CheckSquare className="w-5 h-5 text-sky-600" /> Registar Nova Ação Corretiva
          </h3>

          <form onSubmit={handleCreateAction} className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-1.5 md:col-span-2">
              <label className="text-xs font-bold text-slate-600 uppercase">Título Curto da Ação</label>
              <input 
                type="text"
                placeholder="Ex: Reforço de sinalização, reparação do elevador, etc..."
                value={titulo}
                onChange={(e) => setTitulo(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500/20"
                required
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-600 uppercase">Divisão Responsável</label>
              <select 
                value={divisaoId}
                onChange={(e) => setDivisaoId(e.target.value as DivisionId)}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500/20"
              >
                <option value={DivisionId.DOS}>DOS (Operações)</option>
                <option value={DivisionId.DFC}>DFC (Facilitação)</option>
                <option value={DivisionId.FAL}>FAL (Regulamentação)</option>
                <option value={DivisionId.DRCQ}>DRCQ (Qualidade)</option>
              </select>
            </div>

            <div className="space-y-1.5 md:col-span-3">
              <label className="text-xs font-bold text-slate-600 uppercase">Descrição Detalhada e Causas</label>
              <textarea 
                rows={2}
                placeholder="Introduza detalhes operacionais sobre a não-conformidade e as ações de correção necessárias..."
                value={descricao}
                onChange={(e) => setDescricao(e.target.value)}
                className="w-full p-2.5 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500/20"
                required
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-600 uppercase">Técnico / Responsável</label>
              <input 
                type="text"
                placeholder="Ex: Eng. António Bunga"
                value={responsavel}
                onChange={(e) => setResponsavel(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500/20"
                required
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-600 uppercase">Data Limite (Deadline)</label>
              <input 
                type="date"
                value={dataLimite}
                onChange={(e) => setDataLimite(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500/20"
                required
              />
            </div>

            <div className="flex justify-end gap-2 md:col-span-3 pt-2">
              <button
                type="button"
                onClick={() => setIsCreating(false)}
                className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 border border-slate-200 rounded-lg"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-lg border border-sky-700 shadow-sm"
              >
                Atribuir Ação
              </button>
            </div>
          </form>
        </div>
      )}

      {/* FILTER CONTROL BAR */}
      <div className="bg-slate-50 border border-slate-100 rounded-xl p-4 flex flex-wrap gap-4 items-center justify-between">
        <span className="text-xs font-bold text-slate-600 flex items-center gap-1.5">
          <Filter className="w-4 h-4 text-slate-400" /> Filtrar Plano de Ações:
        </span>

        <div className="flex flex-wrap gap-3">
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 font-medium">Estado:</span>
            <select 
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="text-xs px-2 py-1.5 bg-white border border-slate-200 rounded-lg focus:outline-none"
            >
              <option value="ALL">Todos os Estados</option>
              <option value={ActionPlanStatus.PENDENTE}>Pendente</option>
              <option value={ActionPlanStatus.EM_CURSO}>Em Curso</option>
              <option value={ActionPlanStatus.CONCLUIDO}>Concluído</option>
            </select>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 font-medium">Divisão:</span>
            <select 
              value={divisionFilter}
              onChange={(e) => setDivisionFilter(e.target.value)}
              className="text-xs px-2 py-1.5 bg-white border border-slate-200 rounded-lg focus:outline-none"
            >
              <option value="ALL">Todas as Divisões</option>
              <option value="DOS">DOS</option>
              <option value="DFC">DFC</option>
              <option value="FAL">FAL</option>
              <option value="DRCQ">DRCQ</option>
            </select>
          </div>
        </div>
      </div>

      {/* ACTIONS FEED LIST */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredItems.map((item) => {
          const isOverdue = new Date(item.dataLimite) < new Date() && item.estado !== ActionPlanStatus.CONCLUIDO;
          
          return (
            <div 
              key={item.id} 
              className={`bg-white border border-slate-100 rounded-xl p-5 shadow-sm space-y-4 hover:shadow-md transition-all flex flex-col justify-between ${
                isOverdue ? 'border-rose-200 bg-rose-50/5' : ''
              }`}
            >
              <div className="space-y-2">
                <div className="flex items-start justify-between gap-3">
                  <div className="space-y-1">
                    <span className="inline-flex items-center gap-1 bg-sky-50 text-sky-700 text-[10px] font-extrabold px-2 py-0.5 rounded border border-sky-100 uppercase">
                      {item.divisaoId}
                    </span>
                    <h3 className="font-bold text-slate-900 text-sm md:text-base leading-tight">{item.titulo}</h3>
                  </div>

                  <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold shrink-0 border ${
                    item.estado === ActionPlanStatus.CONCLUIDO ? 'bg-emerald-50 text-emerald-700 border-emerald-100' :
                    item.estado === ActionPlanStatus.EM_CURSO ? 'bg-amber-50 text-amber-700 border-amber-100' :
                    'bg-slate-50 text-slate-600 border-slate-200'
                  }`}>
                    {item.estado === ActionPlanStatus.CONCLUIDO ? 'Concluído' :
                     item.estado === ActionPlanStatus.EM_CURSO ? 'Em Curso' : 'Pendente'}
                  </span>
                </div>

                <p className="text-slate-600 text-xs leading-relaxed line-clamp-3">{item.descricao}</p>
              </div>

              {/* Action meta and operations footer */}
              <div className="pt-3 border-t border-slate-50 space-y-2 text-xs">
                <div className="flex flex-col sm:flex-row gap-2 sm:items-center justify-between text-slate-500 text-[11px] font-medium">
                  <span className="flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-slate-400" /> Resp: <b>{item.responsavel}</b>
                  </span>
                  
                  <span className={`flex items-center gap-1.5 ${isOverdue ? 'text-rose-600 font-bold' : ''}`}>
                    <Calendar className="w-3.5 h-3.5 text-slate-400" /> Limite: {item.dataLimite}
                    {isOverdue && <span className="text-[9px] bg-rose-100 text-rose-700 px-1 py-0.2 rounded border border-rose-200 uppercase font-black tracking-wider animate-pulse ml-1">Excedido</span>}
                  </span>
                </div>

                {item.dataConclusao && (
                  <div className="text-[11px] text-emerald-600 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Concluído a: {item.dataConclusao}
                  </div>
                )}

                {/* Transitions Buttons */}
                {canUpdateItemStatus(item) && item.estado !== ActionPlanStatus.CONCLUIDO && (
                  <div className="flex justify-end gap-1.5 pt-1">
                    {item.estado === ActionPlanStatus.PENDENTE && (
                      <button
                        onClick={() => handleUpdateStatus(item.id, ActionPlanStatus.EM_CURSO)}
                        className="inline-flex items-center gap-1 px-3 py-1 bg-amber-50 text-amber-700 hover:bg-amber-100 border border-amber-200 rounded text-[11px] font-bold"
                      >
                        <Play className="w-3 h-3" /> Iniciar Trabalho
                      </button>
                    )}
                    
                    {item.estado === ActionPlanStatus.EM_CURSO && (
                      <button
                        onClick={() => handleUpdateStatus(item.id, ActionPlanStatus.CONCLUIDO)}
                        className="inline-flex items-center gap-1 px-3 py-1 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200 rounded text-[11px] font-bold"
                      >
                        <CheckCircle2 className="w-3 h-3" /> Concluir Ação
                      </button>
                    )}
                  </div>
                )}
              </div>
            </div>
          );
        })}
        {filteredItems.length === 0 && (
          <div className="col-span-2 bg-white border border-slate-100 rounded-xl p-12 text-center text-slate-400">
            <Briefcase className="w-12 h-12 text-slate-300 mx-auto mb-2" />
            Nenhuma ação corretiva atende aos critérios de filtragem estabelecidos.
          </div>
        )}
      </div>

      {/* Global Upload Center Modal Integration */}
      <UploadCenterModal 
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        user={user}
        onUploadSuccess={() => {
          setIsUploadOpen(false);
          onRefresh();
        }}
      />
    </div>
  );
}
