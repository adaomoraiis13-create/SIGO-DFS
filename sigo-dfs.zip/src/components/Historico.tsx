import React, { useState, useEffect } from 'react';
import { 
  History, 
  Search, 
  ShieldCheck, 
  Lock, 
  User, 
  Calendar, 
  Eye, 
  CheckCircle2, 
  AlertTriangle,
  FileSpreadsheet
} from 'lucide-react';
import { AuditLog } from '../types.js';
import * as api from '../services/api.js';

export default function Historico() {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.fetchAuditLogs()
      .then(data => {
        setLogs(data);
        setLoading(false);
      })
      .catch(err => {
        console.error('Failed to fetch audit logs', err);
        setLoading(false);
      });
  }, []);

  const filteredLogs = logs.filter(log => {
    const term = searchTerm.toLowerCase();
    return log.utilizador.toLowerCase().includes(term) || 
           log.acao.toLowerCase().includes(term) || 
           log.detalhe.toLowerCase().includes(term) || 
           log.perfil.toLowerCase().includes(term);
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="space-y-1">
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">Histórico de Auditoria e Atividades</h1>
        <p className="text-slate-500 text-sm">Registo cronológico imutável de todas as ações de utilizadores, consolidações e modificações efetuadas na plataforma.</p>
      </div>

      {/* Audit control panel */}
      <div className="bg-white border border-slate-100 rounded-xl p-5 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row gap-3 justify-between items-center">
          <div className="relative w-full sm:max-w-xs">
            <Search className="absolute left-2.5 top-2.5 w-4 h-4 text-slate-400" />
            <input 
              type="text"
              placeholder="Pesquisar por utilizador, ação..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500/20"
            />
          </div>

          <button 
            onClick={() => alert('A exportar o registo de auditoria oficial para CSV... (Simulado com Sucesso)')}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-bold text-slate-700 bg-white hover:bg-slate-50 rounded-lg border border-slate-200 shadow-sm"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" /> Exportar Livro de Logs
          </button>
        </div>

        {/* Audit List Table */}
        <div className="overflow-x-auto border border-slate-100 rounded-xl">
          <table className="w-full text-left text-xs text-slate-600 border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-100 text-slate-700 font-bold">
                <th className="p-3">Data e Hora</th>
                <th className="p-3">Utilizador</th>
                <th className="p-3">Perfil</th>
                <th className="p-3">Operação / Ação</th>
                <th className="p-3">Detalhe Imutável</th>
                <th className="p-3 text-center">Estado</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {filteredLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="p-3 text-slate-400 font-mono">
                    {new Date(log.data).toLocaleString()}
                  </td>
                  <td className="p-3 font-bold text-slate-800">
                    {log.utilizador}
                  </td>
                  <td className="p-3">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-700 border border-slate-200">
                      {log.perfil}
                    </span>
                  </td>
                  <td className="p-3 text-sky-800 font-semibold">
                    {log.acao}
                  </td>
                  <td className="p-3 text-slate-500 max-w-xs truncate" title={log.detalhe}>
                    {log.detalhe}
                  </td>
                  <td className="p-3 text-center">
                    <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] bg-emerald-50 text-emerald-700 border border-emerald-200 font-bold uppercase">
                      <ShieldCheck className="w-3 h-3 text-emerald-600" /> Seguro
                    </span>
                  </td>
                </tr>
              ))}
              {filteredLogs.length === 0 && (
                <tr>
                  <td colSpan={6} className="p-12 text-center text-slate-400">
                    Nenhum registo de auditoria encontrado.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Audit info warning */}
        <div className="bg-slate-50 border border-slate-100 p-3.5 rounded-lg flex gap-3 text-slate-500 text-xs leading-relaxed">
          <Lock className="w-4 h-4 text-slate-400 mt-0.5 shrink-0" />
          <p>
            O registo de auditoria cumpre com a regulamentação de integridade de dados operacionais aeroportuários. Os dados armazenados são imutáveis e protegidos contra alterações ou remoções maliciosas.
          </p>
        </div>
      </div>
    </div>
  );
}
