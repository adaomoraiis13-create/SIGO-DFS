import React, { useState, useEffect, useRef } from 'react';
import { 
  Bot, 
  Send, 
  Trash2, 
  Plus, 
  Sparkles, 
  Settings, 
  MessageSquare, 
  HelpCircle, 
  Sliders, 
  Compass, 
  TrendingUp, 
  ShieldAlert, 
  CheckCircle2, 
  Lightbulb, 
  Info,
  ArrowRight,
  User,
  RefreshCw,
  Clock,
  BookOpen
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { User as UserType } from '../types.js';

interface Conversa {
  id: string;
  utilizador_id: string;
  data_inicio: string;
  modelo_utilizado: string;
}

interface Mensagem {
  id: string;
  conversa_id: string;
  tipo: 'utilizador' | 'assistente';
  conteudo: string;
  data_hora: string;
  referencias?: { titulo: string; link: string; tipo: string }[];
}

interface ConfiguracaoIA {
  id: string;
  modelo: string;
  idioma: string;
  temperatura: number;
  limite_tokens: number;
  ativo: boolean;
}

interface SugestaoIA {
  id: string;
  categoria: string;
  descricao: string;
  prioridade: 'Alta' | 'Média' | 'Baixa';
  data_criacao: string;
}

interface CopilotProps {
  user: UserType;
  balances: any[];
  actionPlans: any[];
}

export default function Copilot({ user, balances, actionPlans }: CopilotProps) {
  const [conversas, setConversas] = useState<Conversa[]>([]);
  const [mensagens, setMensagens] = useState<Mensagem[]>([]);
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [configIA, setConfigIA] = useState<ConfiguracaoIA>({
    id: 'cfg-1',
    modelo: 'gemini-3.5-flash',
    idioma: 'Português (AO)',
    temperatura: 0.2,
    limite_tokens: 2048,
    ativo: true
  });
  const [sugestoes, setSugestoes] = useState<SugestaoIA[]>([]);
  const [loadingChats, setLoadingChats] = useState(true);
  const [sendingMessage, setSendingMessage] = useState(false);
  const [userInput, setUserInput] = useState('');
  const [showConfig, setShowConfig] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Quick prompt starters
  const promptStarters = [
    { text: 'Analisar ações atrasadas', desc: 'Verificar os planos de ação corretiva em atraso.' },
    { text: 'Resumo de incidentes de pista', desc: 'Sintetizar as ocorrências de segurança nos últimos balanços.' },
    { text: 'Análise de efetivo e recursos', desc: 'Avaliar os KPIs de RH e equipamentos.' },
    { text: 'Recomendar melhorias AVSEC', desc: 'Gerar sugestões com base em dados operacionais.' }
  ];

  // Fetch initial chats and config
  const fetchChatsAndConfig = async () => {
    setLoadingChats(true);
    try {
      const [chatsRes, configRes, sugRes] = await Promise.all([
        fetch(`/api/copilot/chats/${user.id}`).then(r => r.json()),
        fetch('/api/copilot/config').then(r => r.json()),
        fetch('/api/copilot/suggestions').then(r => r.json())
      ]);

      setConversas(chatsRes || []);
      if (configRes) setConfigIA(configRes);
      setSugestoes(sugRes || []);

      // Auto-select latest chat or create one
      if (chatsRes && chatsRes.length > 0) {
        handleSelectChat(chatsRes[0].id);
      } else {
        await handleNewChat();
      }
    } catch (err) {
      console.error('Falha ao inicializar DFS Copilot:', err);
    } finally {
      setLoadingChats(false);
    }
  };

  useEffect(() => {
    fetchChatsAndConfig();
  }, []);

  // Auto-scroll to messages end
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [mensagens, sendingMessage]);

  const handleSelectChat = async (conversaId: string) => {
    setActiveChatId(conversaId);
    try {
      const res = await fetch(`/api/copilot/chats/${conversaId}/messages`);
      if (res.ok) {
        const msgs = await res.json();
        setMensagens(msgs || []);
      }
    } catch (err) {
      console.error('Falha ao carregar mensagens do chat:', err);
    }
  };

  const handleNewChat = async () => {
    try {
      const res = await fetch('/api/copilot/chats', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          utilizador_id: user.id,
          modelo_utilizado: configIA.modelo
        })
      });
      if (res.ok) {
        const newConversa = await res.json();
        setConversas(prev => [newConversa, ...prev]);
        setActiveChatId(newConversa.id);
        setMensagens([]);
      }
    } catch (err) {
      console.error('Falha ao criar nova conversa:', err);
    }
  };

  const handleClearChat = async (conversaId: string) => {
    if (!confirm('Deseja realmente eliminar esta sessão de conversação?')) return;
    try {
      const res = await fetch(`/api/copilot/chats/${conversaId}`, {
        method: 'DELETE'
      });
      if (res.ok) {
        setConversas(prev => prev.filter(c => c.id !== conversaId));
        if (activeChatId === conversaId) {
          setMensagens([]);
          setActiveChatId(null);
        }
      }
    } catch (err) {
      console.error('Falha ao limpar chat:', err);
    }
  };

  const handleSendMessage = async (customPrompt?: string) => {
    const promptToSend = customPrompt || userInput;
    if (!promptToSend.trim() || !activeChatId || sendingMessage) return;

    setUserInput('');
    setSendingMessage(true);

    try {
      const res = await fetch(`/api/copilot/chats/${activeChatId}/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          conteudo: promptToSend,
          userRole: user.role,
          userDivision: user.divisionId,
          username: user.name
        })
      });

      if (res.ok) {
        const data = await res.json();
        // Append user and assistant response messages
        setMensagens(prev => [...prev, data.userMessage, data.assistantMessage]);
      } else {
        const errData = await res.json();
        alert(`Erro de IA: ${errData.error || 'Falha ao processar resposta.'}`);
      }
    } catch (err: any) {
      console.error('Falha ao enviar mensagem para IA:', err);
    } finally {
      setSendingMessage(false);
    }
  };

  const handleSaveConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/copilot/config', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(configIA)
      });
      if (res.ok) {
        const saved = await res.json();
        setConfigIA(saved);
        setShowConfig(false);
        alert('Configurações do DFS Copilot atualizadas com sucesso!');
      }
    } catch (err) {
      console.error('Erro ao guardar configurações da IA:', err);
    }
  };

  // Convert markdown-like headers and lists to plain text with style on render
  const renderMessageContent = (text: string) => {
    const lines = text.split('\n');
    return lines.map((line, idx) => {
      if (line.startsWith('# ')) {
        return <h2 key={idx} className="text-sm font-black text-slate-800 uppercase tracking-wide mt-3 mb-1.5">{line.substring(2)}</h2>;
      }
      if (line.startsWith('## ')) {
        return <h3 key={idx} className="text-xs font-extrabold text-slate-700 uppercase tracking-wide mt-2.5 mb-1">{line.substring(3)}</h3>;
      }
      if (line.startsWith('### ')) {
        return <h4 key={idx} className="text-xs font-bold text-slate-700 uppercase tracking-wider mt-2 mb-0.5">{line.substring(4)}</h4>;
      }
      if (line.startsWith('- ') || line.startsWith('* ')) {
        return (
          <div key={idx} className="flex items-start gap-1.5 pl-2 py-0.5">
            <span className="text-sky-500 font-extrabold select-none">•</span>
            <p className="text-xs text-slate-600 font-medium leading-relaxed">{line.substring(2)}</p>
          </div>
        );
      }
      if (/^\d+\.\s/.test(line)) {
        return (
          <div key={idx} className="flex items-start gap-1.5 pl-2 py-0.5">
            <span className="text-sky-500 font-bold select-none">{line.match(/^\d+\./)?.[0]}</span>
            <p className="text-xs text-slate-600 font-medium leading-relaxed">{line.replace(/^\d+\.\s/, '')}</p>
          </div>
        );
      }
      if (line.trim() === '---') {
        return <hr key={idx} className="my-3 border-slate-200" />;
      }
      return (
        <p key={idx} className="text-xs text-slate-600 font-medium leading-relaxed py-0.5 whitespace-pre-wrap select-text">
          {line}
        </p>
      );
    });
  };

  return (
    <div className="flex-1 bg-slate-900 min-h-screen flex flex-col md:flex-row h-[calc(100vh-64px)] overflow-hidden">
      
      {/* SIDEBAR: Conversations List & Suggestions */}
      <div className="w-full md:w-80 bg-slate-950 border-r border-slate-800 flex flex-col justify-between shrink-0 h-1/3 md:h-full">
        
        {/* Chats list */}
        <div className="flex-1 flex flex-col overflow-hidden">
          
          <div className="p-4 border-b border-slate-850 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Bot className="w-5 h-5 text-sky-400" />
              <h2 className="text-xs font-black text-white uppercase tracking-wider">DFS Copilot</h2>
            </div>
            <button 
              onClick={handleNewChat}
              className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition"
              title="Nova Conversa"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-3 space-y-1">
            {loadingChats ? (
              <div className="flex justify-center py-10">
                <RefreshCw className="w-5 h-5 text-sky-400 animate-spin" />
              </div>
            ) : conversas.length === 0 ? (
              <p className="text-[10px] text-slate-500 font-bold text-center py-10 uppercase tracking-widest">Sem conversas ativas</p>
            ) : (
              conversas.map((chat) => {
                const isActive = activeChatId === chat.id;
                return (
                  <div 
                    key={chat.id}
                    onClick={() => handleSelectChat(chat.id)}
                    className={`group w-full px-3 py-2.5 rounded-xl cursor-pointer transition flex items-center justify-between gap-2 border ${
                      isActive 
                        ? 'bg-sky-600/10 border-sky-500 text-white font-bold' 
                        : 'bg-transparent border-transparent text-slate-400 hover:bg-slate-900 hover:text-slate-200'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <MessageSquare className={`w-4 h-4 shrink-0 ${isActive ? 'text-sky-400' : 'text-slate-500'}`} />
                      <div className="text-[11px] truncate min-w-0">
                        <p className="font-bold text-slate-200 truncate">Sessão {chat.id.replace('chat-', '')}</p>
                        <p className="text-[9px] text-slate-500 mt-0.5 font-mono">{new Date(chat.data_inicio).toLocaleDateString('pt-PT')} | {chat.modelo_utilizado}</p>
                      </div>
                    </div>
                    
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleClearChat(chat.id);
                      }}
                      className="p-1 rounded opacity-0 group-hover:opacity-100 hover:bg-slate-800 text-slate-500 hover:text-rose-400 transition"
                      title="Eliminar sessão"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* AI Auto-Generated Recommendations List */}
        <div className="border-t border-slate-850 p-4 bg-slate-950/60 max-h-56 overflow-y-auto">
          <div className="flex items-center gap-1.5 mb-3">
            <Lightbulb className="w-4 h-4 text-amber-400" />
            <h4 className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest">Recomendações da IA</h4>
          </div>
          <div className="space-y-2">
            {sugestoes.slice(0, 3).map((s, idx) => (
              <div key={idx} className="p-2.5 rounded-xl bg-slate-900 border border-slate-850 text-[10px] space-y-1.5 hover:border-slate-700 transition">
                <div className="flex justify-between items-center">
                  <span className="font-extrabold text-sky-400 uppercase">{s.categoria}</span>
                  <span className={`px-1.5 py-0.5 rounded text-[8px] font-extrabold uppercase ${
                    s.prioridade === 'Alta' ? 'bg-rose-900/40 text-rose-300' : s.prioridade === 'Média' ? 'bg-amber-900/40 text-amber-300' : 'bg-slate-800 text-slate-300'
                  }`}>
                    {s.prioridade}
                  </span>
                </div>
                <p className="text-slate-300 font-medium leading-relaxed select-text">{s.descricao}</p>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* MAIN CANVAS: AI Chat & Settings */}
      <div className="flex-1 bg-slate-900 flex flex-col justify-between overflow-hidden h-2/3 md:h-full relative">
        
        {/* Chat Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-850 flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-sky-600/10 text-sky-400 border border-sky-500/20 flex items-center justify-center">
              <Bot className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h2 className="text-xs font-black text-white uppercase tracking-wider">DFS Copilot – Assistente Corporativo</h2>
                <span className="px-1.5 py-0.5 bg-emerald-500/10 text-emerald-400 text-[8px] font-black rounded-full border border-emerald-500/20 uppercase">Online</span>
              </div>
              <p className="text-[9px] text-slate-500 mt-0.5 font-bold">
                Modelo Ativo: <span className="text-slate-300 font-mono">{configIA.modelo}</span> | Temperatura: <span className="text-slate-300 font-mono">{configIA.temperatura}</span>
              </p>
            </div>
          </div>

          <button
            onClick={() => setShowConfig(!showConfig)}
            className="p-2 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition flex items-center gap-1.5 text-xs font-extrabold uppercase tracking-wider"
          >
            <Settings className="w-4 h-4" /> Configurar
          </button>
        </div>

        {/* Configuration Overlay Panel */}
        {showConfig && (
          <div className="absolute inset-x-0 top-0 bg-slate-950 border-b border-slate-800 z-30 p-6 shadow-xl animate-in slide-in-from-top duration-200">
            <div className="max-w-xl mx-auto space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-850">
                <div className="flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-sky-400" />
                  <h3 className="text-xs font-black text-white uppercase tracking-wider">Configuração da IA do Copilot</h3>
                </div>
                <button 
                  onClick={() => setShowConfig(false)}
                  className="text-slate-500 hover:text-slate-300 text-lg font-bold"
                >
                  &times;
                </button>
              </div>

              <form onSubmit={handleSaveConfig} className="space-y-4 text-xs">
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[9px] font-extrabold uppercase tracking-wider text-slate-400 mb-1">Modelo de IA</label>
                    <select
                      value={configIA.modelo}
                      onChange={(e) => setConfigIA(prev => ({ ...prev, modelo: e.target.value }))}
                      className="w-full border border-slate-850 rounded-lg p-2 bg-slate-900 text-slate-200 focus:outline-none"
                    >
                      <option value="gemini-3.5-flash">Gemini 3.5 Flash (Recomendado)</option>
                      <option value="gemini-3.1-pro-preview">Gemini 3.1 Pro Preview</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[9px] font-extrabold uppercase tracking-wider text-slate-400 mb-1">Idioma de Interação</label>
                    <input 
                      type="text"
                      value={configIA.idioma}
                      onChange={(e) => setConfigIA(prev => ({ ...prev, idioma: e.target.value }))}
                      className="w-full border border-slate-850 rounded-lg p-2 bg-slate-900 text-slate-200 focus:outline-none font-bold"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[9px] font-extrabold uppercase tracking-wider text-slate-400 mb-1">Temperatura ({configIA.temperatura})</label>
                    <input 
                      type="range"
                      min="0.0"
                      max="1.0"
                      step="0.1"
                      value={configIA.temperatura}
                      onChange={(e) => setConfigIA(prev => ({ ...prev, temperatura: parseFloat(e.target.value) }))}
                      className="w-full accent-sky-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[9px] font-extrabold uppercase tracking-wider text-slate-400 mb-1">Máximo de Tokens</label>
                    <input 
                      type="number"
                      value={configIA.limite_tokens}
                      onChange={(e) => setConfigIA(prev => ({ ...prev, limite_tokens: parseInt(e.target.value) }))}
                      className="w-full border border-slate-850 rounded-lg p-2 bg-slate-900 text-slate-200 focus:outline-none font-mono"
                    />
                  </div>
                </div>

                <div className="flex justify-end gap-2 pt-3 border-t border-slate-850">
                  <button 
                    type="button"
                    onClick={() => setShowConfig(false)}
                    className="px-4 py-2 bg-slate-900 text-slate-400 border border-slate-800 hover:border-slate-700 rounded-lg transition"
                  >
                    Cancelar
                  </button>
                  <button 
                    type="submit"
                    className="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white font-extrabold uppercase tracking-wide rounded-lg transition shadow-sm"
                  >
                    Guardar Alterações
                  </button>
                </div>

              </form>
            </div>
          </div>
        )}

        {/* Message Canvas List */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 bg-slate-900/40 select-text">
          <AnimatePresence initial={false}>
            {mensagens.length === 0 ? (
              <div className="h-full flex flex-col justify-center items-center py-10 max-w-lg mx-auto space-y-6">
                
                <div className="text-center space-y-2">
                  <div className="w-14 h-14 rounded-2xl bg-sky-600/10 text-sky-400 border border-sky-500/20 flex items-center justify-center mx-auto mb-3">
                    <Sparkles className="w-7 h-7 animate-bounce" />
                  </div>
                  <h3 className="text-sm font-black text-white uppercase tracking-wider">Como posso auxiliar hoje?</h3>
                  <p className="text-xs text-slate-400 font-medium leading-relaxed">
                    Olá, **{user.name.split(' ')[0]}**. Sou o assistente corporativo DFS. Estou sintonizado com os balanços operacionais diários, KPIs e planos de ação da ATO & OC SA. 
                  </p>
                </div>

                {/* Prompt Starters */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full">
                  {promptStarters.map((p, idx) => (
                    <div 
                      key={idx}
                      onClick={() => handleSendMessage(p.text)}
                      className="p-3 bg-slate-950/50 border border-slate-800 rounded-xl hover:border-sky-500 cursor-pointer transition flex items-center justify-between group"
                    >
                      <div className="min-w-0 pr-2">
                        <p className="text-slate-200 text-xs font-black truncate">{p.text}</p>
                        <p className="text-[10px] text-slate-500 font-bold truncate mt-0.5">{p.desc}</p>
                      </div>
                      <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-sky-400 group-hover:translate-x-0.5 transition" />
                    </div>
                  ))}
                </div>

              </div>
            ) : (
              mensagens.map((msg) => {
                const isAssistant = msg.tipo === 'assistente';
                return (
                  <motion.div 
                    key={msg.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`flex gap-3 max-w-3xl ${isAssistant ? '' : 'ml-auto flex-row-reverse'}`}
                  >
                    {/* Avatar */}
                    <div className={`w-8 h-8 rounded-lg border flex items-center justify-center shrink-0 font-bold text-xs ${
                      isAssistant 
                        ? 'bg-sky-600/10 border-sky-500/20 text-sky-400' 
                        : 'bg-slate-800 border-slate-700 text-slate-300'
                    }`}>
                      {isAssistant ? <Bot className="w-4 h-4" /> : <User className="w-4 h-4" />}
                    </div>

                    {/* Message Bubble */}
                    <div className={`space-y-1 rounded-2xl p-4 border max-w-full md:max-w-2xl shadow-xs select-text ${
                      isAssistant 
                        ? 'bg-slate-950 border-slate-850 text-slate-300' 
                        : 'bg-sky-600/10 border-sky-500/20 text-sky-200'
                    }`}>
                      {/* Name header */}
                      <div className="flex items-center justify-between pb-1.5 border-b border-slate-850 mb-2">
                        <span className="text-[10px] font-black uppercase tracking-wider text-slate-400">
                          {isAssistant ? 'DFS Copilot' : user.name}
                        </span>
                        <span className="text-[9px] font-mono text-slate-500">
                          {new Date(msg.data_hora).toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>

                      {/* Content Rendered with markdown parsers style */}
                      <div className="space-y-1.5">
                        {isAssistant ? renderMessageContent(msg.conteudo) : <p className="text-xs font-semibold whitespace-pre-wrap select-text leading-relaxed">{msg.conteudo}</p>}
                      </div>

                      {/* Reference grounding files (if any) */}
                      {isAssistant && (
                        <div className="border-t border-slate-850 pt-2.5 mt-3 flex items-center gap-1.5 flex-wrap">
                          <BookOpen className="w-3.5 h-3.5 text-sky-400" />
                          <span className="text-[9px] font-extrabold text-slate-400 uppercase tracking-widest mr-1">Análise Baseada Em:</span>
                          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-[9px] font-bold text-slate-300 uppercase tracking-wide">
                            Balanços DFS
                          </span>
                          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-[9px] font-bold text-slate-300 uppercase tracking-wide">
                            Ações Corretivas
                          </span>
                          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-[9px] font-bold text-slate-300 uppercase tracking-wide">
                            Indicadores BI
                          </span>
                        </div>
                      )}

                    </div>
                  </motion.div>
                );
              })
            )}

            {sendingMessage && (
              <div className="flex gap-3 max-w-xl animate-pulse">
                <div className="w-8 h-8 rounded-lg bg-sky-600/10 border border-sky-500/20 text-sky-400 flex items-center justify-center font-bold text-xs shrink-0">
                  <Bot className="w-4 h-4 animate-spin" />
                </div>
                <div className="bg-slate-950 border border-slate-850 rounded-2xl p-4 flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-500 animate-bounce" style={{ animationDelay: '0ms' }}></span>
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-500 animate-bounce" style={{ animationDelay: '150ms' }}></span>
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-500 animate-bounce" style={{ animationDelay: '300ms' }}></span>
                </div>
              </div>
            )}
          </AnimatePresence>

          <div ref={messagesEndRef} />
        </div>

        {/* Input Message Area */}
        <div className="p-4 bg-slate-950 border-t border-slate-850">
          <div className="max-w-3xl mx-auto flex gap-2">
            <input 
              type="text" 
              placeholder="Pergunte ao DFS Copilot (Ex: Qual é o estado do plano de ação?)..."
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleSendMessage();
              }}
              disabled={sendingMessage}
              className="flex-1 bg-slate-900 border border-slate-800 focus:border-sky-500 rounded-xl px-4 py-2 text-xs text-white focus:outline-none transition disabled:opacity-50"
            />
            <button
              onClick={() => handleSendMessage()}
              disabled={sendingMessage || !userInput.trim()}
              className="p-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white transition disabled:opacity-50 disabled:hover:bg-sky-600 flex items-center justify-center shadow-sm"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
          <p className="text-center text-[9px] text-slate-500 mt-2 font-bold uppercase tracking-wider">
            O DFS Copilot está integrado de forma segura com o sigo-dfs. as respostas respeitam o segredo profissional de angola.
          </p>
        </div>

      </div>

    </div>
  );
}
