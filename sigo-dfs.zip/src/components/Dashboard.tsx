import React, { useState, useEffect } from 'react';
import { 
  FileText, 
  CheckCircle, 
  AlertTriangle, 
  FileUp, 
  Clock, 
  TrendingUp, 
  ArrowRight,
  ShieldAlert,
  UserCheck,
  PlaneTakeoff
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  AreaChart, 
  Area,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { OperationalBalance, ActionPlanItem, Documento, User, BalanceStatus, ActionPlanStatus } from '../types.js';
import Logo from './Logo.js';

interface DashboardProps {
  user: User;
  balances: OperationalBalance[];
  actionPlans: ActionPlanItem[];
  documents: Documento[];
  setView: (view: string) => void;
  setSelectedBalanceId: (id: string | null) => void;
}

export default function Dashboard({ 
  user, 
  balances, 
  actionPlans, 
  documents, 
  setView,
  setSelectedBalanceId
}: DashboardProps) {
  // Stat calculations
  const totalBalances = balances.length;
  const inDraft = balances.filter(b => b.estado === BalanceStatus.EM_ELABORACAO).length;
  const inReview = balances.filter(b => b.estado === BalanceStatus.EM_REVISAO).length;
  const approved = balances.filter(b => b.estado === BalanceStatus.APROVADO).length;
  const correctionRequested = balances.filter(b => b.estado === BalanceStatus.CORRECAO_SOLICITADA).length;

  const totalActions = actionPlans.length;
  const pendingActions = actionPlans.filter(a => a.estado === ActionPlanStatus.PENDENTE).length;
  const inProgressActions = actionPlans.filter(a => a.estado === ActionPlanStatus.EM_CURSO).length;
  const completedActions = actionPlans.filter(a => a.estado === ActionPlanStatus.CONCLUIDO).length;

  const totalDocs = documents.length;

  // Chart Data preparation
  const trendData = balances.map(b => ({
    data: b.data,
    'SLA PMR Assistido': b.fal?.acessibilidadePMR ? parseInt(b.fal.acessibilidadePMR.match(/\d+/)?.[0] || '10') : 10,
    'Tempo Espera Fronteira (m)': b.dfc?.controleFronteiras ? parseInt(b.dfc.controleFronteiras.match(/\d+/)?.[0] || '15') : 15,
  })).reverse();

  const divisionActivityData = [
    { name: 'DOS', Ações: actionPlans.filter(a => a.divisaoId === 'DOS').length, Documentos: documents.filter(d => d.divisaoId === 'DOS').length },
    { name: 'DFC', Ações: actionPlans.filter(a => a.divisaoId === 'DFC').length, Documentos: documents.filter(d => d.divisaoId === 'DFC').length },
    { name: 'FAL', Ações: actionPlans.filter(a => a.divisaoId === 'FAL').length, Documentos: documents.filter(d => d.divisaoId === 'FAL').length },
    { name: 'DRCQ', Ações: actionPlans.filter(a => a.divisaoId === 'DRCQ').length, Documentos: documents.filter(d => d.divisaoId === 'DRCQ').length }
  ];

  const COLORS = ['#38bdf8', '#0284c7', '#0369a1', '#0f172a'];

  const balanceSummaryPie = [
    { name: 'Em Elaboração', value: inDraft },
    { name: 'Em Revisão', value: inReview },
    { name: 'Aprovados', value: approved },
    { name: 'Correção Pedida', value: correctionRequested }
  ].filter(item => item.value > 0);

  return (
    <div className="space-y-6">
      {/* Banner de Boas-vindas */}
      <div className="relative overflow-hidden bg-gradient-to-r from-sky-900 via-sky-800 to-slate-900 rounded-xl p-6 md:p-8 text-white border border-sky-950 shadow-md flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
        <div className="absolute right-0 top-0 opacity-5 transform translate-x-12 -translate-y-12">
          <PlaneTakeoff className="w-96 h-96" />
        </div>
        <div className="relative z-10 space-y-2 max-w-3xl">
          <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight">
            Olá, {user.name}
          </h1>
          <p className="text-sky-100 text-sm md:text-base leading-relaxed">
            Bem-vindo ao SIGO-DFS. A plataforma de gestão operacional da Direção de Facilitação e Segurança está totalmente operacional. Consulte os balanços diários e acompanhe o estado dos planos de ação.
          </p>
          <div className="pt-2 flex flex-wrap gap-2.5">
            <span className="inline-flex items-center gap-1 bg-sky-950/50 backdrop-blur-sm border border-sky-700/50 px-3 py-1 rounded-full text-xs font-semibold text-sky-200">
              Perfil: <b className="text-white font-bold">{user.role}</b>
            </span>
            <span className="inline-flex items-center gap-1 bg-sky-950/50 backdrop-blur-sm border border-sky-700/50 px-3 py-1 rounded-full text-xs font-semibold text-sky-200">
              Divisão: <b className="text-white font-bold">{user.divisionId}</b>
            </span>
            <span className="inline-flex items-center gap-1 bg-emerald-500/10 border border-emerald-500/30 px-3 py-1 rounded-full text-xs font-semibold text-emerald-200">
              Sistema: <b className="text-white font-bold">100% ONLINE</b>
            </span>
          </div>
        </div>
        <div className="relative z-10 bg-white/10 backdrop-blur-xs border border-white/10 p-4 rounded-2xl hidden lg:block shrink-0">
          <Logo size="md" variant="white" showSlogan={true} />
        </div>
      </div>

      {/* Grid de KPIs Corporativos */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Balanços Pendentes */}
        <div className="bg-white border border-slate-100 rounded-xl p-5 shadow-sm flex items-center justify-between hover:shadow-md transition-all">
          <div className="space-y-1">
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Aprovação Pendente</p>
            <h3 className="text-2xl font-black text-slate-900">{inReview}</h3>
            <p className="text-xs text-slate-400 flex items-center gap-1">
              <Clock className="w-3 h-3 text-sky-500" /> Aguardando Diretor
            </p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center border border-sky-100">
            <FileText className="w-6 h-6" />
          </div>
        </div>

        {/* Ações em Curso */}
        <div className="bg-white border border-slate-100 rounded-xl p-5 shadow-sm flex items-center justify-between hover:shadow-md transition-all">
          <div className="space-y-1">
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Ações Corretivas</p>
            <h3 className="text-2xl font-black text-slate-900">{inProgressActions}</h3>
            <p className="text-xs text-amber-600 flex items-center gap-1 font-medium">
              <AlertTriangle className="w-3 h-3" /> {pendingActions} pendentes
            </p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center border border-amber-100">
            <ShieldAlert className="w-6 h-6" />
          </div>
        </div>

        {/* Documentos Operacionais */}
        <div className="bg-white border border-slate-100 rounded-xl p-5 shadow-sm flex items-center justify-between hover:shadow-md transition-all">
          <div className="space-y-1">
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Relatórios Recebidos</p>
            <h3 className="text-2xl font-black text-slate-900">{totalDocs}</h3>
            <p className="text-xs text-slate-400 flex items-center gap-1">
              <FileUp className="w-3 h-3" /> Histórico Powerpoint/PDF
            </p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center border border-teal-100">
            <FileUp className="w-6 h-6" />
          </div>
        </div>

        {/* Balanços Concluídos */}
        <div className="bg-white border border-slate-100 rounded-xl p-5 shadow-sm flex items-center justify-between hover:shadow-md transition-all">
          <div className="space-y-1">
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Balanços Aprovados</p>
            <h3 className="text-2xl font-black text-slate-900">{approved}</h3>
            <p className="text-xs text-slate-400 flex items-center gap-1">
              <UserCheck className="w-3 h-3 text-emerald-500" /> Consolidação efetuada
            </p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center border border-emerald-100">
            <CheckCircle className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Grid de Gráficos de Negócio */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Gráfico do Histórico Operacional */}
        <div className="bg-white border border-slate-100 rounded-xl p-5 shadow-sm lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <h3 className="font-bold text-slate-800 text-base">Indicadores Operacionais Recentes</h3>
              <p className="text-xs text-slate-400">Evolução do tempo médio de espera no controle de fronteiras e assistência PMR</p>
            </div>
            <span className="text-xs font-bold text-sky-600 bg-sky-50 px-2 py-1 rounded border border-sky-100 flex items-center gap-1">
              <TrendingUp className="w-3 h-3" /> Últimos Dias
            </span>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trendData}>
                <defs>
                  <linearGradient id="colorSla" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#38bdf8" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#38bdf8" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorEspera" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#0f172a" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#0f172a" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="data" stroke="#94a3b8" fontSize={12} />
                <YAxis stroke="#94a3b8" fontSize={12} />
                <Tooltip />
                <Area type="monotone" dataKey="SLA PMR Assistido" stroke="#0284c7" fillOpacity={1} fill="url(#colorSla)" strokeWidth={2} />
                <Area type="monotone" dataKey="Tempo Espera Fronteira (m)" stroke="#0f172a" fillOpacity={1} fill="url(#colorEspera)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Distribuição por Divisões */}
        <div className="bg-white border border-slate-100 rounded-xl p-5 shadow-sm space-y-4 flex flex-col justify-between">
          <div className="space-y-1">
            <h3 className="font-bold text-slate-800 text-base">Atividade das Divisões</h3>
            <p className="text-xs text-slate-400">Total de ações e documentos submetidos por divisão</p>
          </div>
          <div className="h-48 flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={divisionActivityData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="name" stroke="#94a3b8" fontSize={12} />
                <YAxis stroke="#94a3b8" fontSize={12} />
                <Tooltip />
                <Bar dataKey="Ações" fill="#0284c7" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Documentos" fill="#0f172a" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-center gap-6 text-xs font-semibold">
            <div className="flex items-center gap-1.5 text-sky-600">
              <span className="w-2.5 h-2.5 rounded bg-sky-600"></span>
              Ações Corretivas
            </div>
            <div className="flex items-center gap-1.5 text-slate-800">
              <span className="w-2.5 h-2.5 rounded bg-slate-900"></span>
              Relatórios PPTX
            </div>
          </div>
        </div>
      </div>

      {/* Grid Operacional do Fluxo de Trabalho (Balanço Diário) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Seção de Balanços Recentes */}
        <div className="bg-white border border-slate-100 rounded-xl p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-slate-800 text-base">Últimos Balanços Operacionais</h3>
            <button 
              onClick={() => setView('balancos')}
              className="text-xs font-bold text-sky-600 hover:text-sky-800 flex items-center gap-1 group"
            >
              Ver todos <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
            </button>
          </div>

          <div className="divide-y divide-slate-100">
            {balances.slice(0, 3).map((bal) => (
              <div 
                key={bal.id} 
                onClick={() => {
                  setSelectedBalanceId(bal.id);
                  setView('balancos');
                }}
                className="py-3.5 flex items-center justify-between hover:bg-slate-50 rounded-lg px-2 cursor-pointer transition-colors"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-800 text-sm">Balanço das últimas 24H</span>
                    <span className="text-xs text-slate-400 font-medium">({bal.data})</span>
                  </div>
                  <p className="text-xs text-slate-500 line-clamp-1 pr-4">{bal.resumoGeral || 'Sem resumo geral preenchido...'}</p>
                </div>

                <div className="flex items-center gap-2">
                  {bal.estado === BalanceStatus.APROVADO && (
                    <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                      Aprovado
                    </span>
                  )}
                  {bal.estado === BalanceStatus.EM_REVISAO && (
                    <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-sky-50 text-sky-700 border border-sky-200">
                      Em Revisão
                    </span>
                  )}
                  {bal.estado === BalanceStatus.EM_ELABORACAO && (
                    <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-slate-50 text-slate-700 border border-slate-200">
                      Em Elaboração
                    </span>
                  )}
                  {bal.estado === BalanceStatus.CORRECAO_SOLICITADA && (
                    <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-rose-50 text-rose-700 border border-rose-200">
                      Correção
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Ações Corretivas em Destaque */}
        <div className="bg-white border border-slate-100 rounded-xl p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-slate-800 text-base">Ações do Plano de Ação Pendentes</h3>
            <button 
              onClick={() => setView('plano-acao')}
              className="text-xs font-bold text-sky-600 hover:text-sky-800 flex items-center gap-1 group"
            >
              Plano Completo <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
            </button>
          </div>

          <div className="divide-y divide-slate-100">
            {actionPlans.filter(a => a.estado !== ActionPlanStatus.CONCLUIDO).slice(0, 3).map((item) => (
              <div 
                key={item.id}
                onClick={() => setView('plano-acao')}
                className="py-3.5 flex items-center justify-between hover:bg-slate-50 rounded-lg px-2 cursor-pointer transition-colors"
              >
                <div className="space-y-1 max-w-[70%]">
                  <h4 className="text-sm font-bold text-slate-800 truncate">{item.titulo}</h4>
                  <div className="flex items-center gap-2 text-[11px] text-slate-400">
                    <span className="font-bold text-sky-600 bg-sky-50 px-1.5 py-0.5 rounded border border-sky-100">{item.divisaoId}</span>
                    <span>Prazo: {item.dataLimite}</span>
                  </div>
                </div>

                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                  item.estado === ActionPlanStatus.EM_CURSO 
                    ? 'bg-amber-50 text-amber-700 border-amber-200' 
                    : 'bg-slate-50 text-slate-600 border-slate-200'
                }`}>
                  {item.estado === ActionPlanStatus.EM_CURSO ? 'Em Curso' : 'Pendente'}
                </span>
              </div>
            ))}
            {actionPlans.filter(a => a.estado !== ActionPlanStatus.CONCLUIDO).length === 0 && (
              <div className="py-8 text-center text-slate-400 text-sm">
                Nenhuma ação corretiva pendente neste momento.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
