import React from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  LineChart, 
  Line,
  Legend,
  PieChart, 
  Pie, 
  Cell 
} from 'recharts';
import { 
  TrendingUp, 
  Clock, 
  Heart, 
  ShieldCheck, 
  AlertTriangle,
  PlaneTakeoff,
  BarChart2
} from 'lucide-react';
import { OperationalBalance } from '../types.js';

interface IndicadoresProps {
  balances: OperationalBalance[];
}

export default function Indicadores({ balances }: IndicadoresProps) {
  // Map analytics data
  const chartData = balances.map(b => {
    // Extract numbers from strings where applicable or use mock defaults
    const PMRAssist = b.fal?.acessibilidadePMR ? parseInt(b.fal.acessibilidadePMR.match(/\d+/)?.[0] || '10') : 10;
    const borderTime = b.dfc?.controleFronteiras ? parseInt(b.dfc.controleFronteiras.match(/\d+/)?.[0] || '15') : 15;
    const safetyIndex = b.drcq?.auditoriasInspecoes ? parseInt(b.drcq.auditoriasInspecoes.match(/\d+/)?.[0] || '95') : 95;
    
    return {
      date: b.data,
      'Assistências PMR': PMRAssist,
      'Fronteira Espera (minutos)': borderTime,
      'Conformidade Auditoria (%)': safetyIndex
    };
  }).reverse(); // chronological

  // Incident types aggregation
  const incidentCategoryData = [
    { name: 'Controlo Fauna / Aves', value: 4, color: '#38bdf8' },
    { name: 'Sistemas TI / SITA', value: 2, color: '#0284c7' },
    { name: 'Equipamentos Terminais', value: 1, color: '#0369a1' },
    { name: 'Outros Incidentes', value: 1, color: '#0f172a' }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="space-y-1">
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">Indicadores Operacionais DFS</h1>
        <p className="text-slate-500 text-sm">Monitore os tempos de espera, assistência a passageiros e conformidade regulamentar em gráficos interativos.</p>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        {/* PMR Assist card */}
        <div className="bg-white border border-slate-100 rounded-xl p-5 shadow-sm space-y-3">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Média de Apoio PMR</span>
            <Heart className="w-5 h-5 text-sky-600" />
          </div>
          <div className="space-y-1">
            <h3 className="text-2xl font-black text-slate-900">14.3 Casos</h3>
            <p className="text-xs text-sky-600 font-bold flex items-center gap-1">
              <TrendingUp className="w-3.5 h-3.5" /> +8% em relação à semana anterior
            </p>
          </div>
        </div>

        {/* Border controls average time card */}
        <div className="bg-white border border-slate-100 rounded-xl p-5 shadow-sm space-y-3">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Tempo de Espera Migratório</span>
            <Clock className="w-5 h-5 text-sky-600" />
          </div>
          <div className="space-y-1">
            <h3 className="text-2xl font-black text-slate-900">21.6 Minutos</h3>
            <p className="text-xs text-amber-600 font-bold flex items-center gap-1">
              <AlertTriangle className="w-3.5 h-3.5" /> Picos de 32m durante falha SITA
            </p>
          </div>
        </div>

        {/* Global Compliance Average card */}
        <div className="bg-white border border-slate-100 rounded-xl p-5 shadow-sm space-y-3">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Média de Conformidade ICAO</span>
            <ShieldCheck className="w-5 h-5 text-sky-600" />
          </div>
          <div className="space-y-1">
            <h3 className="text-2xl font-black text-slate-900">95.5%</h3>
            <p className="text-xs text-emerald-600 font-bold flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" /> Nível Regulamentar Excelente
            </p>
          </div>
        </div>

      </div>

      {/* Charts Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Line chart PMR & Wait times */}
        <div className="bg-white border border-slate-100 rounded-xl p-5 shadow-sm space-y-4">
          <div className="space-y-1">
            <h3 className="font-bold text-slate-800 text-sm">Tempos de Espera vs Assistências de Passageiros</h3>
            <p className="text-xs text-slate-400">Correlação histórica dos fluxos diários de apoio</p>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="date" stroke="#94a3b8" fontSize={11} />
                <YAxis stroke="#94a3b8" fontSize={11} />
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Line type="monotone" dataKey="Assistências PMR" stroke="#38bdf8" strokeWidth={3} activeDot={{ r: 8 }} />
                <Line type="monotone" dataKey="Fronteira Espera (minutos)" stroke="#0f172a" strokeWidth={3} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Bar chart Compliance ratings */}
        <div className="bg-white border border-slate-100 rounded-xl p-5 shadow-sm space-y-4">
          <div className="space-y-1">
            <h3 className="font-bold text-slate-800 text-sm">Nível de Conformidade por Auditoria Diária (%)</h3>
            <p className="text-xs text-slate-400">Inspeções técnicas de rampas e conformidades regulamentares DRCQ</p>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="date" stroke="#94a3b8" fontSize={11} />
                <YAxis stroke="#94a3b8" fontSize={11} domain={[80, 100]} />
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Bar dataKey="Conformidade Auditoria (%)" fill="#0284c7" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Pie Chart Incident Categories */}
        <div className="bg-white border border-slate-100 rounded-xl p-5 shadow-sm space-y-4 flex flex-col justify-between">
          <div className="space-y-1">
            <h3 className="font-bold text-slate-800 text-sm">Distribuição das Ocorrências DFS</h3>
            <p className="text-xs text-slate-400">Classificação de anomalias operacionais registadas nas últimas semanas</p>
          </div>

          <div className="h-48 flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={incidentCategoryData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={70}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {incidentCategoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-2 gap-2 text-[11px] font-semibold">
            {incidentCategoryData.map((item) => (
              <div key={item.name} className="flex items-center gap-1.5 text-slate-600">
                <span className="w-2.5 h-2.5 rounded shrink-0" style={{ backgroundColor: item.color }}></span>
                <span className="truncate">{item.name} ({item.value})</span>
              </div>
            ))}
          </div>
        </div>

        {/* Future predictions preparation notes */}
        <div className="bg-slate-900 text-slate-300 rounded-xl p-6 border border-slate-800 space-y-4 flex flex-col justify-between">
          <div className="space-y-2">
            <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-sky-950 text-sky-400 border border-sky-800 uppercase tracking-widest">
              Futura Integração IA
            </span>
            <h3 className="font-bold text-white text-base">Modelos Preditivos de Fluxo</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              O SIGO-DFS está arquitetado para ligar-se diretamente aos servidores de tráfego aéreo da IATA. Isto permitirá ao sistema prever **gargalos de tráfego de passageiros na migração com 4 horas de antecedência**, sugerindo a abertura preventiva de postos de controle adicionais.
            </p>
          </div>

          <div className="border-t border-slate-800 pt-3 flex items-center gap-2 text-xs font-bold text-sky-400">
            <BarChart2 className="w-4 h-4 animate-pulse" />
            <span>Módulo de IA Analítica Integrado</span>
          </div>
        </div>

      </div>
    </div>
  );
}
