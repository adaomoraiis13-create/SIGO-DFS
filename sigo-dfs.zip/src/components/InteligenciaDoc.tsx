import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  Search, 
  FileText, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  RefreshCw, 
  Layers, 
  Eye, 
  Check, 
  X, 
  SlidersHorizontal, 
  Database, 
  Info, 
  Tag, 
  ChevronRight, 
  CornerDownRight, 
  FileSpreadsheet, 
  FileCode,
  FileDown,
  UserCheck,
  Calendar,
  ShieldCheck,
  SearchCode,
  HelpCircle,
  FileUp
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  User, 
  UserRole, 
  DocType, 
  DivisionId, 
  ProcessStatus, 
  DocumentCategory, 
  DocumentoProcessado, 
  Slide, 
  CampoExtraido, 
  PesquisaIndexada,
  OperationalBalance
} from '../types.js';
import * as api from '../services/api.js';
import UploadCenterModal from './UploadCenterModal.js';

interface InteligenciaDocProps {
  user: User;
}

export default function InteligenciaDoc({ user }: InteligenciaDocProps) {
  // Tabs: 'overview' | 'documents' | 'search'
  const [activeTab, setActiveTab] = useState<'overview' | 'documents' | 'search'>('overview');
  
  // Data State
  const [processedDocs, setProcessedDocs] = useState<DocumentoProcessado[]>([]);
  const [loading, setLoading] = useState(false);
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Search tab states
  const [searchQuery, setSearchQuery] = useState('');
  const [searchDivision, setSearchDivision] = useState<string>('ALL');
  const [searchCategory, setSearchCategory] = useState<string>('ALL');
  const [searchDocType, setSearchDocType] = useState<string>('ALL');
  const [searchResults, setSearchResults] = useState<PesquisaIndexada[]>([]);
  const [searching, setSearching] = useState(false);

  // Document details view modal state
  const [selectedDocId, setSelectedDocId] = useState<string | null>(null);
  const [viewingDetails, setViewingDetails] = useState<{
    doc: DocumentoProcessado;
    slides: Slide[];
    fields: CampoExtraido[];
  } | null>(null);
  const [detailsLoading, setDetailsLoading] = useState(false);
  const [activeSlideIndex, setActiveSlideIndex] = useState<number>(0);

  // Filtering for documents list
  const [filterDivision, setFilterDivision] = useState<string>('ALL');
  const [filterCategory, setFilterCategory] = useState<string>('ALL');
  const [filterStatus, setFilterStatus] = useState<string>('ALL');

  // Consolidation & Duplication States
  const [balances, setBalances] = useState<OperationalBalance[]>([]);
  const [selectedBalanceId, setSelectedBalanceId] = useState<string>('');
  const [duplicates, setDuplicates] = useState<any[]>([]);
  const [consolidating, setConsolidating] = useState(false);
  const [resolvingGroupId, setResolvingGroupId] = useState<string | null>(null);

  const loadConsolidationData = async () => {
    try {
      const allBalances = await api.fetchBalances();
      setBalances(allBalances);
      if (allBalances.length > 0 && !selectedBalanceId) {
        setSelectedBalanceId(allBalances[0].id);
      }
    } catch (err) {
      console.error('Error loading consolidation data', err);
    }
  };

  const loadDuplicates = async (balId: string) => {
    if (!balId) return;
    try {
      const data = await api.fetchBalanceDuplicates(balId);
      setDuplicates(data);
    } catch (err) {
      console.error('Error loading duplicates', err);
    }
  };

  // Load all processed documents
  const loadProcessedDocs = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await api.fetchProcessedDocuments(user);
      setProcessedDocs(data);
      await loadConsolidationData();
    } catch (err: any) {
      console.error('Failed to load processed documents', err);
      setError('Falha ao carregar a lista de documentos processados.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadProcessedDocs();
  }, []);

  useEffect(() => {
    if (selectedBalanceId) {
      loadDuplicates(selectedBalanceId);
    }
  }, [selectedBalanceId]);

  // Handle manual reprocess click
  const handleReprocess = async (docId: string) => {
    setError(null);
    setSuccess(null);
    try {
      const updated = await api.reprocessDocument(user, docId);
      setSuccess(`Documento "${updated.nomeDocumento}" reprocessado com sucesso!`);
      
      // Update local state lists
      await loadProcessedDocs();

      // If active viewing details is this doc, reload it
      if (selectedDocId === docId) {
        await handleViewDetails(docId);
      }
    } catch (err: any) {
      setError(err.message || 'Falha ao despoletar reprocessamento.');
    }
  };

  // Handle single-field validation check
  const handleToggleFieldValidation = async (fieldId: string, currentStatus: boolean) => {
    if (user.role !== UserRole.SECRETARIADO && user.role !== UserRole.ADMIN) {
      setError('Apenas o Secretariado ou Administradores podem validar campos extraídos.');
      return;
    }
    
    try {
      const updatedField = await api.validateExtractedField(user, fieldId, !currentStatus);
      
      // Update fields list in active viewing details
      if (viewingDetails) {
        const updatedFields = viewingDetails.fields.map(f => f.id === fieldId ? updatedField : f);
        setViewingDetails({ ...viewingDetails, fields: updatedFields });
      }
    } catch (err: any) {
      setError(err.message || 'Falha ao atualizar estado de validação do campo.');
    }
  };

  // Handle document approval check
  const handleApproveDocument = async (docId: string, approve: boolean) => {
    if (user.role !== UserRole.SECRETARIADO && user.role !== UserRole.ADMIN) {
      setError('Apenas o Secretariado ou Administradores podem aprovar resultados de extração.');
      return;
    }

    try {
      const updatedDoc = await api.approveProcessedDocument(user, docId, approve);
      setSuccess(approve ? 'Resultados de extração validados e homologados!' : 'Homologação removida.');
      
      // Update parent list
      setProcessedDocs(prev => prev.map(d => d.id === docId ? updatedDoc : d));
      
      // If viewing, reload
      if (selectedDocId === docId) {
        await handleViewDetails(docId);
      }
    } catch (err: any) {
      setError(err.message || 'Falha ao atualizar aprovação.');
    }
  };

  // Handle category override
  const handleCategoryChange = async (docId: string, newCat: DocumentCategory) => {
    if (user.role !== UserRole.SECRETARIADO && user.role !== UserRole.ADMIN) {
      setError('Apenas o Secretariado ou Administradores podem alterar a classificação.');
      return;
    }

    try {
      const updatedDoc = await api.updateProcessedCategory(user, docId, newCat);
      setSuccess(`Categoria alterada manualmente para "${newCat}"!`);
      
      // Update parent list
      setProcessedDocs(prev => prev.map(d => d.id === docId ? updatedDoc : d));

      if (selectedDocId === docId) {
        setViewingDetails(prev => prev ? { ...prev, processedDoc: updatedDoc } : null);
      }
    } catch (err: any) {
      setError(err.message || 'Falha ao atualizar categoria.');
    }
  };

  // View processed document structure & details
  const handleViewDetails = async (docId: string) => {
    setSelectedDocId(docId);
    setDetailsLoading(true);
    try {
      const details = await api.fetchProcessedDocumentDetails(docId);
      setViewingDetails(details);
      setActiveSlideIndex(0);
    } catch (err: any) {
      setError('Falha ao descarregar as estruturas de dados estruturados.');
    } finally {
      setDetailsLoading(false);
    }
  };

  // Perform full-text search
  const handleSearch = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setSearching(true);
    try {
      const results = await api.searchIndexed(searchQuery, {
        divisaoId: searchDivision !== 'ALL' ? searchDivision : undefined,
        categoria: searchCategory !== 'ALL' ? searchCategory : undefined,
        tipoDoc: searchDocType !== 'ALL' ? searchDocType : undefined
      });
      setSearchResults(results);
    } catch (err: any) {
      setError('Erro ao efetuar pesquisa indexada.');
    } finally {
      setSearching(false);
    }
  };

  // Trigger search on filter changes inside search tab
  useEffect(() => {
    if (activeTab === 'search') {
      handleSearch();
    }
  }, [searchDivision, searchCategory, searchDocType]);

  const handleResolveDuplicate = async (groupId: string, estado: 'CONFIRMADO' | 'DESCARTADO') => {
    setResolvingGroupId(groupId);
    setError(null);
    setSuccess(null);
    try {
      const updated = await api.resolveDuplicateGroup(user, groupId, estado);
      setSuccess(`Alerta de duplicação marcado como "${estado}" com sucesso!`);
      if (selectedBalanceId) {
        await loadDuplicates(selectedBalanceId);
      }
    } catch (err: any) {
      setError(err.message || 'Falha ao resolver duplicação.');
    } finally {
      setResolvingGroupId(null);
    }
  };

  const handleConsolidate = async () => {
    setConsolidating(true);
    setError(null);
    setSuccess(null);
    try {
      const updated = await api.consolidateBalance(user, selectedBalanceId);
      setSuccess(`Balanço "${updated.numero}" consolidado automaticamente e promovido para aprovação do Diretor!`);
      await loadProcessedDocs();
    } catch (err: any) {
      setError(err.message || 'Falha ao consolidar balanço.');
    } finally {
      setConsolidating(false);
    }
  };

  // General counts calculations
  const totalDocsCount = processedDocs.length;
  const completedDocsCount = processedDocs.filter(d => d.estado === ProcessStatus.CONCLUIDO).length;
  const errorDocsCount = processedDocs.filter(d => d.estado === ProcessStatus.ERRO).length;
  const approvedDocsCount = processedDocs.filter(d => d.aprovado).length;

  const isSecretariatOrAdmin = user.role === UserRole.SECRETARIADO || user.role === UserRole.ADMIN;

  // Render file type badge
  const renderFileTypeBadge = (type: DocType) => {
    switch (type) {
      case DocType.PPTX:
        return <span className="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase bg-amber-50 text-amber-700 border border-amber-200">PowerPoint</span>;
      case DocType.PDF:
        return <span className="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase bg-rose-50 text-rose-700 border border-rose-200">PDF</span>;
      case DocType.DOCX:
        return <span className="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase bg-blue-50 text-blue-700 border border-blue-200">Word</span>;
      case DocType.XLSX:
        return <span className="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase bg-emerald-50 text-emerald-700 border border-emerald-200">Excel</span>;
      default:
        return <span className="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase bg-slate-50 text-slate-700 border border-slate-200">Ficheiro</span>;
    }
  };

  // Render state badge
  const renderStatusBadge = (status: ProcessStatus) => {
    switch (status) {
      case ProcessStatus.CONCLUIDO:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-100">
            <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Processado
          </span>
        );
      case ProcessStatus.EM_PROCESSAMENTO:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-100 animate-pulse">
            <RefreshCw className="w-3 h-3 text-blue-600 animate-spin" /> A Processar
          </span>
        );
      case ProcessStatus.ERRO:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-100">
            <XCircle className="w-3 h-3 text-rose-600" /> Falha Validação
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-slate-50 text-slate-700 border border-slate-100">
            <Clock className="w-3 h-3 text-slate-600" /> Pendente
          </span>
        );
    }
  };

  // Filter processed documents based on filter states
  const filteredDocsList = processedDocs.filter(d => {
    if (filterDivision !== 'ALL' && d.divisaoId !== filterDivision) return false;
    if (filterCategory !== 'ALL' && d.categoria !== filterCategory) return false;
    if (filterStatus !== 'ALL') {
      if (filterStatus === 'VALIDADO' && !d.aprovado) return false;
      if (filterStatus === 'PENDENTE_VALIDACAO' && d.aprovado) return false;
      if (filterStatus === 'ERRO' && d.estado !== ProcessStatus.ERRO) return false;
    }
    return true;
  });

  return (
    <div className="space-y-6">
      
      {/* HEADER ROW */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center bg-white p-6 rounded-2xl border border-slate-100 shadow-xs gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-sky-50 text-sky-600 rounded-xl">
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-black text-slate-800 uppercase tracking-tight">Centro de Inteligência Documental</h1>
              <p className="text-xs text-slate-400 font-medium">Extração de informação estruturada, classificação e pesquisa indexada de relatórios operacionais.</p>
            </div>
          </div>
        </div>

        {/* Action controls */}
        <div className="flex items-center gap-2 self-stretch md:self-auto">
          <button
            onClick={() => setIsUploadOpen(true)}
            className="flex-1 md:flex-none inline-flex items-center justify-center gap-1.5 px-4 py-2.5 bg-slate-900 hover:bg-slate-850 text-white text-xs font-black uppercase tracking-wider rounded-xl border border-slate-900 transition-colors cursor-pointer"
          >
            <FileUp className="w-3.5 h-3.5 text-orange-400" /> Carregar Documento
          </button>
          
          <button 
            onClick={loadProcessedDocs} 
            className="flex-1 md:flex-none inline-flex items-center justify-center gap-1.5 px-4 py-2.5 bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-extrabold uppercase tracking-wider rounded-xl border border-slate-200 transition-colors"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} /> Sincronizar dados
          </button>
        </div>
      </div>

      {/* ERROR/SUCCESS FEEDBACK ALERTS */}
      {error && (
        <div className="bg-rose-50 border border-rose-100 text-rose-800 p-4 rounded-xl flex items-start gap-3 text-xs shadow-xs">
          <XCircle className="w-5 h-5 text-rose-600 shrink-0" />
          <div className="space-y-1">
            <span className="font-extrabold uppercase tracking-wide text-rose-700">Aviso do Sistema</span>
            <p className="font-medium leading-relaxed">{error}</p>
          </div>
          <button onClick={() => setError(null)} className="ml-auto text-rose-400 hover:text-rose-600">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {success && (
        <div className="bg-emerald-50 border border-emerald-100 text-emerald-800 p-4 rounded-xl flex items-start gap-3 text-xs shadow-xs">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <div className="space-y-1">
            <span className="font-extrabold uppercase tracking-wide text-emerald-700">Operação Bem-sucedida</span>
            <p className="font-medium leading-relaxed">{success}</p>
          </div>
          <button onClick={() => setSuccess(null)} className="ml-auto text-emerald-400 hover:text-emerald-600">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* NAVIGATION TABS */}
      <div className="border-b border-slate-200">
        <div className="flex space-x-6">
          <button
            onClick={() => { setActiveTab('overview'); setSelectedDocId(null); setViewingDetails(null); }}
            className={`pb-3.5 text-xs font-black uppercase tracking-wider border-b-2 transition-all ${
              activeTab === 'overview' 
                ? 'border-sky-600 text-sky-600 font-extrabold' 
                : 'border-transparent text-slate-400 hover:text-slate-700'
            }`}
          >
            Sumário & Estatísticas
          </button>
          <button
            onClick={() => { setActiveTab('documents'); }}
            className={`pb-3.5 text-xs font-black uppercase tracking-wider border-b-2 transition-all ${
              activeTab === 'documents' 
                ? 'border-sky-600 text-sky-600 font-extrabold' 
                : 'border-transparent text-slate-400 hover:text-slate-700'
            }`}
          >
            Painel de Processamento ({filteredDocsList.length})
          </button>
          <button
            onClick={() => { setActiveTab('search'); setSelectedDocId(null); setViewingDetails(null); }}
            className={`pb-3.5 text-xs font-black uppercase tracking-wider border-b-2 transition-all flex items-center gap-1.5 ${
              activeTab === 'search' 
                ? 'border-sky-600 text-sky-600 font-extrabold' 
                : 'border-transparent text-slate-400 hover:text-slate-700'
            }`}
          >
            <Search className="w-3.5 h-3.5" /> Motor de Pesquisa
          </button>
          <button
            onClick={() => { setActiveTab('consolidation'); setSelectedDocId(null); setViewingDetails(null); }}
            className={`pb-3.5 text-xs font-black uppercase tracking-wider border-b-2 transition-all flex items-center gap-1.5 ${
              activeTab === 'consolidation' 
                ? 'border-sky-600 text-sky-600 font-extrabold' 
                : 'border-transparent text-slate-400 hover:text-slate-700'
            }`}
          >
            <Layers className="w-3.5 h-3.5" /> Deduplicação & Consolidação
          </button>
        </div>
      </div>

      {/* TAB CONTENTS */}
      <AnimatePresence mode="wait">
        
        {/* TAB 1: OVERVIEW & STATS */}
        {activeTab === 'overview' && (
          <motion.div
            key="overview"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.15 }}
            className="space-y-6"
          >
            {/* KPI Widgets Row */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs space-y-2">
                <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider">Total de Documentos</span>
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-black text-slate-800">{totalDocsCount}</span>
                  <span className="text-xs font-bold text-slate-400">arquivos na base</span>
                </div>
                <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-sky-500 h-full rounded-full" style={{ width: '100%' }}></div>
                </div>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs space-y-2">
                <span className="text-[10px] font-extrabold text-emerald-600 uppercase tracking-wider">Processados com Sucesso</span>
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-black text-emerald-700">{completedDocsCount}</span>
                  <span className="text-xs font-bold text-emerald-500">
                    {totalDocsCount > 0 ? Math.round((completedDocsCount / totalDocsCount) * 100) : 0}% taxa sucesso
                  </span>
                </div>
                <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                  <div 
                    className="bg-emerald-500 h-full rounded-full" 
                    style={{ width: `${totalDocsCount > 0 ? (completedDocsCount / totalDocsCount) * 100 : 0}%` }}
                  ></div>
                </div>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs space-y-2">
                <span className="text-[10px] font-extrabold text-sky-600 uppercase tracking-wider">Homologados & Validados</span>
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-black text-sky-700">{approvedDocsCount}</span>
                  <span className="text-xs font-bold text-sky-500">
                    {completedDocsCount > 0 ? Math.round((approvedDocsCount / completedDocsCount) * 100) : 0}% validados
                  </span>
                </div>
                <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                  <div 
                    className="bg-sky-500 h-full rounded-full" 
                    style={{ width: `${completedDocsCount > 0 ? (approvedDocsCount / completedDocsCount) * 100 : 0}%` }}
                  ></div>
                </div>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs space-y-2">
                <span className="text-[10px] font-extrabold text-rose-600 uppercase tracking-wider">Falhas de Validação / Erros</span>
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-black text-rose-700">{errorDocsCount}</span>
                  <span className="text-xs font-bold text-rose-500">requerem atenção</span>
                </div>
                <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                  <div 
                    className="bg-rose-500 h-full rounded-full" 
                    style={{ width: `${totalDocsCount > 0 ? (errorDocsCount / totalDocsCount) * 100 : 0}%` }}
                  ></div>
                </div>
              </div>
            </div>

            {/* Explanatory banner of the architecture */}
            <div className="bg-[#0b1c3c] rounded-2xl p-6 text-white border border-slate-800 shadow-md relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="space-y-2.5 z-10 max-w-xl text-center md:text-left">
                <span className="inline-flex items-center gap-1 px-3 py-1 bg-sky-500/10 border border-sky-400/20 rounded-full text-xs font-extrabold text-sky-400 uppercase tracking-widest">
                  <Database className="w-3.5 h-3.5" /> Arquitetura de Dados Estruturados
                </span>
                <h3 className="text-lg font-black tracking-tight leading-snug">
                  Como funciona o Document Intelligence Engine?
                </h3>
                <p className="text-slate-400 text-xs leading-relaxed font-medium">
                  Os ficheiros PowerPoint, PDF, Word e Excel submetidos pelas divisões aeroportuárias são descodificados na nossa base de dados. Em vez de ficarem guardados apenas como ficheiros opacos, as estruturas internas (slides, parágrafos, tabelas, fórmulas) são decompostas e indexadas palavra-a-palavra, permitindo uma verificação minuciosa dos dados regulamentares e pesquisa global imediata.
                </p>
              </div>
              <div className="shrink-0 flex items-center justify-center p-4 bg-white/5 rounded-2xl border border-white/10 z-10 w-full md:w-auto">
                <div className="space-y-3 w-full md:w-60">
                  <div className="flex items-center gap-2 text-xs font-bold text-sky-300">
                    <span className="w-5 h-5 rounded-full bg-sky-500/20 flex items-center justify-center text-[10px]">1</span>
                    <span>Upload & Descodificação</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs font-bold text-teal-300">
                    <span className="w-5 h-5 rounded-full bg-teal-500/20 flex items-center justify-center text-[10px]">2</span>
                    <span>Classificação Auto & Heurísticas</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs font-bold text-amber-300">
                    <span className="w-5 h-5 rounded-full bg-amber-500/20 flex items-center justify-center text-[10px]">3</span>
                    <span>Homologação do Secretariado</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs font-bold text-emerald-300">
                    <span className="w-5 h-5 rounded-full bg-emerald-500/20 flex items-center justify-center text-[10px]">4</span>
                    <span>Consolidação no Balanço</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Actions & Shortcut Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Box 1: Recent errors/validation failures */}
              <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-xs space-y-4">
                <h3 className="text-xs font-black uppercase text-slate-800 tracking-wider flex items-center gap-2">
                  <XCircle className="w-4 h-4 text-rose-500" /> Ficheiros com Erro de Validação ({errorDocsCount})
                </h3>

                {processedDocs.filter(d => d.estado === ProcessStatus.ERRO).length === 0 ? (
                  <div className="py-6 text-center text-xs text-slate-400 font-semibold">
                    Excelente! Sem erros de estrutura ou validação na base de dados.
                  </div>
                ) : (
                  <div className="space-y-3">
                    {processedDocs.filter(d => d.estado === ProcessStatus.ERRO).map(doc => (
                      <div key={doc.id} className="p-3 bg-rose-50/50 rounded-xl border border-rose-100/60 flex items-start justify-between gap-3 text-xs">
                        <div className="space-y-1 min-w-0">
                          <span className="font-extrabold text-rose-900 truncate block">{doc.nomeDocumento}</span>
                          <p className="text-[11px] font-bold text-rose-700/80 leading-relaxed">{doc.erro}</p>
                          <span className="text-[10px] text-slate-400 font-bold uppercase block mt-1">Divisão: {doc.divisaoId}</span>
                        </div>

                        {isSecretariatOrAdmin && (
                          <button 
                            onClick={() => handleReprocess(doc.id)}
                            className="p-1.5 hover:bg-rose-100 rounded text-rose-600 transition-colors shrink-0"
                            title="Tentar Reprocessar"
                          >
                            <RefreshCw className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Box 2: Pending validation indicators */}
              <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-xs space-y-4">
                <h3 className="text-xs font-black uppercase text-slate-800 tracking-wider flex items-center gap-2">
                  <UserCheck className="w-4 h-4 text-sky-500" /> Pendentes de Homologação ({processedDocs.filter(d => d.estado === ProcessStatus.CONCLUIDO && !d.aprovado).length})
                </h3>

                {processedDocs.filter(d => d.estado === ProcessStatus.CONCLUIDO && !d.aprovado).length === 0 ? (
                  <div className="py-6 text-center text-xs text-slate-400 font-semibold">
                    Todos os ficheiros operacionais processados encontram-se homologados!
                  </div>
                ) : (
                  <div className="space-y-3">
                    {processedDocs.filter(d => d.estado === ProcessStatus.CONCLUIDO && !d.aprovado).slice(0, 4).map(doc => (
                      <div key={doc.id} className="p-3 bg-slate-50 hover:bg-slate-100/70 rounded-xl border border-slate-200/50 flex items-center justify-between gap-3 text-xs transition-colors">
                        <div className="min-w-0">
                          <span className="font-extrabold text-slate-700 truncate block">{doc.nomeDocumento}</span>
                          <div className="flex items-center gap-2 mt-1">
                            {renderFileTypeBadge(doc.tipo)}
                            <span className="text-[10px] text-slate-400 font-bold uppercase">Divisão: {doc.divisaoId}</span>
                          </div>
                        </div>

                        <button 
                          onClick={() => { setActiveTab('documents'); handleViewDetails(doc.id); }}
                          className="px-2.5 py-1.5 bg-sky-50 hover:bg-sky-100 text-sky-700 font-extrabold text-[10px] uppercase tracking-wider rounded-lg transition-colors shrink-0"
                        >
                          Analisar
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

            </div>
          </motion.div>
        )}

        {/* TAB 2: DOCUMENTS LIST & WORKBENCH */}
        {activeTab === 'documents' && (
          <motion.div
            key="documents"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.15 }}
            className="space-y-6"
          >
            {/* Filters Row */}
            <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-xs flex flex-wrap gap-4 items-center justify-between">
              <div className="flex flex-wrap gap-3 items-center">
                <span className="text-[10px] font-extrabold uppercase text-slate-400 tracking-wider flex items-center gap-1.5 shrink-0">
                  <SlidersHorizontal className="w-3.5 h-3.5 text-slate-500" /> Filtrar Lista
                </span>

                {/* Division Filter */}
                <select 
                  value={filterDivision} 
                  onChange={(e) => setFilterDivision(e.target.value)}
                  className="px-3 py-1.5 border border-slate-200 text-xs font-bold text-slate-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500"
                >
                  <option value="ALL">Divisão: Todas</option>
                  <option value={DivisionId.DOS}>DOS (Operações)</option>
                  <option value={DivisionId.DFC}>DFC (Facilitação)</option>
                  <option value={DivisionId.FAL}>FAL (Acessibilidade)</option>
                  <option value={DivisionId.DRCQ}>DRCQ (Qualidade)</option>
                </select>

                {/* Category Filter */}
                <select 
                  value={filterCategory} 
                  onChange={(e) => setFilterCategory(e.target.value)}
                  className="px-3 py-1.5 border border-slate-200 text-xs font-bold text-slate-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500"
                >
                  <option value="ALL">Categoria: Todas</option>
                  {Object.values(DocumentCategory).map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>

                {/* Status Filter */}
                <select 
                  value={filterStatus} 
                  onChange={(e) => setFilterStatus(e.target.value)}
                  className="px-3 py-1.5 border border-slate-200 text-xs font-bold text-slate-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500"
                >
                  <option value="ALL">Estado: Todos</option>
                  <option value="VALIDADO">Homologados</option>
                  <option value="PENDENTE_VALIDACAO">Pendentes Homologação</option>
                  <option value="ERRO">Erros de Validação</option>
                </select>
              </div>

              {/* Counter status label */}
              <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wide shrink-0">
                A mostrar <span className="text-slate-700 font-extrabold">{filteredDocsList.length}</span> de <span className="text-slate-700 font-extrabold">{processedDocs.length}</span> registos
              </div>
            </div>

            {/* Main view area layout */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              
              {/* LEFT: Documents Table (Spans 7 columns when a document is selected, 12 otherwise) */}
              <div className={`space-y-4 ${selectedDocId ? 'lg:col-span-6 xl:col-span-5' : 'lg:col-span-12'}`}>
                <div className="bg-white rounded-2xl border border-slate-100 shadow-xs overflow-hidden">
                  <div className="p-4 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
                    <span className="text-xs font-black uppercase text-slate-800 tracking-wider">
                      Ficheiros Extraídos & Indexados
                    </span>
                  </div>

                  {filteredDocsList.length === 0 ? (
                    <div className="py-20 text-center text-xs text-slate-400 font-semibold space-y-2">
                      <FileUp className="w-10 h-10 text-slate-300 mx-auto" />
                      <p>Nenhum documento processado encontrado com os filtros selecionados.</p>
                      <p className="text-[10px] text-slate-400 font-normal">Submeta novos relatórios operacionais no menu do Balanço para desencadear a inteligência automática.</p>
                    </div>
                  ) : (
                    <div className="divide-y divide-slate-100 overflow-x-auto max-h-[580px] overflow-y-auto">
                      {filteredDocsList.map((doc) => {
                        const isSelected = selectedDocId === doc.id;
                        return (
                          <div 
                            key={doc.id}
                            className={`p-4 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs transition-colors cursor-pointer hover:bg-slate-50/50 ${
                              isSelected ? 'bg-sky-50/30 border-l-4 border-sky-500' : ''
                            }`}
                            onClick={() => handleViewDetails(doc.id)}
                          >
                            <div className="space-y-1.5 min-w-0 flex-1">
                              <div className="flex flex-wrap items-center gap-2">
                                <span className="font-extrabold text-slate-800 truncate" title={doc.nomeDocumento}>
                                  {doc.nomeDocumento}
                                </span>
                                {renderFileTypeBadge(doc.tipo)}
                              </div>

                              <div className="flex flex-wrap items-center gap-y-1 gap-x-4 text-[11px] text-slate-400 font-semibold">
                                <span className="bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded text-[10px] uppercase font-bold">
                                  Divisão: {doc.divisaoId}
                                </span>
                                <span className="flex items-center gap-1">
                                  <Tag className="w-3.5 h-3.5 text-sky-600/75" /> {doc.categoria}
                                </span>
                                <span>
                                  {new Date(doc.dataProcessamento).toLocaleDateString()}
                                </span>
                              </div>
                            </div>

                            <div className="flex items-center gap-3 shrink-0 self-end md:self-auto">
                              {/* State indicators */}
                              <div className="space-y-1 text-right">
                                <div>{renderStatusBadge(doc.estado)}</div>
                                <div>
                                  {doc.estado === ProcessStatus.CONCLUIDO && (
                                    doc.aprovado ? (
                                      <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[9px] font-black uppercase">Homologado</span>
                                    ) : (
                                      <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded bg-slate-100 text-slate-500 text-[9px] font-black uppercase">Não Homologado</span>
                                    )
                                  )}
                                </div>
                              </div>

                              <ChevronRight className={`w-4.5 h-4.5 text-slate-300 transition-transform ${isSelected ? 'translate-x-1 text-sky-600' : ''}`} />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>

              {/* RIGHT: Document Structural Workspace (Shown only when a document is selected) */}
              {selectedDocId && (
                <div className="lg:col-span-6 xl:col-span-7 space-y-4">
                  {detailsLoading ? (
                    <div className="bg-white rounded-2xl border border-slate-100 shadow-xs p-20 flex flex-col items-center justify-center space-y-3">
                      <div className="w-10 h-10 border-4 border-sky-600 border-t-transparent rounded-full animate-spin"></div>
                      <p className="text-xs font-semibold text-slate-400">A processar decomposição do ficheiro...</p>
                    </div>
                  ) : viewingDetails ? (
                    <div className="bg-white rounded-2xl border border-slate-100 shadow-md overflow-hidden space-y-6">
                      
                      {/* Document details header */}
                      <div className="p-5 bg-slate-900 text-white flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                        <div className="space-y-1.5">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-sm font-black tracking-tight">{viewingDetails.processedDoc.nomeDocumento}</span>
                            {renderFileTypeBadge(viewingDetails.processedDoc.tipo)}
                          </div>
                          
                          <div className="flex items-center gap-3 text-slate-400 text-xs font-medium">
                            <span>Tamanho original: <b>{viewingDetails.processedDoc.metadados.tamanhoOriginal}</b></span>
                            <span>•</span>
                            <span>Autor: <b>{viewingDetails.processedDoc.metadados.autor}</b></span>
                          </div>
                        </div>

                        {/* Top close button */}
                        <button 
                          onClick={() => { setSelectedDocId(null); setViewingDetails(null); }}
                          className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors self-end sm:self-auto"
                        >
                          <X className="w-5 h-5" />
                        </button>
                      </div>

                      {/* Error panel if state is error */}
                      {viewingDetails.processedDoc.estado === ProcessStatus.ERRO && (
                        <div className="mx-5 p-4 bg-rose-50 border border-rose-100 rounded-xl space-y-3">
                          <div className="flex items-start gap-2.5 text-xs text-rose-800 font-medium">
                            <XCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                            <div className="space-y-1">
                              <span className="font-extrabold uppercase text-rose-700 tracking-wide block">Ficheiro Incompleto / Inválido</span>
                              <p className="leading-relaxed">{viewingDetails.processedDoc.erro}</p>
                            </div>
                          </div>

                          {isSecretariatOrAdmin && (
                            <button
                              onClick={() => handleReprocess(viewingDetails.processedDoc.id)}
                              className="px-3.5 py-1.5 bg-rose-100 hover:bg-rose-200 text-rose-700 font-extrabold text-[10px] uppercase tracking-wider rounded-lg flex items-center gap-1.5 transition-colors"
                            >
                              <RefreshCw className="w-3.5 h-3.5" /> Forçar Reprocessamento
                            </button>
                          )}
                        </div>
                      )}

                      {viewingDetails.processedDoc.estado === ProcessStatus.CONCLUIDO && (
                        <div className="p-5 space-y-6">
                          
                          {/* CONTROL OPERATIONS BAR (Secretariat/Admin only) */}
                          <div className="p-4 bg-slate-50 border border-slate-200/50 rounded-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                            <div className="space-y-1">
                              <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest flex items-center gap-1">
                                <ShieldCheck className="w-3.5 h-3.5 text-sky-600" /> Ações Regulamentares do Secretariado
                              </span>
                              <p className="text-[11px] text-slate-400 font-medium">Classificação heurística inicial e controle de homologação dos dados estruturados.</p>
                            </div>

                            <div className="flex flex-wrap items-center gap-2 self-stretch md:self-auto w-full md:w-auto">
                              
                              {/* Override category selector */}
                              <div className="flex-1 md:flex-none">
                                <select
                                  value={viewingDetails.processedDoc.categoria}
                                  onChange={(e) => handleCategoryChange(viewingDetails.processedDoc.id, e.target.value as DocumentCategory)}
                                  disabled={!isSecretariatOrAdmin}
                                  className="w-full px-2.5 py-1.5 bg-white border border-slate-300 text-[11px] font-extrabold text-slate-600 rounded-lg focus:outline-none disabled:bg-slate-100 disabled:text-slate-400"
                                >
                                  {Object.values(DocumentCategory).map(cat => (
                                    <option key={cat} value={cat}>Mapeamento: {cat}</option>
                                  ))}
                                </select>
                              </div>

                              {/* Manual reprocess trigger */}
                              {isSecretariatOrAdmin ? (
                                <button
                                  onClick={() => handleReprocess(viewingDetails.processedDoc.id)}
                                  className="px-2.5 py-1.5 bg-white hover:bg-slate-100 text-slate-600 border border-slate-300 rounded-lg text-[10px] font-extrabold uppercase tracking-wider transition-colors"
                                  title="Reprocessar"
                                >
                                  <RefreshCw className="w-3.5 h-3.5" />
                                </button>
                              ) : null}

                              {/* Document level approval check */}
                              {isSecretariatOrAdmin ? (
                                viewingDetails.processedDoc.aprovado ? (
                                  <button
                                    onClick={() => handleApproveDocument(viewingDetails.processedDoc.id, false)}
                                    className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-extrabold text-[10px] uppercase tracking-wider rounded-lg transition-colors flex items-center gap-1 shadow-sm"
                                  >
                                    <X className="w-3.5 h-3.5" /> Desaprovar Dados
                                  </button>
                                ) : (
                                  <button
                                    onClick={() => handleApproveDocument(viewingDetails.processedDoc.id, true)}
                                    className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-[10px] uppercase tracking-wider rounded-lg transition-colors flex items-center gap-1 shadow-sm"
                                  >
                                    <Check className="w-3.5 h-3.5" /> Homologar Extração
                                  </button>
                                )
                              ) : (
                                <div className="text-[10px] text-slate-400 font-extrabold uppercase bg-slate-100 px-3 py-1.5 rounded-lg">
                                  {viewingDetails.processedDoc.aprovado ? '✓ HOMOLOGADO' : 'PENDENTE HOMOLOGAÇÃO'}
                                </div>
                              )}

                            </div>
                          </div>

                          {/* POWERPOINT DECOMPOSITION DISPLAY (SLIDES ROW SELECTOR) */}
                          {viewingDetails.processedDoc.tipo === DocType.PPTX && viewingDetails.slides.length > 0 && (
                            <div className="space-y-3">
                              <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                                <Layers className="w-3.5 h-3.5" /> Estrutura de Slides do PowerPoint ({viewingDetails.slides.length} slides detetados)
                              </span>

                              {/* Slide buttons row */}
                              <div className="flex gap-2 overflow-x-auto pb-1">
                                {viewingDetails.slides.map((slide, idx) => (
                                  <button
                                    key={slide.id}
                                    onClick={() => setActiveSlideIndex(idx)}
                                    className={`px-4 py-3 rounded-xl border text-left shrink-0 w-32 space-y-1 transition-all ${
                                      activeSlideIndex === idx 
                                        ? 'border-sky-500 bg-sky-500/10 shadow-xs' 
                                        : 'border-slate-200 bg-slate-50 hover:bg-slate-100/60'
                                    }`}
                                  >
                                    <span className="text-[10px] font-black text-slate-400 block uppercase">SLIDE 0{slide.numero}</span>
                                    <span className="text-[11px] font-extrabold text-slate-700 truncate block">{slide.titulo}</span>
                                  </button>
                                ))}
                              </div>

                              {/* ACTIVE SLIDE DETAIL VIEWER */}
                              {viewingDetails.slides[activeSlideIndex] && (
                                <div className="p-4 bg-slate-900 text-white rounded-xl space-y-3 relative overflow-hidden shadow-inner">
                                  
                                  {/* Yellow neon light indicator of slide representation */}
                                  <div className="absolute top-0 inset-x-0 h-1 bg-yellow-400 shadow-[0_0_8px_#facc15]"></div>

                                  <div className="flex items-center justify-between border-b border-white/10 pb-2">
                                    <span className="text-[9px] font-extrabold text-yellow-400 uppercase tracking-widest bg-yellow-400/10 px-2 py-0.5 rounded">CONTEÚDO LIDO EM PPTX</span>
                                    
                                    <div className="flex items-center gap-3 text-[10px] text-slate-400 font-bold">
                                      <span>Imagens: <b>{viewingDetails.slides[activeSlideIndex].totalImagens}</b></span>
                                      <span>Gráficos: <b>{viewingDetails.slides[activeSlideIndex].totalGraficos}</b></span>
                                    </div>
                                  </div>

                                  <div className="space-y-1">
                                    <h4 className="text-xs font-black tracking-wide uppercase text-white leading-relaxed">
                                      {viewingDetails.slides[activeSlideIndex].titulo}
                                    </h4>
                                    <p className="text-[11px] font-bold text-slate-400 leading-snug">
                                      {viewingDetails.slides[activeSlideIndex].subtitulo}
                                    </p>
                                  </div>

                                  {/* Read slide paragraphs */}
                                  <div className="p-3 bg-white/5 rounded-lg border border-white/5 text-slate-300 text-xs font-medium leading-relaxed italic">
                                    "{viewingDetails.slides[activeSlideIndex].conteudoTextual}"
                                  </div>

                                  {/* Presenter notes section if available */}
                                  {viewingDetails.slides[activeSlideIndex].notasApresentador && (
                                    <div className="pt-2 border-t border-white/5 flex items-start gap-1 text-[11px] text-yellow-300/90 font-bold">
                                      <Info className="w-3.5 h-3.5 shrink-0 mt-0.5 text-yellow-400" />
                                      <p className="leading-snug"><b>Notas do Orador:</b> {viewingDetails.slides[activeSlideIndex].notasApresentador}</p>
                                    </div>
                                  )}
                                </div>
                              )}

                            </div>
                          )}

                          {/* GENERAL METRICS PANEL FOR OTHER TYPES */}
                          {viewingDetails.processedDoc.tipo !== DocType.PPTX && (
                            <div className="p-4 bg-slate-50 border border-slate-100 rounded-xl grid grid-cols-3 gap-4 text-center">
                              <div>
                                <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wide block">Formato Ficheiro</span>
                                <span className="text-sm font-black text-slate-700 block uppercase mt-1">{viewingDetails.processedDoc.tipo}</span>
                              </div>
                              <div>
                                {viewingDetails.processedDoc.totalPaginas && (
                                  <>
                                    <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wide block">Páginas Lidas</span>
                                    <span className="text-sm font-black text-slate-700 block mt-1">{viewingDetails.processedDoc.totalPaginas}</span>
                                  </>
                                )}
                                {viewingDetails.processedDoc.totalFolhas && (
                                  <>
                                    <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wide block">Folhas de Cálculo</span>
                                    <span className="text-sm font-black text-slate-700 block mt-1">{viewingDetails.processedDoc.totalFolhas}</span>
                                  </>
                                )}
                              </div>
                              <div>
                                <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wide block">Linhas Analisadas</span>
                                <span className="text-sm font-black text-slate-700 block mt-1">
                                  {viewingDetails.processedDoc.totalLinhas || 140}
                                </span>
                              </div>
                            </div>
                          )}

                          {/* STRUCTURED EXTRACTED FIELDS LIST */}
                          <div className="space-y-3">
                            <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                              <Database className="w-3.5 h-3.5" /> Informação de Dados Estruturados Extraída
                            </span>

                            <div className="border border-slate-200 rounded-xl overflow-hidden shadow-xs">
                              <table className="w-full text-left border-collapse text-xs">
                                <thead>
                                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-extrabold uppercase text-[10px] tracking-wider">
                                    <th className="p-3">Secção / Contexto</th>
                                    <th className="p-3">Nome do Campo</th>
                                    <th className="p-3">Valor Estruturado Detetado</th>
                                    <th className="p-3 text-center">Confiança</th>
                                    <th className="p-3 text-center">Estado</th>
                                  </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-100">
                                  {viewingDetails.fields.map((field) => {
                                    
                                    // Confidence score colors
                                    let confColor = 'bg-rose-50 text-rose-700 border-rose-200';
                                    if (field.confianca >= 90) confColor = 'bg-emerald-50 text-emerald-700 border-emerald-200';
                                    else if (field.confianca >= 70) confColor = 'bg-amber-50 text-amber-700 border-amber-200';

                                    return (
                                      <tr key={field.id} className="hover:bg-slate-50/40">
                                        
                                        {/* Slide/Sheet Section metadata */}
                                        <td className="p-3 font-semibold text-slate-500">
                                          {field.slideId && (
                                            <span className="inline-flex items-center gap-1">
                                              <CornerDownRight className="w-3.5 h-3.5 text-slate-400" /> Slide {
                                                viewingDetails.slides.find(s => s.id === field.slideId)?.numero || 1
                                              }
                                            </span>
                                          )}
                                          {field.paginaNumero && (
                                            <span className="inline-flex items-center gap-1">
                                              <CornerDownRight className="w-3.5 h-3.5 text-slate-400" /> Página {field.paginaNumero}
                                            </span>
                                          )}
                                          {field.folhaNome && (
                                            <span className="inline-flex items-center gap-1">
                                              <CornerDownRight className="w-3.5 h-3.5 text-slate-400" /> {field.folhaNome}
                                            </span>
                                          )}
                                        </td>

                                        {/* Field title */}
                                        <td className="p-3 font-extrabold text-slate-800">
                                          {field.nome}
                                        </td>

                                        {/* Extracted value */}
                                        <td className="p-3 text-slate-600 font-medium">
                                          <span className="bg-slate-50 px-2 py-1 rounded border border-slate-100 font-semibold text-slate-700">
                                            {field.valor}
                                          </span>
                                        </td>

                                        {/* AI Confidence Score */}
                                        <td className="p-3 text-center">
                                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-black border ${confColor}`}>
                                            {field.confianca}%
                                          </span>
                                        </td>

                                        {/* Handshake: Validate button */}
                                        <td className="p-3 text-center">
                                          <div className="flex items-center justify-center">
                                            {isSecretariatOrAdmin ? (
                                              <button
                                                onClick={() => handleToggleFieldValidation(field.id, field.validado)}
                                                className={`p-1 rounded-full border transition-all ${
                                                  field.validado 
                                                    ? 'bg-emerald-100 text-emerald-800 border-emerald-300 hover:bg-rose-50 hover:text-rose-600 hover:border-rose-200' 
                                                    : 'bg-slate-50 text-slate-400 border-slate-200 hover:bg-emerald-50 hover:text-emerald-700 hover:border-emerald-300'
                                                }`}
                                                title={field.validado ? 'Clique para desvalidar dados' : 'Clique para marcar como validado pelo Secretariado'}
                                              >
                                                {field.validado ? <Check className="w-3.5 h-3.5" /> : <X className="w-3.5 h-3.5" />}
                                              </button>
                                            ) : (
                                              field.validado ? (
                                                <span className="text-emerald-600 font-extrabold" title="Validado pelo Secretariado">✓</span>
                                              ) : (
                                                <span className="text-slate-300" title="Aguardando validação do Secretariado">-</span>
                                              )
                                            )}
                                          </div>
                                        </td>

                                      </tr>
                                    );
                                  })}
                                </tbody>
                              </table>
                            </div>
                          </div>

                        </div>
                      )}

                    </div>
                  ) : null}
                </div>
              )}

            </div>
          </motion.div>
        )}

        {/* TAB 3: INDEX SEARCH WORKSPACE */}
        {activeTab === 'search' && (
          <motion.div
            key="search"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.15 }}
            className="space-y-6"
          >
            {/* Search inputs bar */}
            <form onSubmit={handleSearch} className="bg-white p-6 rounded-2xl border border-slate-100 shadow-xs space-y-4">
              
              <div className="flex flex-col md:flex-row gap-3">
                <div className="relative flex-1">
                  <Search className="absolute left-3.5 top-3.5 w-4.5 h-4.5 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Escreva termos ou palavras-chave de relatórios... (Ex: 'garças', 'rondas', 'avaria', 'pista')"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 border border-slate-200 text-sm font-medium rounded-xl focus:outline-none focus:ring-4 focus:ring-sky-500/10 focus:border-sky-500 transition-all placeholder:text-slate-300"
                  />
                </div>

                <button
                  type="submit"
                  disabled={searching}
                  className="px-6 py-3 bg-sky-600 hover:bg-sky-700 text-white font-extrabold text-sm uppercase tracking-wider rounded-xl shadow-md transition-all shrink-0 flex items-center justify-center gap-2"
                >
                  <Search className="w-4 h-4" /> {searching ? 'A pesquisar...' : 'Pesquisar Termos'}
                </button>
              </div>

              {/* Advanced search filters row */}
              <div className="flex flex-wrap items-center gap-x-6 gap-y-2 border-t border-slate-100 pt-4 text-xs font-bold text-slate-500">
                <span className="flex items-center gap-1 text-[10px] font-extrabold uppercase text-slate-400 tracking-wider">
                  <SearchCode className="w-3.5 h-3.5 text-slate-400" /> Filtros Avançados:
                </span>

                <div className="flex items-center gap-1.5">
                  <span className="font-medium text-slate-400">Divisão</span>
                  <select
                    value={searchDivision}
                    onChange={(e) => setSearchDivision(e.target.value)}
                    className="border-b border-slate-200 text-slate-600 bg-transparent py-0.5 focus:outline-none focus:border-sky-500"
                  >
                    <option value="ALL">Todas</option>
                    <option value={DivisionId.DOS}>DOS</option>
                    <option value={DivisionId.DFC}>DFC</option>
                    <option value={DivisionId.FAL}>FAL</option>
                    <option value={DivisionId.DRCQ}>DRCQ</option>
                  </select>
                </div>

                <div className="flex items-center gap-1.5">
                  <span className="font-medium text-slate-400">Categoria</span>
                  <select
                    value={searchCategory}
                    onChange={(e) => setSearchCategory(e.target.value)}
                    className="border-b border-slate-200 text-slate-600 bg-transparent py-0.5 focus:outline-none focus:border-sky-500"
                  >
                    <option value="ALL">Todas</option>
                    {Object.values(DocumentCategory).map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>

                <div className="flex items-center gap-1.5">
                  <span className="font-medium text-slate-400">Tipo Ficheiro</span>
                  <select
                    value={searchDocType}
                    onChange={(e) => setSearchDocType(e.target.value)}
                    className="border-b border-slate-200 text-slate-600 bg-transparent py-0.5 focus:outline-none focus:border-sky-500"
                  >
                    <option value="ALL">Todos</option>
                    <option value={DocType.PPTX}>PowerPoint (.pptx)</option>
                    <option value={DocType.PDF}>PDF (.pdf)</option>
                    <option value={DocType.DOCX}>Word (.docx)</option>
                    <option value={DocType.XLSX}>Excel (.xlsx)</option>
                  </select>
                </div>
              </div>

            </form>

            {/* Search results list workspace */}
            <div className="space-y-4">
              <h3 className="text-xs font-black uppercase text-slate-800 tracking-wider">
                Resultados da Pesquisa Indexada ({searchResults.length} termos identificados)
              </h3>

              {searchResults.length === 0 ? (
                <div className="bg-white rounded-2xl border border-slate-100 p-16 text-center text-xs text-slate-400 font-semibold space-y-2">
                  <HelpCircle className="w-10 h-10 text-slate-300 mx-auto" />
                  <p>Escreva uma palavra-chave acima ou altere os filtros avançados.</p>
                  <p className="text-[10px] text-slate-400 font-normal">A nossa base de dados indexa dinamicamente as tabelas Excel, textos de PDF e slides PowerPoint carregados.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {searchResults.map((idx, index) => (
                    <motion.div
                      key={idx.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: Math.min(index * 0.03, 0.3), duration: 0.15 }}
                      className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs hover:shadow-md transition-shadow flex flex-col justify-between gap-4"
                    >
                      <div className="space-y-3">
                        <div className="flex items-center justify-between gap-2">
                          <span className="px-2.5 py-1 bg-yellow-50 text-yellow-800 text-[10px] font-black uppercase rounded-lg border border-yellow-200">
                            {idx.palavra}
                          </span>

                          <span className="text-[10px] text-slate-400 font-bold uppercase">
                            {idx.divisaoId} • {idx.categoria}
                          </span>
                        </div>

                        {/* Snippet context with highlighted term */}
                        <div className="p-3 bg-slate-50/70 rounded-xl border border-slate-200/40 text-slate-600 text-xs font-medium leading-relaxed italic">
                          "...{idx.contexto}..."
                        </div>
                      </div>

                      <div className="flex items-center justify-between border-t border-slate-100 pt-3 text-[11px] font-bold text-slate-400">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-3.5 h-3.5 text-slate-400" />
                          <span>{new Date(idx.dataProcessamento).toLocaleDateString()}</span>
                        </div>

                        {/* Open document details action */}
                        <button
                          onClick={() => {
                            setActiveTab('documents');
                            handleViewDetails(idx.documentoProcessadoId);
                          }}
                          className="text-sky-600 hover:text-sky-700 flex items-center gap-1 hover:underline transition-all uppercase text-[10px] tracking-wider"
                        >
                          <Eye className="w-3.5 h-3.5" /> Analisar Origem
                        </button>
                      </div>

                    </motion.div>
                  ))}
                </div>
              )}
            </div>

          </motion.div>
        )}

        {/* TAB 4: CONSOLIDATION & DUPLICATION WORKSPACE */}
        {activeTab === 'consolidation' && (
          <motion.div
            key="consolidation"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.15 }}
            className="space-y-6"
          >
            {/* Balance Select Header */}
            <div className="bg-white p-5 rounded-2xl border border-slate-100 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 shadow-xs">
              <div className="space-y-1">
                <h2 className="text-sm font-black text-slate-800 uppercase tracking-tight flex items-center gap-2">
                  <Database className="w-4 h-4 text-sky-600" /> Balanço Operacional Ativo
                </h2>
                <p className="text-[11px] text-slate-400 font-medium">
                  Selecione o balanço operacional sobre o qual deseja analisar as potenciais duplicações ou consolidar os relatórios das divisões.
                </p>
              </div>
              <select
                value={selectedBalanceId}
                onChange={(e) => setSelectedBalanceId(e.target.value)}
                className="px-4 py-2 border border-slate-200 text-xs font-bold rounded-xl focus:outline-none focus:border-sky-500 bg-white shadow-xs"
              >
                {balances.map(b => (
                  <option key={b.id} value={b.id}>
                    {b.numero} ({b.data}) - {b.estado}
                  </option>
                ))}
              </select>
            </div>

            {/* Split Workspace */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* Left Side: Duplicate Event Detection (7 cols) */}
              <div className="lg:col-span-7 bg-white p-6 rounded-2xl border border-slate-100 shadow-xs space-y-6">
                <div className="space-y-1">
                  <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider flex items-center gap-2">
                    <SlidersHorizontal className="w-4 h-4 text-amber-500" /> Deteção e Tratamento de Duplicações ({duplicates.length})
                  </h3>
                  <p className="text-[11px] text-slate-400 font-medium">
                    O nosso motor analisa cruzamentos semânticos entre os dados das quatro divisões para alertar sobre ocorrências potencialmente redundantes ou sobrepostas.
                  </p>
                </div>

                {duplicates.length === 0 ? (
                  <div className="bg-slate-50 border border-slate-100 rounded-2xl p-10 text-center space-y-2">
                    <ShieldCheck className="w-10 h-10 text-emerald-500 mx-auto" />
                    <p className="text-xs font-black text-slate-700 uppercase tracking-wide">Sem Duplicações Identificadas</p>
                    <p className="text-[11px] text-slate-400 font-medium max-w-md mx-auto">
                      Excelente! Todas as fontes de dados para este período de referência são independentes ou foram devidamente isoladas pelo nosso motor inteligente.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {duplicates.map(g => (
                      <div 
                        key={g.id} 
                        className={`border rounded-2xl p-5 space-y-4 transition-all ${
                          g.estado === 'PENDENTE' 
                            ? 'bg-amber-50/20 border-amber-200/55 shadow-xs' 
                            : g.estado === 'CONFIRMADO'
                            ? 'bg-emerald-50/10 border-emerald-200/40'
                            : 'bg-slate-50/50 border-slate-200/30'
                        }`}
                      >
                        <div className="flex justify-between items-start gap-2">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider ${
                                g.estado === 'PENDENTE' ? 'bg-amber-100 text-amber-800 border border-amber-200' :
                                g.estado === 'CONFIRMADO' ? 'bg-emerald-100 text-emerald-800 border border-emerald-200' :
                                'bg-slate-200 text-slate-600 border border-slate-300'
                              }`}>
                                {g.estado}
                              </span>
                              <span className="text-[10px] text-slate-400 font-bold uppercase">ID: {g.id}</span>
                            </div>
                            <h4 className="text-xs font-black text-slate-800 uppercase tracking-tight">{g.campoReferencia}</h4>
                          </div>
                        </div>

                        <div className="space-y-2.5">
                          <p className="text-[10px] font-black text-slate-400 uppercase tracking-wider">Entradas De Relatórios Envolvidas:</p>
                          <div className="space-y-2">
                            {g.camposEnvolvidos.map((item: any, i: number) => (
                              <div key={i} className="bg-white p-3.5 rounded-xl border border-slate-200/40 flex justify-between items-center text-xs shadow-3xs">
                                <div className="space-y-1 min-w-0">
                                  <div className="flex items-center gap-1.5">
                                    <span className="px-1.5 py-0.5 bg-slate-100 text-slate-600 font-extrabold text-[9px] rounded-sm uppercase tracking-wider">{item.divisaoId}</span>
                                    <span className="text-[10px] text-slate-400 font-semibold truncate">Doc: {item.nome}</span>
                                  </div>
                                  <span className="font-extrabold text-slate-700 truncate block mt-1">{item.nome}</span>
                                </div>
                                <span className="font-bold text-sky-700 bg-sky-50 px-2.5 py-1.5 rounded-lg border border-sky-100 whitespace-nowrap">{item.valor}</span>
                              </div>
                            ))}
                          </div>
                        </div>

                        {g.estado === 'PENDENTE' && isSecretariatOrAdmin ? (
                          <div className="flex flex-col sm:flex-row gap-2 border-t border-slate-200/40 pt-3">
                            <button
                              onClick={() => handleResolveDuplicate(g.id, 'CONFIRMADO')}
                              disabled={resolvingGroupId !== null}
                              className="flex-1 inline-flex items-center justify-center gap-1 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold uppercase text-[10px] tracking-wider rounded-xl transition-all shadow-xs"
                            >
                              <Check className="w-3.5 h-3.5" /> Confirmar Como Duplicado
                            </button>
                            <button
                              onClick={() => handleResolveDuplicate(g.id, 'DESCARTADO')}
                              disabled={resolvingGroupId !== null}
                              className="flex-1 inline-flex items-center justify-center gap-1 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 font-extrabold uppercase text-[10px] tracking-wider rounded-xl transition-all border border-slate-200"
                            >
                              <X className="w-3.5 h-3.5" /> Descartar Alerta
                            </button>
                          </div>
                        ) : (
                          g.estado !== 'PENDENTE' && (
                            <div className="border-t border-slate-200/40 pt-2 flex items-center justify-between text-[10px] text-slate-400 font-bold uppercase">
                              <span>Tratamento Efetuado</span>
                              <span>Por: {g.resolvidoPor} • {new Date(g.resolvidoEm).toLocaleDateString()}</span>
                            </div>
                          )
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Right Side: Consolidation Engine & Download (5 cols) */}
              <div className="lg:col-span-5 bg-white p-6 rounded-2xl border border-slate-100 shadow-xs space-y-6 flex flex-col justify-between">
                <div className="space-y-6">
                  <div className="space-y-1">
                    <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-sky-600" /> Consolidação Operacional Automatizada
                    </h3>
                    <p className="text-[11px] text-slate-400 font-medium">
                      Agrega instantaneamente os contributos homologados de todas as divisões no relatório executivo do Balanço.
                    </p>
                  </div>

                  {/* State of the selected balance */}
                  {(() => {
                    const activeBal = balances.find(b => b.id === selectedBalanceId);
                    if (!activeBal) return null;

                    const isConsolidated = activeBal.estado === 'EM_REVISAO' || activeBal.estado === 'APROVADO';

                    return (
                      <div className="space-y-5">
                        {/* Summary info box */}
                        <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 space-y-3 text-xs">
                          <div className="flex justify-between items-center border-b border-slate-200/50 pb-2">
                            <span className="font-bold text-slate-400 uppercase tracking-wider text-[9px]">Código Balanço</span>
                            <span className="font-extrabold text-slate-700">{activeBal.numero}</span>
                          </div>
                          <div className="flex justify-between items-center border-b border-slate-200/50 pb-2">
                            <span className="font-bold text-slate-400 uppercase tracking-wider text-[9px]">Período Ref</span>
                            <span className="font-bold text-slate-700">{activeBal.data} às {activeBal.hora}</span>
                          </div>
                          <div className="flex justify-between items-center border-b border-slate-200/50 pb-2">
                            <span className="font-bold text-slate-400 uppercase tracking-wider text-[9px]">Estado Atual</span>
                            <span className="font-extrabold text-sky-700">{activeBal.estado}</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="font-bold text-slate-400 uppercase tracking-wider text-[9px]">Responsável</span>
                            <span className="font-bold text-slate-600">{activeBal.utilizador || 'N/A'}</span>
                          </div>
                        </div>

                        {/* Summary narrative or preview */}
                        {isConsolidated ? (
                          <div className="p-4 bg-emerald-50/30 border border-emerald-100 rounded-2xl space-y-3">
                            <div className="flex items-center gap-1.5 text-emerald-800 text-xs font-black uppercase tracking-wider">
                              <CheckCircle2 className="w-4.5 h-4.5 text-emerald-600 shrink-0" />
                              <span>Relatório Consolidado Disponível</span>
                            </div>
                            <p className="text-[11px] font-medium text-slate-500 leading-relaxed italic">
                              "{activeBal.resumoGeral || 'Consolidação concluída com sucesso sem anotações adicionais.'}"
                            </p>
                          </div>
                        ) : (
                          <div className="p-4 bg-amber-50/20 border border-amber-200/50 rounded-2xl space-y-2">
                            <div className="flex items-center gap-1.5 text-amber-800 text-xs font-extrabold uppercase tracking-wider">
                              <Clock className="w-4 h-4 text-amber-600" />
                              <span>Aguardando Consolidação</span>
                            </div>
                            <p className="text-[11px] font-medium text-slate-500 leading-relaxed">
                              O balanço ainda possui os relatórios das divisões separados em ficheiros brutos. Execute o motor para estruturar os dados.
                            </p>
                          </div>
                        )}

                        {/* Action buttons */}
                        <div className="space-y-2 pt-3 border-t border-slate-100">
                          {!isConsolidated && isSecretariatOrAdmin && (
                            <button
                              onClick={handleConsolidate}
                              disabled={consolidating}
                              className="w-full inline-flex items-center justify-center gap-2 py-3 bg-sky-600 hover:bg-sky-700 text-white font-black uppercase text-xs tracking-wider rounded-xl shadow-md transition-all disabled:opacity-50"
                            >
                              <RefreshCw className={`w-4 h-4 ${consolidating ? 'animate-spin' : ''}`} />
                              {consolidating ? 'A consolidar dados...' : 'Consolidar Relatórios das Divisões'}
                            </button>
                          )}

                          {isConsolidated && (
                            <div className="space-y-2">
                              <a
                                href={`/api/balances/${activeBal.id}/export`}
                                target="_blank"
                                rel="noreferrer"
                                className="w-full inline-flex items-center justify-center gap-2 py-3 bg-[#0b1c3c] hover:bg-slate-800 text-white font-black uppercase text-xs tracking-wider rounded-xl shadow-md transition-all"
                              >
                                <FileDown className="w-4 h-4" /> Descarregar Relatório Oficial (.md)
                              </a>
                              <p className="text-[10px] text-slate-400 font-medium text-center">
                                O relatório inclui as seções consolidadas do DOS, DFC, FAL, DRCQ estruturadas para apresentação à Diretoria Geral.
                              </p>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })()}
                </div>

                <div className="pt-6 border-t border-slate-100 text-[10px] text-slate-400 font-medium leading-normal space-y-1.5">
                  <div className="flex items-start gap-1">
                    <Info className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>
                      <strong>Nota de Auditoria:</strong> Qualquer ação executada nesta área gera automaticamente uma entrada detalhada nos diários de auditoria global do SIGO-DFS.
                    </span>
                  </div>
                </div>
              </div>

            </div>

          </motion.div>
        )}

      </AnimatePresence>

      {/* Global Upload Center Modal Integration */}
      <UploadCenterModal 
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        user={user}
        onUploadSuccess={() => {
          setIsUploadOpen(false);
          loadProcessedDocs();
        }}
      />
    </div>
  );
}
