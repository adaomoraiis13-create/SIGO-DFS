import React, { useState, useEffect } from 'react';
import { 
  FileText, 
  Plus, 
  Save, 
  Send, 
  CheckCircle, 
  XCircle, 
  AlertCircle, 
  ChevronRight, 
  Calendar, 
  User, 
  Printer, 
  MessageSquare,
  FileDown,
  Lock,
  Edit3,
  Check,
  PlusCircle,
  FileUp
} from 'lucide-react';
import { 
  User as UserType, 
  UserRole, 
  DivisionId, 
  OperationalBalance, 
  BalanceStatus,
  WorkflowLog
} from '../types.js';
import * as api from '../services/api.js';
import Logo from './Logo.js';
import UploadCenterModal from './UploadCenterModal.js';

interface BalançoOperacionalProps {
  user: UserType;
  balances: OperationalBalance[];
  onRefresh: () => void;
  selectedBalanceId: string | null;
  setSelectedBalanceId: (id: string | null) => void;
  selectedSubView?: string;
  setSelectedSubView?: (view: string) => void;
}

export default function BalançoOperacional({ 
  user, 
  balances, 
  onRefresh,
  selectedBalanceId,
  setSelectedBalanceId
}: BalançoOperacionalProps) {
  const [activeTab, setActiveTab] = useState<'resumo' | 'dos' | 'dfc' | 'fal' | 'drcq' | 'workflow'>('resumo');
  const [isCreating, setIsCreating] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // New balance form state
  const [newDate, setNewDate] = useState(new Date().toISOString().split('T')[0]);
  const [newResumo, setNewResumo] = useState('');

  // Editing state
  const [editResumo, setEditResumo] = useState('');
  
  // DOS Section Editing
  const [editDos, setEditDos] = useState({
    ocorrenciasSeguranca: '',
    estadoPistaTaxiways: '',
    atividadesFauna: '',
    statusTerminaisEquipamentos: '',
    incidentesRelatados: ''
  });

  // DFC Section Editing
  const [editDfc, setEditDfc] = useState({
    controleFronteiras: '',
    reclamacoesBagagens: '',
    filasCheckIn: '',
    tempoEsperaSeguranca: '',
    incidentesFacilitacao: ''
  });

  // FAL Section Editing
  const [editFal, setEditFal] = useState({
    acessibilidadePMR: '',
    conformidadeNormativa: '',
    assistenciaMedica: '',
    feedbackPassageiros: ''
  });

  // DRCQ Section Editing
  const [editDrcq, setEditDrcq] = useState({
    auditoriasInspecoes: '',
    naoConformidadesDetetadas: '',
    avaliacaoRiscoOperacional: '',
    acoesPreventivasRecomendadas: ''
  });

  // Workflow Action state
  const [workflowComment, setWorkflowComment] = useState('');
  const [showWorkflowCommentBox, setShowWorkflowCommentBox] = useState(false);
  const [workflowActionType, setWorkflowActionType] = useState<BalanceStatus | null>(null);
  const [workflowLogs, setWorkflowLogs] = useState<WorkflowLog[]>([]);

  // Find the selected balance
  const activeBalance = balances.find(b => b.id === selectedBalanceId) || balances[0] || null;

  // Sync state with selected balance
  useEffect(() => {
    if (activeBalance) {
      if (!selectedBalanceId) {
        setSelectedBalanceId(activeBalance.id);
      }
      setEditResumo(activeBalance.resumoGeral || '');
      setEditDos({
        ocorrenciasSeguranca: activeBalance.dos?.ocorrenciasSeguranca || '',
        estadoPistaTaxiways: activeBalance.dos?.estadoPistaTaxiways || '',
        atividadesFauna: activeBalance.dos?.atividadesFauna || '',
        statusTerminaisEquipamentos: activeBalance.dos?.statusTerminaisEquipamentos || '',
        incidentesRelatados: activeBalance.dos?.incidentesRelatados || ''
      });
      setEditDfc({
        controleFronteiras: activeBalance.dfc?.controleFronteiras || '',
        reclamacoesBagagens: activeBalance.dfc?.reclamacoesBagagens || '',
        filasCheckIn: activeBalance.dfc?.filasCheckIn || '',
        tempoEsperaSeguranca: activeBalance.dfc?.tempoEsperaSeguranca || '',
        incidentesFacilitacao: activeBalance.dfc?.incidentesFacilitacao || ''
      });
      setEditFal({
        acessibilidadePMR: activeBalance.fal?.acessibilidadePMR || '',
        conformidadeNormativa: activeBalance.fal?.conformidadeNormativa || '',
        assistenciaMedica: activeBalance.fal?.assistenciaMedica || '',
        feedbackPassageiros: activeBalance.fal?.feedbackPassageiros || ''
      });
      setEditDrcq({
        auditoriasInspecoes: activeBalance.drcq?.auditoriasInspecoes || '',
        naoConformidadesDetetadas: activeBalance.drcq?.naoConformidadesDetetadas || '',
        avaliacaoRiscoOperacional: activeBalance.drcq?.avaliacaoRiscoOperacional || '',
        acoesPreventivasRecomendadas: activeBalance.drcq?.acoesPreventivasRecomendadas || ''
      });

      // Load workflow history logs
      api.fetchWorkflowLogs(activeBalance.id)
        .then(setWorkflowLogs)
        .catch(console.error);
    }
  }, [activeBalance, selectedBalanceId, setSelectedBalanceId]);

  // Permissions helper
  const canEditSection = (section: 'resumo' | 'dos' | 'dfc' | 'fal' | 'drcq') => {
    if (!activeBalance) return false;
    // Approved balances can NEVER be edited
    if (activeBalance.estado === BalanceStatus.APROVADO) return false;
    
    // Admins and Secretariat can edit EVERYTHING
    if (user.role === UserRole.ADMIN || user.role === UserRole.SECRETARIADO) return true;

    // Division chiefs can edit ONLY their specific section
    if (user.role === UserRole.CHEFE_DIVISAO) {
      if (section === 'dos' && user.divisionId === DivisionId.DOS) return true;
      if (section === 'dfc' && user.divisionId === DivisionId.DFC) return true;
      if (section === 'fal' && user.divisionId === DivisionId.FAL) return true;
      if (section === 'drcq' && user.divisionId === DivisionId.DRCQ) return true;
    }

    return false;
  };

  const handleCreateBalance = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      // Check if balance for this date already exists
      if (balances.some(b => b.data === newDate)) {
        throw new Error(`Já existe um Balanço Operacional registado para a data ${newDate}.`);
      }

      const created = await api.createBalance(user, {
        data: newDate,
        resumoGeral: newResumo
      });

      setSuccess('Balanço operacional criado com sucesso!');
      setIsCreating(false);
      setNewResumo('');
      onRefresh();
      setSelectedBalanceId(created.id);
      setActiveTab('resumo');
    } catch (err: any) {
      setError(err.message || 'Erro ao criar balanço.');
    }
  };

  const handleSaveEdition = async () => {
    setError(null);
    setSuccess(null);
    if (!activeBalance) return;

    try {
      const updates: Partial<OperationalBalance> = {};
      
      if (canEditSection('resumo')) updates.resumoGeral = editResumo;
      if (canEditSection('dos')) updates.dos = editDos;
      if (canEditSection('dfc')) updates.dfc = editDfc;
      if (canEditSection('fal')) updates.fal = editFal;
      if (canEditSection('drcq')) updates.drcq = editDrcq;

      await api.updateBalance(user, activeBalance.id, updates);
      setSuccess('Seções salvas com sucesso!');
      setIsEditing(false);
      onRefresh();
    } catch (err: any) {
      setError(err.message || 'Erro ao guardar modificações.');
    }
  };

  const handleWorkflowAction = async (status: BalanceStatus) => {
    setWorkflowActionType(status);
    setWorkflowComment('');
    setShowWorkflowCommentBox(true);
  };

  const submitWorkflowAction = async () => {
    setError(null);
    setSuccess(null);
    if (!activeBalance || !workflowActionType) return;

    try {
      await api.submitWorkflow(user, activeBalance.id, workflowActionType, workflowComment);
      
      const statusLabels: Record<string, string> = {
        EM_REVISAO: 'Balanço submetido para revisão do Diretor.',
        APROVADO: 'Balanço operacional aprovado com sucesso!',
        CORRECAO_SOLICITADA: 'Pedido de correções enviado ao Secretariado.'
      };

      setSuccess(statusLabels[workflowActionType] || 'Fluxo de workflow atualizado.');
      setShowWorkflowCommentBox(false);
      onRefresh();
      
      // Update local logs
      const updatedLogs = await api.fetchWorkflowLogs(activeBalance.id);
      setWorkflowLogs(updatedLogs);
    } catch (err: any) {
      setError(err.message || 'Erro ao processar transição de workflow.');
    }
  };

  // Printing Layout
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* HEADER DO MÓDULO */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 print:hidden">
        <div className="space-y-1">
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Balanço Operacional das Últimas 24 Horas</h1>
          <p className="text-slate-500 text-sm">Consolidação, aprovação e controle de relatórios das divisões operacionais.</p>
        </div>

        <div className="flex items-center gap-2.5">
          {/* Permanent Upload Button */}
          <button
            onClick={() => setIsUploadOpen(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-black text-slate-800 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg shadow-xs transition-colors uppercase tracking-wider cursor-pointer"
          >
            <FileUp className="w-4 h-4 text-orange-600" /> Carregar Documento
          </button>

          {/* Create Button (Secretariat & Admin only) */}
          {(user.role === UserRole.SECRETARIADO || user.role === UserRole.ADMIN) && (
            <button
              onClick={() => setIsCreating(true)}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-lg shadow-sm transition-colors border border-sky-700"
            >
              <Plus className="w-4 h-4" /> Novo Balanço
            </button>
          )}

          {activeBalance && (
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-slate-700 bg-white hover:bg-slate-50 rounded-lg shadow-sm border border-slate-200 transition-colors"
            >
              <Printer className="w-4 h-4" /> Imprimir Oficial
            </button>
          )}
        </div>
      </div>

      {/* ALERTAS DE FEEDBACK */}
      {error && (
        <div className="bg-rose-50 border border-rose-200 text-rose-800 p-4 rounded-xl flex items-start gap-3 print:hidden">
          <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
          <div className="text-sm">
            <span className="font-bold">Aviso:</span> {error}
          </div>
        </div>
      )}

      {success && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded-xl flex items-start gap-3 print:hidden">
          <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
          <div className="text-sm">
            <span className="font-bold">Sucesso:</span> {success}
          </div>
        </div>
      )}

      {/* CREATION DIALOG OVERLAY */}
      {isCreating && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-md space-y-4 print:hidden">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-sky-600" /> Criar Novo Balanço Operacional Diário
            </h3>
            <button 
              onClick={() => setIsCreating(false)}
              className="text-slate-400 hover:text-slate-600 text-sm font-semibold"
            >
              Cancelar
            </button>
          </div>

          <form onSubmit={handleCreateBalance} className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-600 uppercase">Data do Balanço</label>
              <input 
                type="date"
                value={newDate}
                onChange={(e) => setNewDate(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
                required
              />
            </div>
            
            <div className="space-y-1.5 md:col-span-2">
              <label className="text-xs font-bold text-slate-600 uppercase">Resumo Executivo Inicial (Opcional)</label>
              <input 
                type="text"
                placeholder="Ex: Operações aeroportuárias decorreram com normalidade..."
                value={newResumo}
                onChange={(e) => setNewResumo(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
              />
            </div>

            <div className="md:col-span-3 flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsCreating(false)}
                className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-50 border border-slate-200 rounded-lg"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-lg border border-sky-700"
              >
                Confirmar Registro
              </button>
            </div>
          </form>
        </div>
      )}

      {/* PAINEL OPERACIONAL PRINCIPAL */}
      {activeBalance ? (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* SIDEBAR: SELETOR DE DATA E WORKFLOW STATUS */}
          <div className="space-y-4 print:hidden">
            {/* Lista de Balanços */}
            <div className="bg-white border border-slate-100 rounded-xl p-4 shadow-sm space-y-3">
              <h3 className="font-bold text-slate-800 text-xs uppercase tracking-wider">Histórico de Datas</h3>
              <div className="space-y-1 max-h-48 overflow-y-auto pr-1">
                {balances.map((b) => (
                  <button
                    key={b.id}
                    onClick={() => {
                      setSelectedBalanceId(b.id);
                      setIsEditing(false);
                      setActiveTab('resumo');
                    }}
                    className={`w-full text-left px-3 py-2.5 rounded-lg text-xs font-medium flex items-center justify-between transition-colors ${
                      b.id === activeBalance.id 
                        ? 'bg-sky-50 text-sky-800 border-l-4 border-sky-600' 
                        : 'text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <span className="font-semibold">{b.data}</span>
                    
                    {b.estado === BalanceStatus.APROVADO && (
                      <span className="text-[9px] font-black bg-emerald-50 text-emerald-700 px-1.5 py-0.5 rounded border border-emerald-200">APROVADO</span>
                    )}
                    {b.estado === BalanceStatus.EM_REVISAO && (
                      <span className="text-[9px] font-black bg-sky-50 text-sky-700 px-1.5 py-0.5 rounded border border-sky-200">REVISÃO</span>
                    )}
                    {b.estado === BalanceStatus.EM_ELABORACAO && (
                      <span className="text-[9px] font-black bg-slate-50 text-slate-600 px-1.5 py-0.5 rounded border border-slate-200">RASCO</span>
                    )}
                    {b.estado === BalanceStatus.CORRECAO_SOLICITADA && (
                      <span className="text-[9px] font-black bg-rose-50 text-rose-700 px-1.5 py-0.5 rounded border border-rose-200">CORREÇÃO</span>
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Workflow Control Box */}
            <div className="bg-white border border-slate-100 rounded-xl p-4 shadow-sm space-y-4">
              <h3 className="font-bold text-slate-800 text-xs uppercase tracking-wider border-b border-slate-50 pb-2 flex items-center gap-1.5">
                <CheckCircle className="w-4 h-4 text-sky-600" /> Estado de Aprovação
              </h3>

              {/* Status Indicator */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs font-medium">
                  <span className="text-slate-500">Estado Atual:</span>
                  <span className={`px-2 py-0.5 rounded-full font-bold border text-[10px] uppercase ${
                    activeBalance.estado === BalanceStatus.APROVADO ? 'bg-emerald-50 text-emerald-700 border-emerald-200' :
                    activeBalance.estado === BalanceStatus.EM_REVISAO ? 'bg-sky-50 text-sky-700 border-sky-200' :
                    activeBalance.estado === BalanceStatus.CORRECAO_SOLICITADA ? 'bg-rose-50 text-rose-700 border-rose-200' :
                    'bg-slate-50 text-slate-700 border-slate-200'
                  }`}>
                    {activeBalance.estado.replace('_', ' ')}
                  </span>
                </div>

                {activeBalance.aprovadoPor && (
                  <div className="text-[11px] text-slate-500 flex items-center gap-1">
                    <Check className="w-3.5 h-3.5 text-emerald-600" /> Aprovado por: <b>{activeBalance.aprovadoPor}</b>
                  </div>
                )}
                
                {activeBalance.revisadoPor && (
                  <div className="text-[11px] text-slate-500 flex items-center gap-1">
                    <User className="w-3.5 h-3.5 text-sky-600" /> Consolidado por: <b>{activeBalance.revisadoPor}</b>
                  </div>
                )}
              </div>

              {/* Workflow Actions Buttons based on user roles */}
              <div className="space-y-2 pt-2 border-t border-slate-50">
                {/* 1. Secretariat can submit Draft/Correction back to review */}
                {(user.role === UserRole.SECRETARIADO || user.role === UserRole.ADMIN) && 
                 (activeBalance.estado === BalanceStatus.EM_ELABORACAO || activeBalance.estado === BalanceStatus.CORRECAO_SOLICITADA) && (
                  <button
                    onClick={() => handleWorkflowAction(BalanceStatus.EM_REVISAO)}
                    className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-lg shadow-sm transition-colors border border-sky-700"
                  >
                    <Send className="w-3.5 h-3.5" /> Submeter para Aprovação
                  </button>
                )}

                {/* 2. Director can Approve or Request Corrections */}
                {(user.role === UserRole.DIRETOR || user.role === UserRole.ADMIN) && 
                 (activeBalance.estado === BalanceStatus.EM_REVISAO) && (
                  <div className="space-y-2">
                    <button
                      onClick={() => handleWorkflowAction(BalanceStatus.APROVADO)}
                      className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-sm transition-colors border border-emerald-700"
                    >
                      <CheckCircle className="w-3.5 h-3.5" /> Aprovar Balanço
                    </button>
                    
                    <button
                      onClick={() => handleWorkflowAction(BalanceStatus.CORRECAO_SOLICITADA)}
                      className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-bold text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-lg border border-rose-200 transition-colors"
                    >
                      <XCircle className="w-3.5 h-3.5" /> Solicitar Correções
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Workflow logs quick view */}
            <div className="bg-white border border-slate-100 rounded-xl p-4 shadow-sm space-y-3">
              <h3 className="font-bold text-slate-800 text-xs uppercase tracking-wider">Histórico de Fluxo</h3>
              <div className="space-y-3 max-h-48 overflow-y-auto pr-1">
                {workflowLogs.map((log) => (
                  <div key={log.id} className="text-[11px] border-l-2 border-slate-200 pl-2.5 py-0.5 space-y-0.5">
                    <div className="flex items-center justify-between text-slate-400">
                      <span>{log.utilizador}</span>
                      <span>{new Date(log.data).toLocaleDateString()}</span>
                    </div>
                    <p className="text-slate-700 font-semibold">{log.deEstado} → {log.paraEstado}</p>
                    {log.comentario && <p className="text-slate-500 italic">"{log.comentario}"</p>}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* ACTIVE CONTENT WORKSPACE */}
          <div className="lg:col-span-3 bg-white border border-slate-100 rounded-xl shadow-sm overflow-hidden flex flex-col justify-between min-h-[500px]">
            {/* CORRECTION WARNING BOX AT TOP */}
            {activeBalance.estado === BalanceStatus.CORRECAO_SOLICITADA && activeBalance.comentariosRevisao && (
              <div className="bg-rose-50 border-b border-rose-100 p-4 flex gap-3 text-rose-900 print:hidden">
                <AlertCircle className="w-5 h-5 text-rose-600 mt-0.5 shrink-0" />
                <div className="text-xs space-y-1">
                  <span className="font-bold block uppercase tracking-wider text-[10px]">Correções Solicitadas pelo Diretor:</span>
                  <p className="italic font-medium">"{activeBalance.comentariosRevisao}"</p>
                </div>
              </div>
            )}

            {/* TABS NAVIGATION */}
            <div className="border-b border-slate-100 flex overflow-x-auto print:hidden">
              <button
                onClick={() => setActiveTab('resumo')}
                className={`px-5 py-4 text-xs font-bold uppercase tracking-wider border-b-2 transition-all ${
                  activeTab === 'resumo' 
                    ? 'border-sky-600 text-sky-700 bg-sky-50/20' 
                    : 'border-transparent text-slate-500 hover:text-slate-800 hover:bg-slate-50/50'
                }`}
              >
                Resumo Geral
              </button>
              <button
                onClick={() => setActiveTab('dos')}
                className={`px-5 py-4 text-xs font-bold uppercase tracking-wider border-b-2 transition-all flex items-center gap-1.5 ${
                  activeTab === 'dos' 
                    ? 'border-sky-600 text-sky-700 bg-sky-50/20' 
                    : 'border-transparent text-slate-500 hover:text-slate-800 hover:bg-slate-50/50'
                }`}
              >
                <span>DOS</span>
                {!canEditSection('dos') && <Lock className="w-3 h-3 text-slate-400" />}
              </button>
              <button
                onClick={() => setActiveTab('dfc')}
                className={`px-5 py-4 text-xs font-bold uppercase tracking-wider border-b-2 transition-all flex items-center gap-1.5 ${
                  activeTab === 'dfc' 
                    ? 'border-sky-600 text-sky-700 bg-sky-50/20' 
                    : 'border-transparent text-slate-500 hover:text-slate-800 hover:bg-slate-50/50'
                }`}
              >
                <span>DFC</span>
                {!canEditSection('dfc') && <Lock className="w-3 h-3 text-slate-400" />}
              </button>
              <button
                onClick={() => setActiveTab('fal')}
                className={`px-5 py-4 text-xs font-bold uppercase tracking-wider border-b-2 transition-all flex items-center gap-1.5 ${
                  activeTab === 'fal' 
                    ? 'border-sky-600 text-sky-700 bg-sky-50/20' 
                    : 'border-transparent text-slate-500 hover:text-slate-800 hover:bg-slate-50/50'
                }`}
              >
                <span>FAL</span>
                {!canEditSection('fal') && <Lock className="w-3 h-3 text-slate-400" />}
              </button>
              <button
                onClick={() => setActiveTab('drcq')}
                className={`px-5 py-4 text-xs font-bold uppercase tracking-wider border-b-2 transition-all flex items-center gap-1.5 ${
                  activeTab === 'drcq' 
                    ? 'border-sky-600 text-sky-700 bg-sky-50/20' 
                    : 'border-transparent text-slate-500 hover:text-slate-800 hover:bg-slate-50/50'
                }`}
              >
                <span>DRCQ</span>
                {!canEditSection('drcq') && <Lock className="w-3 h-3 text-slate-400" />}
              </button>
            </div>

            {/* EDIT STATUS BANNER */}
            <div className="bg-slate-50/50 border-b border-slate-100 px-6 py-3 flex items-center justify-between text-xs text-slate-500 print:hidden">
              <div className="flex items-center gap-1.5 font-medium">
                <User className="w-4 h-4 text-slate-400" />
                <span>Registado por: <b>{activeBalance.criadoPor}</b></span>
                <span className="text-slate-300">|</span>
                <span>Última atualização: {new Date(activeBalance.dataAtualizacao).toLocaleString()}</span>
              </div>

              {!isEditing && activeBalance.estado !== BalanceStatus.APROVADO && (
                <button
                  onClick={() => setIsEditing(true)}
                  className="text-sky-600 hover:text-sky-800 font-bold flex items-center gap-1"
                >
                  <Edit3 className="w-3.5 h-3.5" /> Editar Informações
                </button>
              )}
            </div>

            {/* TAB PANELS */}
            <div className="p-6 flex-1 space-y-6">
              
              {/* TAB 1: RESUMO EXEC */}
              {activeTab === 'resumo' && (
                <div className="space-y-4">
                  <div className="border-l-4 border-sky-600 pl-4 space-y-1">
                    <h2 className="text-lg font-bold text-slate-800">Resumo Executivo Geral</h2>
                    <p className="text-xs text-slate-500">Síntese de alto nível sobre a atividade diária DFS.</p>
                  </div>
                  
                  {isEditing && canEditSection('resumo') ? (
                    <textarea
                      value={editResumo}
                      onChange={(e) => setEditResumo(e.target.value)}
                      rows={6}
                      className="w-full p-3 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 font-sans"
                      placeholder="Insira as principais considerações sobre as últimas 24h..."
                    />
                  ) : (
                    <p className="text-slate-700 text-sm leading-relaxed whitespace-pre-wrap bg-slate-50/50 border border-slate-100 p-4 rounded-xl font-medium">
                      {activeBalance.resumoGeral || 'Nenhum resumo executivo preenchido até ao momento.'}
                    </p>
                  )}
                </div>
              )}

              {/* TAB 2: DOS (Operações e Segurança) */}
              {activeTab === 'dos' && (
                <div className="space-y-4">
                  <div className="border-l-4 border-sky-600 pl-4 space-y-1">
                    <h2 className="text-lg font-bold text-slate-800">Divisão de Operações e Segurança (DOS)</h2>
                    <p className="text-xs text-slate-500">Registo de anomalias perimetrais, pista, avifauna e terminais.</p>
                  </div>

                  <div className="grid grid-cols-1 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-600 uppercase">Ocorrências de Segurança e Intrusões</label>
                      {isEditing && canEditSection('dos') ? (
                        <textarea
                          value={editDos.ocorrenciasSeguranca}
                          onChange={(e) => setEditDos({ ...editDos, ocorrenciasSeguranca: e.target.value })}
                          rows={2}
                          className="w-full p-2.5 text-sm border border-slate-200 rounded-lg focus:outline-none"
                        />
                      ) : (
                        <div className="p-3 bg-slate-50 rounded-lg text-sm text-slate-700">{activeBalance.dos?.ocorrenciasSeguranca || 'Sem registos.'}</div>
                      )}
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-600 uppercase">Estado da Pista e Caminhos de Circulação (FOD)</label>
                      {isEditing && canEditSection('dos') ? (
                        <input
                          type="text"
                          value={editDos.estadoPistaTaxiways}
                          onChange={(e) => setEditDos({ ...editDos, estadoPistaTaxiways: e.target.value })}
                          className="w-full p-2.5 text-sm border border-slate-200 rounded-lg focus:outline-none"
                        />
                      ) : (
                        <div className="p-3 bg-slate-50 rounded-lg text-sm text-slate-700">{activeBalance.dos?.estadoPistaTaxiways || 'Sem registos.'}</div>
                      )}
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-600 uppercase">Incidentes e Atividades de Avifauna / Fauna</label>
                      {isEditing && canEditSection('dos') ? (
                        <textarea
                          value={editDos.atividadesFauna}
                          onChange={(e) => setEditDos({ ...editDos, atividadesFauna: e.target.value })}
                          rows={2}
                          className="w-full p-2.5 text-sm border border-slate-200 rounded-lg focus:outline-none"
                        />
                      ) : (
                        <div className="p-3 bg-slate-50 rounded-lg text-sm text-slate-700">{activeBalance.dos?.atividadesFauna || 'Sem registos.'}</div>
                      )}
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-600 uppercase">Status dos Terminais e Equipamentos de Suporte</label>
                      {isEditing && canEditSection('dos') ? (
                        <input
                          type="text"
                          value={editDos.statusTerminaisEquipamentos}
                          onChange={(e) => setEditDos({ ...editDos, statusTerminaisEquipamentos: e.target.value })}
                          className="w-full p-2.5 text-sm border border-slate-200 rounded-lg focus:outline-none"
                        />
                      ) : (
                        <div className="p-3 bg-slate-50 rounded-lg text-sm text-slate-700">{activeBalance.dos?.statusTerminaisEquipamentos || 'Sem registos.'}</div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: DFC (Facilitação e Controle) */}
              {activeTab === 'dfc' && (
                <div className="space-y-4">
                  <div className="border-l-4 border-sky-600 pl-4 space-y-1">
                    <h2 className="text-lg font-bold text-slate-800">Divisão de Facilitação e Controle (DFC)</h2>
                    <p className="text-xs text-slate-500">Fluxos migratórios, tratamento de bagagens e conformidade de embarque.</p>
                  </div>

                  <div className="grid grid-cols-1 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-600 uppercase">Controle de Fronteira e Migrações (Tempos de Espera)</label>
                      {isEditing && canEditSection('dfc') ? (
                        <input
                          type="text"
                          value={editDfc.controleFronteiras}
                          onChange={(e) => setEditDfc({ ...editDfc, controleFronteiras: e.target.value })}
                          className="w-full p-2.5 text-sm border border-slate-200 rounded-lg focus:outline-none"
                        />
                      ) : (
                        <div className="p-3 bg-slate-50 rounded-lg text-sm text-slate-700">{activeBalance.dfc?.controleFronteiras || 'Sem registos.'}</div>
                      )}
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-600 uppercase">Tratamento e Reclamações de Bagagens (Sistemas/Tapetes)</label>
                      {isEditing && canEditSection('dfc') ? (
                        <textarea
                          value={editDfc.reclamacoesBagagens}
                          onChange={(e) => setEditDfc({ ...editDfc, reclamacoesBagagens: e.target.value })}
                          rows={2}
                          className="w-full p-2.5 text-sm border border-slate-200 rounded-lg focus:outline-none"
                        />
                      ) : (
                        <div className="p-3 bg-slate-50 rounded-lg text-sm text-slate-700">{activeBalance.dfc?.reclamacoesBagagens || 'Sem registos.'}</div>
                      )}
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-600 uppercase">Status do Sistema de Check-in e Filas de Embarque</label>
                      {isEditing && canEditSection('dfc') ? (
                        <textarea
                          value={editDfc.filasCheckIn}
                          onChange={(e) => setEditDfc({ ...editDfc, filasCheckIn: e.target.value })}
                          rows={2}
                          className="w-full p-2.5 text-sm border border-slate-200 rounded-lg focus:outline-none"
                        />
                      ) : (
                        <div className="p-3 bg-slate-50 rounded-lg text-sm text-slate-700">{activeBalance.dfc?.filasCheckIn || 'Sem registos.'}</div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 4: FAL (Facilitação e Regulamentação) */}
              {activeTab === 'fal' && (
                <div className="space-y-4">
                  <div className="border-l-4 border-sky-600 pl-4 space-y-1">
                    <h2 className="text-lg font-bold text-slate-800">Divisão de Facilitação e Regulamentação (FAL)</h2>
                    <p className="text-xs text-slate-500">Assistência a passageiros vulneráveis, apoio médico e conformidade ICAO.</p>
                  </div>

                  <div className="grid grid-cols-1 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-600 uppercase">Assistência PMR (Passageiros de Mobilidade Reduzida)</label>
                      {isEditing && canEditSection('fal') ? (
                        <input
                          type="text"
                          value={editFal.acessibilidadePMR}
                          onChange={(e) => setEditFal({ ...editFal, acessibilidadePMR: e.target.value })}
                          className="w-full p-2.5 text-sm border border-slate-200 rounded-lg focus:outline-none"
                        />
                      ) : (
                        <div className="p-3 bg-slate-50 rounded-lg text-sm text-slate-700">{activeBalance.fal?.acessibilidadePMR || 'Sem registos.'}</div>
                      )}
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-600 uppercase">Ocorrências de Assistência Médica Urgente</label>
                      {isEditing && canEditSection('fal') ? (
                        <textarea
                          value={editFal.assistenciaMedica}
                          onChange={(e) => setEditFal({ ...editFal, assistenciaMedica: e.target.value })}
                          rows={2}
                          className="w-full p-2.5 text-sm border border-slate-200 rounded-lg focus:outline-none"
                        />
                      ) : (
                        <div className="p-3 bg-slate-50 rounded-lg text-sm text-slate-700">{activeBalance.fal?.assistenciaMedica || 'Sem registos.'}</div>
                      )}
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-600 uppercase">Feedback, Queixas e Elogios dos Utentes</label>
                      {isEditing && canEditSection('fal') ? (
                        <textarea
                          value={editFal.feedbackPassageiros}
                          onChange={(e) => setEditFal({ ...editFal, feedbackPassageiros: e.target.value })}
                          rows={2}
                          className="w-full p-2.5 text-sm border border-slate-200 rounded-lg focus:outline-none"
                        />
                      ) : (
                        <div className="p-3 bg-slate-50 rounded-lg text-sm text-slate-700">{activeBalance.fal?.feedbackPassageiros || 'Sem registos.'}</div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 5: DRCQ (Conformidade e Qualidade) */}
              {activeTab === 'drcq' && (
                <div className="space-y-4">
                  <div className="border-l-4 border-sky-600 pl-4 space-y-1">
                    <h2 className="text-lg font-bold text-slate-800">Divisão de Regulação, Conformidade e Qualidade (DRCQ)</h2>
                    <p className="text-xs text-slate-500">Auditorias, deteção de não-conformidades regulamentares e mitigação de risco.</p>
                  </div>

                  <div className="grid grid-cols-1 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-600 uppercase">Inspeções Técnicas e Auditorias de Rampas</label>
                      {isEditing && canEditSection('drcq') ? (
                        <input
                          type="text"
                          value={editDrcq.auditoriasInspecoes}
                          onChange={(e) => setEditDrcq({ ...editDrcq, auditoriasInspecoes: e.target.value })}
                          className="w-full p-2.5 text-sm border border-slate-200 rounded-lg focus:outline-none"
                        />
                      ) : (
                        <div className="p-3 bg-slate-50 rounded-lg text-sm text-slate-700">{activeBalance.drcq?.auditoriasInspecoes || 'Sem registos.'}</div>
                      )}
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-600 uppercase">Não-Conformidades Detetadas (Registos de SLA)</label>
                      {isEditing && canEditSection('drcq') ? (
                        <textarea
                          value={editDrcq.naoConformidadesDetetadas}
                          onChange={(e) => setEditDrcq({ ...editDrcq, naoConformidadesDetetadas: e.target.value })}
                          rows={2}
                          className="w-full p-2.5 text-sm border border-slate-200 rounded-lg focus:outline-none"
                        />
                      ) : (
                        <div className="p-3 bg-slate-50 rounded-lg text-sm text-slate-700">{activeBalance.drcq?.naoConformidadesDetetadas || 'Sem registos.'}</div>
                      )}
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-600 uppercase">Ações Preventivas de Mitigação de Risco</label>
                      {isEditing && canEditSection('drcq') ? (
                        <textarea
                          value={editDrcq.acoesPreventivasRecomendadas}
                          onChange={(e) => setEditDrcq({ ...editDrcq, acoesPreventivasRecomendadas: e.target.value })}
                          rows={2}
                          className="w-full p-2.5 text-sm border border-slate-200 rounded-lg focus:outline-none"
                        />
                      ) : (
                        <div className="p-3 bg-slate-50 rounded-lg text-sm text-slate-700">{activeBalance.drcq?.acoesPreventivasRecomendadas || 'Sem registos.'}</div>
                      )}
                    </div>
                  </div>
                </div>
              )}

            </div>

            {/* SAVE BUTTON FOOTER */}
            {isEditing && (
              <div className="border-t border-slate-100 p-4 bg-slate-50/50 flex justify-end gap-2 print:hidden">
                <button
                  onClick={() => setIsEditing(false)}
                  className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors"
                >
                  Cancelar
                </button>
                <button
                  onClick={handleSaveEdition}
                  className="px-4 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-lg border border-sky-700 shadow-sm transition-colors flex items-center gap-1.5"
                >
                  <Save className="w-4 h-4" /> Guardar Alterações
                </button>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="bg-white border border-slate-100 rounded-xl p-12 text-center text-slate-400 space-y-3">
          <FileText className="w-12 h-12 text-slate-300 mx-auto" />
          <h3 className="font-bold text-slate-700 text-lg">Nenhum Balanço Registado</h3>
          <p className="text-sm text-slate-400 max-w-md mx-auto">Registe a primeira entrada diária operacional DFS a partir do botão acima.</p>
        </div>
      )}

      {/* WORKFLOW COMMENT MODAL DIALOG */}
      {showWorkflowCommentBox && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50 print:hidden">
          <div className="bg-white border border-slate-200 rounded-xl max-w-md w-full p-6 shadow-xl space-y-4">
            <h3 className="text-base font-bold text-slate-800 flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-sky-600" /> Confirmar Ação no Fluxo de Trabalho
            </h3>
            
            <p className="text-xs text-slate-500">
              Esta ação alterará o estado do Balanço Operacional ({activeBalance?.data}) para: 
              <b className="text-slate-800 block uppercase mt-1">
                {workflowActionType?.replace('_', ' ')}
              </b>
            </p>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-600 uppercase">Comentários / Justificativa</label>
              <textarea
                value={workflowComment}
                onChange={(e) => setWorkflowComment(e.target.value)}
                rows={3}
                placeholder="Introduza detalhes adicionais de aprovação ou correções requeridas..."
                className="w-full p-2.5 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500/10"
              />
            </div>

            <div className="flex justify-end gap-2">
              <button
                onClick={() => setShowWorkflowCommentBox(false)}
                className="px-4 py-2 text-xs font-bold text-slate-500 hover:bg-slate-50 rounded-lg border border-slate-200"
              >
                Cancelar
              </button>
              <button
                onClick={submitWorkflowAction}
                className="px-4 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-lg shadow-sm border border-sky-700"
              >
                Confirmar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* --- PRINT TEMPLATE VIEW (HIDDEN ON SCREEN, REVEALED ON WINDOW.PRINT()) --- */}
      {activeBalance && (
        <div className="hidden print:block space-y-8 p-10 bg-white text-slate-900 font-sans">
          
          {/* Print Header */}
          <div className="flex justify-between items-center border-b-2 border-sky-600 pb-5">
            <div className="flex items-center gap-4">
              <Logo size="md" variant="light" showSlogan={true} />
            </div>
            
            <div className="text-right">
              <h2 className="text-lg font-extrabold text-slate-800">BALANÇO OPERACIONAL DIÁRIO</h2>
              <p className="text-xs font-bold text-sky-600 uppercase tracking-widest mt-1">Últimas 24 Horas</p>
              <p className="text-sm font-bold text-slate-700 mt-0.5">DATA: {activeBalance.data}</p>
            </div>
          </div>

          {/* Slogan Banner */}
          <div className="bg-sky-50 border border-sky-100 p-4 rounded-lg flex justify-between items-center text-xs">
            <span className="font-bold text-sky-800 text-sm">ATO & OC, SA</span>
            <span className="font-bold text-sky-600 italic">"Seu Destino, Nossa Missão"</span>
          </div>

          {/* Resumo Geral */}
          <div className="space-y-2">
            <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider border-b border-slate-200 pb-1">1. RESUMO OPERACIONAL EXECUTIVO</h3>
            <p className="text-xs text-slate-700 leading-relaxed whitespace-pre-wrap">{activeBalance.resumoGeral || 'Nenhum resumo preenchido.'}</p>
          </div>

          {/* Seção DOS */}
          <div className="space-y-3 pt-2">
            <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider border-b border-slate-200 pb-1">2. DIVISÃO DE OPERAÇÕES E SEGURANÇA (DOS)</h3>
            <div className="grid grid-cols-1 gap-2.5 text-xs text-slate-700">
              <div>
                <b className="block text-[10px] text-slate-500 uppercase">2.1 Ocorrências de Segurança e Intrusões:</b>
                <p className="mt-0.5">{activeBalance.dos?.ocorrenciasSeguranca || 'Sem ocorrências.'}</p>
              </div>
              <div>
                <b className="block text-[10px] text-slate-500 uppercase">2.2 Estado de Pistas e Caminhos de Circulação:</b>
                <p className="mt-0.5">{activeBalance.dos?.estadoPistaTaxiways || 'Operacional.'}</p>
              </div>
              <div>
                <b className="block text-[10px] text-slate-500 uppercase">2.3 Avifauna e Fauna:</b>
                <p className="mt-0.5">{activeBalance.dos?.atividadesFauna || 'Sem incidentes.'}</p>
              </div>
              <div>
                <b className="block text-[10px] text-slate-500 uppercase">2.4 Terminais e Sistemas Técnicos:</b>
                <p className="mt-0.5">{activeBalance.dos?.statusTerminaisEquipamentos || 'Tudo operacional.'}</p>
              </div>
            </div>
          </div>

          {/* Seção DFC */}
          <div className="space-y-3 pt-2 page-break-before">
            <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider border-b border-slate-200 pb-1">3. DIVISÃO DE FACILITAÇÃO E CONTROLE (DFC)</h3>
            <div className="grid grid-cols-1 gap-2.5 text-xs text-slate-700">
              <div>
                <b className="block text-[10px] text-slate-500 uppercase">3.1 Fluxos de Fronteira e Migrações:</b>
                <p className="mt-0.5">{activeBalance.dfc?.controleFronteiras || 'Fluido.'}</p>
              </div>
              <div>
                <b className="block text-[10px] text-slate-500 uppercase">3.2 Reclamações de Bagagens / Sistemas:</b>
                <p className="mt-0.5">{activeBalance.dfc?.reclamacoesBagagens || 'Sem queixas.'}</p>
              </div>
              <div>
                <b className="block text-[10px] text-slate-500 uppercase">3.3 Check-in e Filas de Embarque:</b>
                <p className="mt-0.5">{activeBalance.dfc?.filasCheckIn || 'Fluido.'}</p>
              </div>
            </div>
          </div>

          {/* Seção FAL */}
          <div className="space-y-3 pt-2">
            <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider border-b border-slate-200 pb-1">4. DIVISÃO DE FACILITAÇÃO E REGULAMENTAÇÃO (FAL)</h3>
            <div className="grid grid-cols-1 gap-2.5 text-xs text-slate-700">
              <div>
                <b className="block text-[10px] text-slate-500 uppercase">4.1 Acessibilidade PMR:</b>
                <p className="mt-0.5">{activeBalance.fal?.acessibilidadePMR || 'Sem queixas.'}</p>
              </div>
              <div>
                <b className="block text-[10px] text-slate-500 uppercase">4.2 Assistência Médica:</b>
                <p className="mt-0.5">{activeBalance.fal?.assistenciaMedica || 'Sem ocorrências.'}</p>
              </div>
              <div>
                <b className="block text-[10px] text-slate-500 uppercase">4.3 Queixas e Sugestões dos Passageiros:</b>
                <p className="mt-0.5">{activeBalance.fal?.feedbackPassageiros || 'Sem registos.'}</p>
              </div>
            </div>
          </div>

          {/* Seção DRCQ */}
          <div className="space-y-3 pt-2">
            <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider border-b border-slate-200 pb-1">5. CONFORMIDADE, REGULAÇÃO E QUALIDADE (DRCQ)</h3>
            <div className="grid grid-cols-1 gap-2.5 text-xs text-slate-700">
              <div>
                <b className="block text-[10px] text-slate-500 uppercase">5.1 Inspeções Técnicas e Auditorias:</b>
                <p className="mt-0.5">{activeBalance.drcq?.auditoriasInspecoes || 'Em conformidade.'}</p>
              </div>
              <div>
                <b className="block text-[10px] text-slate-500 uppercase">5.2 Não-Conformidades Detetadas:</b>
                <p className="mt-0.5">{activeBalance.drcq?.naoConformidadesDetetadas || 'Nenhuma.'}</p>
              </div>
            </div>
          </div>

          {/* Signature Block */}
          <div className="grid grid-cols-2 gap-8 pt-12 text-center text-xs">
            <div className="space-y-12">
              <p className="font-bold text-slate-500 uppercase tracking-widest text-[10px]">CONSOLIDADO POR</p>
              <div className="border-t border-slate-300 mx-10 pt-2">
                <p className="font-bold text-slate-800">{activeBalance.criadoPor}</p>
                <p className="text-[10px] text-slate-400 font-semibold uppercase">Secretariado DFS</p>
              </div>
            </div>
            
            <div className="space-y-12">
              <p className="font-bold text-slate-500 uppercase tracking-widest text-[10px]">REVISADO E APROVADO POR</p>
              <div className="border-t border-slate-300 mx-10 pt-2">
                <p className="font-bold text-slate-800">{activeBalance.aprovadoPor || '_______________________________'}</p>
                <p className="text-[10px] text-slate-400 font-semibold uppercase">Diretor DFS</p>
              </div>
            </div>
          </div>

          {/* Footer of print page */}
          <div className="text-center pt-8 border-t border-slate-100 text-[10px] text-slate-400 font-mono flex justify-between items-center">
            <span>ATO & OC, SA — SIGO-DFS</span>
            <span>DATA IMPRESSÃO: {new Date().toLocaleDateString()}</span>
          </div>

        </div>
      )}

      {/* Global Upload Center Modal Integration */}
      <UploadCenterModal 
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        user={user}
        onUploadSuccess={() => {
          setIsUploadOpen(false);
          onRefresh();
        }}
        preselectedBalanceId={selectedBalanceId}
      />
    </div>
  );
}
