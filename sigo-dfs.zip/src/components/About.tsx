import React from 'react';
import Logo from './Logo.js';
import { Shield, Plane, HelpCircle, Building2, MapPin, Globe, Mail } from 'lucide-react';

export default function About() {
  return (
    <div className="space-y-6">
      {/* Hero Header */}
      <div className="bg-white border border-slate-100 rounded-xl p-8 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-4 max-w-2xl">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-sky-50 text-sky-700 border border-sky-100">
            <Plane className="w-3 h-3 animate-pulse" /> Plataforma Digital de Inteligência Operacional
          </span>
          <h1 className="text-3xl font-bold tracking-tight text-slate-900">
            Sobre o SIGO-DFS
          </h1>
          <p className="text-slate-600 leading-relaxed text-sm md:text-base">
            O Sistema Integrado de Gestão Operacional da Direção de Facilitação e Segurança (SIGO-DFS) foi concebido para centralizar, analisar e gerir toda a atividade operacional aeroportuária da ATO & OC, SA. Digitaliza a recolha diária de dados, agiliza fluxos de aprovação e unifica o conhecimento institucional da Direção.
          </p>
        </div>
        <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 flex items-center justify-center">
          <Logo size="lg" variant="light" showSlogan={true} />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Mission Card */}
        <div className="bg-white border border-slate-100 rounded-xl p-6 shadow-sm hover:shadow-md transition-all space-y-4">
          <div className="w-10 h-10 rounded-lg bg-sky-50 text-sky-600 flex items-center justify-center border border-sky-100">
            <Shield className="w-5 h-5" />
          </div>
          <h3 className="text-lg font-bold text-slate-800">Nossa Missão</h3>
          <p className="text-slate-600 text-sm leading-relaxed">
            Assegurar a facilitação eficiente do fluxo de passageiros e garantir os mais altos padrões de segurança em toda a infraestrutura aeroportuária, agilizando processos diários e promovendo a melhoria contínua através de decisões baseadas em dados em tempo real.
          </p>
        </div>

        {/* Vision Card */}
        <div className="bg-white border border-slate-100 rounded-xl p-6 shadow-sm hover:shadow-md transition-all space-y-4">
          <div className="w-10 h-10 rounded-lg bg-sky-50 text-sky-600 flex items-center justify-center border border-sky-100">
            <Plane className="w-5 h-5" />
          </div>
          <h3 className="text-lg font-bold text-slate-800">Visão de Futuro</h3>
          <p className="text-slate-600 text-sm leading-relaxed">
            Evoluir para uma plataforma de Inteligência Artificial Operacional capaz de prever congestionamentos de fluxo, detetar automaticamente não-conformidades a partir de relatórios externos e preencher de forma 100% automatizada relatórios executivos para a Direção Executiva.
          </p>
        </div>

        {/* Structure Card */}
        <div className="bg-white border border-slate-100 rounded-xl p-6 shadow-sm hover:shadow-md transition-all space-y-4">
          <div className="w-10 h-10 rounded-lg bg-sky-50 text-sky-600 flex items-center justify-center border border-sky-100">
            <Building2 className="w-5 h-5" />
          </div>
          <h3 className="text-lg font-bold text-slate-800">Divisões Operacionais</h3>
          <ul className="text-slate-600 text-sm space-y-2 list-none">
            <li className="flex items-center gap-2">
              <span className="font-bold text-sky-600 text-xs bg-sky-50 px-1.5 py-0.5 rounded border border-sky-100">DOS</span>
              <span>Operações e Segurança</span>
            </li>
            <li className="flex items-center gap-2">
              <span className="font-bold text-sky-600 text-xs bg-sky-50 px-1.5 py-0.5 rounded border border-sky-100">DFC</span>
              <span>Facilitação e Controle</span>
            </li>
            <li className="flex items-center gap-2">
              <span className="font-bold text-sky-600 text-xs bg-sky-50 px-1.5 py-0.5 rounded border border-sky-100">FAL</span>
              <span>Facilitação e Regulamentação</span>
            </li>
            <li className="flex items-center gap-2">
              <span className="font-bold text-sky-600 text-xs bg-sky-50 px-1.5 py-0.5 rounded border border-sky-100">DRCQ</span>
              <span>Conformidade e Qualidade</span>
            </li>
          </ul>
        </div>
      </div>

      {/* Corporate Metadata Footer */}
      <div className="bg-slate-900 text-slate-300 rounded-xl p-8 border border-slate-800 flex flex-col md:flex-row gap-8 justify-between">
        <div className="space-y-4">
          <h4 className="text-white font-bold text-lg">Entidade Gestora</h4>
          <div className="space-y-2 text-sm text-slate-400">
            <div className="flex items-center gap-2">
              <Building2 className="w-4 h-4 text-sky-400" />
              <span>ATO & OC, SA</span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-sky-400" />
              <span>Aeroporto Internacional Dr. António Agostinho Neto (AIAAN)</span>
            </div>
            <div className="flex items-center gap-2">
              <Globe className="w-4 h-4 text-sky-400" />
              <span>Luanda, Angola</span>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <h4 className="text-white font-bold text-lg">Suporte ao Utilizador</h4>
          <div className="space-y-2 text-sm text-slate-400">
            <div className="flex items-center gap-2">
              <Mail className="w-4 h-4 text-sky-400" />
              <span>suporte.sigo@ato-oc.co.ao</span>
            </div>
            <div className="flex items-center gap-2">
              <HelpCircle className="w-4 h-4 text-sky-400" />
              <span>Extensão Interna DFS: 4410 / 4412</span>
            </div>
          </div>
        </div>

        <div className="border-t border-slate-800 pt-6 md:border-none md:pt-0 flex flex-col justify-end items-start md:items-end gap-2">
          <Logo size="sm" variant="white" showSlogan={false} />
          <p className="text-xs text-slate-500">
            © 2026 ATO & OC, SA. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </div>
  );
}
