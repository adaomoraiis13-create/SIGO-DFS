import React, { useState } from 'react';
import { 
  Building2, 
  Plus, 
  Check, 
  Mail, 
  Phone, 
  ShieldCheck, 
  Power, 
  User, 
  X,
  Palette
} from 'lucide-react';

export default function AdminDivisions() {
  const [divisions, setDivisions] = useState([
    { id: 'DOS', name: 'Divisão de Operações e Segurança', sigla: 'DOS', responsavel: 'Eng. António Bunga', cor: '#0284c7', estado: 'Ativa', email: 'antonio.bunga.dos@ato-oc.co.ao', telefone: '+244 923 000 101' },
    { id: 'DFC', name: 'Divisão de Facilitação e Controle', sigla: 'DFC', responsavel: 'Dra. Isabel Cassule', cor: '#f59e0b', estado: 'Ativa', email: 'isabel.cassule.dfc@ato-oc.co.ao', telefone: '+244 923 000 102' },
    { id: 'FAL', name: 'Divisão de Facilitação / Regulamentação', sigla: 'FAL', responsavel: 'Dr. Manuel Mendes', cor: '#10b981', estado: 'Ativa', email: 'manuel.mendes.fal@ato-oc.co.ao', telefone: '+244 923 000 103' },
    { id: 'DRCQ', name: 'Divisão de Regulação e Qualidade', sigla: 'DRCQ', responsavel: 'Eng. Sofia Martins', cor: '#8b5cf6', estado: 'Ativa', email: 'sofia.martins.drcq@ato-oc.co.ao', telefone: '+244 923 000 104' },
    { id: 'DFS', name: 'Direção Geral de Facilitação e Segurança', sigla: 'DFS', responsavel: 'Dr. Valdemar Neto', cor: '#0f172a', estado: 'Ativa', email: 'valdemar.neto@ato-oc.co.ao', telefone: '+244 923 000 100' },
  ]);

  const [showAddModal, setShowAddModal] = useState(false);
  const [newDiv, setNewDiv] = useState({
    name: '',
    sigla: '',
    responsavel: '',
    cor: '#0ea5e9',
    estado: 'Ativa',
    email: '',
    telefone: ''
  });

  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const handleAddDivision = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDiv.name || !newDiv.sigla) return;

    const added = {
      id: newDiv.sigla.toUpperCase(),
      name: newDiv.name,
      sigla: newDiv.sigla.toUpperCase(),
      responsavel: newDiv.responsavel || 'A Nomear',
      cor: newDiv.cor,
      estado: newDiv.estado,
      email: newDiv.email || `info.${newDiv.sigla.toLowerCase()}@ato-oc.co.ao`,
      telefone: newDiv.telefone || '+244 923 000 000'
    };

    setDivisions(prev => [...prev, added]);
    setShowAddModal(false);
    setSuccessMsg(`Divisão ${added.sigla} registada com sucesso.`);
    setTimeout(() => setSuccessMsg(null), 3000);

    setNewDiv({
      name: '',
      sigla: '',
      responsavel: '',
      cor: '#0ea5e9',
      estado: 'Ativa',
      email: '',
      telefone: ''
    });
  };

  const toggleDivisionState = (id: string) => {
    setDivisions(prev => prev.map(d => {
      if (d.id === id) {
        const nextState = d.estado === 'Ativa' ? 'Inativa' : 'Ativa';
        return { ...d, estado: nextState };
      }
      return d;
    }));
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* HEADER CONTROLS */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div className="space-y-0.5">
          <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
            <Building2 className="w-5 h-5 text-sky-600" /> Administração de Divisões Institucionais
          </h3>
          <p className="text-xs text-slate-500 font-medium">Configure as divisões operacionais e os chefes regulamentares correspondentes.</p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="inline-flex items-center gap-1.5 px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs rounded-lg border border-sky-500 cursor-pointer"
        >
          <Plus className="w-4 h-4" /> Nova Divisão
        </button>
      </div>

      {successMsg && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-3 rounded-xl text-xs flex gap-2 font-bold">
          <Check className="w-4 h-4 text-emerald-600 mt-0.5" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* DIVISIONS GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {divisions.map(div => (
          <div 
            key={div.id} 
            className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-2xs hover:border-slate-350 transition-all flex flex-col justify-between"
          >
            {/* Top border colored by division institutional color */}
            <div className="h-2 w-full" style={{ backgroundColor: div.cor }}></div>

            <div className="p-4 space-y-4 flex-1 flex flex-col justify-between">
              
              <div className="space-y-1">
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-2">
                    <span 
                      className="px-2 py-0.5 rounded text-[11px] font-black text-white font-mono uppercase"
                      style={{ backgroundColor: div.cor }}
                    >
                      {div.sigla}
                    </span>
                    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded border uppercase ${
                      div.estado === 'Ativa' ? 'bg-emerald-50 text-emerald-800 border-emerald-200' : 'bg-slate-50 text-slate-400 border-slate-200'
                    }`}>
                      {div.estado}
                    </span>
                  </div>

                  <button
                    onClick={() => toggleDivisionState(div.id)}
                    className={`p-1.5 rounded-lg border transition-all ${
                      div.estado === 'Ativa' 
                        ? 'bg-rose-50 hover:bg-rose-100 text-rose-600 border-rose-200' 
                        : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-600 border-emerald-200'
                    }`}
                    title={div.estado === 'Ativa' ? 'Desactivar Divisão' : 'Activar Divisão'}
                  >
                    <Power className="w-3.5 h-3.5" />
                  </button>
                </div>

                <h4 className="font-extrabold text-slate-900 text-sm pt-2">{div.name}</h4>
              </div>

              {/* CONTACT DETAILS */}
              <div className="space-y-2 border-t border-slate-100 pt-3 text-xs leading-relaxed font-medium">
                
                <div className="flex items-center gap-2 text-slate-600">
                  <User className="w-4 h-4 text-slate-400 shrink-0" />
                  <span>Responsável: <b className="text-slate-800">{div.responsavel}</b></span>
                </div>

                <div className="flex items-center gap-2 text-slate-600">
                  <Mail className="w-4 h-4 text-slate-400 shrink-0" />
                  <span className="font-mono text-[11px] text-slate-500">{div.email}</span>
                </div>

                <div className="flex items-center gap-2 text-slate-600">
                  <Phone className="w-4 h-4 text-slate-400 shrink-0" />
                  <span className="font-mono text-[11px] text-slate-500">{div.telefone}</span>
                </div>

              </div>

            </div>
          </div>
        ))}
      </div>

      {/* ADD DIVISION MODAL */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl shadow-2xl w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            
            <div className="px-5 py-4 bg-slate-50 border-b border-slate-150 flex justify-between items-center">
              <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-1.5">
                <Building2 className="w-5 h-5 text-sky-600" /> Adicionar Nova Divisão Organizacional
              </h3>
              <button 
                type="button"
                onClick={() => setShowAddModal(false)}
                className="p-1 text-slate-400 hover:text-slate-800 hover:bg-slate-150 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddDivision} className="p-5 space-y-4 text-xs font-medium">
              
              <div className="space-y-1">
                <label className="text-slate-700 block font-bold">Nome da Divisão</label>
                <input
                  type="text"
                  value={newDiv.name}
                  onChange={e => setNewDiv(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-bold focus:outline-hidden focus:ring-1 focus:ring-sky-500"
                  placeholder="Ex: Divisão de Tecnologia e Inovação"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-slate-700 block font-bold">Sigla (ID Único)</label>
                  <input
                    type="text"
                    value={newDiv.sigla}
                    onChange={e => setNewDiv(prev => ({ ...prev, sigla: e.target.value }))}
                    className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-mono font-bold"
                    placeholder="Ex: DTI"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-700 block font-bold flex items-center gap-1">
                    <Palette className="w-3.5 h-3.5 text-slate-400" /> Cor Institucional
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="color"
                      value={newDiv.cor}
                      onChange={e => setNewDiv(prev => ({ ...prev, cor: e.target.value }))}
                      className="w-10 h-8 p-0 bg-transparent border-0 cursor-pointer rounded"
                    />
                    <input
                      type="text"
                      value={newDiv.cor}
                      onChange={e => setNewDiv(prev => ({ ...prev, cor: e.target.value }))}
                      className="w-full py-2 px-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-mono font-bold"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-slate-700 block font-bold">Responsável Principal</label>
                <input
                  type="text"
                  value={newDiv.responsavel}
                  onChange={e => setNewDiv(prev => ({ ...prev, responsavel: e.target.value }))}
                  className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-semibold"
                  placeholder="Ex: Eng. Manuel Carlos"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-slate-700 block font-bold">E-mail de Contacto</label>
                  <input
                    type="email"
                    value={newDiv.email}
                    onChange={e => setNewDiv(prev => ({ ...prev, email: e.target.value }))}
                    className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-mono"
                    placeholder="Ex: dti@ato-oc.co.ao"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-700 block font-bold">Telefone de Contacto</label>
                  <input
                    type="text"
                    value={newDiv.telefone}
                    onChange={e => setNewDiv(prev => ({ ...prev, telefone: e.target.value }))}
                    className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-mono"
                    placeholder="Ex: +244 923 000 000"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-bold"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-lg font-bold border border-sky-500 cursor-pointer"
                >
                  Registar Divisão
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
}
