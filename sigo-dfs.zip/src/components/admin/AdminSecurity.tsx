import React, { useState } from 'react';
import { 
  ShieldAlert, 
  ShieldCheck, 
  Lock, 
  Eye, 
  EyeOff, 
  Check, 
  ToggleLeft, 
  ToggleRight, 
  Smartphone, 
  Server 
} from 'lucide-react';

export default function AdminSecurity() {
  const [jwtExpiry, setJwtExpiry] = useState('1440'); // minutes (24 hours)
  const [mfaMandatory, setMfaMandatory] = useState(false);
  const [tls13Only, setTls13Only] = useState(true);
  const [aesEnabled, setAesEnabled] = useState(true);
  const [sessionTimeout, setSessionTimeout] = useState('15'); // minutes
  const [maxAttempts, setMaxAttempts] = useState('5');

  // Password requirements
  const [minChars, setMinChars] = useState(8);
  const [reqUppercase, setReqUppercase] = useState(true);
  const [reqNumbers, setReqNumbers] = useState(true);
  const [reqSymbols, setReqSymbols] = useState(true);

  const [devices, setDevices] = useState([
    { name: 'Terminal Biométrico Portaria Sul', type: 'AVSEC Gate', ip: '10.12.140.12', status: 'Autorizado', date: 'Há 5 mins' },
    { name: 'Laptop Secretaria Executiva', type: 'Windows 11', ip: '10.12.144.55', status: 'Autorizado', date: 'Há 1 hora' },
    { name: 'Consola Central DFS (Servidor)', type: 'Linux Node', ip: '127.0.0.1', status: 'Autorizado', date: 'Sempre Ativo' },
  ]);

  const [successBanner, setSuccessBanner] = useState<string | null>(null);

  const handleSaveSecurity = (e: React.FormEvent) => {
    e.preventDefault();
    setSuccessBanner('Políticas de segurança de rede e autenticação enterprise atualizadas!');
    setTimeout(() => setSuccessBanner(null), 3000);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      <div className="space-y-0.5">
        <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
          <ShieldAlert className="w-5 h-5 text-sky-600" /> Diretrizes de Segurança Corporativa
        </h3>
        <p className="text-xs text-slate-500 font-medium">Configure as políticas de encriptação, complexidade de credenciais e autorização por dispositivo.</p>
      </div>

      {successBanner && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-3 rounded-xl text-xs flex gap-2 font-bold animate-in slide-in-from-top-1 duration-150">
          <Check className="w-4 h-4 text-emerald-600 mt-0.5" />
          <span>{successBanner}</span>
        </div>
      )}

      <form onSubmit={handleSaveSecurity} className="grid grid-cols-1 lg:grid-cols-3 gap-6 text-xs font-medium">
        
        {/* POLICIES AND CREDENTIALS SETTINGS */}
        <div className="lg:col-span-2 space-y-6">
          
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4">
            <h4 className="text-slate-800 font-extrabold text-sm pb-1 border-b border-slate-100 flex items-center gap-1.5">
              <Lock className="w-4.5 h-4.5 text-sky-600" /> Complexidade de Palavras-passe & Lockout
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-1">
                <label className="text-slate-700 block font-bold">Comprimento Mínimo (caracteres)</label>
                <input
                  type="number"
                  value={minChars}
                  onChange={e => setMinChars(parseInt(e.target.value) || 8)}
                  className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-bold"
                  min={6}
                  max={32}
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-700 block font-bold">Tempo Expirar Sessão (minutos)</label>
                <input
                  type="number"
                  value={sessionTimeout}
                  onChange={e => setSessionTimeout(e.target.value)}
                  className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-bold"
                  min={5}
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-700 block font-bold">Tentativas Máximas de Acesso</label>
                <input
                  type="number"
                  value={maxAttempts}
                  onChange={e => setMaxAttempts(e.target.value)}
                  className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-bold"
                  min={3}
                  max={10}
                />
              </div>
            </div>

            {/* Checkboxes parameters */}
            <div className="grid grid-cols-2 gap-3 pt-2">
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="uppercaseReq"
                  checked={reqUppercase}
                  onChange={e => setReqUppercase(e.target.checked)}
                  className="w-4.5 h-4.5 rounded text-sky-600 border-slate-300 focus:ring-sky-500 cursor-pointer"
                />
                <label htmlFor="uppercaseReq" className="text-slate-700 font-bold cursor-pointer">Exigir Letra Maiúscula</label>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="numbersReq"
                  checked={reqNumbers}
                  onChange={e => setReqNumbers(e.target.checked)}
                  className="w-4.5 h-4.5 rounded text-sky-600 border-slate-300 focus:ring-sky-500 cursor-pointer"
                />
                <label htmlFor="numbersReq" className="text-slate-700 font-bold cursor-pointer">Exigir Caracteres Numéricos</label>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="symbolsReq"
                  checked={reqSymbols}
                  onChange={e => setReqSymbols(e.target.checked)}
                  className="w-4.5 h-4.5 rounded text-sky-600 border-slate-300 focus:ring-sky-500 cursor-pointer"
                />
                <label htmlFor="symbolsReq" className="text-slate-700 font-bold cursor-pointer">Exigir Caracteres Especiais</label>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="mfaMandatoryReq"
                  checked={mfaMandatory}
                  onChange={e => setMfaMandatory(e.target.checked)}
                  className="w-4.5 h-4.5 rounded text-sky-600 border-slate-300 focus:ring-sky-500 cursor-pointer"
                />
                <label htmlFor="mfaMandatoryReq" className="text-slate-700 font-bold cursor-pointer text-sky-700">MFA Obrigatório para Chefias</label>
              </div>
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4">
            <h4 className="text-slate-800 font-extrabold text-sm pb-1 border-b border-slate-100 flex items-center gap-1.5">
              <Server className="w-4.5 h-4.5 text-sky-600" /> Encriptação de Rede & Encriptação de Base de Dados (AES-256)
            </h4>

            <div className="space-y-4">
              <div className="flex justify-between items-center bg-slate-50 border border-slate-150 p-3 rounded-lg">
                <div className="space-y-0.5">
                  <span className="font-bold text-slate-800 block">Restringir a TLS 1.3 (Recomendado)</span>
                  <span className="text-[10px] text-slate-400">Rejeitar conexões antigas não seguras.</span>
                </div>
                <button
                  type="button"
                  onClick={() => setTls13Only(!tls13Only)}
                  className="text-sky-600"
                >
                  {tls13Only ? <ToggleRight className="w-10 h-6" /> : <ToggleLeft className="w-10 h-6 text-slate-400" />}
                </button>
              </div>

              <div className="flex justify-between items-center bg-slate-50 border border-slate-150 p-3 rounded-lg">
                <div className="space-y-0.5">
                  <span className="font-bold text-slate-800 block">Encriptação AES-256 em Repouso</span>
                  <span className="text-[10px] text-slate-400">Proteção de arquivos carregados contra espionagem física de disco.</span>
                </div>
                <button
                  type="button"
                  onClick={() => setAesEnabled(!aesEnabled)}
                  className="text-sky-600"
                >
                  {aesEnabled ? <ToggleRight className="w-10 h-6" /> : <ToggleLeft className="w-10 h-6 text-slate-400" />}
                </button>
              </div>

              <div className="space-y-1">
                <label className="text-slate-700 block font-bold">Tempo de Vida dos Tokens JWT (minutos)</label>
                <input
                  type="number"
                  value={jwtExpiry}
                  onChange={e => setJwtExpiry(e.target.value)}
                  className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-mono"
                  placeholder="Ex: 1440"
                />
              </div>
            </div>
          </div>

        </div>

        {/* DEVICE ACCESS CONTROL LIST */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4 flex flex-col justify-between">
          
          <div className="space-y-4">
            <h4 className="text-slate-800 font-extrabold text-sm pb-1 border-b border-slate-100 flex items-center gap-1.5">
              <Smartphone className="w-4.5 h-4.5 text-sky-600" /> Dispositivos e Terminais Homologados
            </h4>

            <div className="space-y-3">
              {devices.map((dev, idx) => (
                <div key={idx} className="p-3 bg-slate-50 border border-slate-150 rounded-xl flex items-center justify-between text-xs">
                  <div className="space-y-0.5">
                    <span className="font-bold text-slate-800 block">{dev.name}</span>
                    <span className="text-[10px] text-slate-400 font-mono">IP: {dev.ip} | {dev.type}</span>
                  </div>
                  <span className="px-2 py-0.5 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded text-[9px] font-black uppercase font-sans">
                    {dev.status}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100">
            <button
              type="submit"
              className="w-full px-4 py-2.5 bg-sky-600 hover:bg-sky-700 text-white font-bold rounded-lg border border-sky-500 transition-all text-center cursor-pointer"
            >
              Guardar Diretivas de Segurança
            </button>
          </div>

        </div>

      </form>

    </div>
  );
}
