import React, { useState } from 'react';
import { 
  Terminal, 
  Search, 
  Filter, 
  Trash2, 
  Download, 
  CheckCircle, 
  AlertTriangle, 
  XCircle, 
  Info, 
  Clock 
} from 'lucide-react';

interface AuditLog {
  id: string;
  data: string;
  utilizador: string;
  modulo: string;
  acao: string;
  detalhe: string;
  severidade: 'INFO' | 'SUCCESS' | 'WARNING' | 'ERROR' | 'CRITICAL';
  ip: string;
}

export default function AdminLogs() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSeverity, setSelectedSeverity] = useState('ALL');
  const [selectedModule, setSelectedModule] = useState('ALL');

  // Interactive logs representation
  const [logs, setLogs] = useState<AuditLog[]>([
    { id: 'aud-10', data: '2026-07-16T11:42:15Z', utilizador: 'Super Administrador', modulo: 'ADMIN_SETTINGS', acao: 'Atualização de Matriz', detalhe: 'Alteração das permissões do perfil "Secretariado" para o módulo BI.', severidade: 'SUCCESS', ip: '192.168.1.100' },
    { id: 'aud-9', data: '2026-07-16T11:30:10Z', utilizador: 'Dra. Isabel Cassule', modulo: 'WORKFLOW', acao: 'Submissão de Documento', detalhe: 'Submetido relatório consolidado DFC para o Balanço Operacional de 15/07.', severidade: 'INFO', ip: '10.12.144.12' },
    { id: 'aud-8', data: '2026-07-16T11:15:00Z', utilizador: 'Sistema Copilot', modulo: 'AI_COPILOT', acao: 'Invocação de LLM', detalhe: 'Pedido de sumário executivo gerado por gemini-3.5-flash com sucesso.', severidade: 'SUCCESS', ip: '127.0.0.1' },
    { id: 'aud-7', data: '2026-07-16T10:05:42Z', utilizador: 'antonio.bunga', modulo: 'AUTH', acao: 'Login Rejeitado', detalhe: 'Tentativa de login com senha incorreta para utilizador.', severidade: 'WARNING', ip: '10.12.144.22' },
    { id: 'aud-6', data: '2026-07-16T09:12:00Z', utilizador: 'Maria Antónia Santos', modulo: 'FILE_UPLOAD', acao: 'Upload de PowerPoint', detalhe: 'Carregado ficheiro "Relatorio_FAL_Q2.pptx" no motor de OCR.', severidade: 'INFO', ip: '10.12.144.31' },
    { id: 'aud-5', data: '2026-07-16T08:00:10Z', utilizador: 'Sistema Backups', modulo: 'DATABASE', acao: 'Backup Automático', detalhe: 'Criado backup diário completo "backup_sigo_dfs_2026-07-16_0200.json".', severidade: 'SUCCESS', ip: '127.0.0.1' },
    { id: 'aud-4', data: '2026-07-16T07:44:23Z', utilizador: 'Dr. Valdemar Neto', modulo: 'WORKFLOW', acao: 'Aprovação de Balanço', detalhe: 'Balanço Geral de 14/07 homologado e assinado digitalmente.', severidade: 'SUCCESS', ip: '10.12.144.10' },
    { id: 'aud-3', data: '2026-07-16T06:12:15Z', utilizador: 'Conector LDAP', modulo: 'INTEGRATIONS', acao: 'Falha de Sincronização', detalhe: 'Não foi possível ligar ao Servidor Active Directory no IP 10.12.100.1.', severidade: 'ERROR', ip: '10.12.100.1' },
    { id: 'aud-2', data: '2026-07-16T04:22:00Z', utilizador: 'Super Administrador', modulo: 'AUTH', acao: 'Habilitação MFA', detalhe: 'MFA ativado com sucesso para a conta "Super Administrador".', severidade: 'SUCCESS', ip: '192.168.1.100' },
    { id: 'aud-1', data: '2026-07-15T23:55:00Z', utilizador: 'Gateway API', modulo: 'INTEGRATIONS', acao: 'Bloqueio de Rate Limit', detalhe: 'IP 198.51.100.42 temporariamente bloqueado por exceder 150 req/min.', severidade: 'CRITICAL', ip: '198.51.100.42' },
  ]);

  const getSeverityStyle = (severity: string) => {
    switch (severity) {
      case 'SUCCESS': return 'bg-emerald-50 text-emerald-800 border-emerald-200';
      case 'WARNING': return 'bg-amber-50 text-amber-800 border-amber-200';
      case 'ERROR': return 'bg-rose-50 text-rose-800 border-rose-200';
      case 'CRITICAL': return 'bg-red-100 text-red-900 border-red-300';
      default: return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'SUCCESS': return <CheckCircle className="w-3.5 h-3.5 text-emerald-600 shrink-0" />;
      case 'WARNING': return <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0" />;
      case 'ERROR': return <XCircle className="w-3.5 h-3.5 text-rose-600 shrink-0" />;
      case 'CRITICAL': return <XCircle className="w-3.5 h-3.5 text-red-700 shrink-0" />;
      default: return <Info className="w-3.5 h-3.5 text-slate-600 shrink-0" />;
    }
  };

  const filteredLogs = logs.filter(log => {
    const matchesSearch = log.utilizador.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          log.detalhe.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          log.acao.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesSeverity = selectedSeverity === 'ALL' || log.severidade === selectedSeverity;
    const matchesModule = selectedModule === 'ALL' || log.modulo === selectedModule;

    return matchesSearch && matchesSeverity && matchesModule;
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* HEADER ACTIONS */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div className="space-y-0.5">
          <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
            <Terminal className="w-5 h-5 text-sky-600" /> Histórico de Auditoria & Logs de Sistema
          </h3>
          <p className="text-xs text-slate-500 font-medium">Histórico permanente e inalterável de todas as ações operacionais ocorridas no DFS Insight Hub.</p>
        </div>

        <button
          onClick={() => alert('A descarregar os logs de auditoria no formato CSV criptografado AES-256...')}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-lg border border-slate-200 cursor-pointer"
        >
          <Download className="w-4 h-4" /> Exportar Logs (CSV)
        </button>
      </div>

      {/* FILTER PANEL */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-2xs flex flex-col sm:flex-row gap-3 text-xs font-bold text-slate-700">
        
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Pesquisar por utilizador, detalhe ou ação específica..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium focus:outline-hidden"
          />
        </div>

        <select
          value={selectedSeverity}
          onChange={e => setSelectedSeverity(e.target.value)}
          className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden"
        >
          <option value="ALL">Todas as Severidades</option>
          <option value="INFO">INFO (Operações Comuns)</option>
          <option value="SUCCESS">SUCCESS (Sucessos)</option>
          <option value="WARNING">WARNING (Avisos de Segurança)</option>
          <option value="ERROR">ERROR (Erros Críticos)</option>
          <option value="CRITICAL">CRITICAL (Avisos Fatais)</option>
        </select>

        <select
          value={selectedModule}
          onChange={e => setSelectedModule(e.target.value)}
          className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden font-mono"
        >
          <option value="ALL">Todos os Módulos</option>
          <option value="AUTH">AUTH</option>
          <option value="WORKFLOW">WORKFLOW</option>
          <option value="FILE_UPLOAD">FILE_UPLOAD</option>
          <option value="AI_COPILOT">AI_COPILOT</option>
          <option value="DATABASE">DATABASE</option>
          <option value="ADMIN_SETTINGS">ADMIN_SETTINGS</option>
          <option value="INTEGRATIONS">INTEGRATIONS</option>
        </select>

      </div>

      {/* AUDIT TABLE */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 text-slate-400 text-[10px] font-black uppercase tracking-wider border-b border-slate-200">
                <th className="p-3 pl-4">Data e Hora</th>
                <th className="p-3">Utilizador</th>
                <th className="p-3 font-mono">Módulo</th>
                <th className="p-3">Operação</th>
                <th className="p-3">Detalhe</th>
                <th className="p-3">Severidade</th>
                <th className="p-3 pr-4 font-mono">IP Origem</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {filteredLogs.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400 font-medium">
                    Nenhum registo de auditoria atende aos filtros definidos.
                  </td>
                </tr>
              ) : (
                filteredLogs.map(log => (
                  <tr key={log.id} className="hover:bg-slate-50/50">
                    <td className="p-3 pl-4 text-slate-500 font-mono flex items-center gap-1.5 whitespace-nowrap">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      {new Date(log.data).toLocaleString('pt-AO')}
                    </td>
                    <td className="p-3 font-bold text-slate-800">{log.utilizador}</td>
                    <td className="p-3 font-bold text-slate-600 font-mono text-[10px] uppercase">{log.modulo}</td>
                    <td className="p-3 font-semibold text-sky-850">{log.acao}</td>
                    <td className="p-3 text-slate-600 max-w-sm font-medium leading-relaxed">{log.detalhe}</td>
                    <td className="p-3">
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded border text-[9px] font-black uppercase tracking-wider ${getSeverityStyle(log.severidade)}`}>
                        {getSeverityIcon(log.severidade)} {log.severidade}
                      </span>
                    </td>
                    <td className="p-3 pr-4 font-mono text-slate-500 text-[11px]">{log.ip}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
