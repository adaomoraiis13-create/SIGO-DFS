import React, { useState } from 'react';
import { 
  Users, 
  Search, 
  UserPlus, 
  Shield, 
  Mail, 
  Phone, 
  Edit2, 
  Trash2, 
  Check, 
  X, 
  Lock, 
  KeyRound, 
  ShieldAlert, 
  ShieldCheck, 
  Camera 
} from 'lucide-react';
import { User, UserRole, DivisionId } from '../../types.js';
import * as api from '../../services/api.js';

interface AdminUsersProps {
  users: User[];
  onRefresh: () => void;
  allowedDomain: string;
  registrationPolicy?: string;
}

export default function AdminUsers({ users, onRefresh, allowedDomain, registrationPolicy }: AdminUsersProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRoleFilter, setSelectedRoleFilter] = useState('ALL');
  const [selectedDivFilter, setSelectedDivFilter] = useState('ALL');

  // Edit / Create Modals
  const [showEditForm, setShowEditForm] = useState(false);
  const [isCreatingNew, setIsCreatingNew] = useState(false);
  const [selectedUser, setSelectedUser] = useState<Partial<User & { password?: string; mfaEnabled?: boolean; photoUrl?: string }> | null>(null);

  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Profile Photos
  const avatarPlaceholders = [
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=120',
    'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=120',
    'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=120',
    'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=120',
  ];

  const handleOpenEdit = (user: User) => {
    setSelectedUser({
      ...user,
      mfaEnabled: true,
      photoUrl: avatarPlaceholders[Math.floor(Math.random() * avatarPlaceholders.length)]
    });
    setIsCreatingNew(false);
    setShowEditForm(true);
    setErrorMsg(null);
  };

  const handleOpenCreate = () => {
    setSelectedUser({
      name: '',
      email: '',
      phone: '',
      divisionId: DivisionId.DOS,
      role: UserRole.CHEFE_DIVISAO,
      position: '',
      status: 'Ativa',
      password: '',
      mfaEnabled: false,
      photoUrl: avatarPlaceholders[0]
    });
    setIsCreatingNew(true);
    setShowEditForm(true);
    setErrorMsg(null);
  };

  const handleDeleteUser = async (userId: string) => {
    if (!window.confirm('Tem a certeza que deseja eliminar permanentemente este utilizador do sistema?')) return;
    try {
      await api.deleteUser(userId);
      setSuccessMsg('Utilizador eliminado com sucesso.');
      setTimeout(() => setSuccessMsg(null), 3000);
      onRefresh();
    } catch (err: any) {
      setErrorMsg('Erro ao eliminar utilizador.');
    }
  };

  const handleApproveUser = async (user: User) => {
    try {
      await api.updateUser(user.id, { status: 'Ativa' });
      setSuccessMsg(`Utilizador ${user.name} aprovado com sucesso.`);
      setTimeout(() => setSuccessMsg(null), 3000);
      onRefresh();
    } catch (err) {
      setErrorMsg('Erro ao aprovar utilizador.');
    }
  };

  const handleSaveUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUser) return;
    setErrorMsg(null);

    // Basic Validations
    if (!selectedUser.name || !selectedUser.email) {
      setErrorMsg('Nome e E-mail são obrigatórios.');
      return;
    }

    if (isCreatingNew && !selectedUser.password) {
      setErrorMsg('Palavra-passe é obrigatória para novas contas.');
      return;
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(selectedUser.email)) {
      setErrorMsg('O endereço de e-mail introduzido possui um formato inválido.');
      return;
    }

    // Check institutional domain if policy is ONLY_INSTITUTIONAL
    const policy = registrationPolicy || 'ANY_VALID_EMAIL';
    if (policy === 'ONLY_INSTITUTIONAL') {
      if (!selectedUser.email.endsWith(`@${allowedDomain}`)) {
        setErrorMsg(`O e-mail deve obrigatoriamente pertencer ao domínio @${allowedDomain}`);
        return;
      }
    }

    try {
      setLoading(true);
      if (isCreatingNew) {
        await api.createUser({
          name: selectedUser.name,
          email: selectedUser.email,
          phone: selectedUser.phone,
          divisionId: selectedUser.divisionId,
          role: selectedUser.role,
          position: selectedUser.position,
          status: selectedUser.status,
          password: selectedUser.password,
          mfaEnabled: selectedUser.mfaEnabled,
          photoUrl: selectedUser.photoUrl
        });
        setSuccessMsg('Utilizador criado com sucesso.');
      } else {
        await api.updateUser(selectedUser.id!, {
          name: selectedUser.name,
          email: selectedUser.email,
          phone: selectedUser.phone,
          divisionId: selectedUser.divisionId,
          role: selectedUser.role,
          position: selectedUser.position,
          status: selectedUser.status,
          ...(selectedUser.password ? { password: selectedUser.password } : {}),
          mfaEnabled: selectedUser.mfaEnabled,
          photoUrl: selectedUser.photoUrl
        });
        setSuccessMsg('Utilizador atualizado com sucesso.');
      }
      setTimeout(() => setSuccessMsg(null), 3000);
      setShowEditForm(false);
      setSelectedUser(null);
      onRefresh();
    } catch (err: any) {
      setErrorMsg(err.message || 'Erro ao guardar dados do utilizador.');
    } finally {
      setLoading(false);
    }
  };

  const pendingUsers = users.filter(u => u.status === 'Pendente de Aprovação');
  const activeAndOtherUsers = users.filter(u => u.status !== 'Pendente de Aprovação');

  const filteredUsers = activeAndOtherUsers.filter(u => {
    const matchesSearch = u.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          u.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          u.position?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesRole = selectedRoleFilter === 'ALL' || u.role === selectedRoleFilter;
    const matchesDiv = selectedDivFilter === 'ALL' || u.divisionId === selectedDivFilter;

    return matchesSearch && matchesRole && matchesDiv;
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* feedback */}
      {errorMsg && (
        <div className="bg-rose-50 border border-rose-200 text-rose-800 p-4 rounded-xl text-sm flex gap-2.5 font-medium">
          <ShieldAlert className="w-5 h-5 text-rose-600 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}
      {successMsg && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded-xl text-sm flex gap-2.5 font-medium">
          <Check className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* SOLICITAÇÕES DE ACESSO PENDENTES */}
      {pendingUsers.length > 0 && (
        <div className="bg-amber-50/50 border border-amber-200 rounded-xl p-5 space-y-4 shadow-2xs">
          <div className="flex justify-between items-center pb-2 border-b border-amber-100">
            <h3 className="font-extrabold text-amber-950 text-sm flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-amber-600" /> Solicitações de Acesso Pendentes ({pendingUsers.length})
            </h3>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] bg-amber-200 text-amber-900 font-extrabold uppercase animate-pulse border border-amber-300">
              Pendente de Homologação
            </span>
          </div>

          <div className="divide-y divide-amber-100">
            {pendingUsers.map(usr => (
              <div key={usr.id} className="py-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div className="flex gap-3">
                  <div className="w-10 h-10 rounded-full bg-amber-100 text-amber-800 border border-amber-200 flex items-center justify-center font-black">
                    {usr.name.split(' ').map(n => n[0]).slice(0, 2).join('')}
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-amber-950 text-sm">{usr.name}</h4>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-900 text-white font-mono">
                        {usr.divisionId}
                      </span>
                    </div>
                    <p className="text-xs text-amber-800 font-medium">
                      <Mail className="inline w-3 h-3 mr-1" /> {usr.email} {usr.phone && `| ${usr.phone}`}
                    </p>
                    <p className="text-xs text-slate-500 font-medium">
                      Cargo: <b>{usr.position}</b> - Perfil: <b>{usr.role}</b>
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end md:self-center">
                  <button
                    onClick={() => handleApproveUser(usr)}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg border border-emerald-500 flex items-center gap-1 transition-all cursor-pointer"
                  >
                    <Check className="w-3.5 h-3.5" /> Aprovar Acesso
                  </button>
                  <button
                    onClick={() => handleOpenEdit(usr)}
                    className="px-3 py-1.5 bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold rounded-lg border border-slate-200 flex items-center gap-1 transition-all"
                  >
                    <Edit2 className="w-3.5 h-3.5" /> Alterar Dados
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ACTIVE USERS REGISTRIES */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-2xs p-5 space-y-4">
        
        {/* SEARCH & FILTERS */}
        <div className="flex flex-col lg:flex-row justify-between gap-4 pb-4 border-b border-slate-100">
          <div className="flex flex-col sm:flex-row gap-3 flex-1">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Pesquisar utilizador por nome, email ou cargo..."
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium focus:outline-hidden focus:ring-1 focus:ring-sky-500"
              />
            </div>

            <select
              value={selectedRoleFilter}
              onChange={e => setSelectedRoleFilter(e.target.value)}
              className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold focus:outline-hidden"
            >
              <option value="ALL">Todos os Perfis</option>
              <option value={UserRole.ADMIN}>ADMIN (Administrador)</option>
              <option value={UserRole.DIRETOR}>DIRETOR (Direção)</option>
              <option value={UserRole.SECRETARIADO}>SECRETARIADO (Secretariado)</option>
              <option value={UserRole.CHEFE_DIVISAO}>CHEFE DIVISÃO (Divisões)</option>
            </select>

            <select
              value={selectedDivFilter}
              onChange={e => setSelectedDivFilter(e.target.value)}
              className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold focus:outline-hidden font-mono"
            >
              <option value="ALL">Todas as Divisões</option>
              <option value="DFS">DFS (Direção Geral)</option>
              <option value="DOS">DOS (Operações & Segurança)</option>
              <option value="DFC">DFC (Facilitação & Controlo)</option>
              <option value="FAL">FAL (Facilitação / Regulamentação)</option>
              <option value="DRCQ">DRCQ (Regulação & Qualidade)</option>
            </select>
          </div>

          <button
            onClick={handleOpenCreate}
            className="inline-flex items-center justify-center gap-1.5 px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold rounded-lg shrink-0 border border-sky-500 cursor-pointer"
          >
            <UserPlus className="w-4 h-4" /> Criar Utilizador
          </button>
        </div>

        {/* USERS TABLE */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-100 text-slate-400 text-[10px] font-black uppercase tracking-wider">
                <th className="pb-3 pl-2">Utilizador</th>
                <th className="pb-3">Contacto</th>
                <th className="pb-3">Perfil (RBAC)</th>
                <th className="pb-3">Divisão / Cargo</th>
                <th className="pb-3">Autenticação MFA</th>
                <th className="pb-3">Estado</th>
                <th className="pb-3 text-right pr-2">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50 text-xs">
              {filteredUsers.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400 font-medium">
                    Nenhum utilizador registado atende a estes critérios de busca.
                  </td>
                </tr>
              ) : (
                filteredUsers.map(usr => (
                  <tr key={usr.id} className="hover:bg-slate-50/50">
                    <td className="py-3 pl-2 flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-slate-100 text-slate-600 border border-slate-200 flex items-center justify-center font-bold overflow-hidden">
                        <span className="font-extrabold">{usr.name.split(' ').map(n => n[0]).slice(0, 2).join('')}</span>
                      </div>
                      <div>
                        <span className="font-bold text-slate-800 block">{usr.name}</span>
                        <span className="text-[10px] text-slate-400 font-mono">@{usr.username}</span>
                      </div>
                    </td>
                    <td className="py-3">
                      <span className="block text-slate-700">{usr.email}</span>
                      <span className="text-slate-400 block font-mono text-[10px]">{usr.phone || 'Sem contacto telefónico'}</span>
                    </td>
                    <td className="py-3">
                      <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold tracking-wide ${
                        usr.role === UserRole.ADMIN ? 'bg-indigo-50 text-indigo-800 border border-indigo-200' :
                        usr.role === UserRole.DIRETOR ? 'bg-amber-50 text-amber-800 border border-amber-200' :
                        usr.role === UserRole.SECRETARIADO ? 'bg-sky-50 text-sky-800 border border-sky-200' :
                        'bg-slate-50 text-slate-800 border border-slate-200'
                      }`}>
                        <Shield className="w-3 h-3" /> {usr.role}
                      </span>
                    </td>
                    <td className="py-3">
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-black bg-slate-900 text-white font-mono mr-1.5 uppercase">
                        {usr.divisionId}
                      </span>
                      <span className="text-slate-500 font-medium">{usr.position || 'N/A'}</span>
                    </td>
                    <td className="py-3">
                      <span className="inline-flex items-center gap-1">
                        <span className={`w-2 h-2 rounded-full ${usr.id === 'usr-1' ? 'bg-emerald-500' : 'bg-slate-300'}`}></span>
                        <span className="text-slate-500 font-medium text-[11px]">{usr.id === 'usr-1' ? 'MFA Activo (App)' : 'Configurável'}</span>
                      </span>
                    </td>
                    <td className="py-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold border uppercase ${
                        usr.status === 'Ativa' ? 'bg-emerald-50 text-emerald-800 border-emerald-200' :
                        usr.status === 'Suspensa' ? 'bg-amber-50 text-amber-800 border-amber-200' :
                        'bg-rose-50 text-rose-800 border-rose-200'
                      }`}>
                        {usr.status || 'Ativa'}
                      </span>
                    </td>
                    <td className="py-3 text-right pr-2">
                      <div className="flex justify-end gap-1.5">
                        <button
                          onClick={() => handleOpenEdit(usr)}
                          className="p-1.5 text-slate-400 hover:text-sky-600 hover:bg-sky-50 rounded-lg transition-all"
                          title="Editar Ficha"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteUser(usr.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all cursor-pointer"
                          title="Eliminar Conta"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

      </div>

      {/* EDIT / CREATE MODAL OVERLAY */}
      {showEditForm && selectedUser && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl shadow-2xl w-full max-w-lg overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            
            <div className="px-5 py-4 bg-slate-50 border-b border-slate-150 flex justify-between items-center">
              <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
                {isCreatingNew ? <UserPlus className="w-5 h-5 text-sky-600" /> : <Edit2 className="w-5 h-5 text-sky-600" />}
                {isCreatingNew ? 'Adicionar Utilizador Corporativo' : `Editar Utilizador: ${selectedUser.name}`}
              </h3>
              <button 
                type="button"
                onClick={() => { setShowEditForm(false); setSelectedUser(null); }}
                className="p-1 text-slate-400 hover:text-slate-800 hover:bg-slate-150 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveUser} className="p-5 space-y-4 text-xs font-medium">
              
              {/* Profile Photo and MFA Quick setup */}
              <div className="flex items-center gap-4 p-3 bg-slate-50 border border-slate-150 rounded-lg">
                <div className="relative group">
                  <div className="w-14 h-14 rounded-full bg-slate-200 border border-slate-350 overflow-hidden flex items-center justify-center">
                    {selectedUser.photoUrl ? (
                      <img src={selectedUser.photoUrl} alt="Avatar" className="w-full h-full object-cover" />
                    ) : (
                      <Users className="w-6 h-6 text-slate-400" />
                    )}
                  </div>
                  <button 
                    type="button" 
                    onClick={() => {
                      const randIdx = Math.floor(Math.random() * avatarPlaceholders.length);
                      setSelectedUser(p => ({ ...p, photoUrl: avatarPlaceholders[randIdx] }));
                    }}
                    className="absolute bottom-0 right-0 p-1 bg-sky-600 hover:bg-sky-700 text-white rounded-full border border-white"
                    title="Simular Carregamento"
                  >
                    <Camera className="w-3 h-3" />
                  </button>
                </div>

                <div className="space-y-1">
                  <div className="font-bold text-slate-800">Fotografia Corporativa</div>
                  <p className="text-[10px] text-slate-400">Tamanho ideal: quadrado, formato PNG ou JPEG.</p>
                  
                  {/* MFA toggle */}
                  <div className="flex items-center gap-2 pt-1">
                    <input 
                      type="checkbox" 
                      id="mfaToggle"
                      checked={selectedUser.mfaEnabled || false}
                      onChange={e => setSelectedUser(p => ({ ...p, mfaEnabled: e.target.checked }))}
                      className="w-4 h-4 text-sky-600 border-slate-300 rounded focus:ring-sky-500" 
                    />
                    <label htmlFor="mfaToggle" className="text-slate-700 text-[11px] font-bold cursor-pointer">
                      Exigir Autenticação Multifator (MFA)
                    </label>
                  </div>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-slate-700 block font-bold">Nome Completo</label>
                <input
                  type="text"
                  value={selectedUser.name || ''}
                  onChange={e => setSelectedUser(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-bold focus:outline-hidden focus:ring-1 focus:ring-sky-500"
                  placeholder="Ex: Manuel de Sousa Neto"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-slate-700 block font-bold">Endereço de E-mail</label>
                  <input
                    type="email"
                    value={selectedUser.email || ''}
                    onChange={e => setSelectedUser(prev => ({ ...prev, email: e.target.value }))}
                    className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-semibold focus:outline-hidden focus:ring-1 focus:ring-sky-500"
                    placeholder={registrationPolicy === 'ONLY_INSTITUTIONAL' ? `Ex: manuel@${allowedDomain}` : "Ex: manuel@exemplo.com"}
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-700 block font-bold">Telefone Principal</label>
                  <input
                    type="text"
                    value={selectedUser.phone || ''}
                    onChange={e => setSelectedUser(prev => ({ ...prev, phone: e.target.value }))}
                    className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-mono"
                    placeholder="Ex: +244 923 000 000"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-slate-700 block font-bold">Divisão Regulamentar</label>
                  <select
                    value={selectedUser.divisionId || DivisionId.DOS}
                    onChange={e => setSelectedUser(prev => ({ ...prev, divisionId: e.target.value as DivisionId }))}
                    className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-bold focus:outline-hidden font-sans"
                  >
                    <option value="DFS">DFS (Direção Geral)</option>
                    <option value="DOS">DOS (Operações & Segurança)</option>
                    <option value="DFC">DFC (Facilitação & Controlo)</option>
                    <option value="FAL">FAL (Facilitação / Regulamentação)</option>
                    <option value="DRCQ">DRCQ (Regulação & Qualidade)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-slate-700 block font-bold">Perfil de Acesso (RBAC)</label>
                  <select
                    value={selectedUser.role || UserRole.CHEFE_DIVISAO}
                    onChange={e => setSelectedUser(prev => ({ ...prev, role: e.target.value as UserRole }))}
                    className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-bold focus:outline-hidden"
                  >
                    <option value={UserRole.ADMIN}>ADMIN (Gestão Total)</option>
                    <option value={UserRole.DIRETOR}>DIRETOR (Aprovação Final)</option>
                    <option value={UserRole.SECRETARIADO}>SECRETARIADO (Consolidador)</option>
                    <option value={UserRole.CHEFE_DIVISAO}>CHEFE DIVISÃO (Editor de Área)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-slate-700 block font-bold">Cargo Efetivo</label>
                  <input
                    type="text"
                    value={selectedUser.position || ''}
                    onChange={e => setSelectedUser(prev => ({ ...prev, position: e.target.value }))}
                    className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-semibold"
                    placeholder="Ex: Inspetor Técnico AVSEC"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-700 block font-bold">Estado da Conta</label>
                  <select
                    value={selectedUser.status || 'Ativa'}
                    onChange={e => setSelectedUser(prev => ({ ...prev, status: e.target.value as any }))}
                    className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-bold focus:outline-hidden"
                  >
                    <option value="Ativa">Ativa (Acesso Pleno)</option>
                    <option value="Suspensa">Suspensa (Bloqueado p/ Tentativas)</option>
                    <option value="Desativada">Desativada (Inativo permanentemente)</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-slate-700 block font-bold flex items-center gap-1">
                  <KeyRound className="w-3.5 h-3.5 text-slate-400" />
                  Palavra-passe {!isCreatingNew && <span className="text-slate-400 font-normal">(Deixe em branco para manter a actual)</span>}
                </label>
                <input
                  type="password"
                  value={selectedUser.password || ''}
                  onChange={e => setSelectedUser(prev => ({ ...prev, password: e.target.value }))}
                  className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-mono"
                  placeholder="Mínimo 8 caracteres com regras enterprise"
                />
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => { setShowEditForm(false); setSelectedUser(null); }}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-bold"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-lg font-bold border border-sky-500 cursor-pointer disabled:opacity-50"
                >
                  {loading ? 'A processar...' : isCreatingNew ? 'Criar Utilizador' : 'Guardar Alterações'}
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
}
