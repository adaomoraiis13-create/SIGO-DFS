import React, { useState } from 'react';
import { 
  Brain, 
  Check, 
  Settings, 
  Sliders, 
  ShieldCheck, 
  Sparkles, 
  RefreshCw 
} from 'lucide-react';

export default function AdminAI() {
  const [selectedModel, setSelectedModel] = useState('gemini-2.5-flash');
  const [temperature, setTemperature] = useState(0.2);
  const [maxTokens, setMaxTokens] = useState(2048);
  const [systemInstruction, setSystemInstruction] = useState(
    'Você é o DFS Copilot, assistente inteligente oficial da ATO (Aeroportos e Terminais de Angola) para facilitação e segurança operacional (AVSEC) de acordo com o Anexo 9 e Anexo 17 da ICAO.'
  );

  // Safety settings sliders (mock)
  const [harassmentFilter, setHarassmentFilter] = useState('BLOCK_MEDIUM_AND_ABOVE');
  const [hateSpeechFilter, setHateSpeechFilter] = useState('BLOCK_MEDIUM_AND_ABOVE');

  const [saving, setSaving] = useState(false);
  const [successBanner, setSuccessBanner] = useState<string | null>(null);

  const handleSaveAI = (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setTimeout(() => {
      setSaving(false);
      setSuccessBanner('Parâmetros de Hiper-ajuste do modelo Gemini atualizados com sucesso no servidor Express.');
      setTimeout(() => setSuccessBanner(null), 3000);
    }, 800);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      <div className="space-y-0.5">
        <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
          <Brain className="w-5 h-5 text-sky-600" /> Configuração do Motor de Inteligência Artificial (Gemini)
        </h3>
        <p className="text-xs text-slate-500 font-medium">Faça o ajuste fino das chamadas da API Gemini, controlando a criatividade (temperatura) e o contexto regulatório dos sumários.</p>
      </div>

      {successBanner && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-3.5 rounded-xl text-xs flex gap-2 font-bold animate-in slide-in-from-top-1 duration-150">
          <Check className="w-4 h-4 text-emerald-600 mt-0.5" />
          <span>{successBanner}</span>
        </div>
      )}

      <form onSubmit={handleSaveAI} className="grid grid-cols-1 lg:grid-cols-3 gap-6 text-xs font-medium">
        
        {/* PARAMS AND MODEL CHOOSER */}
        <div className="lg:col-span-2 space-y-6">
          
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4">
            <h4 className="text-slate-800 font-extrabold text-sm pb-1 border-b border-slate-100 flex items-center gap-1.5">
              <Sliders className="w-4.5 h-4.5 text-sky-600" /> Parâmetros de Inferência
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-slate-700 block font-bold">Seleção do Modelo (Google GenAI SDK)</label>
                <select
                  value={selectedModel}
                  onChange={e => setSelectedModel(e.target.value)}
                  className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-bold focus:outline-hidden"
                >
                  <option value="gemini-2.5-flash">gemini-2.5-flash (Ideal para sumários de balanços rápidos e OCR)</option>
                  <option value="gemini-2.5-pro">gemini-2.5-pro (Ideal para relatórios profundos e análise jurídica)</option>
                  <option value="gemini-1.5-flash">gemini-1.5-flash (Modelo legado de alta velocidade)</option>
                  <option value="gemini-1.5-pro">gemini-1.5-pro (Modelo legado para contexto ultra-longo)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-slate-700 block font-bold">Limite Máximo de Tokens de Resposta (Max Tokens)</label>
                <select
                  value={maxTokens}
                  onChange={e => setMaxTokens(parseInt(e.target.value))}
                  className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-bold focus:outline-hidden"
                >
                  <option value="1024">1024 tokens (~750 palavras)</option>
                  <option value="2048">2048 tokens (~1500 palavras)</option>
                  <option value="4096">4096 tokens (~3000 palavras)</option>
                  <option value="8192">8192 tokens (Contexto expandido de rascunhos)</option>
                </select>
              </div>
            </div>

            {/* TEMPERATURE SLIDER */}
            <div className="space-y-2 pt-2">
              <div className="flex justify-between font-bold">
                <span className="text-slate-700">Temperatura (Criatividade vs Precisão)</span>
                <span className="text-sky-600 font-mono">{temperature}</span>
              </div>
              <input
                type="range"
                min="0.0"
                max="1.0"
                step="0.1"
                value={temperature}
                onChange={e => setTemperature(parseFloat(e.target.value))}
                className="w-full accent-sky-600"
              />
              <div className="flex justify-between text-[10px] text-slate-400">
                <span>0.0 - Altamente Determinístico (Análise de Dados)</span>
                <span>1.0 - Totalmente Criativo (Ideias de Ação)</span>
              </div>
            </div>

          </div>

          {/* SYSTEM INSTRUCTIONS */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4">
            <h4 className="text-slate-800 font-extrabold text-sm pb-1 border-b border-slate-100 flex items-center gap-1.5">
              <Sparkles className="w-4.5 h-4.5 text-sky-600" /> Instruções do Sistema (System Instructions)
            </h4>

            <div className="space-y-1">
              <label className="text-slate-700 block font-bold">Directrizes Básicas de Contexto (System Prompt)</label>
              <textarea
                value={systemInstruction}
                onChange={e => setSystemInstruction(e.target.value)}
                rows={5}
                className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium leading-relaxed"
                placeholder="Insira as regras para o modelo..."
              />
            </div>
          </div>

        </div>

        {/* COMPLIANCE AND SAVE CHANNELS */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-5 flex flex-col justify-between">
          
          <div className="space-y-4">
            <h4 className="text-slate-800 font-extrabold text-sm pb-1 border-b border-slate-100 flex items-center gap-1.5">
              <ShieldCheck className="w-4.5 h-4.5 text-sky-600" /> Filtros de Segurança (Safety Filters)
            </h4>

            <div className="space-y-3">
              <div className="space-y-1">
                <label className="text-slate-700 block font-bold">Conteúdo Ofensivo & Assédio</label>
                <select
                  value={harassmentFilter}
                  onChange={e => setHarassmentFilter(e.target.value)}
                  className="w-full py-1.5 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-bold focus:outline-hidden"
                >
                  <option value="BLOCK_LOW_AND_ABOVE">Filtro Rigoroso (Bloquear todos os níveis)</option>
                  <option value="BLOCK_MEDIUM_AND_ABOVE">Filtro Médio (Padrão corporativo)</option>
                  <option value="BLOCK_NONE">Sem restrições (Apenas auditoria de logs)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-slate-700 block font-bold">Discurso de Ódio & Preconceito</label>
                <select
                  value={hateSpeechFilter}
                  onChange={e => setHateSpeechFilter(e.target.value)}
                  className="w-full py-1.5 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-bold focus:outline-hidden"
                >
                  <option value="BLOCK_LOW_AND_ABOVE">Filtro Rigoroso (Bloquear todos os níveis)</option>
                  <option value="BLOCK_MEDIUM_AND_ABOVE">Filtro Médio (Padrão corporativo)</option>
                  <option value="BLOCK_NONE">Sem restrições (Apenas auditoria de logs)</option>
                </select>
              </div>
            </div>

            <div className="p-3 bg-slate-50 border border-slate-150 rounded-lg text-[11px] text-slate-500 leading-relaxed font-medium">
              As alterações nos parâmetros do modelo influenciam imediatamente o comportamento das sugestões inteligentes e do assistente virtual (DFS Copilot).
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100">
            <button
              type="submit"
              disabled={saving}
              className="w-full px-4 py-2.5 bg-sky-600 hover:bg-sky-700 text-white font-bold rounded-lg border border-sky-500 transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
            >
              {saving ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" /> A Guardar...
                </>
              ) : (
                <>
                  Guardar Definições IA
                </>
              )}
            </button>
          </div>

        </div>

      </form>

    </div>
  );
}
