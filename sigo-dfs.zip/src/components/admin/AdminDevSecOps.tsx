import React, { useState } from 'react';
import { 
  Cpu, 
  Terminal, 
  Copy, 
  Check, 
  Download, 
  Cloud, 
  RefreshCw, 
  FileCode, 
  Boxes 
} from 'lucide-react';

export default function AdminDevSecOps() {
  const [activeCodeTab, setActiveCodeTab] = useState<'dockerfile' | 'dockercompose' | 'github'>('dockerfile');
  const [copiedText, setCopiedText] = useState(false);

  const dockerfileCode = `## =========================================================================
## MULTI-STAGE DOCKERFILE FOR DFS INSIGHT HUB - ATO ANGOLA
## PRODUCTION COMPLIANT | ENCRYPTED CONTAINER FLOW
## =========================================================================

# Stage 1: Build the client & server bundles
FROM node:22-alpine AS builder
WORKDIR /app

# Install native dependencies and tools
RUN apk add --no-cache python3 make g++

COPY package*.json ./
RUN npm ci

COPY . .
RUN npm run build

# Stage 2: Production runtime image
FROM node:22-alpine AS runner
WORKDIR /app

ENV NODE_ENV=production
ENV PORT=3000

COPY package*.json ./
RUN npm ci --only=production

COPY --from=builder /app/dist ./dist
COPY --from=builder /app/data ./data
COPY --from=builder /app/server-db.ts ./server-db.ts

EXPOSE 3000
CMD ["npm", "start"]`;

  const dockerComposeCode = `version: '3.8'

services:
  dfs-insight-hub:
    image: ato-oc/dfs-insight-hub:latest
    container_name: sigo-dfs-hub
    build:
      context: .
      dockerfile: Dockerfile
    restart: always
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
      - PORT=3000
      - GEMINI_API_KEY=\${GEMINI_API_KEY}
      - JWT_SECRET=\${JWT_SECRET}
      - ALLOWED_DOMAIN=ato-oc.co.ao
    volumes:
      - dfs-shared-volume:/app/data

volumes:
  dfs-shared-volume:
    driver: local`;

  const githubActionsCode = `name: CI/CD - Deploy DFS Insight Hub to Cloud Run (ATO Angola)

on:
  push:
    branches: [ "main" ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
    - name: Checkout Source Code
      uses: actions/checkout@v4

    - name: Authenticate to Google Cloud
      uses: google-github-actions/auth@v2
      with:
        credentials_json: \${{ secrets.GCP_SA_KEY }}

    - name: Set up Cloud SDK
      uses: google-github-actions/setup-gcloud@v2

    - name: Configure Docker to use GCP Registry
      run: |
        gcloud auth configure-docker europe-west3-docker.pkg.dev

    - name: Build & Push Container Image
      run: |
        docker build -t europe-west3-docker.pkg.dev/\${{ secrets.GCP_PROJECT }}/ato/dfs-hub:\${{ github.sha }} .
        docker push europe-west3-docker.pkg.dev/\${{ secrets.GCP_PROJECT }}/ato/dfs-hub:\${{ github.sha }}

    - name: Deploy to GCP Cloud Run
      run: |
        gcloud run deploy dfs-insight-hub \\
          --image europe-west3-docker.pkg.dev/\${{ secrets.GCP_PROJECT }}/ato/dfs-hub:\${{ github.sha }} \\
          --region europe-west3 \\
          --platform managed \\
          --allow-unauthenticated \\
          --set-env-vars="NODE_ENV=production,GEMINI_API_KEY=\${{ secrets.GEMINI_API_KEY }}"`;

  const getCodeString = () => {
    switch (activeCodeTab) {
      case 'dockercompose': return dockerComposeCode;
      case 'github': return githubActionsCode;
      default: return dockerfileCode;
    }
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(getCodeString());
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2500);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      <div className="space-y-0.5">
        <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
          <Boxes className="w-5 h-5 text-sky-600" /> DevSecOps & Orquestração de Containers
        </h3>
        <p className="text-xs text-slate-500 font-medium">Faça o download das configurações de containerização e CI/CD oficiais para implementação robusta e isolada em servidores locais ou na Google Cloud da ATO.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 text-xs font-medium">
        
        {/* HOST METRIC INFRA SUMMARY */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4 lg:col-span-1 flex flex-col justify-between">
          <div className="space-y-4">
            <h4 className="text-slate-800 font-extrabold text-sm pb-1 border-b border-slate-100 flex items-center gap-1.5">
              <Cpu className="w-4.5 h-4.5 text-sky-600" /> Estado do Nó Host
            </h4>

            <div className="space-y-3 text-xs leading-relaxed">
              <div className="flex justify-between items-center bg-slate-50 border border-slate-150 p-2.5 rounded-lg">
                <span className="text-slate-500">Motor de Container:</span>
                <span className="font-bold text-emerald-700">Docker 26.1.4</span>
              </div>
              <div className="flex justify-between items-center bg-slate-50 border border-slate-150 p-2.5 rounded-lg">
                <span className="text-slate-500">Sistema Operativo:</span>
                <span className="font-bold text-slate-800">Alpine Linux v3.20</span>
              </div>
              <div className="flex justify-between items-center bg-slate-50 border border-slate-150 p-2.5 rounded-lg">
                <span className="text-slate-500">Node.js Runtime:</span>
                <span className="font-mono text-slate-800 font-bold">v22.14.0 (ESM)</span>
              </div>
            </div>

            <div className="p-3 bg-slate-50 border border-slate-150 rounded-lg text-[11px] text-slate-500 leading-relaxed font-medium">
              <b>Escalabilidade Geográfica:</b> O DFS Insight Hub foi concebido para suportar implementações multi-aeroporto isoladas por instâncias Docker conectadas à WAN nacional.
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100">
            <button
              onClick={() => alert('Parâmetros de monitorização re-sincronizados.')}
              className="w-full px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-lg flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <RefreshCw className="w-4 h-4" /> Atualizar Estado do Nó
            </button>
          </div>
        </div>

        {/* CODE BLOCKS AND COPIER */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4 lg:col-span-3">
          
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 pb-3 border-b border-slate-100">
            <div className="flex gap-2">
              <button
                onClick={() => setActiveCodeTab('dockerfile')}
                className={`px-3 py-1.5 font-bold text-xs rounded-lg border transition-all ${
                  activeCodeTab === 'dockerfile' ? 'bg-sky-50 text-sky-700 border-sky-350' : 'bg-slate-50 text-slate-600 border-slate-200'
                }`}
              >
                Dockerfile
              </button>
              <button
                onClick={() => setActiveCodeTab('dockercompose')}
                className={`px-3 py-1.5 font-bold text-xs rounded-lg border transition-all ${
                  activeCodeTab === 'dockercompose' ? 'bg-sky-50 text-sky-700 border-sky-350' : 'bg-slate-50 text-slate-600 border-slate-200'
                }`}
              >
                docker-compose.yml
              </button>
              <button
                onClick={() => setActiveCodeTab('github')}
                className={`px-3 py-1.5 font-bold text-xs rounded-lg border transition-all ${
                  activeCodeTab === 'github' ? 'bg-sky-50 text-sky-700 border-sky-350' : 'bg-slate-50 text-slate-600 border-slate-200'
                }`}
              >
                GitHub Actions CI/CD
              </button>
            </div>

            <button
              onClick={handleCopyCode}
              className="px-3.5 py-1.5 bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs rounded-lg border border-sky-500 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              {copiedText ? (
                <>
                  <Check className="w-3.5 h-3.5" /> Copiado!
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" /> Copiar Código
                </>
              )}
            </button>
          </div>

          {/* DARK THEMED CONSOLE CODEBLOCK */}
          <div className="relative bg-slate-900 border border-slate-950 rounded-xl overflow-hidden shadow-inner">
            <div className="flex items-center gap-1 px-4 py-2 border-b border-slate-800 bg-slate-950">
              <span className="w-3 h-3 rounded-full bg-rose-500"></span>
              <span className="w-3 h-3 rounded-full bg-amber-500"></span>
              <span className="w-3 h-3 rounded-full bg-emerald-500"></span>
              <span className="text-[10px] text-slate-500 font-mono pl-2">
                {activeCodeTab === 'dockerfile' ? 'Dockerfile' : activeCodeTab === 'dockercompose' ? 'docker-compose.yml' : 'gcp-deploy.yml'}
              </span>
            </div>

            <pre className="p-4 overflow-x-auto text-slate-200 font-mono text-[11px] leading-relaxed max-h-96 select-all scrollbar-thin">
              <code>{getCodeString()}</code>
            </pre>
          </div>

        </div>

      </div>

    </div>
  );
}
