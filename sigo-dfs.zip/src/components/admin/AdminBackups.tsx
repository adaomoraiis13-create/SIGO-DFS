import React, { useState } from 'react';
import { 
  Database, 
  Check, 
  RefreshCw, 
  Download, 
  Trash2, 
  AlertOctagon, 
  Calendar, 
  Play, 
  CheckCircle2 
} from 'lucide-react';

export default function AdminBackups() {
  const [backups, setBackups] = useState([
    { id: 'b-1', name: 'backup_dfs_sigo_completo_2026-07-16.json', type: 'Completo', size: '1.24 MB', date: '16/07/2026 02:00', status: 'Sucesso', integrity: 'Válido' },
    { id: 'b-2', name: 'backup_dfs_sigo_inc_2026-07-15.json', type: 'Incremental', size: '142 KB', date: '15/07/2026 02:00', status: 'Sucesso', integrity: 'Válido' },
    { id: 'b-3', name: 'backup_dfs_sigo_inc_2026-07-14.json', type: 'Incremental', size: '128 KB', date: '14/07/2026 02:00', status: 'Sucesso', integrity: 'Válido' },
    { id: 'b-4', name: 'backup_dfs_sigo_completo_2026-07-09.json', type: 'Completo', size: '1.20 MB', date: '09/07/2026 02:00', status: 'Sucesso', integrity: 'Válido' },
  ]);

  const [backupType, setBackupType] = useState('Completo');
  const [schedule, setSchedule] = useState('daily');
  const [backingUp, setBackingUp] = useState(false);
  const [backupProgress, setBackupProgress] = useState(0);
  const [successBanner, setSuccessBanner] = useState<string | null>(null);

  const triggerManualBackup = () => {
    setBackingUp(true);
    setBackupProgress(10);
    
    const interval = setInterval(() => {
      setBackupProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setBackingUp(false);
          setSuccessBanner(`Backup "${backupType}" gerado com sucesso no container de dados!`);
          
          const newB = {
            id: `b-${Date.now()}`,
            name: `backup_dfs_sigo_manual_${new Date().toISOString().split('T')[0]}_${Date.now().toString().slice(-4)}.json`,
            type: backupType,
            size: backupType === 'Completo' ? '1.25 MB' : '45 KB',
            date: new Date().toLocaleDateString('pt-AO') + ' ' + new Date().toLocaleTimeString('pt-AO', { hour: '2-digit', minute: '2-digit' }),
            status: 'Sucesso',
            integrity: 'Válido'
          };
          setBackups(prevB => [newB, ...prevB]);
          setTimeout(() => setSuccessBanner(null), 4000);
          return 0;
        }
        return prev + 15;
      });
    }, 200);
  };

  const verifyIntegrity = () => {
    alert('A verificar integridade hash SHA-256 de todas as coleções de dados...\n\nResultado: Sincronismo 100% íntegro. Nenhuma anomalia de persistência ou corrupção de JSON detetada.');
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      <div className="space-y-0.5">
        <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
          <Database className="w-5 h-5 text-sky-600" /> Cópias de Segurança & Restauro (Backups)
        </h3>
        <p className="text-xs text-slate-500 font-medium">Configure e descarregue cópias completas do banco de dados JSON SIGO-DFS para garantir a integridade histórica dos dados.</p>
      </div>

      {successBanner && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-3.5 rounded-xl text-xs flex gap-2 font-bold">
          <Check className="w-4 h-4 text-emerald-600 mt-0.5" />
          <span>{successBanner}</span>
        </div>
      )}

      {/* BACKUP CONTROLS AND SETTINGS */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 text-xs font-medium">
        
        {/* MANUAL BACKUP CARD */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4 flex flex-col justify-between">
          <div className="space-y-4">
            <h4 className="text-slate-800 font-extrabold text-sm pb-1 border-b border-slate-100">Cópia de Segurança Manual</h4>
            
            <div className="space-y-1">
              <label className="text-slate-700 block font-bold">Tipo de Backup</label>
              <select
                value={backupType}
                onChange={e => setBackupType(e.target.value)}
                className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-bold focus:outline-hidden"
              >
                <option value="Completo">Completo (Full Database Image)</option>
                <option value="Incremental">Incremental (Apenas alterações do dia)</option>
                <option value="Diferencial">Diferencial (Alterações desde o último Full)</option>
              </select>
            </div>

            {backingUp && (
              <div className="space-y-1.5 p-3 bg-slate-50 border border-slate-150 rounded-lg">
                <div className="flex justify-between text-[11px] font-bold text-slate-700">
                  <span>A compactar e cifrar...</span>
                  <span className="font-mono">{backupProgress}%</span>
                </div>
                <div className="w-full bg-slate-200 rounded-full h-1.5 overflow-hidden">
                  <div className="bg-sky-500 h-1.5 rounded-full transition-all duration-150" style={{ width: `${backupProgress}%` }}></div>
                </div>
              </div>
            )}
          </div>

          <div className="space-y-2 pt-4 border-t border-slate-100">
            <button
              onClick={triggerManualBackup}
              disabled={backingUp}
              className="w-full px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white font-bold rounded-lg border border-sky-500 transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
            >
              <Play className="w-3.5 h-3.5" /> Executar Backup Agora
            </button>
            <button
              onClick={verifyIntegrity}
              disabled={backingUp}
              className="w-full px-4 py-2 bg-slate-50 hover:bg-slate-100 text-slate-700 rounded-lg border border-slate-200 transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
            >
              <CheckCircle2 className="w-3.5 h-3.5" /> Validar Integridade (Integrity Check)
            </button>
          </div>
        </div>

        {/* AUTOMATIC SCHEDULE CARD */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4 flex flex-col justify-between">
          <div className="space-y-4">
            <h4 className="text-slate-800 font-extrabold text-sm pb-1 border-b border-slate-100 flex items-center gap-1.5">
              <Calendar className="w-4.5 h-4.5 text-sky-600" /> Agendamento de Rotinas (Cron)
            </h4>

            <div className="space-y-1.5">
              <label className="text-slate-700 block font-bold">Frequência Automática</label>
              <select
                value={schedule}
                onChange={e => setSchedule(e.target.value)}
                className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-bold focus:outline-hidden"
              >
                <option value="daily">Diário (Todas as noites às 02:00 WAT)</option>
                <option value="weekly">Semanal (Todos os domingos às 03:00 WAT)</option>
                <option value="disabled">Desativar backups automáticos</option>
              </select>
            </div>

            <div className="bg-slate-50 p-3 rounded-lg flex gap-2 text-[11px] text-slate-500 leading-relaxed font-medium">
              <AlertOctagon className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
              <span>Rotinas automáticas são armazenadas de forma segura em buckets cifrados no Google Cloud Storage (GCS) em Luanda.</span>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100">
            <button
              onClick={() => alert('Políticas de rotina cron gravadas com sucesso.')}
              className="w-full px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-lg transition-all text-center cursor-pointer"
            >
              Aplicar Rotina de Agendamento
            </button>
          </div>
        </div>

        {/* ACTIVE HISTORY LOG OF GENERATED BACKUPS */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4 lg:col-span-1">
          <h4 className="text-slate-800 font-extrabold text-sm pb-1 border-b border-slate-100">Estatísticas do Disco da Base de Dados</h4>
          <div className="space-y-3 leading-relaxed">
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-500">Último Backup Completo:</span>
              <span className="font-bold text-slate-800">Hoje às 02:00</span>
            </div>
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-500">Número Total de Imagens:</span>
              <span className="font-bold text-slate-800">12 cópias</span>
            </div>
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-500">Espaço em uso por Backups:</span>
              <span className="font-bold text-sky-600 font-mono">14.8 MB</span>
            </div>
            <div className="p-3 bg-indigo-50/50 border border-indigo-150 rounded-lg text-[11px] text-indigo-950 font-medium leading-relaxed">
              <b>Política de Retenção:</b> Cópias de segurança diárias são conservadas por 30 dias de acordo com os regulamentos de auditoria AVSEC da ATO.
            </div>
          </div>
        </div>

      </div>

      {/* BACKUPS HISTORY TABLE LIST */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-2xs overflow-hidden">
        <div className="px-4 py-3 bg-slate-50 border-b border-slate-150">
          <h4 className="font-extrabold text-slate-800 text-xs">Histórico Recente de Imagens de Dados</h4>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-100 text-slate-500 text-[10px] font-black uppercase tracking-wider border-b border-slate-200">
                <th className="p-3 pl-4">Nome do Ficheiro de Backup</th>
                <th className="p-3">Tipo</th>
                <th className="p-3 font-mono">Tamanho</th>
                <th className="p-3">Data e Hora</th>
                <th className="p-3">Integridade SHA-256</th>
                <th className="p-3">Estado</th>
                <th className="p-3 pr-4 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {backups.map(b => (
                <tr key={b.id} className="hover:bg-slate-50/50 text-slate-700">
                  <td className="p-3 pl-4 font-bold text-slate-800 font-mono text-[11px] max-w-xs truncate">{b.name}</td>
                  <td className="p-3">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                      b.type === 'Completo' ? 'bg-indigo-50 text-indigo-800 border-indigo-200' : 'bg-slate-50 text-slate-600 border-slate-200'
                    }`}>
                      {b.type}
                    </span>
                  </td>
                  <td className="p-3 font-mono">{b.size}</td>
                  <td className="p-3 text-slate-500 font-mono">{b.date}</td>
                  <td className="p-3">
                    <span className="inline-flex items-center gap-1 text-emerald-600 font-bold">
                      <Check className="w-3.5 h-3.5" /> Hash Válido
                    </span>
                  </td>
                  <td className="p-3">
                    <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-50 text-emerald-800 border border-emerald-200 font-bold">
                      {b.status}
                    </span>
                  </td>
                  <td className="p-3 pr-4 text-right">
                    <div className="flex justify-end gap-1.5">
                      <button
                        onClick={() => alert(`A transferir cópia ${b.name} do servidor...`)}
                        className="p-1.5 text-slate-400 hover:text-sky-600 hover:bg-sky-50 rounded-lg transition-all"
                        title="Descarregar Backup"
                      >
                        <Download className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => {
                          if (window.confirm(`Tem a certeza que deseja eliminar permanentemente a imagem ${b.name}?`)) {
                            setBackups(prev => prev.filter(bk => bk.id !== b.id));
                          }
                        }}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all cursor-pointer"
                        title="Remover Cópia"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
