import React, { useState } from 'react';
import { 
  Link, 
  Check, 
  Copy, 
  Plus, 
  Key, 
  FileCode, 
  Settings2, 
  CloudLightning, 
  RefreshCw, 
  Info,
  Sliders
} from 'lucide-react';

interface ApiKey {
  id: string;
  name: string;
  key: string;
  created: string;
  calls: number;
}

export default function AdminIntegrations() {
  const [activeTab, setActiveTab] = useState<'integrations' | 'api'>('integrations');

  // Integrations state
  const [m365Connected, setM365Connected] = useState(true);
  const [teamsConnected, setTeamsConnected] = useState(true);
  const [ldapConnected, setLdapConnected] = useState(false);

  // LDAP parameters
  const [ldapServer, setLdapServer] = useState('ldap://ad.ato-oc.co.ao:389');
  const [ldapBaseDn, setLdapBaseDn] = useState('DC=ato-oc,DC=co,DC=ao');

  // API rate limit slider
  const [rateLimit, setRateLimit] = useState(150);

  // Generated API keys list
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([
    { id: 'key-1', name: 'Power BI Executivo Dashboard', key: 'dfs_live_pk_814ea3899f1c718a7c6f', created: '14/07/2026', calls: 1420 },
    { id: 'key-2', name: 'Sincronizador ANAC Angola', key: 'dfs_live_pk_352bc1946820df38a163', created: '12/07/2026', calls: 350 },
  ]);

  const [newKeyName, setNewKeyName] = useState('');
  const [successBanner, setSuccessBanner] = useState<string | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const handleGenerateKey = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKeyName) return;

    const randomHex = Array.from({ length: 20 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
    const createdKey: ApiKey = {
      id: `key-${Date.now()}`,
      name: newKeyName,
      key: `dfs_live_pk_${randomHex}`,
      created: new Date().toLocaleDateString('pt-AO'),
      calls: 0
    };

    setApiKeys(prev => [...prev, createdKey]);
    setNewKeyName('');
    setSuccessBanner(`Chave de API "${newKeyName}" gerada com sucesso!`);
    setTimeout(() => setSuccessBanner(null), 3000);
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(id);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* SUCCESS BANNER */}
      {successBanner && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-3.5 rounded-xl text-xs flex gap-2 font-bold animate-in slide-in-from-top-1 duration-150">
          <Check className="w-4 h-4 text-emerald-600 mt-0.5" />
          <span>{successBanner}</span>
        </div>
      )}

      {/* TOP NAVIGATION SUB-SELECTORS */}
      <div className="flex gap-2 border-b border-slate-200 pb-px font-bold text-xs text-slate-500">
        <button
          onClick={() => setActiveTab('integrations')}
          className={`py-1.5 px-3 border-b-2 flex items-center gap-1.5 whitespace-nowrap transition-all ${
            activeTab === 'integrations' ? 'border-sky-600 text-sky-600' : 'border-transparent hover:text-slate-800'
          }`}
        >
          <CloudLightning className="w-4 h-4" /> Conectores Corporativos (M365, Teams, LDAP)
        </button>
        <button
          onClick={() => setActiveTab('api')}
          className={`py-1.5 px-3 border-b-2 flex items-center gap-1.5 whitespace-nowrap transition-all ${
            activeTab === 'api' ? 'border-sky-600 text-sky-600' : 'border-transparent hover:text-slate-800'
          }`}
        >
          <Key className="w-4 h-4" /> APIs Corporativas & Chaves (REST/JSON)
        </button>
      </div>

      {/* TAB CONTENTS */}
      
      {/* 1. CONNECTORS TAB */}
      {activeTab === 'integrations' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 text-xs font-medium">
          
          {/* MICROSOFT 365 CARD */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs flex flex-col justify-between space-y-4">
            <div className="space-y-3">
              <div className="flex justify-between items-start">
                <span className="p-2 bg-indigo-50 border border-indigo-100 rounded-xl">
                  <CloudLightning className="w-5 h-5 text-indigo-600" />
                </span>
                <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase ${
                  m365Connected ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' : 'bg-slate-100 text-slate-500 border border-slate-200'
                }`}>
                  {m365Connected ? 'Ligado' : 'Desligado'}
                </span>
              </div>

              <h4 className="font-extrabold text-slate-950 text-sm">Microsoft 365 & SharePoint</h4>
              <p className="text-slate-500 leading-relaxed font-medium">
                Sincronize arquivos de balanço e relatórios gerados diretamente no portal de partilha do SharePoint corporativo da ATO.
              </p>
            </div>

            <div className="pt-3 border-t border-slate-100 flex justify-between items-center">
              <span className="text-[10px] text-slate-400 font-mono">ID: ato_sharepoint_connector</span>
              <button
                onClick={() => setM365Connected(!m365Connected)}
                className={`px-3 py-1.5 font-bold rounded-lg border transition-all cursor-pointer ${
                  m365Connected ? 'bg-slate-100 text-slate-700 hover:bg-slate-200' : 'bg-sky-600 text-white hover:bg-sky-700 border-sky-500'
                }`}
              >
                {m365Connected ? 'Desconectar' : 'Sincronizar'}
              </button>
            </div>
          </div>

          {/* TEAMS CONNECTOR */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs flex flex-col justify-between space-y-4">
            <div className="space-y-3">
              <div className="flex justify-between items-start">
                <span className="p-2 bg-sky-50 border border-sky-100 rounded-xl">
                  <CloudLightning className="w-5 h-5 text-sky-600" />
                </span>
                <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase ${
                  teamsConnected ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' : 'bg-slate-100 text-slate-500 border border-slate-200'
                }`}>
                  {teamsConnected ? 'Ligado' : 'Desligado'}
                </span>
              </div>

              <h4 className="font-extrabold text-slate-950 text-sm">Canais & Webhooks Microsoft Teams</h4>
              <p className="text-slate-500 leading-relaxed font-medium">
                Dispare notificações em canais dedicados da Direção da ATO sempre que rascunhos de Balanço Operacional forem criados ou homologados.
              </p>
            </div>

            <div className="pt-3 border-t border-slate-100 flex justify-between items-center">
              <span className="text-[10px] text-slate-400 font-mono">Teams Webhook Activo</span>
              <button
                onClick={() => setTeamsConnected(!teamsConnected)}
                className={`px-3 py-1.5 font-bold rounded-lg border transition-all cursor-pointer ${
                  teamsConnected ? 'bg-slate-100 text-slate-700 hover:bg-slate-200' : 'bg-sky-600 text-white hover:bg-sky-700 border-sky-500'
                }`}
              >
                {teamsConnected ? 'Desconectar' : 'Sincronizar'}
              </button>
            </div>
          </div>

          {/* ACTIVE DIRECTORY CONNECTOR */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4">
            <div className="flex justify-between items-start pb-1 border-b border-slate-100">
              <h4 className="font-extrabold text-slate-900 text-sm">Active Directory / LDAP Credenciais</h4>
              <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase ${
                ldapConnected ? 'bg-emerald-50 text-emerald-800' : 'bg-amber-50 text-amber-800'
              }`}>
                {ldapConnected ? 'Activo' : 'Offline'}
              </span>
            </div>

            <div className="space-y-3">
              <div className="space-y-1">
                <label className="text-slate-700 block font-bold">Servidor LDAP Corporativo</label>
                <input
                  type="text"
                  value={ldapServer}
                  onChange={e => setLdapServer(e.target.value)}
                  className="w-full py-1.5 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-700 block font-bold">Base DN (Filtro Hierárquico)</label>
                <input
                  type="text"
                  value={ldapBaseDn}
                  onChange={e => setLdapBaseDn(e.target.value)}
                  className="w-full py-1.5 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-mono"
                />
              </div>

              <button
                type="button"
                onClick={() => {
                  setLdapConnected(!ldapConnected);
                  alert(ldapConnected ? 'Desconexão AD bem-sucedida.' : 'Sincronização com Active Directory estabelecida no fuso de Luanda.');
                }}
                className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-lg border border-slate-900 cursor-pointer text-center"
              >
                {ldapConnected ? 'Cortar Ligação LDAP' : 'Testar & Ligar Conectores'}
              </button>
            </div>
          </div>

        </div>
      )}

      {/* 2. API KEYS TAB */}
      {activeTab === 'api' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 text-xs font-medium">
          
          {/* API RATE LIMIT & SPECIFICATION */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4 lg:col-span-1 flex flex-col justify-between">
            <div className="space-y-4">
              <h4 className="text-slate-800 font-extrabold text-sm pb-1 border-b border-slate-100 flex items-center gap-1.5">
                <Sliders className="w-4.5 h-4.5 text-sky-600" /> Diretivas de Tráfego de API
              </h4>

              <div className="space-y-2">
                <div className="flex justify-between font-bold">
                  <span className="text-slate-700">Taxa Limite (Rate Limiting)</span>
                  <span className="text-sky-600 font-mono">{rateLimit} reqs / min</span>
                </div>
                <input
                  type="range"
                  min="50"
                  max="500"
                  step="25"
                  value={rateLimit}
                  onChange={e => setRateLimit(parseInt(e.target.value))}
                  className="w-full accent-sky-600"
                />
                <p className="text-[10px] text-slate-400">Impede ataques de negação de serviço e abuso de OCR no container.</p>
              </div>

              <div className="bg-slate-50 border border-slate-150 p-3 rounded-lg flex gap-2 text-slate-600 leading-relaxed font-medium">
                <Info className="w-4.5 h-4.5 text-slate-400 shrink-0 mt-0.5" />
                <span>O portal disponibiliza especificações OpenAPI compiladas automaticamente.</span>
              </div>
            </div>

            <div className="space-y-2 pt-4 border-t border-slate-100">
              <button
                onClick={() => alert('Swagger JSON exportado para a área de transferência')}
                className="w-full px-4 py-2 bg-slate-50 hover:bg-slate-100 text-slate-700 rounded-lg border border-slate-200 transition-all flex items-center justify-center gap-1.5 cursor-pointer font-bold"
              >
                <FileCode className="w-4 h-4" /> Descarregar OpenAPI / Swagger
              </button>
            </div>
          </div>

          {/* GENERATE NEW API KEYS */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4 lg:col-span-2">
            <h4 className="text-slate-800 font-extrabold text-sm pb-1 border-b border-slate-100">Gerar Chave de Integração Corporativa</h4>

            <form onSubmit={handleGenerateKey} className="flex flex-col sm:flex-row gap-3 items-end">
              <div className="space-y-1 flex-1">
                <label className="text-slate-700 block font-bold">Nome identificador da Aplicação / Sistema parceiro</label>
                <input
                  type="text"
                  placeholder="Ex: Conector SIGA, Consola Aeroporto de Catumbela"
                  value={newKeyName}
                  onChange={e => setNewKeyName(e.target.value)}
                  className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-bold focus:outline-hidden"
                  required
                />
              </div>

              <button
                type="submit"
                className="px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-lg font-bold border border-sky-500 cursor-pointer flex items-center gap-1.5 whitespace-nowrap"
              >
                <Plus className="w-4 h-4" /> Criar Credencial
              </button>
            </form>

            <div className="border border-slate-150 rounded-xl overflow-hidden mt-4">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-50 text-slate-500 text-[10px] font-black uppercase border-b border-slate-200">
                    <th className="p-3 pl-4">Identificador</th>
                    <th className="p-3">Chave de Produção</th>
                    <th className="p-3">Criado Em</th>
                    <th className="p-3">Total Consumido</th>
                    <th className="p-3 pr-4 text-right">Ação</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  {apiKeys.map(key => (
                    <tr key={key.id} className="hover:bg-slate-50/50 text-slate-700">
                      <td className="p-3 pl-4 font-bold text-slate-800">{key.name}</td>
                      <td className="p-3 font-mono text-[10.5px] text-slate-500">
                        {key.key}
                      </td>
                      <td className="p-3 font-mono">{key.created}</td>
                      <td className="p-3 font-mono text-slate-500">{key.calls} reqs</td>
                      <td className="p-3 pr-4 text-right">
                        <button
                          onClick={() => copyToClipboard(key.key, key.id)}
                          className="p-1.5 text-slate-400 hover:text-sky-600 hover:bg-sky-50 rounded-lg transition-all"
                          title="Copiar Chave para a Clipboard"
                        >
                          {copiedKey === key.id ? (
                            <span className="text-emerald-600 text-[10px] font-bold">Copiado!</span>
                          ) : (
                            <Copy className="w-4 h-4" />
                          )}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

          </div>

        </div>
      )}

    </div>
  );
}
