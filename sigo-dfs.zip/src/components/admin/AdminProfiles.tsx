import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Shield, 
  Plus, 
  Check, 
  Info, 
  UserSquare2, 
  Lock, 
  Eye, 
  Edit3, 
  FileCheck 
} from 'lucide-react';

export default function AdminProfiles() {
  const [profiles, setProfiles] = useState([
    { id: 'p-1', name: 'Diretor', desc: 'Acesso estratégico. Leitura de todas as divisões e aprovação final de balanços operacionais.' },
    { id: 'p-2', name: 'Secretariado', desc: 'Acesso operacional central. Consolidação automática de balanços, uploads de fontes e triagem.' },
    { id: 'p-3', name: 'Chefe da DOS', desc: 'Acesso restrito à Divisão de Operações e Segurança. Submissão e resposta a planos de ação.' },
    { id: 'p-4', name: 'Chefe da DFC', desc: 'Acesso restrito à Divisão de Facilitação e Controle. Submissão e resposta a planos de ação.' },
    { id: 'p-5', name: 'Chefe da FAL', desc: 'Acesso restrito à Divisão de Facilitação e Regulamentação. Submissão e resposta.' },
    { id: 'p-6', name: 'Chefe da DRCQ', desc: 'Acesso restrito à Divisão de Regulação e Qualidade. Auditoria e homologação de planos.' },
    { id: 'p-7', name: 'Operador', desc: 'Leitura e escrita de minutas e relatórios preliminares de campo.' },
    { id: 'p-8', name: 'Consulta', desc: 'Acesso estritamente de leitura aos dashboards executivos e relatórios homologados.' },
  ]);

  const [selectedProfile, setSelectedProfile] = useState('p-1');
  const [newProfileName, setNewProfileName] = useState('');
  const [newProfileDesc, setNewProfileDesc] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);

  // Modular and granular permission categories
  const modulesList = [
    { key: 'balancos', label: 'Workflow de Balanços' },
    { key: 'documentos', label: 'Gestão Documental & OCR' },
    { key: 'plano_acao', label: 'Plano de Ação Inteligente' },
    { key: 'bi', label: 'Business Intelligence (BI)' },
    { key: 'auditoria', label: 'Histórico de Auditoria' },
    { key: 'administracao', label: 'Módulo Administrativo' }
  ];

  const operationsList = [
    { key: 'ler', label: 'Leitura (Read)' },
    { key: 'criar', label: 'Criação (Create)' },
    { key: 'editar', label: 'Edição (Update)' },
    { key: 'eliminar', label: 'Eliminação (Delete)' },
    { key: 'aprovar', label: 'Aprovação (Approve)' },
    { key: 'exportar', label: 'Exportações' }
  ];

  // Permissions state per profile ID
  const [permissions, setPermissions] = useState<{ [profileId: string]: { [moduleKey: string]: { [opKey: string]: boolean } } }>({
    'p-1': { // Diretor: Full read, approve, export, but limited delete
      'balancos': { 'ler': true, 'criar': false, 'editar': true, 'eliminar': false, 'aprovar': true, 'exportar': true },
      'documentos': { 'ler': true, 'criar': false, 'editar': false, 'eliminar': false, 'aprovar': true, 'exportar': true },
      'plano_acao': { 'ler': true, 'criar': true, 'editar': true, 'eliminar': false, 'aprovar': true, 'exportar': true },
      'bi': { 'ler': true, 'criar': false, 'editar': false, 'eliminar': false, 'aprovar': false, 'exportar': true },
      'auditoria': { 'ler': true, 'criar': false, 'editar': false, 'eliminar': false, 'aprovar': false, 'exportar': true },
      'administracao': { 'ler': true, 'criar': false, 'editar': false, 'eliminar': false, 'aprovar': false, 'exportar': false },
    },
    'p-2': { // Secretariado: Creation, editing, full file uploads, consolidate
      'balancos': { 'ler': true, 'criar': true, 'editar': true, 'eliminar': true, 'aprovar': false, 'exportar': true },
      'documentos': { 'ler': true, 'criar': true, 'editar': true, 'eliminar': true, 'aprovar': true, 'exportar': true },
      'plano_acao': { 'ler': true, 'criar': true, 'editar': true, 'eliminar': false, 'aprovar': false, 'exportar': true },
      'bi': { 'ler': true, 'criar': true, 'editar': true, 'eliminar': false, 'aprovar': false, 'exportar': true },
      'auditoria': { 'ler': true, 'criar': false, 'editar': false, 'eliminar': false, 'aprovar': false, 'exportar': true },
      'administracao': { 'ler': true, 'criar': false, 'editar': false, 'eliminar': false, 'aprovar': false, 'exportar': false },
    },
    'p-3': { // Chefe da DOS: limited to read/update of DOS
      'balancos': { 'ler': true, 'criar': false, 'editar': true, 'eliminar': false, 'aprovar': false, 'exportar': true },
      'documentos': { 'ler': true, 'criar': true, 'editar': true, 'eliminar': false, 'aprovar': false, 'exportar': false },
      'plano_acao': { 'ler': true, 'criar': false, 'editar': true, 'eliminar': false, 'aprovar': false, 'exportar': true },
      'bi': { 'ler': true, 'criar': false, 'editar': false, 'eliminar': false, 'aprovar': false, 'exportar': true },
      'auditoria': { 'ler': false, 'criar': false, 'editar': false, 'eliminar': false, 'aprovar': false, 'exportar': false },
      'administracao': { 'ler': false, 'criar': false, 'editar': false, 'eliminar': false, 'aprovar': false, 'exportar': false },
    }
  });

  const [saveSuccess, setSaveSuccess] = useState(false);

  const togglePermission = (profileId: string, moduleKey: string, opKey: string) => {
    setPermissions(prev => {
      const profilePerms = prev[profileId] || {};
      const modulePerms = profilePerms[moduleKey] || {};
      const currentVal = modulePerms[opKey] || false;

      return {
        ...prev,
        [profileId]: {
          ...profilePerms,
          [moduleKey]: {
            ...modulePerms,
            [opKey]: !currentVal
          }
        }
      };
    });
  };

  const handleAddProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProfileName) return;

    const id = `p-custom-${Date.now()}`;
    const newProf = {
      id,
      name: newProfileName,
      desc: newProfileDesc || 'Perfil de utilizador customizado para a estrutura aeroportuária.'
    };

    setProfiles(p => [...p, newProf]);
    setSelectedProfile(id);
    
    // Seed blank permissions
    setPermissions(prev => ({
      ...prev,
      [id]: modulesList.reduce((acc, m) => {
        acc[m.key] = operationsList.reduce((oAcc, o) => {
          oAcc[o.key] = false;
          return oAcc;
        }, {} as { [key: string]: boolean });
        return acc;
      }, {} as { [moduleKey: string]: { [opKey: string]: boolean } })
    }));

    setNewProfileName('');
    setNewProfileDesc('');
    setShowAddModal(false);
  };

  const handleSaveMatrix = () => {
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  const activeProf = profiles.find(p => p.id === selectedProfile) || profiles[0];

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        
        {/* PROFILE LIST */}
        <div className="lg:col-span-1 bg-white border border-slate-200 rounded-xl p-4 shadow-2xs space-y-4">
          <div className="flex justify-between items-center border-b border-slate-100 pb-2">
            <h3 className="font-extrabold text-slate-800 text-sm flex items-center gap-1.5">
              <UserSquare2 className="w-4 h-4 text-sky-600" /> Perfis Ativos
            </h3>
            <button 
              onClick={() => setShowAddModal(true)}
              className="p-1 hover:bg-slate-100 text-sky-600 rounded-lg border border-slate-200 transition-all"
              title="Adicionar Perfil Customizado"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>

          <div className="space-y-1.5 max-h-96 overflow-y-auto">
            {profiles.map(p => (
              <button
                key={p.id}
                onClick={() => setSelectedProfile(p.id)}
                className={`w-full text-left p-2.5 rounded-lg text-xs transition-all flex flex-col gap-1 ${
                  selectedProfile === p.id 
                    ? 'bg-sky-50 text-sky-950 border-l-4 border-sky-600 font-bold' 
                    : 'hover:bg-slate-50 text-slate-600 border-l-4 border-transparent'
                }`}
              >
                <span>{p.name}</span>
                <span className="text-[10px] text-slate-400 font-normal line-clamp-1">{p.desc}</span>
              </button>
            ))}
          </div>

          <div className="bg-slate-50 p-3 rounded-lg flex gap-2 text-[11px] text-slate-500 leading-relaxed font-medium">
            <Info className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
            <span>Modifique as permissões de acesso ao clicar nas caixas de seleção da matriz correspondente.</span>
          </div>
        </div>

        {/* PERMISSIONS MATRIX */}
        <div className="lg:col-span-3 bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-100 pb-3">
            <div>
              <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-sky-600" /> Matriz de Permissões: {activeProf.name}
              </h3>
              <p className="text-xs text-slate-500 font-medium">{activeProf.desc}</p>
            </div>

            <button
              onClick={handleSaveMatrix}
              className="px-4 py-1.5 bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs rounded-lg border border-sky-500 transition-all shrink-0 cursor-pointer"
            >
              Salvar Matriz do Perfil
            </button>
          </div>

          {/* Success message banner */}
          {saveSuccess && (
            <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-3 rounded-xl text-xs flex gap-2 font-bold animate-in slide-in-from-top-2 duration-150">
              <Check className="w-4 h-4 text-emerald-600 mt-0.5" />
              <span>Alterações de segurança e RBAC para "{activeProf.name}" sincronizadas em toda a nuvem ATO.</span>
            </div>
          )}

          {/* Matrix table representation */}
          <div className="overflow-x-auto border border-slate-150 rounded-xl">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 text-slate-500 text-[10px] font-black uppercase tracking-wider border-b border-slate-200">
                  <th className="p-3">Módulo / Área de Funcionalidade</th>
                  {operationsList.map(op => (
                    <th key={op.key} className="p-3 text-center">{op.label}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                {modulesList.map(m => {
                  const modulePerms = permissions[activeProf.id]?.[m.key] || {};
                  return (
                    <tr key={m.key} className="hover:bg-slate-50/50">
                      <td className="p-3 font-bold text-slate-800">{m.label}</td>
                      {operationsList.map(op => {
                        const isGranted = modulePerms[op.key] || false;
                        return (
                          <td key={op.key} className="p-3 text-center">
                            <input
                              type="checkbox"
                              checked={isGranted}
                              onChange={() => togglePermission(activeProf.id, m.key, op.key)}
                              className="w-4.5 h-4.5 rounded text-sky-600 border-slate-300 focus:ring-sky-500 cursor-pointer"
                            />
                          </td>
                        );
                      })}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
            <div className="border border-slate-150 p-3 rounded-xl flex gap-3 text-xs">
              <Lock className="w-4.5 h-4.5 text-slate-400 mt-0.5 shrink-0" />
              <div className="space-y-1 leading-relaxed font-medium">
                <span className="font-extrabold text-slate-800 block text-xs">Acessos Condicionais de Divisão</span>
                <p className="text-slate-500 text-[11px]">
                  Utilizadores com perfil <b>Chefe de Divisão</b> herdam filtros automáticos que vedam a escrita e leitura de balanços de outras divisões no servidor SIGO-DFS.
                </p>
              </div>
            </div>

            <div className="border border-slate-150 p-3 rounded-xl flex gap-3 text-xs">
              <FileCheck className="w-4.5 h-4.5 text-slate-400 mt-0.5 shrink-0" />
              <div className="space-y-1 leading-relaxed font-medium">
                <span className="font-extrabold text-slate-800 block text-xs">Assinatura de Logs de Homologação</span>
                <p className="text-slate-500 text-[11px]">
                  Qualquer mudança efetuada nesta matriz gera logs auditáveis permanentes no container, registando o IP do Administrador que autenticou a operação.
                </p>
              </div>
            </div>
          </div>

        </div>

      </div>

      {/* ADD PROFILE MODAL OVERLAY */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl shadow-2xl w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            
            <div className="px-5 py-4 bg-slate-50 border-b border-slate-150 flex justify-between items-center">
              <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-1.5">
                <Shield className="w-5 h-5 text-sky-600" /> Criar Perfil de Acesso Customizado
              </h3>
              <button 
                type="button"
                onClick={() => setShowAddModal(false)}
                className="p-1 text-slate-400 hover:text-slate-800 hover:bg-slate-150 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddProfile} className="p-5 space-y-4 text-xs font-medium">
              
              <div className="space-y-1">
                <label className="text-slate-700 block font-bold">Nome do Perfil</label>
                <input
                  type="text"
                  value={newProfileName}
                  onChange={e => setNewProfileName(e.target.value)}
                  className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-bold focus:outline-hidden"
                  placeholder="Ex: Auditor Externo ICAO, Inspetor Técnico"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-700 block font-bold">Descrição Funcional</label>
                <textarea
                  value={newProfileDesc}
                  onChange={e => setNewProfileDesc(e.target.value)}
                  rows={3}
                  className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium"
                  placeholder="Defina o propósito de negócio ou escopo operacional deste perfil..."
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-bold"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-lg font-bold border border-sky-500 cursor-pointer"
                >
                  Criar Perfil
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
}

interface XProps {
  className?: string;
}
function X({ className }: XProps) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor" className={className}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M6 18 18 6M6 6l12 12" />
    </svg>
  );
}
