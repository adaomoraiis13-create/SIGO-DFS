import React, { useState, useEffect } from 'react';
import { 
  Settings, 
  Palette, 
  Globe, 
  Mail, 
  Check, 
  RotateCcw, 
  Type, 
  Signature,
  UserPlus,
  ShieldCheck,
  RefreshCw
} from 'lucide-react';
import * as api from '../../services/api.js';

export default function AdminSettings() {
  const [platformName, setPlatformName] = useState('DFS Insight Hub');
  const [logoUrl, setLogoUrl] = useState('');
  const [fontFamily, setFontFamily] = useState('Inter');
  const [language, setLanguage] = useState('pt_AO');
  const [timezone, setTimezone] = useState('Africa/Luanda');
  const [dateFormat, setDateFormat] = useState('DD/MM/YYYY');
  const [signatureText, setSignatureText] = useState('Direção Geral de Facilitação e Segurança aeroportuária - ATO OC Angola');

  // Colors
  const [primaryColor, setPrimaryColor] = useState('#0ea5e9'); // sky-500
  const [secondaryColor, setSecondaryColor] = useState('#f59e0b'); // amber-500

  // SMTP Settings
  const [smtpServer, setSmtpServer] = useState('smtp.ato-oc.co.ao');
  const [smtpPort, setSmtpPort] = useState('465');
  const [smtpUser, setSmtpUser] = useState('notificacoes.dfs@ato-oc.co.ao');
  const [smtpPass, setSmtpPass] = useState('************');
  const [smtpSecure, setSmtpSecure] = useState(true);

  // Real Database Persistence States
  const [allowedDomain, setAllowedDomain] = useState('ato-oc.co.ao');
  const [registrationPolicy, setRegistrationPolicy] = useState<'ONLY_INSTITUTIONAL' | 'ANY_VALID_EMAIL'>('ANY_VALID_EMAIL');

  const [activeSubTab, setActiveSubTab] = useState<'branding' | 'localization' | 'smtp' | 'registration'>('branding');
  const [successBanner, setSuccessBanner] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const loadRealSettings = async () => {
      try {
        setLoading(true);
        const data = await api.fetchSettings();
        if (data) {
          if (data.allowedDomain) setAllowedDomain(data.allowedDomain);
          if (data.registrationPolicy) setRegistrationPolicy(data.registrationPolicy);
        }
      } catch (err) {
        console.error('[SIGO-DFS AdminSettings] Falha ao ler configurações reais do servidor:', err);
      } finally {
        setLoading(false);
      }
    };
    loadRealSettings();
  }, []);

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setLoading(true);
      await api.updateSettings({
        allowedDomain,
        registrationPolicy,
        idleTimeoutMinutes: 15,
        powerpointTemplateName: 'Modelo_Institucional_DFS.pptx',
        pdfTemplateName: 'Modelo_Relatorio_DFS.pdf'
      });
      setSuccessBanner('Configurações globais e diretrizes de registo atualizadas de forma segura no servidor central.');
      setTimeout(() => setSuccessBanner(null), 4000);
    } catch (err) {
      console.error('[SIGO-DFS AdminSettings] Falha ao salvar configurações:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* SUCCESS BANNER */}
      {successBanner && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded-xl text-xs flex gap-2 font-bold shadow-2xs">
          <Check className="w-4 h-4 text-emerald-600 mt-0.5" />
          <span>{successBanner}</span>
        </div>
      )}

      {/* SUB-TABS SELECTOR */}
      <div className="flex gap-2 border-b border-slate-200 pb-px overflow-x-auto scrollbar-none">
        <button
          type="button"
          onClick={() => setActiveSubTab('branding')}
          className={`py-1.5 px-3 font-bold text-xs border-b-2 flex items-center gap-1.5 whitespace-nowrap transition-all ${
            activeSubTab === 'branding' ? 'border-sky-600 text-sky-600' : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Palette className="w-4 h-4" /> Branding & Identidade Visual
        </button>
        <button
          type="button"
          onClick={() => setActiveSubTab('localization')}
          className={`py-1.5 px-3 font-bold text-xs border-b-2 flex items-center gap-1.5 whitespace-nowrap transition-all ${
            activeSubTab === 'localization' ? 'border-sky-600 text-sky-600' : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Globe className="w-4 h-4" /> Localização & Formatos
        </button>
        <button
          type="button"
          onClick={() => setActiveSubTab('smtp')}
          className={`py-1.5 px-3 font-bold text-xs border-b-2 flex items-center gap-1.5 whitespace-nowrap transition-all ${
            activeSubTab === 'smtp' ? 'border-sky-600 text-sky-600' : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Mail className="w-4 h-4" /> Servidor de Correio (SMTP)
        </button>
        <button
          type="button"
          onClick={() => setActiveSubTab('registration')}
          className={`py-1.5 px-3 font-bold text-xs border-b-2 flex items-center gap-1.5 whitespace-nowrap transition-all ${
            activeSubTab === 'registration' ? 'border-sky-600 text-sky-600' : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <UserPlus className="w-4 h-4" /> Diretrizes de Registo
        </button>
      </div>

      {/* FORM BODY */}
      <form onSubmit={handleSaveSettings} className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs text-xs font-medium space-y-6">
        
        {/* 1. BRANDING TAB */}
        {activeSubTab === 'branding' && (
          <div className="space-y-4">
            <h4 className="text-slate-800 font-extrabold text-sm pb-1 border-b border-slate-100">Design Institucional da ATO</h4>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-slate-700 block font-bold">Nome Corporativo da Plataforma</label>
                <input
                  type="text"
                  value={platformName}
                  onChange={e => setPlatformName(e.target.value)}
                  className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-bold"
                  placeholder="Ex: DFS Insight Hub, SIGO-DFS"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-700 block font-bold">Caminho do Logótipo Oficial (URL/Vector)</label>
                <input
                  type="text"
                  value={logoUrl}
                  onChange={e => setLogoUrl(e.target.value)}
                  className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-mono"
                  placeholder="Deixe em branco para usar o logótipo pré-definido da ATO"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-1">
                <label className="text-slate-700 block font-bold">Cor Primária (ATO Blue)</label>
                <div className="flex gap-2">
                  <input
                    type="color"
                    value={primaryColor}
                    onChange={e => setPrimaryColor(e.target.value)}
                    className="w-10 h-8 p-0 bg-transparent border-0 cursor-pointer"
                  />
                  <input
                    type="text"
                    value={primaryColor}
                    onChange={e => setPrimaryColor(e.target.value)}
                    className="w-full py-2 px-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-mono font-bold"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-slate-700 block font-bold">Cor Secundária (ATO Gold)</label>
                <div className="flex gap-2">
                  <input
                    type="color"
                    value={secondaryColor}
                    onChange={e => setSecondaryColor(e.target.value)}
                    className="w-10 h-8 p-0 bg-transparent border-0 cursor-pointer"
                  />
                  <input
                    type="text"
                    value={secondaryColor}
                    onChange={e => setSecondaryColor(e.target.value)}
                    className="w-full py-2 px-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-mono font-bold"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-slate-700 block font-bold flex items-center gap-1">
                  <Type className="w-3.5 h-3.5 text-slate-400" /> Tipografia do Sistema
                </label>
                <select
                  value={fontFamily}
                  onChange={e => setFontFamily(e.target.value)}
                  className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-bold"
                >
                  <option value="Inter">Inter (Sans-Serif Moderno)</option>
                  <option value="Space Grotesk">Space Grotesk (Tech/Design)</option>
                  <option value="Outfit">Outfit (Display Elegant)</option>
                  <option value="JetBrains Mono">JetBrains Mono (Console/Developer)</option>
                </select>
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-slate-700 block font-bold flex items-center gap-1">
                <Signature className="w-3.5 h-3.5 text-slate-400" /> Assinatura Institucional Padrão (Rodapés)
              </label>
              <input
                type="text"
                value={signatureText}
                onChange={e => setSignatureText(e.target.value)}
                className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-semibold"
                placeholder="Ex: Direção Geral de Facilitação e Segurança"
              />
            </div>
          </div>
        )}

        {/* 2. LOCALIZATION TAB */}
        {activeSubTab === 'localization' && (
          <div className="space-y-4">
            <h4 className="text-slate-800 font-extrabold text-sm pb-1 border-b border-slate-100">Região, Fuso Horário e Idioma</h4>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-1">
                <label className="text-slate-700 block font-bold">Idioma Padrão</label>
                <select
                  value={language}
                  onChange={e => setLanguage(e.target.value)}
                  className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-bold"
                >
                  <option value="pt_AO">Português de Angola (AO)</option>
                  <option value="en_US">English (EN)</option>
                  <option value="fr_FR">Français (FR)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-slate-700 block font-bold">Fuso Horário Operacional</label>
                <select
                  value={timezone}
                  onChange={e => setTimezone(e.target.value)}
                  className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-bold"
                >
                  <option value="Africa/Luanda">Africa/Luanda (WAT - UTC+1)</option>
                  <option value="UTC">Universal Time Coordinated (UTC)</option>
                  <option value="Europe/Lisbon">Europe/Lisbon (WET - UTC+0)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-slate-700 block font-bold">Formato de Data Regulamentar</label>
                <select
                  value={dateFormat}
                  onChange={e => setDateFormat(e.target.value)}
                  className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-mono font-bold"
                >
                  <option value="DD/MM/YYYY">DD/MM/YYYY (Ex: 16/07/2026)</option>
                  <option value="YYYY-MM-DD">YYYY-MM-DD (Ex: 2026-07-16)</option>
                  <option value="MM/DD/YYYY">MM/DD/YYYY (Ex: 07/16/2026)</option>
                </select>
              </div>
            </div>
          </div>
        )}

        {/* 3. SMTP TAB */}
        {activeSubTab === 'smtp' && (
          <div className="space-y-4">
            <h4 className="text-slate-800 font-extrabold text-sm pb-1 border-b border-slate-100">Servidor de Correio Eletrónico (SMTP)</h4>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-slate-700 block font-bold">Servidor SMTP de Saída</label>
                <input
                  type="text"
                  value={smtpServer}
                  onChange={e => setSmtpServer(e.target.value)}
                  className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-mono font-semibold"
                  placeholder="smtp.exemplo.com"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-slate-700 block font-bold">Porta de Saída</label>
                  <input
                    type="text"
                    value={smtpPort}
                    onChange={e => setSmtpPort(e.target.value)}
                    className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-mono font-semibold"
                    placeholder="465 ou 587"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-700 block font-bold">Conexão Segura</label>
                  <div className="flex items-center gap-2 pt-1.5">
                    <input
                      type="checkbox"
                      id="smtpSecure"
                      checked={smtpSecure}
                      onChange={e => setSmtpSecure(e.target.checked)}
                      className="w-4.5 h-4.5 rounded text-sky-600 border-slate-300 focus:ring-sky-500 cursor-pointer"
                    />
                    <label htmlFor="smtpSecure" className="text-slate-700 font-bold cursor-pointer">Usar SSL/TLS</label>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-slate-700 block font-bold">Utilizador SMTP Authentificado</label>
                <input
                  type="text"
                  value={smtpUser}
                  onChange={e => setSmtpUser(e.target.value)}
                  className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-mono"
                  placeholder="email@dominio.com"
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-700 block font-bold">Palavra-passe SMTP</label>
                <input
                  type="password"
                  value={smtpPass}
                  onChange={e => setSmtpPass(e.target.value)}
                  className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-mono"
                  placeholder="Palavra-passe segura"
                />
              </div>
            </div>
          </div>
        )}

        {/* 4. REGISTRATION POLICY TAB */}
        {activeSubTab === 'registration' && (
          <div className="space-y-4 animate-in fade-in duration-200">
            <h4 className="text-slate-800 font-extrabold text-sm pb-1 border-b border-slate-100 flex items-center gap-2">
              <ShieldCheck className="w-4.5 h-4.5 text-sky-600" /> Diretrizes de Criação de Contas e Acesso
            </h4>

            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-slate-700 block font-bold">Política de Registo de Utilizadores</label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div 
                    onClick={() => setRegistrationPolicy('ANY_VALID_EMAIL')}
                    className={`p-4 border rounded-xl flex items-start gap-3 cursor-pointer transition-all ${
                      registrationPolicy === 'ANY_VALID_EMAIL' 
                        ? 'border-sky-500 bg-sky-50/20 ring-1 ring-sky-500' 
                        : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <input 
                      type="radio" 
                      name="regPolicy" 
                      checked={registrationPolicy === 'ANY_VALID_EMAIL'}
                      onChange={() => setRegistrationPolicy('ANY_VALID_EMAIL')}
                      className="mt-0.5 w-4.5 h-4.5 text-sky-600 border-slate-300 focus:ring-sky-500 cursor-pointer"
                    />
                    <div className="space-y-1">
                      <span className="font-extrabold text-slate-800 block">Qualquer endereço de e-mail válido</span>
                      <span className="text-[10px] text-slate-400 font-medium">Permite o registo de colaboradores utilizando qualquer domínio público ou privado (Gmail, Outlook, Yahoo, etc.). Mantém o fluxo de aprovação pendente pelo Secretariado.</span>
                    </div>
                  </div>

                  <div 
                    onClick={() => setRegistrationPolicy('ONLY_INSTITUTIONAL')}
                    className={`p-4 border rounded-xl flex items-start gap-3 cursor-pointer transition-all ${
                      registrationPolicy === 'ONLY_INSTITUTIONAL' 
                        ? 'border-sky-500 bg-sky-50/20 ring-1 ring-sky-500' 
                        : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <input 
                      type="radio" 
                      name="regPolicy" 
                      checked={registrationPolicy === 'ONLY_INSTITUTIONAL'}
                      onChange={() => setRegistrationPolicy('ONLY_INSTITUTIONAL')}
                      className="mt-0.5 w-4.5 h-4.5 text-sky-600 border-slate-300 focus:ring-sky-500 cursor-pointer"
                    />
                    <div className="space-y-1">
                      <span className="font-extrabold text-slate-800 block">Apenas e-mails institucionais</span>
                      <span className="text-[10px] text-slate-400 font-medium">Restringe estritamente o registo de novas contas a e-mails pertencentes ao domínio institucional autorizado do sistema.</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-1 max-w-md pt-2">
                <label className="text-slate-700 block font-bold">Domínio Institucional Autorizado</label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-slate-400 font-bold font-sans">@</span>
                  <input
                    type="text"
                    value={allowedDomain}
                    onChange={e => setAllowedDomain(e.target.value.replace(/^@/, ''))}
                    className="w-full py-2 pl-7 pr-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-bold font-mono focus:outline-hidden focus:ring-1 focus:ring-sky-500"
                    placeholder="Ex: ato-oc.co.ao"
                    required
                  />
                </div>
                <p className="text-[10px] text-slate-400 font-medium">Define o domínio corporativo que será verificado caso a política de restrição esteja ativa.</p>
              </div>
            </div>
          </div>
        )}

        {/* BOTTOM FORM BUTTONS */}
        <div className="pt-4 border-t border-slate-100 flex justify-between items-center">
          <button
            type="button"
            onClick={() => {
              setPlatformName('DFS Insight Hub');
              setFontFamily('Inter');
              setPrimaryColor('#0ea5e9');
              setSecondaryColor('#f59e0b');
              setDateFormat('DD/MM/YYYY');
              setAllowedDomain('ato-oc.co.ao');
              setRegistrationPolicy('ANY_VALID_EMAIL');
            }}
            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-bold flex items-center gap-1.5 transition-all"
            disabled={loading}
          >
            <RotateCcw className="w-4 h-4" /> Restaurar Padrões ATO
          </button>

          <button
            type="submit"
            className="px-5 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-lg font-bold border border-sky-500 transition-all flex items-center gap-1.5 cursor-pointer"
            disabled={loading}
          >
            {loading && <RefreshCw className="w-3.5 h-3.5 animate-spin" />}
            {loading ? 'A Guardar...' : 'Guardar Configurações'}
          </button>
        </div>

      </form>

    </div>
  );
}
