import React from 'react';
import { 
  Users, 
  Clock, 
  Database, 
  Brain, 
  Terminal, 
  Cpu, 
  Activity, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  ArrowUpRight 
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  Tooltip 
} from 'recharts';

interface AdminDashboardProps {
  usersCount: number;
  sessionsCount: number;
  auditLogsCount: number;
}

export default function AdminDashboard({ usersCount, sessionsCount, auditLogsCount }: AdminDashboardProps) {
  // Mock performance metric trends for the dashboard chart
  const performanceData = [
    { time: '00:00', cpu: 12, mem: 42, reqs: 15 },
    { time: '04:00', cpu: 8, mem: 42, reqs: 5 },
    { time: '08:00', cpu: 28, mem: 48, reqs: 145 },
    { time: '12:00', cpu: 45, mem: 55, reqs: 220 },
    { time: '16:00', cpu: 32, mem: 52, reqs: 190 },
    { time: '20:00', cpu: 15, mem: 45, reqs: 80 },
    { time: '24:00', cpu: 10, mem: 43, reqs: 30 },
  ];

  const onlineServices = [
    { name: 'Base de Dados (JSON / SIGO)', status: 'online', details: 'Saudável - Latência 1.2ms' },
    { name: 'Módulo de IA (Google Gemini API)', status: 'online', details: 'gemini-3.5-flash operacional' },
    { name: 'Servidor Express (Cloud Run)', status: 'online', details: 'Versão de Produção v2.4.0' },
    { name: 'Gateway de APIs Corporativas', status: 'online', details: 'Sem erros de autenticação' },
    { name: 'Integração Microsoft Teams Webhooks', status: 'online', details: 'Sincronizado' },
    { name: 'Integração SharePoint & Active Directory', status: 'online', details: 'Autenticação LDAP Ativa' },
  ];

  const criticalAlerts = [
    { id: 'alt-1', severity: 'warning', message: 'Uso de armazenamento atingiu 74% no volume DFS-Shared.', time: 'Há 15 mins' },
    { id: 'alt-2', severity: 'info', message: 'Backup diário completo programado para as 02:00 UTC+1.', time: 'Há 1 hora' },
    { id: 'alt-3', severity: 'success', message: 'Verificação periódica de integridade dos ficheiros PDF concluída.', time: 'Há 3 horas' },
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* METRIC CARD GRID */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div className="bg-white border border-slate-200 rounded-xl p-4 flex items-center justify-between shadow-2xs">
          <div className="space-y-1">
            <span className="text-slate-500 text-xs font-bold block">Utilizadores Registados</span>
            <span className="text-2xl font-black text-slate-800 font-mono">{usersCount || 7}</span>
          </div>
          <div className="w-10 h-10 rounded-lg bg-sky-50 text-sky-600 flex items-center justify-center">
            <Users className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 flex items-center justify-between shadow-2xs">
          <div className="space-y-1">
            <span className="text-slate-500 text-xs font-bold block">Sessões Ativas</span>
            <span className="text-2xl font-black text-slate-800 font-mono">{sessionsCount || 1}</span>
          </div>
          <div className="w-10 h-10 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <Clock className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 flex items-center justify-between shadow-2xs">
          <div className="space-y-1">
            <span className="text-slate-500 text-xs font-bold block">Tamanho da Base de Dados</span>
            <span className="text-2xl font-black text-slate-800 font-mono">152 KB</span>
          </div>
          <div className="w-10 h-10 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
            <Database className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 flex items-center justify-between shadow-2xs">
          <div className="space-y-1">
            <span className="text-slate-500 text-xs font-bold block">Estado da IA</span>
            <span className="text-2xl font-black text-slate-800 font-mono">Online</span>
          </div>
          <div className="w-10 h-10 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
            <Brain className="w-5 h-5" />
          </div>
        </div>

      </div>

      {/* PERFORMANCE GRAPH SECTION */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4">
          <div className="flex justify-between items-center pb-2 border-b border-slate-100">
            <div>
              <h3 className="font-extrabold text-slate-800 text-sm flex items-center gap-2">
                <Activity className="w-4 h-4 text-sky-600" /> Monitorização de Performance em Tempo Real
              </h3>
              <p className="text-xs text-slate-500">Métricas consolidadas de utilização do servidor (CPU % e Memória %)</p>
            </div>
            <span className="px-2 py-0.5 rounded text-[10px] bg-slate-100 text-slate-700 font-bold font-mono">
              Atualização automática (15s)
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={performanceData}>
                <defs>
                  <linearGradient id="colorCpu" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#0ea5e9" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#0ea5e9" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorMem" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="time" stroke="#94a3b8" fontSize={10} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} />
                <Tooltip />
                <Area type="monotone" dataKey="cpu" name="CPU (%)" stroke="#0ea5e9" fillOpacity={1} fill="url(#colorCpu)" strokeWidth={2} />
                <Area type="monotone" dataKey="mem" name="Memória (%)" stroke="#8b5cf6" fillOpacity={1} fill="url(#colorMem)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* HOST METRIC GAUGES */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-6">
          <h3 className="font-extrabold text-slate-800 text-sm pb-2 border-b border-slate-100 flex items-center gap-2">
            <Cpu className="w-4 h-4 text-sky-600" /> Recursos do Container
          </h3>

          <div className="space-y-4">
            
            {/* CPU Gauge */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-bold">
                <span className="text-slate-700">Utilização de CPU</span>
                <span className="text-sky-600 font-mono">24%</span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2">
                <div className="bg-sky-500 h-2 rounded-full transition-all duration-500" style={{ width: '24%' }}></div>
              </div>
              <p className="text-[10px] text-slate-400">1 vCPU reservado (Google Cloud Run Sandbox)</p>
            </div>

            {/* Memory Gauge */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-bold">
                <span className="text-slate-700">Utilização de Memória</span>
                <span className="text-purple-600 font-mono">512 MB (48%)</span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2">
                <div className="bg-purple-500 h-2 rounded-full transition-all duration-500" style={{ width: '48%' }}></div>
              </div>
              <p className="text-[10px] text-slate-400">Capacidade total alocada: 1024 MB RAM</p>
            </div>

            {/* Storage Gauge */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-bold">
                <span className="text-slate-700">Armazenamento (Ficheiros/OCR)</span>
                <span className="text-amber-600 font-mono">7.4 GB (74%)</span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2">
                <div className="bg-amber-500 h-2 rounded-full transition-all duration-500" style={{ width: '74%' }}></div>
              </div>
              <p className="text-[10px] text-slate-400">Capacidade máxima do disco virtual: 10 GB</p>
            </div>

          </div>

          <div className="p-3.5 bg-slate-50 border border-slate-150 rounded-lg space-y-1.5 text-xs text-slate-600 leading-relaxed font-medium">
            <div className="font-extrabold text-slate-800 text-xs">Uptime do Servidor:</div>
            <div className="font-mono text-[11px] text-slate-500">99.98% (12 dias, 4 horas em execução)</div>
          </div>
        </div>

      </div>

      {/* ONLINE SERVICES & HEALTH ALERT CHANNELS */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* SERVICES CHECK */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-3">
          <h3 className="font-extrabold text-slate-800 text-sm pb-2 border-b border-slate-100">
            Estado dos Serviços Corporativos
          </h3>
          <div className="space-y-2.5">
            {onlineServices.map((srv, idx) => (
              <div key={idx} className="flex justify-between items-center text-xs">
                <div className="space-y-0.5">
                  <span className="font-bold text-slate-700 block">{srv.name}</span>
                  <span className="text-[10px] text-slate-400">{srv.details}</span>
                </div>
                <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-50 text-emerald-800 border border-emerald-200">
                  <CheckCircle2 className="w-3 h-3" /> Activo
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* ALERTS & UPDATES CHANNELS */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4">
          <h3 className="font-extrabold text-slate-800 text-sm pb-2 border-b border-slate-100">
            Alertas Técnicos e Notificações de Infraestrutura
          </h3>
          <div className="space-y-3">
            {criticalAlerts.map(alt => (
              <div 
                key={alt.id} 
                className={`p-3 border rounded-xl flex gap-3 text-xs leading-relaxed font-medium ${
                  alt.severity === 'warning' ? 'bg-amber-50/50 border-amber-200 text-amber-900' :
                  alt.severity === 'success' ? 'bg-emerald-50/50 border-emerald-200 text-emerald-900' :
                  'bg-sky-50/50 border-sky-200 text-sky-950'
                }`}
              >
                {alt.severity === 'warning' && <AlertTriangle className="w-4 h-4 text-amber-600 mt-0.5 shrink-0" />}
                {alt.severity === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-600 mt-0.5 shrink-0" />}
                {alt.severity === 'info' && <Cpu className="w-4 h-4 text-sky-600 mt-0.5 shrink-0" />}
                
                <div className="flex-1 space-y-0.5">
                  <p className="font-bold">{alt.message}</p>
                  <span className="text-[10px] text-slate-400 font-mono block">{alt.time}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
}
