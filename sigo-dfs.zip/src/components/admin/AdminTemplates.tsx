import React, { useState } from 'react';
import { 
  FileText, 
  Upload, 
  Download, 
  Check, 
  Trash2, 
  FileSpreadsheet, 
  RefreshCw,
  Eye,
  Sliders,
  Table,
  Layers,
  ChevronRight,
  Info,
  Calendar,
  AlertTriangle,
  User,
  Users,
  CheckCircle,
  Clock,
  Briefcase
} from 'lucide-react';

export default function AdminTemplates() {
  const [templates, setTemplates] = useState([
    { id: 't-1', name: 'Modelo_Institucional_DFS.pptx', type: 'pptx', size: '12.4 MB', lastUpdated: '14/07/2026 18:32', version: 'v3.2', status: 'Ativo', description: 'Modelo oficial com 13 slides estruturados para a apresentação do Balanço Operacional da Direção de Facilitação e Segurança.' },
    { id: 't-2', name: 'Modelo_Balanço_Oficial_DFS.docx', type: 'docx', size: '3.1 MB', lastUpdated: '12/07/2026 11:15', version: 'v2.1', status: 'Ativo', description: 'Template de relatório executivo em formato Word com cabeçalhos e rodapés institucionais integrados.' },
    { id: 't-3', name: 'Estrutura_Plano_Accao_Padrao.xlsx', type: 'xlsx', size: '1.2 MB', lastUpdated: '15/07/2026 09:00', version: 'v1.4', status: 'Ativo', description: 'Matriz padrão do Plano de Ação para importação/exportação e controlo de pendências regulamentares.' },
    { id: 't-4', name: 'Cabecalho_Oficial_Rodapes.pdf', type: 'pdf', size: '850 KB', lastUpdated: '10/07/2026 14:00', version: 'v4.0', status: 'Ativo', description: 'Especificação técnica de marcas, logótipos oficiais, cores corporativas e diretrizes de design.' },
  ]);

  const [uploading, setUploading] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [selectedPPTXStructure, setSelectedPPTXStructure] = useState<boolean>(false);
  const [selectedSlide, setSelectedSlide] = useState<number>(0);

  // Parsed slides structure from official PDF Model
  const slideModel = [
    {
      index: 1,
      title: "Capa do Balanço",
      type: "Secção Fixa",
      section: "Geral",
      indicators: ["Data do Balanço", "ID do Documento", "Logo ATO & OC"],
      description: "Estrutura padrão de abertura institucional. Contém o título 'Administração Executiva para Aeroportos', 'Direcção de Facilitação e Segurança', o subtítulo 'Balanço Operacional de [Data]' e o logótipo oficial.",
      visualComponents: "Imagem do Terminal do AIAAN em background de alta definição, caixa azul institucional semi-transparente."
    },
    {
      index: 2,
      title: "Objectivo do Relatório",
      type: "Secção Fixa",
      section: "Geral",
      indicators: ["4 Objetivos Corporativos Estratégicos"],
      description: "Define a finalidade do relatório: 1. Informar registos nas últimas 24h; 2. Avaliar dados para monitorização; 3. Recolher feedback de chefia; 4. Prevenir recorrência de não conformidades.",
      visualComponents: "Três personagens 3D em uniformes corporativos (AVSEC, Facilitação) ao lado esquerdo, texto com tipografia limpa à direita."
    },
    {
      index: 3,
      title: "Recursos Humanos - Últimas 24h",
      type: "Secção Dinâmica",
      section: "Recursos Humanos (ATO & WSS)",
      indicators: ["Total Geral Colaboradores (156)", "Diferencial anterior (-14)", "Distribuição de Género (79% M / 21% F)", "Taxa de Absentismo WSS (33 Ausentes)"],
      description: "Dados operacionais de pessoal ativo no aeroporto nas últimas 24 horas. Divisão entre pessoal próprio da ATO/OC (74) e pessoal externo terceirizado da WSS (82).",
      visualComponents: "Três cartões de dados (ATO, WSS, Total Geral), barra de progresso de género, lista de 'Dados Relevantes' com ícone negativo vermelho para alertar sobre o absentismo severo de screeners e vigilantes."
    },
    {
      index: 4,
      title: "Recursos Materiais",
      type: "Secção Dinâmica",
      section: "Logística / Meios",
      indicators: ["Total Geral de Meios (153)", "Equipamentos de Segurança (143)", "Veículos Operacionais (10)", "Equipamentos em Avaria (5)"],
      description: "Controlo operacional de equipamentos físicos de inspeção (Raio-X, pórticos, detetores manuais, ETD fixos e móveis, tambores de explosão) e frota de viaturas operacionais.",
      visualComponents: "Tabela de viaturas ativas (Suzuki Jimny, Toyota Hilux, Wuling Opaia com estado 'Operacional'), lista de registo de avarias (detetores, calibração ETD pendente), e painel de Dados Relevantes."
    },
    {
      index: 5,
      title: "Operações AVSEC - Estatísticas",
      type: "Secção Dinâmica",
      section: "AVSEC",
      indicators: ["Artigos Proibidos Retidos (127)", "Armas de Fogo Despachadas (1)", "Detecções (0)", "Violações de Segurança (0)"],
      description: "KPIs agregados de segurança física aeroportuária. Classificação de artigos retidos por categoria oficial (Cat 1 a Cat 6) e registo quantitativo de intervenções.",
      visualComponents: "Gráfico de barras horizontais azul para as categorias de artigos (Cat 6 Líquidos/Aerossóis liderando com 63), tabela resumo de intervenções e contador amarelo de ocorrências relevantes (6 no total)."
    },
    {
      index: 6,
      title: "Registos Operacionais - Detalhes",
      type: "Secção Dinâmica",
      section: "AVSEC",
      indicators: ["Descrição das 6 Ocorrências AVSEC", "Intervenientes", "Supervisor", "Estado (Concluída)"],
      description: "Detalhamento textual preciso de cada uma das ocorrências registadas nas últimas 24 horas, incluindo horas exatas (ex: 10:46, 11:30, 12:30, 15:15, 16:30, 22:20).",
      visualComponents: "Bento grid com 6 cartões independentes, cabeçalhos cinza com tags de categoria, estado da ocorrência e descrição contextualizada."
    },
    {
      index: 7,
      title: "Boletim Ebola - FAL",
      type: "Secção Dinâmica",
      section: "FAL (Saúde)",
      indicators: ["Passageiros Rastreados (293)", "Casos Detetados (0)", "Casos Suspeitos (0)", "Passageiros por Voo"],
      description: "Integração oficial de vigilância epidemiológica em cooperação com o Ministério da Saúde (MINSA) de Angola para voos internacionais que aterram no AIAAN.",
      visualComponents: "Gráfico circular de distribuição por voo (ET851 Addis Abeba com 85.3% dos passageiros), tabela de voos rastreados (AT291, ASKY, KT851) e caixa de análise executiva."
    },
    {
      index: 8,
      title: "Operações - FAL (Ocorrências)",
      type: "Secção Dinâmica",
      section: "FAL",
      indicators: ["Detalhe de Embarque Remoto", "Atrasos em Bagagem Executiva", "Erros de Alocação de Handling"],
      description: "Relatórios de ocorrências operacionais específicas que afetam a facilitação de fluxo de passageiros e bagagens no terminal do aeroporto.",
      visualComponents: "Três cartões verticais com fotografias em alta resolução anexadas do terminal de embarque subterrâneo e das etiquetas de bagagem prioritária desviada."
    },
    {
      index: 9,
      title: "Facilitação do Transporte Aéreo",
      type: "Secção Dinâmica",
      section: "FAL",
      indicators: ["Tempo Médio de Entrega (41 min)", "Variação vs anterior (-8 min)", "Performance por Companhia", "Assistência de Passageiros (7)"],
      description: "Painel de desempenho e eficiência do sistema de transporte de bagagens e assistência de mobilidade (PMR, carrinhos elétricos) no aeroporto.",
      visualComponents: "Gráfico de evolução do tempo de restituição (49min vs 41min), gráfico de barras horizontais comparativo de companhias aéreas (Emirates 68min vs Airlink 15min) e tabela de assistência."
    },
    {
      index: 10,
      title: "Credenciamento e Formações",
      type: "Secção Dinâmica",
      section: "Administrativo / Segurança",
      indicators: ["Total de Credenciados Pessoas (12.190)", "Veículos Credenciados (522)", "Processos Concluídos (24+06+00)", "Pessoas Sensibilizadas (4.450)"],
      description: "Métricas de emissão de passes de aeroporto (provisórios e permanentes) e dados acumulados de sessões de formação em segurança da informação e física.",
      visualComponents: "Indicadores de processos em análise ou indeferidos (00), cards de formações agendadas (05) e painel analítico com próximos passos operacionais."
    },
    {
      index: 11,
      title: "Divisória: Planos de Acção",
      type: "Secção Fixa",
      section: "Geral",
      indicators: ["Divisória de Secção"],
      description: "Slide de transição visual oficial indicando o início da secção de acompanhamento de planos de ação e melhorias.",
      visualComponents: "Imagem institucional de fundo do terminal AIAAN com uma faixa azul central de destaque e o texto 'PLANOS DE ACÇÃO' em tamanho gigante."
    },
    {
      index: 12,
      title: "Plano de Acção e Cumprimento",
      type: "Secção Dinâmica",
      section: "Melhoria Contínua",
      indicators: ["Ações Planeadas (11)", "Ações Concluídas (0)", "Ações Em Curso (10)", "Grau de Cumprimento (28%)"],
      description: "Matriz oficial de acompanhamento de todas as iniciativas regulamentares, tecnológicas e operacionais ativas na Direção de Facilitação e Segurança.",
      visualComponents: "Tabela oficial de 11 linhas com descrição detalhada (ex: software de credenciamento, podar vegetação CCTV, sinalização PMR), responsáveis (DFS/TI, GCIMI, DITI, DIM), data limite, estado e percentagem de execução. Gráfico de anel de cumprimento geral."
    },
    {
      index: 13,
      title: "Slide de Encerramento",
      type: "Secção Fixa",
      section: "Geral",
      indicators: ["Logótipos de Rodapé", "Slogan 'De Angola para o Mundo'"],
      description: "Encerramento formal da apresentação operacional de balanço com menções institucionais de autoridade nacional angolana.",
      visualComponents: "Imagem dinâmica de aeronave da TAAG em pleno voo com céu ensolarado de fundo, logótipo da ATO, insígnias do Governo de Angola e Ministério dos Transportes."
    }
  ];

  const simulateUpload = (templateId: string) => {
    setUploading(templateId);
    setTimeout(() => {
      setUploading(null);
      setSuccessMsg(`Ficheiro de modelo "${templates.find(t => t.id === templateId)?.name}" atualizado com sucesso no container!`);
      setTemplates(prev => prev.map(t => {
        if (t.id === templateId) {
          const vNum = parseFloat(t.version.replace('v', ''));
          return {
            ...t,
            version: `v${(vNum + 0.1).toFixed(1)}`,
            lastUpdated: new Date().toLocaleDateString('pt-AO') + ' ' + new Date().toLocaleTimeString('pt-AO', { hour: '2-digit', minute: '2-digit' })
          };
        }
        return t;
      }));
      setTimeout(() => setSuccessMsg(null), 4000);
    }, 1500);
  };

  const getFileIcon = (type: string) => {
    switch (type) {
      case 'pptx': return <FileText className="w-5 h-5 text-orange-600" />;
      case 'docx': return <FileText className="w-5 h-5 text-blue-600" />;
      case 'xlsx': return <FileSpreadsheet className="w-5 h-5 text-emerald-600" />;
      default: return <FileText className="w-5 h-5 text-rose-600" />;
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      <div className="space-y-1">
        <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
          <FileText className="w-5 h-5 text-sky-600" /> Modelos Oficiais e Identidade Visual
        </h3>
        <p className="text-xs text-slate-500 font-medium">Controle de versões, download de cabeçalhos institucionais e analisador oficial do Balanço Operacional (.pptx).</p>
      </div>

      {successMsg && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-3 rounded-xl text-xs flex gap-2 font-bold">
          <Check className="w-4 h-4 text-emerald-600 mt-0.5" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* TEMPLATE CARDS LIST */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-2xs overflow-hidden">
        <div className="divide-y divide-slate-100">
          
          {templates.map(tpl => (
            <div key={tpl.id} className="p-4 flex flex-col hover:bg-slate-50/40 text-xs">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div className="flex gap-3">
                  <div className="p-2.5 bg-slate-50 border border-slate-150 rounded-xl shrink-0 flex items-center justify-center">
                    {getFileIcon(tpl.type)}
                  </div>

                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-800 text-sm">{tpl.name}</span>
                      <span className="px-2 py-0.5 rounded-full text-[10px] bg-slate-100 text-slate-700 font-bold border border-slate-200">
                        {tpl.version}
                      </span>
                    </div>

                    <p className="text-slate-500 font-normal">
                      {tpl.description}
                    </p>
                    <p className="text-slate-400 font-medium text-[10px]">
                      Tamanho: <b>{tpl.size}</b> | Última atualização: <b>{tpl.lastUpdated}</b>
                    </p>
                  </div>
                </div>

                {/* ACTION BUTTONS */}
                <div className="flex items-center gap-1.5 self-end sm:self-center font-bold">
                  {tpl.type === 'pptx' && (
                    <button
                      onClick={() => setSelectedPPTXStructure(!selectedPPTXStructure)}
                      className={`px-3 py-1.5 rounded-lg border flex items-center gap-1.5 transition-all cursor-pointer ${selectedPPTXStructure ? 'bg-orange-50 border-orange-200 text-orange-700' : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'}`}
                    >
                      <Eye className="w-3.5 h-3.5" /> 
                      {selectedPPTXStructure ? 'Ocultar Estrutura' : 'Analisar Slides'}
                    </button>
                  )}
                  
                  <button
                    onClick={() => alert(`A descarregar o modelo original "${tpl.name}" dos servidores corporativos do DFS... (v${tpl.version})`)}
                    className="px-3 py-1.5 bg-slate-50 hover:bg-slate-100 text-slate-700 rounded-lg border border-slate-200 flex items-center gap-1.5 transition-all cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" /> Descarregar
                  </button>

                  <button
                    onClick={() => simulateUpload(tpl.id)}
                    disabled={uploading !== null}
                    className="px-3 py-1.5 bg-sky-600 hover:bg-sky-700 text-white rounded-lg border border-sky-500 flex items-center gap-1.5 transition-all cursor-pointer disabled:opacity-50"
                  >
                    {uploading === tpl.id ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" /> A Carregar...
                      </>
                    ) : (
                      <>
                        <Upload className="w-3.5 h-3.5" /> Atualizar
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* EXPANDED PPTX STRUCTURE PREVIEW */}
              {tpl.type === 'pptx' && selectedPPTXStructure && (
                <div className="mt-4 pt-4 border-t border-slate-100 grid grid-cols-1 lg:grid-cols-12 gap-5 animate-in fade-in slide-in-from-top-2 duration-300">
                  
                  {/* Left slide timeline list */}
                  <div className="lg:col-span-4 space-y-1.5 max-h-[380px] overflow-y-auto pr-1">
                    <div className="text-[10px] font-black uppercase text-slate-400 tracking-wider mb-2 flex items-center justify-between">
                      <span>Lista de Slides do Modelo</span>
                      <span className="bg-slate-100 px-1.5 py-0.5 rounded text-slate-500 font-mono">13 slides</span>
                    </div>

                    {slideModel.map((slide, sIdx) => (
                      <button
                        key={slide.index}
                        onClick={() => setSelectedSlide(sIdx)}
                        className={`w-full text-left p-2.5 rounded-lg border flex items-start gap-2.5 transition-all cursor-pointer ${selectedSlide === sIdx ? 'bg-orange-50/50 border-orange-200/80 ring-1 ring-orange-200' : 'bg-white hover:bg-slate-50/60 border-slate-200/60'}`}
                      >
                        <span className={`w-5 h-5 rounded-md flex items-center justify-center text-[10px] font-black shrink-0 ${selectedSlide === sIdx ? 'bg-orange-600 text-white' : 'bg-slate-100 text-slate-500 border border-slate-200'}`}>
                          {slide.index}
                        </span>
                        
                        <div className="space-y-0.5 min-w-0">
                          <div className="font-bold text-slate-800 text-[11px] truncate leading-tight">
                            {slide.title}
                          </div>
                          <div className="flex items-center gap-1.5 text-[9px] font-semibold">
                            <span className={slide.type === 'Secção Fixa' ? 'text-blue-600 font-extrabold' : 'text-emerald-600 font-extrabold'}>
                              {slide.type}
                            </span>
                            <span className="text-slate-300">•</span>
                            <span className="text-slate-500 truncate">{slide.section}</span>
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>

                  {/* Right slide visual details representation */}
                  <div className="lg:col-span-8 bg-slate-900 text-slate-100 rounded-xl p-5 border border-slate-800 flex flex-col justify-between min-h-[350px] relative overflow-hidden">
                    
                    {/* Decorative watermark representation of slide container */}
                    <div className="absolute right-4 bottom-4 text-slate-800 opacity-20 pointer-events-none font-black text-6xl select-none uppercase tracking-widest">
                      SLIDE {slideModel[selectedSlide].index}
                    </div>

                    {/* Slide details */}
                    <div className="space-y-4 relative z-10">
                      
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                        <div className="space-y-1">
                          <span className="text-[10px] font-black uppercase text-orange-400 tracking-widest bg-orange-500/10 px-2 py-0.5 rounded border border-orange-500/10">
                            Modelo Corporativo Reconhecido • Slide {slideModel[selectedSlide].index} de 13
                          </span>
                          <h4 className="text-base font-black text-white tracking-wide mt-1">
                            {slideModel[selectedSlide].title}
                          </h4>
                        </div>

                        <span className={`px-2.5 py-1 rounded-md text-[10px] font-extrabold tracking-wider uppercase self-start sm:self-center ${slideModel[selectedSlide].type === 'Secção Fixa' ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'}`}>
                          {slideModel[selectedSlide].type}
                        </span>
                      </div>

                      {/* Description */}
                      <div className="space-y-1.5">
                        <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1">
                          <Info className="w-3.5 h-3.5 text-slate-500" /> Descrição do Conteúdo e Sequência
                        </div>
                        <p className="text-slate-300 text-[11px] leading-relaxed">
                          {slideModel[selectedSlide].description}
                        </p>
                      </div>

                      {/* Parsed Fields & Indicators */}
                      <div className="space-y-2">
                        <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1">
                          <Table className="w-3.5 h-3.5 text-slate-500" /> Campos & Indicadores Identificados
                        </div>
                        
                        <div className="flex flex-wrap gap-1.5">
                          {slideModel[selectedSlide].indicators.map((ind, i) => (
                            <span key={i} className="px-2 py-1 bg-slate-800 border border-slate-700/60 rounded text-[10.5px] font-semibold text-slate-200">
                              {ind}
                            </span>
                          ))}
                        </div>
                      </div>

                      {/* Visual styling components */}
                      <div className="space-y-1">
                        <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1">
                          <Sliders className="w-3.5 h-3.5 text-slate-500" /> Elementos Visuais Reutilizados
                        </div>
                        <p className="text-slate-400 text-[10.5px]">
                          {slideModel[selectedSlide].visualComponents}
                        </p>
                      </div>

                    </div>

                    <div className="border-t border-slate-800 pt-3 mt-4 flex items-center justify-between text-[10px] text-slate-400">
                      <span className="font-semibold text-slate-500">
                        * Referência obrigatória para compilações automatizadas de relatórios pela IA.
                      </span>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => setSelectedSlide(prev => Math.max(0, prev - 1))}
                          disabled={selectedSlide === 0}
                          className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded disabled:opacity-40 font-bold transition-all"
                        >
                          Anterior
                        </button>
                        <button
                          onClick={() => setSelectedSlide(prev => Math.min(slideModel.length - 1, prev + 1))}
                          disabled={selectedSlide === slideModel.length - 1}
                          className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded disabled:opacity-40 font-bold transition-all"
                        >
                          Seguinte
                        </button>
                      </div>
                    </div>

                  </div>

                </div>
              )}

            </div>
          ))}

        </div>
      </div>

    </div>
  );
}

