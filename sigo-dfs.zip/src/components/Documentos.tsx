import React, { useState } from 'react';
import { 
  FileText, 
  Search, 
  FileUp, 
  Download, 
  Trash2, 
  Filter, 
  AlertCircle, 
  File, 
  Check, 
  ChevronRight,
  Sparkles,
  History,
  RotateCcw,
  Layers,
  FileCheck,
  Calendar,
  Eye,
  RefreshCw,
  X,
  ChevronLeft,
  Info,
  Layers3,
  Flame,
  FileSpreadsheet
} from 'lucide-react';
import { 
  User, 
  UserRole, 
  DivisionId, 
  Documento, 
  DocType 
} from '../types.js';
import * as api from '../services/api.js';
import UploadCenterModal from './UploadCenterModal.js';

interface DocumentosProps {
  user: User;
  documents: Documento[];
  onRefresh: () => void;
}

export default function Documentos({ user, documents, onRefresh }: DocumentosProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [divisionFilter, setDivisionFilter] = useState<string>('ALL');
  const [showAllVersions, setShowAllVersions] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  
  // Upload Center Modal Trigger state
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [replaceDocId, setReplaceDocId] = useState<string | null>(null);
  
  // PowerPoint Viewer State
  const [viewerDoc, setViewerDoc] = useState<Documento | null>(null);
  const [activeSlide, setActiveSlide] = useState(0);

  // Filter logic
  const filteredDocs = documents.filter(doc => {
    const matchesSearch = doc.nome.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          doc.carregadoPor.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDivision = divisionFilter === 'ALL' || doc.divisaoId === divisionFilter;
    const matchesCurrent = showAllVersions || doc.isCurrent;
    return matchesSearch && matchesDivision && matchesCurrent;
  });

  const handleDelete = async (id: string, name: string) => {
    if (!window.confirm(`Tem a certeza que pretende eliminar logicamente o documento "${name}"? Esta ação será registada para auditoria.`)) {
      return;
    }

    setError(null);
    setSuccess(null);

    try {
      await api.deleteDocument(user, id);
      setSuccess(`Documento "${name}" eliminado logicamente com sucesso.`);
      onRefresh();
    } catch (err: any) {
      setError(err.message || 'Erro ao eliminar o documento.');
    }
  };

  const handleRestoreVersion = async (id: string, version: number) => {
    if (!window.confirm(`Tem a certeza que deseja restaurar a Versão ${version} como a versão ativa do documento?`)) {
      return;
    }

    setError(null);
    setSuccess(null);

    try {
      await api.restoreDocumentVersion(user, id);
      setSuccess(`Versão ${version} restaurada como ativa com sucesso.`);
      onRefresh();
    } catch (err: any) {
      setError(err.message || 'Erro ao restaurar versão do documento.');
    }
  };

  const handleDownloadSim = (name: string, version: number) => {
    alert(`A descarregar o relatório oficial "${name}" (v${version}) do servidor DFS... (Simulação de Download Concluída com Auditoria)`);
  };

  const handleOpenReplace = (doc: Documento) => {
    setReplaceDocId(doc.id);
    setIsUploadOpen(true);
  };

  // Mock slides metadata based on typical ATO DFS reports for PPTX preview
  const getPptxSlides = (docName: string) => {
    return [
      {
        title: "Slide 1: Identificação Institucional",
        section: "Abertura",
        bullets: [
          "SIGO-DFS - Sistema Integrado de Gestão Operacional",
          `Documento Oficial: ${docName}`,
          "Direção de Facilitação e Segurança (DFS)",
          "AIAAN Temporary Operator & Orange Coast (Angola)"
        ],
        kpis: "Autor: Maria Silva / DOS Chief"
      },
      {
        title: "Slide 2: Resumo do Balanço Operacional",
        section: "Resultados",
        bullets: [
          "Voos comerciais processados com sucesso absoluto de pontualidade.",
          "Incidentes insignificantes de facilitação resolvidos em tempo recorde.",
          "Otimização no fluxo de bagagens na sala de chegadas internacionais."
        ],
        kpis: "KPI: 99.4% de voos no horário"
      },
      {
        title: "Slide 3: Controle AVSEC de Passageiros",
        section: "Segurança",
        bullets: [
          "Inspeções de bagagem de cabine efetuadas sem constrangimentos.",
          "Controles de cartões de acesso aeroportuário auditados sem falhas.",
          "Rondas regulares nos perímetros internos e áreas críticas de segurança."
        ],
        kpis: "Rondas: 24/24h executadas"
      },
      {
        title: "Slide 4: Plano de Ação & Medidas Corretivas",
        section: "Ação Corretiva",
        bullets: [
          "Correção imediata dos sensores de vedação norte reportada.",
          "Ações preventivas para manutenção dos equipamentos de raio-X do terminal 2.",
          "Reforço de formação de operadores de triagem programada para próximo ciclo."
        ],
        kpis: "Pendentes: 0 | Em Execução: 1"
      }
    ];
  };

  return (
    <div className="space-y-6">
      
      {/* Header and Floating Action */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-100 shadow-xs">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="bg-orange-150 text-orange-800 font-extrabold text-[10px] px-2.5 py-1 rounded-full uppercase border border-orange-200">
              Formato Recomendado: PowerPoint (.pptx)
            </span>
          </div>
          <h1 className="text-2xl font-black tracking-tight text-slate-900">Gestão de Documentos DFS</h1>
          <p className="text-slate-500 text-xs font-medium">Controle de versões, arquivo regulamentar e histórico auditável das apresentações PowerPoint de cada divisão.</p>
        </div>

        {/* Permanent Upload Button */}
        <button
          onClick={() => { setReplaceDocId(null); setIsUploadOpen(true); }}
          className="px-5 py-3 bg-slate-900 hover:bg-slate-800 hover:scale-101 text-white text-xs font-black rounded-xl uppercase tracking-wider transition-all inline-flex items-center justify-center gap-2 shadow-xs cursor-pointer"
        >
          <FileUp className="w-4 h-4 text-orange-400" />
          Carregar Documento
        </button>
      </div>

      {/* FEEDBACK STATUS */}
      {error && (
        <div className="bg-rose-50 border border-rose-200 text-rose-800 p-4 rounded-xl flex items-start gap-3 shadow-xs">
          <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
          <div className="text-xs">
            <span className="font-bold">Aviso:</span> {error}
          </div>
        </div>
      )}

      {success && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded-xl flex items-start gap-3 shadow-xs">
          <Check className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
          <div className="text-xs">
            <span className="font-bold">Sucesso:</span> {success}
          </div>
        </div>
      )}

      {/* SEARCH AND FILTERS */}
      <div className="bg-white border border-slate-100 rounded-2xl p-5 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
          <div className="relative w-full sm:max-w-md">
            <Search className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
            <input 
              type="text"
              placeholder="Pesquisar documentos operacionais..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-1 focus:ring-sky-500 text-xs font-semibold text-slate-800"
            />
          </div>

          <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto justify-end">
            <button
              type="button"
              onClick={() => setShowAllVersions(!showAllVersions)}
              className={`flex items-center gap-1.5 px-3 py-2 text-[11px] font-bold border rounded-xl transition-all uppercase tracking-wider ${
                showAllVersions 
                  ? 'bg-sky-50 text-sky-800 border-sky-200' 
                  : 'bg-white text-slate-500 hover:text-slate-800 border-slate-200'
              }`}
            >
              <History className="w-4 h-4" />
              <span>{showAllVersions ? 'Ocultar Histórico' : 'Mostrar Histórico'}</span>
            </button>

            <div className="flex items-center gap-1 text-xs font-semibold">
              <Filter className="w-4 h-4 text-slate-400" />
              <select 
                value={divisionFilter}
                onChange={(e) => setDivisionFilter(e.target.value)}
                className="text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-hidden bg-white font-bold text-slate-700"
              >
                <option value="ALL">Todas as Divisões</option>
                <option value="DOS">DOS - Operações</option>
                <option value="DFC">DFC - Facilitação</option>
                <option value="FAL">FAL - Facilitação Aeroporto</option>
                <option value="DRCQ">DRCQ - Qualidade</option>
                <option value="DFS">DFS - Direção</option>
              </select>
            </div>
          </div>
        </div>

        {/* 8. TABLE DESIGN FOR DOCUMENTOS COLUMNS */}
        <div className="overflow-x-auto border border-slate-100 rounded-xl">
          <table className="w-full text-left text-xs text-slate-600 border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-150 text-slate-800 font-extrabold uppercase tracking-wider text-[10px]">
                <th className="p-4">Documento</th>
                <th className="p-4">Tipo</th>
                <th className="p-4">Versão</th>
                <th className="p-4">Estado</th>
                <th className="p-4">Data</th>
                <th className="p-4 text-center">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {filteredDocs.map((doc) => (
                <tr key={doc.id} className={`hover:bg-slate-50/50 transition-colors ${!doc.isCurrent ? 'bg-slate-50/40 opacity-80' : ''}`}>
                  
                  {/* Documento Name & Details */}
                  <td className="p-4 font-bold text-slate-800 max-w-[240px] truncate">
                    <div className="flex items-center gap-2.5">
                      {doc.tipo === DocType.PPTX ? (
                        <span className="w-8 h-8 rounded-lg bg-orange-50 text-orange-700 flex items-center justify-center font-black text-xs border border-orange-100 shrink-0">PPT</span>
                      ) : doc.tipo === DocType.PDF ? (
                        <span className="w-8 h-8 rounded-lg bg-rose-50 text-rose-700 flex items-center justify-center font-black text-xs border border-rose-100 shrink-0">PDF</span>
                      ) : (
                        <span className="w-8 h-8 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center font-black text-xs border border-blue-100 shrink-0">DOC</span>
                      )}
                      <div className="flex flex-col truncate">
                        <span className="truncate text-slate-900 font-extrabold text-xs">{doc.nome}</span>
                        <span className="text-[10px] text-slate-400 font-bold flex items-center gap-1 mt-0.5">
                          <span>Carregado por:</span>
                          <span className="text-slate-600 font-black">{doc.carregadoPor}</span>
                        </span>
                      </div>
                    </div>
                  </td>

                  {/* Tipo */}
                  <td className="p-4">
                    <span className="font-extrabold text-[10px] tracking-wide uppercase font-mono text-slate-500">
                      {doc.tipo}
                    </span>
                  </td>

                  {/* Versão */}
                  <td className="p-4">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-extrabold ${
                      doc.isCurrent 
                        ? 'bg-sky-50 text-sky-800 border border-sky-100' 
                        : 'bg-slate-100 text-slate-600 border border-slate-200'
                    }`}>
                      v{doc.versao}
                    </span>
                  </td>

                  {/* Estado */}
                  <td className="p-4">
                    {doc.isCurrent ? (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 text-emerald-800 border border-emerald-200 uppercase tracking-wide">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span> Ativo
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-slate-100 text-slate-500 border border-slate-200 uppercase tracking-wide">
                        Histórico
                      </span>
                    )}
                  </td>

                  {/* Data */}
                  <td className="p-4 text-slate-500 font-semibold">
                    <div className="flex flex-col">
                      <span>{new Date(doc.dataCarregamento).toLocaleDateString('pt-PT')}</span>
                      <span className="text-[9px] text-slate-400 font-mono font-bold">{new Date(doc.dataCarregamento).toLocaleTimeString('pt-PT', {hour: '2-digit', minute:'2-digit'})}</span>
                    </div>
                  </td>

                  {/* Ações */}
                  <td className="p-4">
                    <div className="flex items-center justify-center gap-1.5">
                      
                      {/* Visualizar */}
                      <button
                        onClick={() => { setViewerDoc(doc); setActiveSlide(0); }}
                        title="Visualizar slides sem descarregar"
                        className="p-1.5 text-sky-600 hover:text-sky-800 hover:bg-sky-50 border border-transparent hover:border-sky-200 rounded-lg transition-all bg-white cursor-pointer"
                      >
                        <Eye className="w-4 h-4" />
                      </button>

                      {/* Download */}
                      <button
                        onClick={() => handleDownloadSim(doc.nome, doc.versao)}
                        title="Descarregar ficheiro"
                        className="p-1.5 text-slate-600 hover:text-slate-800 hover:bg-slate-50 border border-transparent hover:border-slate-200 rounded-lg transition-all bg-white cursor-pointer"
                      >
                        <Download className="w-4 h-4" />
                      </button>

                      {/* Substituir */}
                      <button
                        onClick={() => handleOpenReplace(doc)}
                        title="Substituir por nova versão"
                        className="p-1.5 text-amber-600 hover:text-amber-800 hover:bg-amber-50 border border-transparent hover:border-amber-200 rounded-lg transition-all bg-white cursor-pointer"
                      >
                        <RefreshCw className="w-4 h-4" />
                      </button>

                      {/* Histórico */}
                      <button
                        onClick={() => setShowAllVersions(true)}
                        title="Ver histórico de alterações"
                        className="p-1.5 text-indigo-600 hover:text-indigo-800 hover:bg-indigo-50 border border-transparent hover:border-indigo-200 rounded-lg transition-all bg-white cursor-pointer"
                      >
                        <History className="w-4 h-4" />
                      </button>

                      {/* Eliminar (Lógica) */}
                      {(user.role === UserRole.ADMIN || user.role === UserRole.SECRETARIADO) && (
                        <button
                          onClick={() => handleDelete(doc.id, doc.nome)}
                          title="Eliminar logicamente"
                          className="p-1.5 text-rose-600 hover:text-rose-800 hover:bg-rose-50 border border-transparent hover:border-rose-200 rounded-lg transition-all bg-white cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}

                    </div>
                  </td>

                </tr>
              ))}
              
              {filteredDocs.length === 0 && (
                <tr>
                  <td colSpan={6} className="p-12 text-center text-slate-400 font-bold">
                    Nenhum documento encontrado com os filtros selecionados.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* 9. VISUALIZAÇÃO INTERATIVA DO POWERPOINT MODAL */}
      {viewerDoc && (
        <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-4xl overflow-hidden flex flex-col">
            
            {/* Viewer Header */}
            <div className="bg-slate-900 text-white px-6 py-4 flex justify-between items-center border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <span className="px-2 py-0.5 rounded bg-orange-600 text-white text-[10px] font-black uppercase">PPTX Viewer</span>
                <div>
                  <h3 className="font-extrabold text-sm tracking-tight">{viewerDoc.nome}</h3>
                  <p className="text-[10px] text-slate-400 font-bold">Versão v{viewerDoc.versao} • Divisão {viewerDoc.divisaoId} • Tamanho {viewerDoc.tamanho}</p>
                </div>
              </div>
              <button 
                onClick={() => setViewerDoc(null)}
                className="p-1.5 hover:bg-white/10 rounded-lg text-slate-400 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Viewer Body */}
            <div className="flex-1 bg-slate-100 grid grid-cols-1 md:grid-cols-4 min-h-[420px]">
              
              {/* Left sidebar: Thumbnails */}
              <div className="md:col-span-1 bg-slate-800 text-white p-3 space-y-2 border-r border-slate-700 overflow-y-auto max-h-[460px]">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider block mb-2 px-1">Miniaturas</span>
                {getPptxSlides(viewerDoc.nome).map((slide, sIdx) => (
                  <button
                    key={sIdx}
                    onClick={() => setActiveSlide(sIdx)}
                    className={`w-full text-left p-2 rounded-lg text-[11px] font-bold transition-all border block ${
                      activeSlide === sIdx 
                        ? 'bg-orange-600 text-white border-orange-500 scale-102 shadow-xs' 
                        : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-850'
                    }`}
                  >
                    <span className="text-[9px] text-slate-400 block font-black uppercase mb-0.5">Slide {sIdx + 1}</span>
                    <span className="line-clamp-1">{slide.title.replace(/Slide \d+: /, '')}</span>
                  </button>
                ))}
              </div>

              {/* Main slide display area */}
              <div className="md:col-span-3 p-6 flex flex-col justify-between max-h-[460px]">
                
                {/* Visual Slide Stage */}
                <div className="flex-1 bg-white border border-slate-200 rounded-xl p-6 shadow-sm flex flex-col justify-between text-left relative overflow-hidden">
                  
                  {/* Slide background watermark branding */}
                  <div className="absolute right-4 bottom-4 opacity-5 text-slate-900 select-none pointer-events-none font-black text-3xl font-mono">
                    ATO OC
                  </div>

                  {/* Slide Header */}
                  <div className="border-b border-slate-100 pb-3 flex justify-between items-start">
                    <div>
                      <span className="text-[10px] font-extrabold text-orange-600 tracking-wider uppercase bg-orange-50 px-2 py-0.5 rounded">
                        {getPptxSlides(viewerDoc.nome)[activeSlide].section}
                      </span>
                      <h4 className="text-sm font-black text-slate-900 tracking-tight mt-1">
                        {getPptxSlides(viewerDoc.nome)[activeSlide].title}
                      </h4>
                    </div>
                    <span className="text-xs font-mono font-bold text-slate-400">Slide {activeSlide + 1} de {getPptxSlides(viewerDoc.nome).length}</span>
                  </div>

                  {/* Slide Content Bullets */}
                  <div className="py-6 space-y-3 flex-1">
                    {getPptxSlides(viewerDoc.nome)[activeSlide].bullets.map((bullet, bIdx) => (
                      <div key={bIdx} className="flex items-start gap-2 text-xs font-semibold text-slate-600">
                        <ChevronRight className="w-4 h-4 text-orange-500 shrink-0 mt-0.5" />
                        <p className="leading-relaxed">{bullet}</p>
                      </div>
                    ))}
                  </div>

                  {/* Slide Footer */}
                  <div className="border-t border-slate-100 pt-3 flex justify-between items-center text-[10px] font-bold text-slate-400">
                    <span className="uppercase tracking-wider font-mono">ATO-OC DFS Angola</span>
                    <span className="bg-slate-50 border border-slate-200 px-2 py-0.5 rounded text-slate-600">
                      {getPptxSlides(viewerDoc.nome)[activeSlide].kpis}
                    </span>
                  </div>

                </div>

                {/* Slide controls bar */}
                <div className="flex justify-between items-center mt-4">
                  <button
                    disabled={activeSlide === 0}
                    onClick={() => setActiveSlide(prev => prev - 1)}
                    className="px-3.5 py-1.5 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-xs font-extrabold rounded-lg transition-colors inline-flex items-center gap-1.5 disabled:opacity-50 cursor-pointer"
                  >
                    <ChevronLeft className="w-4 h-4" /> Anterior
                  </button>

                  <div className="text-xs font-mono font-bold text-slate-500">
                    Navegação do Apresentador
                  </div>

                  <button
                    disabled={activeSlide === getPptxSlides(viewerDoc.nome).length - 1}
                    onClick={() => setActiveSlide(prev => prev + 1)}
                    className="px-3.5 py-1.5 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-xs font-extrabold rounded-lg transition-colors inline-flex items-center gap-1.5 disabled:opacity-50 cursor-pointer"
                  >
                    Seguinte <ChevronRight className="w-4 h-4" />
                  </button>
                </div>

              </div>

            </div>

            {/* Viewer Footer */}
            <div className="bg-slate-50 px-6 py-3 flex justify-between items-center border-t border-slate-200 text-xs font-bold text-slate-500">
              <span className="inline-flex items-center gap-1.5 text-[10px] text-slate-400 uppercase">
                <Info className="w-4 h-4 text-sky-500 shrink-0" />
                Extração automática por Inteligência Documental SIGO-DFS ativa para PowerPoint
              </span>
              <button
                onClick={() => handleDownloadSim(viewerDoc.nome, viewerDoc.versao)}
                className="px-4 py-1.5 bg-sky-600 hover:bg-sky-700 text-white rounded-lg text-xs font-black uppercase tracking-wider transition-colors inline-flex items-center gap-1.5 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" /> Descarregar Original
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Global Upload Center Modal Integration */}
      <UploadCenterModal 
        isOpen={isUploadOpen}
        onClose={() => { setIsUploadOpen(false); setReplaceDocId(null); }}
        user={user}
        onUploadSuccess={() => {
          setIsUploadOpen(false);
          setReplaceDocId(null);
          onRefresh();
        }}
        preselectedBalanceId={null}
      />

    </div>
  );
}
