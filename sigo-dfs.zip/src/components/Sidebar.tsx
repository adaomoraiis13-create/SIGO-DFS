import React, { useState } from 'react';
import { 
  LayoutDashboard, 
  FileText, 
  FileUp, 
  CheckSquare, 
  BarChart2, 
  History, 
  Settings, 
  LogOut,
  ChevronRight,
  Plane,
  PlusCircle,
  Clock,
  Eye,
  ShieldAlert,
  CheckCircle,
  Archive,
  Activity,
  ChevronDown,
  Sparkles,
  PieChart,
  Bot
} from 'lucide-react';
import Logo from './Logo.js';
import { User, UserRole } from '../types.js';

interface SidebarProps {
  user: User;
  activeView: string;
  setView: (view: string) => void;
  selectedSubView: string;
  setSelectedSubView: (subView: string) => void;
  onLogout: () => void;
}

export default function Sidebar({ user, activeView, setView, selectedSubView, setSelectedSubView, onLogout }: SidebarProps) {
  const [balancosExpanded, setBalancosExpanded] = useState(true);

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'balancos', label: 'Balanço Operacional', icon: FileText, hasSubmenu: true },
    { id: 'documentos', label: 'Documentos', icon: FileUp },
    { id: 'inteligencia', label: 'Inteligência Doc', icon: Sparkles },
    { id: 'plano-acao', label: 'Plano de Ação', icon: CheckSquare },
    { id: 'indicadores', label: 'Indicadores', icon: BarChart2 },
    { id: 'bi', label: 'Centro de BI', icon: PieChart },
    { id: 'copilot', label: 'Copilot DFS', icon: Bot },
    { id: 'historico', label: 'Auditoria', icon: History },
    { id: 'administracao', label: 'Administração', icon: Settings },
  ];

  const subMenuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'novo', label: 'Novo Balanço', icon: PlusCircle, roles: [UserRole.ADMIN, UserRole.SECRETARIADO] },
    { id: 'elaboracao', label: 'Em Elaboração', icon: Clock },
    { id: 'revisao', label: 'Em Revisão', icon: Eye },
    { id: 'aguardando_aprovacao', label: 'Aguardando Aprovação', icon: ShieldAlert, roles: [UserRole.ADMIN, UserRole.DIRETOR, UserRole.SECRETARIADO] },
    { id: 'concluidos', label: 'Concluídos', icon: CheckCircle },
    { id: 'arquivados', label: 'Arquivados', icon: Archive },
    { id: 'historico_workflow', label: 'Histórico', icon: Activity },
  ];

  const handleMenuItemClick = (itemId: string) => {
    setView(itemId);
    if (itemId === 'balancos') {
      setSelectedSubView('dashboard');
      setBalancosExpanded(true);
    }
  };

  return (
    <aside className="w-64 bg-slate-900 border-r border-slate-800 flex flex-col justify-between shrink-0 h-screen overflow-y-auto text-slate-300 print:hidden">
      
      {/* TOP HEADER: Corporate Branding */}
      <div className="space-y-4 pt-6 px-5">
        <div className="flex items-center gap-2 pb-4 border-b border-slate-800">
          <Logo size="sm" variant="dark" showSlogan={true} />
        </div>
        
        <div className="space-y-1">
          <h2 className="text-sm font-extrabold text-white tracking-widest uppercase">SIGO-DFS</h2>
          <p className="text-[10px] text-slate-500 font-bold leading-tight">
            Gestão Operacional Facilitada
          </p>
        </div>
      </div>

      {/* MID PORTION: Menu items navigation */}
      <nav className="flex-1 py-6 px-3 space-y-1.5">
        {menuItems.map((item) => {
          const isActive = activeView === item.id;
          const Icon = item.icon;
          
          return (
            <div key={item.id} className="space-y-1">
              <button
                onClick={() => handleMenuItemClick(item.id)}
                className={`w-full text-left px-3 py-2 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center justify-between transition-all group ${
                  isActive 
                    ? 'bg-sky-600 text-white shadow-sm font-black' 
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-4 h-4 transition-transform group-hover:scale-110 ${isActive ? 'text-white' : 'text-slate-400 group-hover:text-sky-400'}`} />
                  <span>{item.label}</span>
                </div>
                {item.hasSubmenu ? (
                  <button 
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setBalancosExpanded(!balancosExpanded);
                    }}
                    className="p-1 hover:bg-slate-800/50 rounded"
                  >
                    {balancosExpanded ? (
                      <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                    ) : (
                      <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                    )}
                  </button>
                ) : (
                  <ChevronRight className={`w-3.5 h-3.5 transition-transform ${isActive ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-1 group-hover:opacity-100 group-hover:translate-x-0'}`} />
                )}
              </button>

              {/* Submenu for Balanço Operacional */}
              {item.hasSubmenu && balancosExpanded && activeView === 'balancos' && (
                <div className="pl-4 pr-1 py-1 space-y-1 bg-slate-950/20 rounded-lg mt-1 border border-slate-800/20">
                  {subMenuItems.map((subItem) => {
                    // Check role permissions if specified
                    if (subItem.roles && !subItem.roles.includes(user.role)) return null;

                    const isSubActive = selectedSubView === subItem.id;
                    const SubIcon = subItem.icon;

                    return (
                      <button
                        key={subItem.id}
                        onClick={() => {
                          setView('balancos');
                          setSelectedSubView(subItem.id);
                        }}
                        className={`w-full text-left px-3 py-1.5 rounded-md text-[11px] font-medium tracking-wide flex items-center gap-2.5 transition-colors ${
                          isSubActive
                            ? 'bg-sky-500/10 text-sky-400 font-bold border-l-2 border-sky-400'
                            : 'text-slate-500 hover:text-slate-300 hover:bg-slate-800/40'
                        }`}
                      >
                        <SubIcon className={`w-3.5 h-3.5 ${isSubActive ? 'text-sky-400' : 'text-slate-500'}`} />
                        <span>{subItem.label}</span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </nav>

      {/* BOTTOM PORTION: Active User Profile & Logout */}
      <div className="p-4 border-t border-slate-800 bg-slate-950/40 space-y-3.5">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-sky-400 font-bold text-sm shrink-0">
            {user.name.split(' ').map(n => n[0]).slice(0, 2).join('')}
          </div>
          <div className="space-y-0.5 min-w-0">
            <h4 className="text-xs font-bold text-white truncate">{user.name}</h4>
            <p className="text-[10px] text-slate-500 font-bold uppercase truncate">{user.role.replace('_', ' ')}</p>
          </div>
        </div>

        <button
          onClick={onLogout}
          className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-bold text-slate-400 hover:text-white bg-slate-800/40 hover:bg-rose-900/20 border border-slate-800 hover:border-rose-900/30 rounded-lg transition-all shadow-xs"
        >
          <LogOut className="w-4 h-4" /> Terminar Sessão
        </button>
      </div>

    </aside>
  );
}
