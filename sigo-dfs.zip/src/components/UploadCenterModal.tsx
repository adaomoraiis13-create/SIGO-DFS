import React, { useState, useRef } from 'react';
import { 
  X, 
  FileUp, 
  Sparkles, 
  CheckCircle2, 
  AlertCircle, 
  FileText, 
  Image, 
  FileArchive, 
  Briefcase,
  ChevronRight,
  RefreshCw,
  Loader2,
  Trash2,
  Check,
  ShieldAlert
} from 'lucide-react';
import { User, DocType, DivisionId } from '../types.js';
import * as api from '../services/api.js';

interface UploadCenterModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: User;
  onUploadSuccess: () => void;
  preselectedBalanceId?: string | null;
}

export default function UploadCenterModal({ 
  isOpen, 
  onClose, 
  user, 
  onUploadSuccess,
  preselectedBalanceId = null 
}: UploadCenterModalProps) {
  const [dragActive, setDragActive] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [fileDivision, setFileDivision] = useState<DivisionId>(
    user.divisionId === DivisionId.DFS ? DivisionId.DOS : user.divisionId
  );
  
  // Custom metadata input fields
  const [customName, setCustomName] = useState('');
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const [uploadState, setUploadState] = useState<'idle' | 'uploading' | 'processing' | 'success' | 'error'>('idle');
  const [statusMessage, setStatusMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const validateAndSetFile = (file: File) => {
    const ext = file.name.split('.').pop()?.toLowerCase();
    const allowed = ['pptx', 'pdf', 'docx', 'xlsx', 'png', 'jpg', 'jpeg', 'zip'];
    
    if (!ext || !allowed.includes(ext)) {
      setErrorMessage(`O formato .${ext || ''} não é suportado pelo SIGO-DFS. Formatos autorizados: .pptx (Principal), .pdf, .docx, .xlsx, imagens e .zip`);
      setUploadState('error');
      return;
    }
    
    setSelectedFile(file);
    setCustomName(file.name);
    setUploadState('idle');
    setErrorMessage('');
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      validateAndSetFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      validateAndSetFile(e.target.files[0]);
    }
  };

  const getDocTypeFromExt = (filename: string): DocType => {
    const ext = filename.split('.').pop()?.toLowerCase();
    if (ext === 'pptx') return DocType.PPTX;
    if (ext === 'pdf') return DocType.PDF;
    if (ext === 'docx') return DocType.DOCX;
    if (ext === 'xlsx') return DocType.XLSX;
    if (['png', 'jpg', 'jpeg'].includes(ext || '')) return DocType.OUTRO;
    return DocType.PPTX; // default
  };

  const triggerUploadAndProcess = async () => {
    if (!selectedFile) return;
    
    setUploadState('uploading');
    setUploadProgress(10);
    setStatusMessage('A enviar documento para o servidor corporativo...');
    
    // 1. Simulate Upload Phase (0-100% on network transfer)
    const uploadInterval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 90) {
          clearInterval(uploadInterval);
          // Transition to processing phase
          triggerProcessingPhase();
          return 95;
        }
        return prev + 15;
      });
    }, 150);

    const triggerProcessingPhase = async () => {
      setUploadState('processing');
      setUploadProgress(95);
      setStatusMessage('Validação de formato e verificação criptográfica...');

      // Step-by-step descriptive processing statuses
      const steps = [
        'A validar cabeçalhos e metadados estruturais...',
        'Leitura avançada de slides e extração de textos...',
        'Processamento inteligente de tabelas e KPIs...',
        'A registar alterações no histórico de auditoria...'
      ];

      for (let i = 0; i < steps.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 600));
        setStatusMessage(steps[i]);
      }

      // Actually register the document in the central database
      try {
        const type = getDocTypeFromExt(customName);
        const sizeMb = (selectedFile.size / (1024 * 1024)).toFixed(1) + ' MB';
        
        await api.createDocument(user, {
          nome: customName,
          tipo: type,
          divisaoId: fileDivision,
          tamanho: sizeMb,
          balanceId: preselectedBalanceId || undefined
        });

        setUploadProgress(100);
        setUploadState('success');
        setStatusMessage('Documento processado e armazenado com sucesso na base de dados DFS!');
        onUploadSuccess();
      } catch (err: any) {
        setErrorMessage(err.message || 'Falha no processamento central do documento.');
        setUploadState('error');
      }
    };
  };

  const getFileIcon = (filename: string) => {
    const ext = filename.split('.').pop()?.toLowerCase();
    if (ext === 'pptx') return <span className="bg-orange-100 text-orange-700 font-bold px-2 py-1 rounded text-xs">PPTX</span>;
    if (ext === 'pdf') return <span className="bg-rose-100 text-rose-700 font-bold px-2 py-1 rounded text-xs">PDF</span>;
    if (ext === 'docx') return <span className="bg-blue-100 text-blue-700 font-bold px-2 py-1 rounded text-xs">DOCX</span>;
    if (ext === 'xlsx') return <span className="bg-emerald-100 text-emerald-700 font-bold px-2 py-1 rounded text-xs">XLSX</span>;
    if (['png', 'jpg', 'jpeg'].includes(ext || '')) return <span className="bg-violet-100 text-violet-700 font-bold px-2 py-1 rounded text-xs">IMG</span>;
    return <span className="bg-slate-100 text-slate-700 font-bold px-2 py-1 rounded text-xs">ZIP</span>;
  };

  const handleReset = () => {
    setSelectedFile(null);
    setCustomName('');
    setUploadProgress(0);
    setUploadState('idle');
    setErrorMessage('');
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl w-full max-w-xl overflow-hidden flex flex-col">
        
        {/* Header */}
        <div className="bg-slate-50 border-b border-slate-100 px-6 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-sky-100 text-sky-700 rounded-lg">
              <FileUp className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h3 className="font-extrabold text-slate-900 text-sm tracking-tight uppercase">Centro de Upload DFS</h3>
              <p className="text-[10px] text-slate-400 font-bold tracking-wider">PREFERÊNCIA AUTOMÁTICA DE POWERPOINT (.PPTX)</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1 hover:bg-slate-150 rounded-lg text-slate-400 hover:text-slate-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Area */}
        <div className="p-6 flex-1 space-y-5 overflow-y-auto max-h-[70vh]">
          
          {uploadState === 'idle' && !selectedFile && (
            <div 
              onDragEnter={handleDrag}
              onDragOver={handleDrag}
              onDragLeave={handleDrag}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all flex flex-col items-center justify-center gap-3 ${
                dragActive 
                  ? 'border-sky-500 bg-sky-50/50 scale-[0.99]' 
                  : 'border-slate-200 hover:border-sky-400 hover:bg-slate-50/50'
              }`}
            >
              <input 
                ref={fileInputRef}
                type="file"
                className="hidden"
                accept=".pptx,.pdf,.docx,.xlsx,.png,.jpg,.jpeg,.zip"
                onChange={handleFileChange}
              />
              
              <div className="p-4 bg-sky-50 text-sky-600 rounded-full">
                <FileUp className="w-8 h-8" />
              </div>
              
              <div className="space-y-1">
                <p className="text-xs font-bold text-slate-700">
                  Arraste e largue o seu ficheiro ou <span className="text-sky-600 underline">procure no computador</span>
                </p>
                <p className="text-[10px] text-slate-400 font-semibold leading-relaxed">
                  PowerPoint (.pptx), PDF (.pdf), Word (.docx), Excel (.xlsx), PNG, JPG ou ZIP
                </p>
              </div>

              <div className="mt-3 inline-flex items-center gap-1.5 px-3 py-1 bg-amber-50 border border-amber-200 text-amber-800 text-[10px] font-black rounded-full uppercase tracking-wider animate-pulse">
                <Sparkles className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                PowerPoint (.pptx) é o formato recomendado
              </div>
            </div>
          )}

          {/* Error Banner */}
          {uploadState === 'error' && (
            <div className="bg-rose-50 border border-rose-200 p-4 rounded-xl flex gap-3 text-xs text-rose-800 font-semibold">
              <ShieldAlert className="w-5 h-5 text-rose-600 shrink-0" />
              <div className="space-y-1">
                <p className="font-bold uppercase tracking-wider">Falha no Processamento</p>
                <p className="font-medium">{errorMessage}</p>
                <button 
                  onClick={handleReset}
                  className="mt-2 text-sky-600 hover:underline font-bold"
                >
                  Tentar carregar outro ficheiro
                </button>
              </div>
            </div>
          )}

          {/* Success Banner */}
          {uploadState === 'success' && (
            <div className="bg-emerald-50 border border-emerald-200 p-5 rounded-xl text-center space-y-4">
              <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-7 h-7" />
              </div>
              <div className="space-y-1">
                <h4 className="text-xs font-black text-emerald-950 uppercase tracking-wider">Submissão Concluída</h4>
                <p className="text-xs text-emerald-800 font-semibold max-w-sm mx-auto">{statusMessage}</p>
              </div>
              
              <div className="pt-2">
                <button 
                  onClick={onClose}
                  className="px-4 py-2 bg-slate-900 text-white hover:bg-slate-800 text-xs font-black rounded-lg uppercase tracking-wider"
                >
                  Fechar Janela
                </button>
              </div>
            </div>
          )}

          {/* Active Upload/Processing Progress */}
          {(uploadState === 'uploading' || uploadState === 'processing') && (
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-4">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <Loader2 className="w-4 h-4 text-sky-600 animate-spin" />
                  <span className="text-xs font-bold text-slate-700">{statusMessage}</span>
                </div>
                <span className="text-xs font-black text-sky-700 font-mono">{uploadProgress}%</span>
              </div>
              
              {/* Progress Bar Container */}
              <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                <div 
                  className="bg-sky-600 h-full transition-all duration-300"
                  style={{ width: `${uploadProgress}%` }}
                ></div>
              </div>

              {/* Informational slide metadata during extraction */}
              {uploadState === 'processing' && (
                <div className="text-[10px] bg-sky-50/50 text-sky-950 border border-sky-100 rounded-lg p-3 font-semibold space-y-1">
                  <div className="flex items-center gap-1.5 font-bold uppercase tracking-wide text-sky-700">
                    <Sparkles className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                    Leitor Inteligente SIGO-DFS
                  </div>
                  <p className="text-slate-600 leading-relaxed font-medium">
                    O nosso algoritmo extrai e classifica automaticamente slides, tabelas, chefias e planos de ação para consolidação automática no Balanço Operacional.
                  </p>
                </div>
              )}
            </div>
          )}

          {/* File Selected Meta Form */}
          {selectedFile && uploadState === 'idle' && (
            <div className="space-y-4">
              
              {/* Selected File Details */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  {getFileIcon(selectedFile.name)}
                  <div className="space-y-0.5 text-left">
                    <p className="text-xs font-bold text-slate-800 line-clamp-1">{selectedFile.name}</p>
                    <p className="text-[10px] text-slate-400 font-bold">{(selectedFile.size / (1024 * 1024)).toFixed(2)} MB</p>
                  </div>
                </div>
                
                <button 
                  onClick={handleReset}
                  className="p-1.5 hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded-lg transition-colors"
                  title="Remover ficheiro"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              {/* Custom naming */}
              <div className="space-y-1.5 text-xs font-bold text-slate-600 text-left">
                <label className="uppercase">Nome do Ficheiro no Sistema</label>
                <input 
                  type="text"
                  value={customName}
                  onChange={(e) => setCustomName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-sky-500 font-semibold text-slate-800 text-xs"
                />
              </div>

              {/* Division ownership selection */}
              <div className="space-y-1.5 text-xs font-bold text-slate-600 text-left">
                <label className="uppercase">Divisão Proprietária do Relatório</label>
                <select 
                  value={fileDivision}
                  onChange={(e) => setFileDivision(e.target.value as DivisionId)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-sky-500 font-semibold text-slate-800 text-xs"
                >
                  <option value={DivisionId.DOS}>DOS - Divisão de Operações de Segurança</option>
                  <option value={DivisionId.DFC}>DFC - Divisão de Facilitação e Controlo</option>
                  <option value={DivisionId.FAL}>FAL - Divisão de Facilitação de Aeroporto</option>
                  <option value={DivisionId.DRCQ}>DRCQ - Divisão de Regulação, Controlo e Qualidade</option>
                </select>
              </div>

              {/* Footer Actions inside selected card */}
              <div className="pt-2 flex gap-3">
                <button 
                  onClick={handleReset}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-black rounded-xl uppercase tracking-wider transition-colors"
                >
                  Cancelar
                </button>
                <button 
                  onClick={triggerUploadAndProcess}
                  className="flex-1 py-2.5 bg-sky-600 hover:bg-sky-700 text-white text-xs font-black rounded-xl uppercase tracking-wider transition-colors inline-flex items-center justify-center gap-1.5"
                >
                  <FileUp className="w-4 h-4" />
                  Carregar e Processar
                </button>
              </div>

            </div>
          )}

        </div>

      </div>
    </div>
  );
}
