import React, { useState, useEffect } from 'react';
import { 
  Bell, 
  Clock, 
  HelpCircle, 
  Check, 
  CheckCheck,
  Building,
  UserCheck
} from 'lucide-react';
import { User, Notification } from '../types.js';
import * as api from '../services/api.js';
import Logo from './Logo.js';

interface HeaderProps {
  user: User;
  notifications: Notification[];
  onRefreshNotifications: () => void;
  setView: (view: string) => void;
}

export default function Header({ user, notifications, onRefreshNotifications, setView }: HeaderProps) {
  const [time, setTime] = useState(new Date());
  const [showNotifBox, setShowNotifBox] = useState(false);

  // Update clock every second
  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Filter notifications relevant to this specific user (by userId, divisionId, role, or broadcast)
  const userNotifs = notifications.filter(n => {
    if (n.utilizadorId && n.utilizadorId !== user.id) return false;
    if (n.divisaoId && n.divisaoId !== user.divisionId) return false;
    if (n.role && n.role !== user.role) return false;
    return true;
  });

  const unreadCount = userNotifs.filter(n => !n.lida).length;

  const handleReadNotif = async (id: string) => {
    try {
      await api.markNotificationAsRead(id);
      onRefreshNotifications();
    } catch (err) {
      console.error(err);
    }
  };

  const handleReadAll = async () => {
    try {
      await api.markAllNotificationsAsRead();
      onRefreshNotifications();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <header className="h-16 bg-white border-b border-slate-100 flex items-center justify-between px-6 shrink-0 z-40 print:hidden shadow-2xs">
      
      {/* LEFT: System Title & Branch */}
      <div className="flex items-center gap-4">
        <Logo size="sm" variant="light" showSlogan={false} className="scale-95 origin-left" />
        <span className="text-slate-200">|</span>
        <span className="font-black text-slate-900 tracking-wider text-sm md:text-base">
          SIGO-DFS
        </span>
      </div>

      {/* RIGHT: Clock, Notifications & Actions */}
      <div className="flex items-center gap-5">
        
        {/* REAL-TIME CLOCK */}
        <div className="hidden md:flex items-center gap-1.5 text-xs text-slate-500 font-semibold font-mono bg-slate-50 border border-slate-100 px-3 py-1.5 rounded-lg select-none">
          <Clock className="w-3.5 h-3.5 text-sky-600 animate-spin-slow" />
          <span>{time.toLocaleString('pt-PT')}</span>
        </div>

        {/* NOTIFICATIONS BELL DROPDOWN */}
        <div className="relative">
          <button 
            onClick={() => setShowNotifBox(!showNotifBox)}
            className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-50 rounded-xl relative transition-all"
          >
            <Bell className="w-4.5 h-4.5" />
            {unreadCount > 0 && (
              <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-rose-600 text-[10px] font-black text-white flex items-center justify-center border border-white animate-bounce">
                {unreadCount}
              </span>
            )}
          </button>

          {showNotifBox && (
            <div className="absolute right-0 mt-2.5 w-80 bg-white border border-slate-200 rounded-xl shadow-xl p-4 space-y-3 z-50">
              <div className="flex items-center justify-between border-b border-slate-50 pb-2">
                <span className="text-xs font-bold text-slate-800 uppercase tracking-wide">Notificações</span>
                {unreadCount > 0 && (
                  <button 
                    onClick={handleReadAll}
                    className="text-[10px] font-bold text-sky-600 hover:text-sky-800 flex items-center gap-0.5"
                  >
                    <CheckCheck className="w-3.5 h-3.5" /> Ler todas
                  </button>
                )}
              </div>

              <div className="space-y-2 max-h-64 overflow-y-auto pr-1 text-xs">
                {userNotifs.map((notif) => (
                  <div 
                    key={notif.id} 
                    onClick={() => {
                      if (!notif.lida) handleReadNotif(notif.id);
                      if (notif.link) {
                        setView(notif.link.split('/')[1]); // Routing
                      }
                      setShowNotifBox(false);
                    }}
                    className={`p-2.5 rounded-lg border text-left cursor-pointer transition-all space-y-1 ${
                      notif.lida 
                        ? 'bg-slate-50/50 border-slate-100 text-slate-500' 
                        : 'bg-sky-50/20 border-sky-100 text-slate-800 font-medium'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold truncate max-w-[85%]">{notif.titulo}</span>
                      {!notif.lida && <span className="w-1.5 h-1.5 rounded-full bg-sky-600 shrink-0"></span>}
                    </div>
                    <p className="text-[11px] leading-relaxed text-slate-500">{notif.mensagem}</p>
                    <span className="text-[9px] text-slate-400 block font-mono text-right">{new Date(notif.dataCriacao).toLocaleDateString()}</span>
                  </div>
                ))}
                {userNotifs.length === 0 && (
                  <p className="py-6 text-center text-slate-400">Nenhum alerta operacional registado.</p>
                )}
              </div>
            </div>
          )}
        </div>

        {/* ABOUT PAGE LINK */}
        <button
          onClick={() => setView('about')}
          title="Sobre a Plataforma"
          className="p-2 text-slate-500 hover:text-sky-600 hover:bg-slate-50 rounded-xl transition-all flex items-center gap-1"
        >
          <HelpCircle className="w-4.5 h-4.5" />
        </button>

        {/* LOGGED IN USER PROFILE INDICATOR */}
        <div className="flex items-center gap-2 border-l border-slate-100 pl-4">
          <div className="w-8 h-8 rounded-full bg-sky-50 text-sky-700 border border-sky-100 flex items-center justify-center font-bold text-xs shrink-0 select-none">
            {user.name.split(' ').map(n => n[0]).slice(0, 2).join('')}
          </div>
          <div className="hidden lg:block space-y-0.5 text-left select-none">
            <h4 className="text-xs font-bold text-slate-800 leading-none flex items-center gap-1">
              {user.name.split(' ').slice(0, 2).join(' ')} <UserCheck className="w-3.5 h-3.5 text-emerald-600" />
            </h4>
            <p className="text-[9px] text-slate-400 font-extrabold uppercase leading-none">{user.divisionId}</p>
          </div>
        </div>

      </div>

    </header>
  );
}
