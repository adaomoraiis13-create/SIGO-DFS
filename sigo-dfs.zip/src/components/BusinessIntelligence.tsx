import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  Users, 
  ShieldCheck, 
  Activity, 
  Search, 
  Plus, 
  Filter, 
  Calendar, 
  Building2, 
  FileSpreadsheet, 
  CheckCircle2, 
  AlertTriangle, 
  RefreshCw, 
  Download, 
  FileText,
  Briefcase,
  AlertCircle
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  LineChart, 
  Line, 
  PieChart, 
  Pie, 
  Cell, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend 
} from 'recharts';
import { User, DivisionId } from '../types.js';

interface KPI {
  id: string;
  nome: string;
  categoria: string;
  valor: number;
  unidade: string;
  data: string;
}

interface RelatorioAnalitico {
  id: string;
  tipo: string;
  periodo: string;
  gerado_por: string;
  data: string;
}

interface Estatistica {
  id: string;
  categoria: string;
  indicador: string;
  valor: number;
  data: string;
}

interface BusinessIntelligenceProps {
  user: User;
  balances: any[];
  actionPlans: any[];
}

export default function BusinessIntelligence({ user, balances, actionPlans }: BusinessIntelligenceProps) {
  const [activeTab, setActiveTab] = useState<'executivo' | 'kpis' | 'divisões' | 'relatorios'>('executivo');
  const [kpis, setKpis] = useState<KPI[]>([]);
  const [estatisticas, setEstatisticas] = useState<Estatistica[]>([]);
  const [relatorios, setRelatorios] = useState<RelatorioAnalitico[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Filters state
  const [divisionFilter, setDivisionFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Add KPI Modal / Form state
  const [showAddModal, setShowAddModal] = useState(false);
  const [newKpi, setNewKpi] = useState({
    nome: '',
    categoria: 'Operações AVSEC',
    valor: 0,
    unidade: 'unidades'
  });

  // Report Generator State
  const [reportType, setReportType] = useState<string>('Diário');
  const [reportPeriod, setReportPeriod] = useState<string>('15/07/2026');
  const [generatedReport, setGeneratedReport] = useState<string | null>(null);

  // Sync data on mount
  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [kpiRes, estRes, repRes] = await Promise.all([
        fetch('/api/bi/kpis').then(r => r.json()),
        fetch('/api/bi/statistics').then(r => r.json()),
        fetch('/api/bi/reports').then(r => r.json())
      ]);
      setKpis(kpiRes || []);
      setEstatisticas(estRes || []);
      setRelatorios(repRes || []);
    } catch (err: any) {
      console.error('Falha ao carregar dados do BI:', err);
      setError('Lamento, ocorreu um erro ao carregar os dados operacionais do BI.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleAddKpi = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKpi.nome) return;

    try {
      const res = await fetch('/api/bi/kpis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...newKpi,
          data: new Date().toISOString()
        })
      });
      if (res.ok) {
        const added = await res.json();
        setKpis(prev => [added, ...prev]);
        setShowAddModal(false);
        setNewKpi({
          nome: '',
          categoria: 'Operações AVSEC',
          valor: 0,
          unidade: 'unidades'
        });
      }
    } catch (err) {
      console.error('Erro ao adicionar KPI:', err);
    }
  };

  const handleGenerateReport = async () => {
    try {
      const res = await fetch('/api/bi/reports', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tipo: reportType,
          periodo: reportPeriod,
          gerado_por: user.name
        })
      });
      if (res.ok) {
        const added = await res.json();
        setRelatorios(prev => [added, ...prev]);
        
        // Compute dynamic summary text
        const totalAcoes = actionPlans.length;
        const acoesPendentes = actionPlans.filter(a => a.estado !== 'Concluído' && a.estado !== 'Resolvido').length;
        const totalBalancos = balances.length;

        const summaryMarkdown = `
# ATO & OC, SA
## DIRECÇÃO DE FACILITAÇÃO E SEGURANÇA (DFS)
*Seu Destino, Nossa Missão*

---

# RELATÓRIO ANALÍTICO OPERACIONAL (${reportType.toUpperCase()})
**Período:** ${reportPeriod} | **Gerado em:** ${new Date().toLocaleDateString('pt-PT')}
**Responsável de Emissão:** ${user.name} (${user.role.replace('_', ' ')})

---

## 1. RESUMO EXECUTIVO DO DESEMPENHO
De acordo com os registos consolidados no sistema SIGO-DFS, as divisões operacionais demonstraram um elevado índice de conformidade com os regulamentos institucionais vigentes.

- **KPIs Ativos Monitorizados:** ${kpis.length} indicadores operacionais
- **Balanços Operacionais Coletados:** ${totalBalancos} balanços consolidados
- **Plano de Ação Corretiva:** ${totalAcoes} ações totais registadas (${acoesPendentes} em curso/pendentes)

## 2. KPIS CRÍTICOS E CONTROLO DE RECURSOS
As rondas de segurança perimetral (AVSEC) mantiveram-se nos 100% de realização programada. Registou-se uma disponibilidade de efetivo humano na ordem dos **${kpis.find(k => k.id === 'kpi-2')?.valor || 128} colaboradores ativos**, contra as **${kpis.find(k => k.id === 'kpi-3')?.valor || 14} ausências reportadas**.

Em termos de recursos materiais, foram assinalados **${kpis.find(k => k.id === 'kpi-6')?.valor || 3} equipamentos avariados** que requerem reparação urgente sob supervisão técnica.

## 3. RECOMENDAÇÕES DA DIREÇÃO
1. Alocar pessoal suplementar nos portões de embarque de modo a otimizar tempos de fila de check-in.
2. Agilizar a auditoria do scanner de bagagem de mão avariado na ala sul de passageiros.
3. Certificar que todas as ações prioritárias em atraso sejam resolvidas até ao final da semana corrente.
`;
        setGeneratedReport(summaryMarkdown.trim());
      }
    } catch (err) {
      console.error('Erro ao gerar relatório analítico:', err);
    }
  };

  // Filter KPI items
  const filteredKPIs = kpis.filter(k => {
    // Search filter
    const matchesSearch = k.nome.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          k.categoria.toLowerCase().includes(searchQuery.toLowerCase());
    
    // Category filter
    let matchesCategory = true;
    if (categoryFilter !== 'all') {
      matchesCategory = k.categoria === categoryFilter;
    }

    // Division Filter mapping
    let matchesDivision = true;
    if (divisionFilter !== 'all') {
      if (divisionFilter === 'DOS') {
        matchesDivision = k.categoria === 'Recursos Humanos' || k.categoria === 'Recursos Materiais' || k.categoria === 'Operações AVSEC';
      } else if (divisionFilter === 'DFC') {
        matchesDivision = k.categoria === 'Facilitação' || k.categoria === 'Credenciamento';
      } else {
        matchesDivision = false; // or general
      }
    }

    return matchesSearch && matchesCategory && matchesDivision;
  });

  // KPI Categories list for filter dropdown
  const kpiCategories = Array.from(new Set(kpis.map(k => k.categoria)));

  // Grouped charts calculations
  const radarPerfData = [
    { name: 'Pontualidade', DOS: 95, DFC: 88, FAL: 100, DRCQ: 90 },
    { name: 'Relatórios Env.', DOS: 85, DFC: 78, FAL: 95, DRCQ: 80 },
    { name: 'Plano Ação', DOS: 80, DFC: 70, FAL: 90, DRCQ: 85 },
    { name: 'Cumprimento', DOS: 92, DFC: 85, FAL: 98, DRCQ: 89 },
  ];

  const planActionStatusData = [
    { name: 'DOS', Concluido: 12, EmCurso: 4, Atrasado: 1 },
    { name: 'DFC', Concluido: 8, EmCurso: 3, Atrasado: 2 },
    { name: 'FAL', Concluido: 15, EmCurso: 1, Atrasado: 0 },
    { name: 'DRCQ', Concluido: 6, EmCurso: 2, Atrasado: 0 },
  ];

  const materialResourcesData = [
    { name: 'Operacionais', value: kpis.find(k => k.id === 'kpi-5')?.valor || 34, color: '#10b981' },
    { name: 'Avariados', value: kpis.find(k => k.id === 'kpi-6')?.valor || 3, color: '#f43f5e' },
    { name: 'Manutenção', value: kpis.find(k => k.id === 'kpi-7')?.valor || 2, color: '#f59e0b' },
  ];

  const avsecSecurityData = [
    { data: '11/07', Inspecoes: 30, Apreensoes: 12 },
    { data: '12/07', Inspecoes: 35, Apreensoes: 15 },
    { data: '13/07', Inspecoes: 42, Apreensoes: 18 },
    { data: '14/07', Inspecoes: 38, Apreensoes: 14 },
    { data: '15/07', Inspecoes: 45, Apreensoes: 20 },
  ];

  return (
    <div className="flex-1 bg-slate-50 min-h-screen pb-16">
      
      {/* Title block with deep indigo styling */}
      <div className="bg-slate-900 border-b border-slate-800 text-white px-8 py-8 shadow-sm">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <div className="flex items-center gap-2 text-sky-400 text-xs font-black uppercase tracking-wider mb-1">
              <TrendingUp className="w-4 h-4" /> Centro de Business Intelligence SIGO-DFS
            </div>
            <h1 className="text-2xl font-black tracking-tight text-white md:text-3xl">
              Dashboards e Indicadores Estratégicos
            </h1>
            <p className="text-slate-400 text-xs mt-1 font-medium max-w-2xl">
              Análise em tempo real do Balanço Operacional, KPIS corporativos e desempenho integrado das Divisões de Facilitação, Segurança, Operações e Qualidade.
            </p>
          </div>

          <div className="flex flex-wrap gap-2.5">
            <button 
              onClick={fetchData}
              className="px-3.5 py-2 text-xs font-bold bg-slate-800 text-slate-200 border border-slate-700 rounded-lg hover:bg-slate-700 transition flex items-center gap-2"
            >
              <RefreshCw className="w-3.5 h-3.5" /> Atualizar Dados
            </button>
            <button 
              onClick={() => {
                setActiveTab('kpis');
                setShowAddModal(true);
              }}
              className="px-3.5 py-2 text-xs font-bold bg-sky-600 text-white rounded-lg hover:bg-sky-500 transition shadow-sm flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" /> Lançar KPI
            </button>
          </div>
        </div>
      </div>

      {/* Main Container */}
      <div className="max-w-7xl mx-auto px-4 md:px-8 mt-6">
        
        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-200 overflow-x-auto gap-2 mb-6">
          <button
            onClick={() => setActiveTab('executivo')}
            className={`px-4 py-2.5 text-xs font-extrabold uppercase tracking-wider border-b-2 transition-all shrink-0 ${
              activeTab === 'executivo'
                ? 'border-sky-600 text-sky-600 font-black'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Dashboard Executivo
          </button>
          <button
            onClick={() => setActiveTab('kpis')}
            className={`px-4 py-2.5 text-xs font-extrabold uppercase tracking-wider border-b-2 transition-all shrink-0 ${
              activeTab === 'kpis'
                ? 'border-sky-600 text-sky-600 font-black'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Matriz de KPIs
          </button>
          <button
            onClick={() => setActiveTab('divisões')}
            className={`px-4 py-2.5 text-xs font-extrabold uppercase tracking-wider border-b-2 transition-all shrink-0 ${
              activeTab === 'divisões'
                ? 'border-sky-600 text-sky-600 font-black'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Performance Divisional
          </button>
          <button
            onClick={() => setActiveTab('relatorios')}
            className={`px-4 py-2.5 text-xs font-extrabold uppercase tracking-wider border-b-2 transition-all shrink-0 ${
              activeTab === 'relatorios'
                ? 'border-sky-600 text-sky-600 font-black'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Relatórios Analíticos
          </button>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-rose-500 shrink-0 mt-0.5" />
            <div className="text-xs font-bold leading-tight">{error}</div>
          </div>
        )}

        {loading ? (
          <div className="flex flex-col items-center justify-center py-24 space-y-3">
            <div className="w-12 h-12 border-4 border-sky-600 border-t-transparent rounded-full animate-spin"></div>
            <p className="text-sm font-semibold text-slate-500">A processar dados analíticos do SIGO-DFS...</p>
          </div>
        ) : (
          <>
            {/* TAB 1: EXECUTIVE DASHBOARD */}
            {activeTab === 'executivo' && (
              <div className="space-y-6">
                
                {/* Scorecards Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  {/* HR card */}
                  <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs hover:shadow-md transition">
                    <div className="flex justify-between items-start">
                      <div className="space-y-1">
                        <p className="text-[10px] text-slate-400 font-extrabold uppercase tracking-wider">Efetivo Operacional (DOS)</p>
                        <h3 className="text-2xl font-black text-slate-800">
                          {kpis.find(k => k.id === 'kpi-2')?.valor || 128} <span className="text-xs font-bold text-slate-500">/ {kpis.find(k => k.id === 'kpi-1')?.valor || 142}</span>
                        </h3>
                        <p className="text-[10px] text-emerald-600 font-bold flex items-center gap-0.5">
                          90.1% de taxa de presença ativa
                        </p>
                      </div>
                      <div className="p-3 rounded-lg bg-sky-50 text-sky-600">
                        <Users className="w-5 h-5" />
                      </div>
                    </div>
                  </div>

                  {/* AVSEC Inspections card */}
                  <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs hover:shadow-md transition">
                    <div className="flex justify-between items-start">
                      <div className="space-y-1">
                        <p className="text-[10px] text-slate-400 font-extrabold uppercase tracking-wider">Inspeções AVSEC</p>
                        <h3 className="text-2xl font-black text-slate-800">
                          {kpis.find(k => k.id === 'kpi-8')?.valor || 42} <span className="text-xs font-bold text-slate-500">hoje</span>
                        </h3>
                        <p className="text-[10px] text-sky-600 font-bold flex items-center gap-0.5">
                          {kpis.find(k => k.id === 'kpi-9')?.valor || 18} artigos proibidos apreendidos
                        </p>
                      </div>
                      <div className="p-3 rounded-lg bg-emerald-50 text-emerald-600">
                        <ShieldCheck className="w-5 h-5" />
                      </div>
                    </div>
                  </div>

                  {/* Equipment card */}
                  <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs hover:shadow-md transition">
                    <div className="flex justify-between items-start">
                      <div className="space-y-1">
                        <p className="text-[10px] text-slate-400 font-extrabold uppercase tracking-wider">Status Equipamentos</p>
                        <h3 className="text-2xl font-black text-slate-800">
                          {kpis.find(k => k.id === 'kpi-5')?.valor || 34} <span className="text-xs font-bold text-slate-500">ativos</span>
                        </h3>
                        <p className="text-[10px] text-rose-500 font-bold flex items-center gap-0.5">
                          {kpis.find(k => k.id === 'kpi-6')?.valor || 3} avariados / {kpis.find(k => k.id === 'kpi-7')?.valor || 2} manutenção
                        </p>
                      </div>
                      <div className="p-3 rounded-lg bg-amber-50 text-amber-600">
                        <Activity className="w-5 h-5" />
                      </div>
                    </div>
                  </div>

                  {/* Plan of Action Status card */}
                  <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs hover:shadow-md transition">
                    <div className="flex justify-between items-start">
                      <div className="space-y-1">
                        <p className="text-[10px] text-slate-400 font-extrabold uppercase tracking-wider">Ações Corretivas Totais</p>
                        <h3 className="text-2xl font-black text-slate-800">
                          {actionPlans.length} <span className="text-xs font-bold text-slate-500">registadas</span>
                        </h3>
                        <p className="text-[10px] text-sky-600 font-bold flex items-center gap-0.5">
                          {actionPlans.filter(a => a.estado === 'Concluído').length} ações dadas como resolvidas
                        </p>
                      </div>
                      <div className="p-3 rounded-lg bg-purple-50 text-purple-600">
                        <CheckCircle2 className="w-5 h-5" />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Recharts Grid Section */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  
                  {/* Chart 1: Plan of Action Execution by Division */}
                  <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
                    <h4 className="text-xs font-black text-slate-700 uppercase tracking-wider mb-4 flex items-center gap-2">
                      <Building2 className="w-4 h-4 text-sky-500" /> Ações do Plano de Ação por Divisão
                    </h4>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={planActionStatusData}>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} />
                          <XAxis dataKey="name" stroke="#64748b" fontSize={11} tickLine={false} />
                          <YAxis stroke="#64748b" fontSize={11} tickLine={false} />
                          <Tooltip contentStyle={{ fontSize: 11, borderRadius: 8 }} />
                          <Legend wrapperStyle={{ fontSize: 10, pt: 10 }} />
                          <Bar dataKey="Concluido" name="Concluídas" fill="#10b981" radius={[4, 4, 0, 0]} />
                          <Bar dataKey="EmCurso" name="Em Curso" fill="#0284c7" radius={[4, 4, 0, 0]} />
                          <Bar dataKey="Atrasado" name="Atrasadas" fill="#ef4444" radius={[4, 4, 0, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* Chart 2: Material Resources Availability (Pie) */}
                  <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
                    <h4 className="text-xs font-black text-slate-700 uppercase tracking-wider mb-4 flex items-center gap-2">
                      <Activity className="w-4 h-4 text-sky-500" /> Disponibilidade de Recursos Materiais
                    </h4>
                    <div className="h-64 flex flex-col md:flex-row justify-around items-center">
                      <div className="w-1/2 h-full">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={materialResourcesData}
                              cx="50%"
                              cy="50%"
                              innerRadius={60}
                              outerRadius={80}
                              paddingAngle={5}
                              dataKey="value"
                            >
                              {materialResourcesData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={entry.color} />
                              ))}
                            </Pie>
                            <Tooltip contentStyle={{ fontSize: 11 }} />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                      <div className="space-y-2 mt-4 md:mt-0">
                        {materialResourcesData.map((res, idx) => (
                          <div key={idx} className="flex items-center gap-2.5">
                            <span className="w-3 h-3 rounded-full" style={{ backgroundColor: res.color }}></span>
                            <span className="text-xs font-bold text-slate-600">{res.name}:</span>
                            <span className="text-xs font-black text-slate-800">{res.value} un.</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Chart 3: AVSEC Inspections Rate vs Prohibited Items */}
                  <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs lg:col-span-2">
                    <h4 className="text-xs font-black text-slate-700 uppercase tracking-wider mb-4 flex items-center gap-2">
                      <ShieldCheck className="w-4 h-4 text-sky-500" /> Atividade e Apreensões Diárias (Pistas e Terminais)
                    </h4>
                    <div className="h-72">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={avsecSecurityData}>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} />
                          <XAxis dataKey="data" stroke="#64748b" fontSize={11} tickLine={false} />
                          <YAxis stroke="#64748b" fontSize={11} tickLine={false} />
                          <Tooltip contentStyle={{ fontSize: 11, borderRadius: 8 }} />
                          <Legend wrapperStyle={{ fontSize: 10 }} />
                          <Line type="monotone" dataKey="Inspecoes" name="Inspeções de Rastreio" stroke="#0284c7" strokeWidth={2.5} dot={{ r: 4 }} />
                          <Line type="monotone" dataKey="Apreensoes" name="Artigos Proibidos Detetados" stroke="#ef4444" strokeWidth={2} dot={{ r: 4 }} />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                </div>

              </div>
            )}

            {/* TAB 2: LIVE KPI GRID */}
            {activeTab === 'kpis' && (
              <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
                
                {/* Grid filter bar */}
                <div className="flex flex-col md:flex-row gap-4 justify-between items-start md:items-center mb-6">
                  <div className="flex flex-wrap gap-2">
                    
                    {/* Search field */}
                    <div className="relative">
                      <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                      <input 
                        type="text" 
                        placeholder="Pesquisar KPI..." 
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-9 pr-4 py-1.5 w-60 border border-slate-200 rounded-lg text-xs bg-slate-50 focus:bg-white transition focus:outline-none"
                      />
                    </div>

                    {/* Division selector */}
                    <select
                      value={divisionFilter}
                      onChange={(e) => setDivisionFilter(e.target.value)}
                      className="border border-slate-200 rounded-lg text-xs px-3 py-1.5 bg-slate-50 focus:bg-white focus:outline-none font-medium"
                    >
                      <option value="all">Todas as Divisões</option>
                      <option value="DOS">DOS (Operações & AVSEC)</option>
                      <option value="DFC">DFC (Facilitação & Credenciais)</option>
                    </select>

                    {/* Category Selector */}
                    <select
                      value={categoryFilter}
                      onChange={(e) => setCategoryFilter(e.target.value)}
                      className="border border-slate-200 rounded-lg text-xs px-3 py-1.5 bg-slate-50 focus:bg-white focus:outline-none font-medium"
                    >
                      <option value="all">Todas as Categorias</option>
                      {kpiCategories.map((cat, idx) => (
                        <option key={idx} value={cat}>{cat}</option>
                      ))}
                    </select>

                  </div>

                  <button 
                    onClick={() => setShowAddModal(true)}
                    className="px-3.5 py-1.5 text-xs font-bold bg-sky-600 text-white rounded-lg hover:bg-sky-500 transition flex items-center gap-1.5"
                  >
                    <Plus className="w-4 h-4" /> Novo KPI
                  </button>
                </div>

                {/* Table Grid of KPIs */}
                <div className="overflow-x-auto border border-slate-100 rounded-lg">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-200 text-[10px] font-extrabold uppercase tracking-widest text-slate-500">
                        <th className="py-3 px-4">Indicador</th>
                        <th className="py-3 px-4">Categoria / Divisão</th>
                        <th className="py-3 px-4 text-right">Valor Operacional</th>
                        <th className="py-3 px-4">Status / Padrão</th>
                        <th className="py-3 px-4">Última Atualização</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-xs text-slate-600">
                      {filteredKPIs.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="text-center py-10 font-bold text-slate-400">
                            Nenhum KPI operacional correspondente aos filtros.
                          </td>
                        </tr>
                      ) : (
                        filteredKPIs.map((k, idx) => {
                          // Determine color indicator status
                          let isHealthy = true;
                          if (k.nome.includes('Ausências') && k.valor > 10) isHealthy = false;
                          if (k.nome.includes('avariados') && k.valor > 0) isHealthy = false;
                          if (k.nome.includes('reclamações') && k.valor > 0) isHealthy = false;

                          return (
                            <tr key={idx} className="hover:bg-slate-50 transition">
                              <td className="py-3 px-4 font-black text-slate-800">{k.nome}</td>
                              <td className="py-3 px-4">
                                <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-slate-100 border border-slate-200 text-slate-600 uppercase">
                                  {k.categoria}
                                </span>
                              </td>
                              <td className="py-3 px-4 text-right font-extrabold text-slate-900">
                                {k.valor.toLocaleString()} <span className="text-[10px] font-normal text-slate-400 uppercase">{k.unidade}</span>
                              </td>
                              <td className="py-3 px-4">
                                <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                                  isHealthy 
                                    ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' 
                                    : 'bg-amber-50 text-amber-700 border border-amber-200'
                                }`}>
                                  <span className={`w-1.5 h-1.5 rounded-full ${isHealthy ? 'bg-emerald-500' : 'bg-amber-500 animate-pulse'}`}></span>
                                  {isHealthy ? 'Conforme' : 'Acompanhamento'}
                                </span>
                              </td>
                              <td className="py-3 px-4 font-mono text-[11px] text-slate-400">
                                {new Date(k.data).toLocaleString('pt-PT')}
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>

              </div>
            )}

            {/* TAB 3: PERFORMANCE DIVISIONAL */}
            {activeTab === 'divisões' && (
              <div className="space-y-6">
                
                {/* Grid comparativo */}
                <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
                  <h4 className="text-sm font-black text-slate-800 uppercase tracking-wider mb-4 flex items-center gap-2">
                    <Building2 className="w-5 h-5 text-sky-500" /> Matriz de Performance Integrada por Divisão (%)
                  </h4>
                  <p className="text-xs text-slate-500 font-medium mb-6">
                    A pontuação de desempenho reflete o cumprimento de prazos, punctualidade na entrega de relatórios e progresso das ações preventivas e corretivas recomendadas pela Direção.
                  </p>

                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={radarPerfData}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} />
                        <XAxis dataKey="name" stroke="#64748b" fontSize={11} tickLine={false} />
                        <YAxis stroke="#64748b" fontSize={11} tickLine={false} unit="%" />
                        <Tooltip contentStyle={{ fontSize: 11, borderRadius: 8 }} />
                        <Legend wrapperStyle={{ fontSize: 11 }} />
                        <Bar dataKey="DOS" name="DOS (Pistas & Terminais)" fill="#0284c7" radius={[4, 4, 0, 0]} />
                        <Bar dataKey="DFC" name="DFC (Facilitação)" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                        <Bar dataKey="FAL" name="FAL (Apoio & Acessibilidade)" fill="#10b981" radius={[4, 4, 0, 0]} />
                        <Bar dataKey="DRCQ" name="DRCQ (Qualidade & Risco)" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Resumo da Performance em Cards de Divisão */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Card DOS */}
                  <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex items-start gap-4">
                    <div className="w-12 h-12 rounded-xl bg-sky-50 text-sky-600 font-black flex items-center justify-center text-sm shrink-0">
                      DOS
                    </div>
                    <div className="space-y-1">
                      <h4 className="text-xs font-black text-slate-800 uppercase tracking-wider">Divisão de Operações e AVSEC</h4>
                      <p className="text-xs text-slate-500 font-medium leading-relaxed">
                        Desempenho forte em pista. Necessidade de foco na resolução das ações em atraso referentes à sinalização vertical e controlo de fauna noturno.
                      </p>
                    </div>
                  </div>

                  {/* Card DFC */}
                  <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex items-start gap-4">
                    <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 font-black flex items-center justify-center text-sm shrink-0">
                      DFC
                    </div>
                    <div className="space-y-1">
                      <h4 className="text-xs font-black text-slate-800 uppercase tracking-wider">Divisão de Facilitação e Fluxo</h4>
                      <p className="text-xs text-slate-500 font-medium leading-relaxed">
                        Pontos de atenção nas filas de migração e triagem de bagagens. Plano de contingência manual ativado com sucesso após quebra parcial do sistema.
                      </p>
                    </div>
                  </div>
                </div>

              </div>
            )}

            {/* TAB 4: ANALYTICAL REPORTS */}
            {activeTab === 'relatorios' && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                
                {/* Left side: Generator */}
                <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs h-fit space-y-4">
                  <h4 className="text-xs font-black text-slate-800 uppercase tracking-wider flex items-center gap-2">
                    <FileSpreadsheet className="w-4 h-4 text-sky-500" /> Emissor de Relatório Analítico
                  </h4>

                  <div className="space-y-3">
                    <div>
                      <label className="block text-[10px] font-extrabold uppercase tracking-wider text-slate-400 mb-1">Tipo de Relatório</label>
                      <select 
                        value={reportType}
                        onChange={(e) => setReportType(e.target.value)}
                        className="w-full border border-slate-200 rounded-lg text-xs px-3 py-2 bg-slate-50 focus:bg-white focus:outline-none"
                      >
                        <option value="Diário">Relatório de Performance Diário</option>
                        <option value="Semanal">Análise de Tendência Semanal</option>
                        <option value="Mensal">Balanço Consolidado Mensal</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] font-extrabold uppercase tracking-wider text-slate-400 mb-1">Período de Referência</label>
                      <input 
                        type="text" 
                        value={reportPeriod}
                        onChange={(e) => setReportPeriod(e.target.value)}
                        className="w-full border border-slate-200 rounded-lg text-xs px-3 py-2 bg-slate-50 focus:bg-white focus:outline-none"
                      />
                    </div>

                    <button
                      onClick={handleGenerateReport}
                      className="w-full py-2 bg-sky-600 hover:bg-sky-500 text-white font-extrabold text-xs uppercase tracking-wider rounded-lg transition shadow-xs flex items-center justify-center gap-1.5"
                    >
                      <FileText className="w-4 h-4" /> Compilar Relatório
                    </button>
                  </div>

                  {/* Generated logs list */}
                  <div className="border-t border-slate-100 pt-4 mt-4 space-y-2.5">
                    <h5 className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest">Histórico de Emissões BI</h5>
                    <div className="space-y-2 max-h-40 overflow-y-auto">
                      {relatorios.map((r, idx) => (
                        <div key={idx} className="flex justify-between items-center p-2 rounded-lg bg-slate-50 border border-slate-100 text-[11px]">
                          <div className="min-w-0">
                            <p className="font-extrabold text-slate-700 truncate">{r.tipo} - {r.periodo}</p>
                            <p className="text-[9px] text-slate-400 truncate">Por: {r.gerado_por}</p>
                          </div>
                          <span className="text-[9px] font-mono text-slate-400 shrink-0">
                            {new Date(r.data).toLocaleDateString('pt-PT')}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Right side: Report viewer */}
                <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs lg:col-span-2 h-fit min-h-96 flex flex-col">
                  {generatedReport ? (
                    <div className="flex-1 flex flex-col justify-between">
                      <div className="bg-slate-50 border border-slate-100 rounded-lg p-5 font-mono text-xs text-slate-700 whitespace-pre-wrap select-text leading-relaxed">
                        {generatedReport}
                      </div>
                      <div className="flex justify-end gap-2 mt-4 pt-4 border-t border-slate-100">
                        <button 
                          onClick={() => {
                            navigator.clipboard.writeText(generatedReport);
                            alert('Relatório copiado para a área de transferência!');
                          }}
                          className="px-3.5 py-2 text-xs font-bold bg-slate-100 text-slate-600 border border-slate-200 rounded-lg hover:bg-slate-200 transition"
                        >
                          Copiar Texto
                        </button>
                        <a
                          href={`data:text/markdown;charset=utf-8,${encodeURIComponent(generatedReport)}`}
                          download={`Relatorio_BI_${reportType}_${reportPeriod.replace(/\//g, '-')}.md`}
                          className="px-3.5 py-2 text-xs font-bold bg-sky-600 text-white rounded-lg hover:bg-sky-500 transition shadow-xs flex items-center gap-1.5"
                        >
                          <Download className="w-3.5 h-3.5" /> Descarregar .MD
                        </a>
                      </div>
                    </div>
                  ) : (
                    <div className="flex-1 flex flex-col items-center justify-center text-center p-12 space-y-3">
                      <FileText className="w-12 h-12 text-slate-300" />
                      <p className="text-sm font-extrabold text-slate-500 uppercase tracking-wider">Visualizador de Relatórios</p>
                      <p className="text-xs text-slate-400 font-medium max-w-sm">
                        Preencha o formulário ao lado e clique em **"Compilar Relatório"** para sintetizar os KPIs e ações corretivas num documento institucional pronto a imprimir ou exportar.
                      </p>
                    </div>
                  )}
                </div>

              </div>
            )}
          </>
        )}

      </div>

      {/* MODAL: ADD KPI */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-md shadow-xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            
            <div className="bg-slate-900 text-white p-5 flex justify-between items-center">
              <div>
                <h3 className="text-sm font-black uppercase tracking-wider">Lançar Novo Indicador Operacional</h3>
                <p className="text-[10px] text-slate-400 font-bold">SIGO-DFS Business Intelligence</p>
              </div>
              <button 
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white text-lg font-black transition"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleAddKpi} className="p-6 space-y-4">
              
              <div>
                <label className="block text-[10px] font-extrabold uppercase tracking-wider text-slate-400 mb-1">Nome do Indicador</label>
                <input 
                  type="text" 
                  required
                  placeholder="Ex: Bagagens extraviadas no voo DT-712"
                  value={newKpi.nome}
                  onChange={(e) => setNewKpi(prev => ({ ...prev, nome: e.target.value }))}
                  className="w-full border border-slate-200 rounded-lg text-xs px-3 py-2 bg-slate-50 focus:bg-white focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-extrabold uppercase tracking-wider text-slate-400 mb-1">Categoria de KPI</label>
                  <select 
                    value={newKpi.categoria}
                    onChange={(e) => setNewKpi(prev => ({ ...prev, categoria: e.target.value }))}
                    className="w-full border border-slate-200 rounded-lg text-xs px-3 py-2 bg-slate-50 focus:bg-white focus:outline-none"
                  >
                    <option value="Operações AVSEC">Operações AVSEC</option>
                    <option value="Recursos Humanos">Recursos Humanos</option>
                    <option value="Recursos Materiais">Recursos Materiais</option>
                    <option value="Facilitação">Facilitação</option>
                    <option value="Credenciamento">Credenciamento</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-extrabold uppercase tracking-wider text-slate-400 mb-1">Unidade de Medida</label>
                  <input 
                    type="text" 
                    required
                    placeholder="Ex: un, pax, incidentes, %"
                    value={newKpi.unidade}
                    onChange={(e) => setNewKpi(prev => ({ ...prev, unidade: e.target.value }))}
                    className="w-full border border-slate-200 rounded-lg text-xs px-3 py-2 bg-slate-50 focus:bg-white focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-extrabold uppercase tracking-wider text-slate-400 mb-1">Valor do Registo</label>
                <input 
                  type="number" 
                  required
                  min={0}
                  value={newKpi.valor}
                  onChange={(e) => setNewKpi(prev => ({ ...prev, valor: Number(e.target.value) }))}
                  className="w-full border border-slate-200 rounded-lg text-xs px-3 py-2 bg-slate-50 focus:bg-white focus:outline-none font-bold"
                />
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t border-slate-100">
                <button 
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 text-xs font-bold bg-slate-100 text-slate-600 border border-slate-200 rounded-lg hover:bg-slate-200 transition"
                >
                  Cancelar
                </button>
                <button 
                  type="submit"
                  className="px-4 py-2 text-xs font-bold bg-sky-600 text-white rounded-lg hover:bg-sky-500 transition shadow-sm"
                >
                  Registar KPI
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

    </div>
  );
}
