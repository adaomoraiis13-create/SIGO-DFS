import React, { useState, useEffect } from 'react';
import { 
  Users, 
  ShieldCheck, 
  Lock, 
  Settings, 
  ShieldAlert, 
  Building2,
  RefreshCw,
  Clock,
  Terminal,
  FileText,
  Database,
  Brain,
  Link as LinkIcon,
  Cpu,
  Activity,
  LogOut,
  AppWindow,
  Menu,
  ChevronRight,
  UserCheck
} from 'lucide-react';
import { User, UserRole, DivisionId, AuditLog } from '../types.js';
import * as api from '../services/api.js';

// Modular Subcomponents Imports
import AdminDashboard from './admin/AdminDashboard.js';
import AdminUsers from './admin/AdminUsers.js';
import AdminProfiles from './admin/AdminProfiles.js';
import AdminDivisions from './admin/AdminDivisions.js';
import AdminSettings from './admin/AdminSettings.js';
import AdminTemplates from './admin/AdminTemplates.js';
import AdminSecurity from './admin/AdminSecurity.js';
import AdminLogs from './admin/AdminLogs.js';
import AdminBackups from './admin/AdminBackups.js';
import AdminIntegrations from './admin/AdminIntegrations.js';
import AdminAI from './admin/AdminAI.js';
import AdminDevSecOps from './admin/AdminDevSecOps.js';

type TabId = 
  | 'dashboard' 
  | 'utilizadores' 
  | 'perfis' 
  | 'divisoes' 
  | 'config_geral' 
  | 'modelos' 
  | 'seguranca' 
  | 'logs_auditoria' 
  | 'backups' 
  | 'integracoes' 
  | 'ia_config' 
  | 'monitorizacao';

export default function Administracao() {
  const [activeTab, setActiveTab] = useState<TabId>('dashboard');
  const [users, setUsers] = useState<User[]>([]);
  const [sessions, setSessions] = useState<any[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [settings, setSettings] = useState({
    allowedDomain: 'ato-oc.co.ao',
    idleTimeoutMinutes: 15,
    powerpointTemplateName: 'Modelo_Institucional_DFS.pptx',
    pdfTemplateName: 'Modelo_Relatorio_DFS.pdf'
  });

  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const loadData = async () => {
    setLoading(true);
    setErrorMsg(null);
    try {
      const fetchedUsers = await api.fetchUsers();
      setUsers(fetchedUsers);

      const fetchedSettings = await api.fetchSettings();
      setSettings(fetchedSettings);

      const fetchedSessions = await api.fetchSessions();
      setSessions(fetchedSessions);

      const fetchedLogs = await api.fetchAuditLogs();
      setAuditLogs(fetchedLogs.slice().reverse()); // show latest first

      setLoading(false);
    } catch (err: any) {
      console.error(err);
      setErrorMsg('Falha ao carregar dados do painel administrativo.');
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [activeTab]);

  const handleTerminateSession = async (sessionId: string) => {
    try {
      await api.terminateSession(sessionId);
      setSessions(prev => prev.filter(s => s.sessionId !== sessionId));
      setSuccessMsg('Sessão terminada e utilizador desconectado com sucesso.');
      setTimeout(() => setSuccessMsg(null), 3000);
    } catch (err) {
      setErrorMsg('Erro ao encerrar sessão.');
    }
  };

  // Sidebar navigation sections structured like Microsoft 365 Admin Center
  const navigationSections = [
    {
      title: 'GERAL',
      items: [
        { id: 'dashboard', label: 'Painel Geral', icon: Activity, desc: 'Estado global do sistema e gauges' },
        { id: 'config_geral', label: 'Configurações Gerais', icon: Settings, desc: 'Branding, logos e SMTP' },
        { id: 'divisoes', label: 'Gestão de Divisões', icon: Building2, desc: 'DOS, DFC, FAL, DRCQ' },
        { id: 'modelos', label: 'Modelos Oficiais', icon: FileText, desc: 'PowerPoint, PDFs e Word' },
      ]
    },
    {
      title: 'ACESSO E SEGURANÇA',
      items: [
        { id: 'utilizadores', label: 'Utilizadores', icon: Users, desc: 'CRUD, MFA, suspensões', badge: users.filter(u => u.status === 'Pendente de Aprovação').length || undefined },
        { id: 'perfis', label: 'Perfis e Permissões', icon: ShieldCheck, desc: 'RBAC granular modular' },
        { id: 'seguranca', label: 'Políticas de Segurança', icon: ShieldAlert, desc: 'Telas, JWT, Lockout' },
      ]
    },
    {
      title: 'DADOS E SISTEMAS',
      items: [
        { id: 'backups', label: 'Cópias de Segurança', icon: Database, desc: 'Backups do banco JSON' },
        { id: 'logs_auditoria', label: 'Centro de Logs', icon: Terminal, desc: 'Logs de auditoria e nível' },
      ]
    },
    {
      title: 'IA E INTEGRAÇÕES',
      items: [
        { id: 'ia_config', label: 'Inteligência Artificial', icon: Brain, desc: 'Hiper-ajuste do Gemini' },
        { id: 'integracoes', label: 'Integrações & APIs', icon: LinkIcon, desc: 'M365, Teams, AD e Webhooks' },
        { id: 'monitorizacao', label: 'Monitorização & DevSecOps', icon: Cpu, desc: 'Docker, K8s e CI/CD' },
      ]
    }
  ];

  const getTabLabel = (id: TabId) => {
    for (const section of navigationSections) {
      const found = section.items.find(item => item.id === id);
      if (found) return found.label;
    }
    return 'Administração';
  };

  return (
    <div className="flex flex-col lg:flex-row min-h-screen -m-6 bg-slate-50/50">
      
      {/* 1. LEFT SIDE NAVIGATION BAR (MICROSOFT FLUENT INSPIRED) */}
      <aside 
        className={`bg-white border-r border-slate-200 shrink-0 transition-all duration-300 flex flex-col justify-between ${
          sidebarOpen ? 'w-full lg:w-72' : 'w-full lg:w-0 overflow-hidden lg:border-r-0'
        }`}
      >
        <div className="p-5 flex flex-col h-full overflow-y-auto">
          {/* ATO Label & System Identification */}
          <div className="flex items-center gap-3 pb-5 border-b border-slate-100 mb-4">
            <div className="w-10 h-10 rounded-lg bg-sky-600 flex items-center justify-center font-black text-white text-lg shadow-xs">
              DFS
            </div>
            <div>
              <h2 className="font-black text-slate-800 text-sm tracking-tight">SIGO-DFS Admin</h2>
              <span className="text-[10px] text-slate-400 font-bold block uppercase">ATO OC Angola</span>
            </div>
          </div>

          {/* Collapsible toggle for Mobile / Small Screens */}
          <div className="space-y-6">
            {navigationSections.map((sect, sIdx) => (
              <div key={sIdx} className="space-y-1.5">
                <span className="text-[10px] font-black text-slate-400 tracking-wider block px-2">
                  {sect.title}
                </span>
                
                <div className="space-y-0.5">
                  {sect.items.map(item => {
                    const Icon = item.icon;
                    const isActive = activeTab === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() => {
                          setActiveTab(item.id as TabId);
                          if (window.innerWidth < 1024) setSidebarOpen(false);
                        }}
                        className={`w-full text-left p-2 rounded-lg text-xs flex items-center justify-between transition-all group font-medium ${
                          isActive 
                            ? 'bg-sky-50 text-sky-950 border-l-4 border-sky-600 font-bold' 
                            : 'hover:bg-slate-50 text-slate-600 border-l-4 border-transparent'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <Icon className={`w-4 h-4 shrink-0 transition-colors ${
                            isActive ? 'text-sky-600' : 'text-slate-400 group-hover:text-slate-700'
                          }`} />
                          <div className="text-left">
                            <span className="block">{item.label}</span>
                            {sidebarOpen && (
                              <span className="text-[10px] text-slate-400 font-normal line-clamp-1 group-hover:text-slate-500">
                                {item.desc}
                              </span>
                            )}
                          </div>
                        </div>

                        {item.badge && (
                          <span className="bg-amber-100 text-amber-800 text-[10px] font-black px-1.5 py-0.5 rounded-full border border-amber-200 animate-pulse">
                            {item.badge}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* BOTTOM METRICS IN SIDEBAR */}
        <div className="p-4 bg-slate-50 border-t border-slate-150 text-xs text-slate-500 flex flex-col gap-2 font-medium">
          <div className="flex justify-between items-center">
            <span>Sessões em aberto:</span>
            <span className="font-mono font-bold text-slate-800">{sessions.length}</span>
          </div>
          <div className="flex justify-between items-center">
            <span>Servidor Central:</span>
            <span className="inline-flex items-center gap-1 text-emerald-600 font-bold">
              <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></span> Online
            </span>
          </div>
        </div>
      </aside>

      {/* 2. MAIN WORKSPACE */}
      <main className="flex-1 p-6 lg:p-8 space-y-6 overflow-x-hidden min-w-0">
        
        {/* WORKSPACE TOP CONTROL HEADER BAR */}
        <div className="flex items-center justify-between bg-white border border-slate-200 p-4 rounded-xl shadow-2xs">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-500 border border-slate-200"
              title="Alternar Barra Lateral"
            >
              <Menu className="w-4 h-4" />
            </button>
            <div className="space-y-0.5">
              <div className="flex items-center gap-1.5 text-slate-400 font-medium text-xs">
                <span>Administração</span>
                <ChevronRight className="w-3 h-3 text-slate-300" />
                <span className="text-slate-600 font-bold">{getTabLabel(activeTab)}</span>
              </div>
              <h1 className="text-base font-black text-slate-900 tracking-tight">
                {getTabLabel(activeTab)}
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={loadData}
              disabled={loading}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-bold border border-slate-200 rounded-lg transition-all"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              Sincronizar
            </button>
          </div>
        </div>

        {/* FEEDBACK BANNERS */}
        {errorMsg && (
          <div className="bg-rose-50 border border-rose-200 text-rose-800 p-4 rounded-xl text-sm flex gap-2.5 font-semibold">
            <ShieldAlert className="w-5 h-5 text-rose-600 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}
        {successMsg && (
          <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded-xl text-sm flex gap-2.5 font-semibold">
            <UserCheck className="w-5 h-5 text-emerald-600 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* LOADING INDICATOR SKELETON */}
        {loading ? (
          <div className="bg-white border border-slate-200 rounded-xl p-8 text-center text-slate-400 space-y-3 shadow-2xs">
            <RefreshCw className="w-8 h-8 animate-spin text-sky-500 mx-auto" />
            <p className="text-xs font-bold font-mono">A ler coleções seguras do SIGO-DFS...</p>
          </div>
        ) : (
          /* TAB ROUTING RENDERING ENGINE */
          <div className="transition-all duration-300">
            {activeTab === 'dashboard' && (
              <AdminDashboard 
                usersCount={users.length} 
                sessionsCount={sessions.length} 
                auditLogsCount={auditLogs.length} 
              />
            )}
            
            {activeTab === 'utilizadores' && (
              <AdminUsers 
                users={users} 
                onRefresh={loadData} 
                allowedDomain={settings.allowedDomain} 
                registrationPolicy={(settings as any).registrationPolicy}
              />
            )}

            {activeTab === 'perfis' && (
              <AdminProfiles />
            )}

            {activeTab === 'divisoes' && (
              <AdminDivisions />
            )}

            {activeTab === 'config_geral' && (
              <AdminSettings />
            )}

            {activeTab === 'modelos' && (
              <AdminTemplates />
            )}

            {activeTab === 'seguranca' && (
              <AdminSecurity />
            )}

            {activeTab === 'backups' && (
              <AdminBackups />
            )}

            {activeTab === 'logs_auditoria' && (
              <AdminLogs />
            )}

            {activeTab === 'ia_config' && (
              <AdminAI />
            )}

            {activeTab === 'integracoes' && (
              <AdminIntegrations />
            )}

            {activeTab === 'monitorizacao' && (
              <AdminDevSecOps />
            )}
          </div>
        )}

      </main>

    </div>
  );
}
