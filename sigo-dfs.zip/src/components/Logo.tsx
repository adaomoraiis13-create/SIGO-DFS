import React from 'react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showSlogan?: boolean;
  variant?: 'light' | 'dark' | 'white';
}

export default function Logo({ 
  className = '', 
  size = 'md', 
  showSlogan = true, 
  variant = 'light' 
}: LogoProps) {
  // Dimensions based on size
  const sizes = {
    sm: { width: 140, height: 46 },
    md: { width: 220, height: 72 },
    lg: { width: 320, height: 105 },
    xl: { width: 420, height: 138 }
  };

  const { width, height } = sizes[size];

  // Colors based on variant
  const primaryBlue = variant === 'white' ? '#FFFFFF' : '#1ea6e3';
  const darkBlue = variant === 'white' ? '#FFFFFF' : '#0f75bc';
  
  // Set text color according to dark/light backgrounds
  const textColor = variant === 'white' 
    ? '#FFFFFF' 
    : variant === 'dark' 
      ? '#cbd5e1' // High contrast silver gray on dark backgrounds
      : '#7f8c8d'; // Medium brand gray on light backgrounds

  const sloganColor = variant === 'white' ? '#FFFFFF' : '#1ea6e3';

  return (
    <div className={`flex items-center select-none ${className}`} style={{ height: 'auto' }}>
      <svg 
        width={width} 
        height={height} 
        viewBox="0 0 350 115" 
        fill="none" 
        xmlns="http://www.w3.org/2000/svg"
        className="max-w-full"
      >
        <defs>
          <linearGradient id="logo-blue-grad" x1="0%" y1="100%" x2="100%" y2="0%">
            <stop offset="0%" stopColor={darkBlue} />
            <stop offset="100%" stopColor={primaryBlue} />
          </linearGradient>
        </defs>

        {/* 1. Stylized Lowercase "a" Glyph representing aviation and operations */}
        <path 
          d="M 15 90 C 10 90, 5 80, 5 70 C 5 45, 20 10, 50 10 C 75 10, 90 25, 90 50 L 90 90 L 70 90 L 70 75 C 70 65, 60 55, 48 55 C 36 55, 28 65, 28 75 L 28 90 Z" 
          fill="url(#logo-blue-grad)" 
          fillRule="evenodd"
        />
        
        {/* 2. White Airplane Silhouette flying horizontally to the right through the top loop */}
        <path 
          d="M 15 30 L 45 30 L 35 12 L 42 12 L 56 30 L 78 30 C 82 30, 82 34, 78 34 L 54 34 L 40 52 L 34 52 L 48 34 L 20 34 L 12 38 L 15 30 Z" 
          fill="#FFFFFF" 
        />

        {/* 3. Wordmark "ATO" drawn as custom vector paths for perfect bold italic rendering */}
        {/* Letter 'A' */}
        <path 
          d="M 115 75 L 142 12 C 143.5 9, 146.5 8, 150 8 L 165 8 C 168.5 8, 171.5 9, 173 12 L 200 75 L 175 75 L 168 55 L 144 55 L 137 75 Z M 148 44 L 164 44 L 156 22 C 155 20, 153 20, 152 22 Z" 
          fill={primaryBlue}
          fillRule="evenodd"
        />

        {/* Letter 'T' */}
        <path 
          d="M 195 15 C 195 11, 198 8, 202 8 L 258 8 C 262 8, 265 11, 265 15 C 265 19, 262 22, 258 22 L 238 22 L 219 75 L 195 75 L 214 22 L 202 22 C 198 22, 195 19, 195 15 Z" 
          fill={primaryBlue}
        />

        {/* Letter 'O' */}
        <path 
          d="M 255 42 C 248 60, 258 75, 275 75 L 305 75 C 322 75, 332 60, 332 42 C 332 24, 322 8, 305 8 L 275 8 C 258 8, 248 24, 255 42 Z M 276 42 C 272 32, 277 22, 285 22 L 297 22 C 305 22, 310 32, 306 42 C 302 52, 297 61, 289 61 L 277 61 C 269 61, 266 52, 276 42 Z" 
          fill={primaryBlue}
          fillRule="evenodd"
        />

        {/* 4. Subtitle: "AIAAN Temporary Operator" */}
        <text 
          x="116" 
          y="93" 
          fontFamily="var(--font-display), system-ui, -apple-system, sans-serif" 
          fontWeight="700" 
          fontStyle="italic"
          fontSize="14" 
          fill={textColor}
          letterSpacing="0.2"
        >
          AIAAN Temporary Operator
        </text>

        {/* 5. Slogan: "Seu Destino, Nossa Missão" */}
        {showSlogan && (
          <text 
            x="120" 
            y="110" 
            fontFamily="var(--font-sans), system-ui, -apple-system, sans-serif" 
            fontWeight="700" 
            fontStyle="italic"
            fontSize="13" 
            fill={sloganColor}
            letterSpacing="0.3"
          >
            Seu Destino, Nossa Missão
          </text>
        )}
      </svg>
    </div>
  );
}

