import React, { useState, useEffect } from 'react';
import { 
  User, 
  OperationalBalance, 
  Documento, 
  ActionPlanItem, 
  Notification 
} from './types.js';
import * as api from './services/api.js';

// Layout and Core Modules
import Sidebar from './components/Sidebar.js';
import Header from './components/Header.js';
import Dashboard from './components/Dashboard.js';
import BalançoOperacional from './components/BalançoOperacional.js';
import Documentos from './components/Documentos.js';
import InteligenciaDoc from './components/InteligenciaDoc.js';
import PlanoAcao from './components/PlanoAcao.js';
import Indicadores from './components/Indicadores.js';
import Historico from './components/Historico.js';
import Administracao from './components/Administracao.js';
import About from './components/About.js';
import Logo from './components/Logo.js';
import BusinessIntelligence from './components/BusinessIntelligence.js';
import Copilot from './components/Copilot.js';

// Icons for login helper
import { 
  KeyRound, 
  User as UserIcon, 
  LogIn, 
  Sparkles, 
  Shield, 
  AlertCircle,
  UserPlus,
  ArrowLeft,
  Mail,
  Phone,
  Briefcase,
  HelpCircle,
  Building,
  Info,
  CheckCircle2,
  Lock,
  LockKeyhole
} from 'lucide-react';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [activeView, setView] = useState<string>('dashboard');
  const [selectedBalanceId, setSelectedBalanceId] = useState<string | null>(null);
  const [selectedSubView, setSelectedSubView] = useState<string>('dashboard');

  // Database cached states
  const [balances, setBalances] = useState<OperationalBalance[]>([]);
  const [documents, setDocuments] = useState<Documento[]>([]);
  const [actionPlans, setActionPlans] = useState<ActionPlanItem[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(false);

  // Auth Routing
  const [authScreen, setAuthScreen] = useState<'login' | 'signup' | 'recovery' | 'reset'>('login');

  // Login form state
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [rememberMe, setRememberMe] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  // Signup form state
  const [signupName, setSignupName] = useState('');
  const [signupEmail, setSignupEmail] = useState('');
  const [signupPhone, setSignupPhone] = useState('');
  const [signupDivisionId, setSignupDivisionId] = useState<string>('DOS');
  const [signupPosition, setSignupPosition] = useState('');
  const [signupPassword, setSignupPassword] = useState('');
  const [signupConfirmPassword, setSignupConfirmPassword] = useState('');
  const [signupError, setSignupError] = useState<string | null>(null);
  const [signupSuccess, setSignupSuccess] = useState<string | null>(null);

  // Recovery form state
  const [recoveryEmail, setRecoveryEmail] = useState('');
  const [recoveryError, setRecoveryError] = useState<string | null>(null);
  const [recoverySuccess, setRecoverySuccess] = useState<string | null>(null);

  // Reset password form state
  const [resetEmail, setResetEmail] = useState('');
  const [resetPasswordVal, setResetPasswordVal] = useState('');
  const [resetConfirmPassword, setResetConfirmPassword] = useState('');
  const [resetError, setResetError] = useState<string | null>(null);
  const [resetSuccess, setResetSuccess] = useState<string | null>(null);

  // System settings
  const [settings, setSettings] = useState({
    allowedDomain: 'ato-oc.co.ao',
    idleTimeoutMinutes: 15,
    powerpointTemplateName: 'Modelo_Institucional_DFS.pptx',
    pdfTemplateName: 'Modelo_Relatorio_DFS.pdf',
    registrationPolicy: 'ANY_VALID_EMAIL'
  });

  // Fetch settings when logged in or when auth screen updates
  const fetchSettings = async () => {
    try {
      const data = await api.fetchSettings();
      setSettings(data);
    } catch (err) {
      console.error('Failed to fetch settings', err);
    }
  };

  useEffect(() => {
    fetchSettings();
  }, [currentUser, authScreen]);

  // Pull all data from Express API
  const refreshAppData = async () => {
    if (!currentUser) return;
    setLoading(true);
    try {
      const [b, d, ap, n] = await Promise.all([
        api.fetchBalances(),
        api.fetchDocuments(),
        api.fetchActionPlans(),
        api.fetchNotifications()
      ]);
      setBalances(b);
      setDocuments(d);
      setActionPlans(ap);
      setNotifications(n);
    } catch (err) {
      console.error('Failed to sync app operational data', err);
    } finally {
      setLoading(false);
    }
  };

  // Run initial fetch on log in
  useEffect(() => {
    if (currentUser) {
      refreshAppData();
    }
  }, [currentUser]);

  // Auto logout on inactivity based on settings.idleTimeoutMinutes
  useEffect(() => {
    if (!currentUser) return;

    let timeoutId: any;
    const timeoutDuration = (settings.idleTimeoutMinutes || 15) * 60 * 1000;

    const resetTimer = () => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        handleAutoLogout();
      }, timeoutDuration);
    };

    const handleAutoLogout = () => {
      alert(`Sessão terminada automaticamente após ${settings.idleTimeoutMinutes} minutos de inatividade para proteção de dados do SIGO-DFS.`);
      setCurrentUser(null);
      setView('dashboard');
      setUsername('');
      setPassword('');
      setSelectedBalanceId(null);
      setAuthScreen('login');
    };

    const events = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart'];
    events.forEach(event => {
      window.addEventListener(event, resetTimer);
    });

    resetTimer();

    return () => {
      clearTimeout(timeoutId);
      events.forEach(event => {
        window.removeEventListener(event, resetTimer);
      });
    };
  }, [currentUser, settings.idleTimeoutMinutes]);

  // Load saved username on mount (Remember Me)
  useEffect(() => {
    const savedUser = localStorage.getItem('sigo_saved_username');
    if (savedUser) {
      setUsername(savedUser);
      setRememberMe(true);
    }
  }, []);

  // Handle Authentication submit
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    try {
      const user = await api.login(username, password);
      if (rememberMe) {
        localStorage.setItem('sigo_saved_username', username);
      } else {
        localStorage.removeItem('sigo_saved_username');
      }
      setCurrentUser(user);
    } catch (err: any) {
      setLoginError(err.message || 'Falha de credenciais.');
    }
  };

  const handleSignupSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSignupError(null);
    setSignupSuccess(null);

    if (signupPassword !== signupConfirmPassword) {
      setSignupError('As palavras-passes introduzidas não coincidem.');
      return;
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(signupEmail)) {
      setSignupError('O endereço de e-mail introduzido possui um formato inválido.');
      return;
    }

    const policy = settings.registrationPolicy || 'ANY_VALID_EMAIL';
    if (policy === 'ONLY_INSTITUTIONAL') {
      if (!signupEmail.endsWith(`@${settings.allowedDomain}`)) {
        setSignupError(`O e-mail deve obrigatoriamente pertencer ao domínio institucional da ATO & OC (@${settings.allowedDomain}).`);
        return;
      }
    }

    try {
      await api.signup({
        name: signupName,
        email: signupEmail,
        phone: signupPhone,
        divisionId: signupDivisionId,
        position: signupPosition,
        password: signupPassword
      });

      setSignupSuccess('Pedido de criação de conta submetido com sucesso! A conta encontra-se "Pendente de Aprovação" por parte do Secretariado. Será notificado assim que for ativada.');
      
      // Reset fields
      setSignupName('');
      setSignupEmail('');
      setSignupPhone('');
      setSignupDivisionId('DOS');
      setSignupPosition('');
      setSignupPassword('');
      setSignupConfirmPassword('');
    } catch (err: any) {
      setSignupError(err.message || 'Erro ao criar conta.');
    }
  };

  const handleRecoverySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setRecoveryError(null);
    setRecoverySuccess(null);

    try {
      const res = await api.recoverPassword(recoveryEmail);
      setRecoverySuccess(res.message);
    } catch (err: any) {
      setRecoveryError(err.message || 'Erro ao solicitar a recuperação de senha.');
    }
  };

  const handleSimulateResetClick = (email: string) => {
    setResetEmail(email);
    setAuthScreen('reset');
    setResetError(null);
    setResetSuccess(null);
  };

  const handleResetSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setResetError(null);
    setResetSuccess(null);

    if (resetPasswordVal !== resetConfirmPassword) {
      setResetError('As palavras-passes introduzidas não coincidem.');
      return;
    }

    try {
      await api.resetPassword(resetEmail, resetPasswordVal);
      setResetSuccess('Palavra-passe redefinida com sucesso! Agora já pode iniciar sessão.');
      setResetPasswordVal('');
      setResetConfirmPassword('');
    } catch (err: any) {
      setResetError(err.message || 'Erro ao redefinir palavra-passe.');
    }
  };

  const handleLogout = () => {
    if (window.confirm('Deseja realmente terminar sessão no SIGO-DFS?')) {
      setCurrentUser(null);
      setView('dashboard');
      setUsername('');
      setPassword('');
      setSelectedBalanceId(null);
      setAuthScreen('login');
    }
  };

  // Render main sub-views
  const renderActiveView = () => {
    if (loading && balances.length === 0) {
      return (
        <div className="flex flex-col items-center justify-center py-20 space-y-3">
          <div className="w-10 h-10 border-4 border-sky-600 border-t-transparent rounded-full animate-spin"></div>
          <p className="text-sm font-medium text-slate-500">A sincronizar base de dados DFS...</p>
        </div>
      );
    }

    switch (activeView) {
      case 'dashboard':
        return (
          <Dashboard 
            user={currentUser!} 
            balances={balances} 
            actionPlans={actionPlans} 
            documents={documents}
            setView={setView}
            setSelectedBalanceId={setSelectedBalanceId}
          />
        );
      case 'balancos':
        return (
          <BalançoOperacional 
            user={currentUser!} 
            balances={balances} 
            onRefresh={refreshAppData}
            selectedBalanceId={selectedBalanceId}
            setSelectedBalanceId={setSelectedBalanceId}
            selectedSubView={selectedSubView}
            setSelectedSubView={setSelectedSubView}
          />
        );
      case 'documentos':
        return (
          <Documentos 
            user={currentUser!} 
            documents={documents} 
            onRefresh={refreshAppData} 
          />
        );
      case 'inteligencia':
        return (
          <InteligenciaDoc 
            user={currentUser!}
          />
        );
      case 'plano-acao':
        return (
          <PlanoAcao 
            user={currentUser!} 
            actionPlans={actionPlans} 
            onRefresh={refreshAppData} 
          />
        );
      case 'indicadores':
        return <Indicadores balances={balances} />;
      case 'bi':
        return (
          <BusinessIntelligence 
            user={currentUser!}
            balances={balances}
            actionPlans={actionPlans}
          />
        );
      case 'copilot':
        return (
          <Copilot 
            user={currentUser!}
            balances={balances}
            actionPlans={actionPlans}
          />
        );
      case 'historico':
        return <Historico />;
      case 'administracao':
        return <Administracao />;
      case 'about':
        return <About />;
      default:
        return <div className="p-6">Módulo em desenvolvimento...</div>;
    }
  };

  // --- 1. AUTHENTICATION & LANDING SCREENS ---
  if (!currentUser) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col justify-between font-sans relative overflow-y-auto select-none">
        
        {/* Background Image with Ambient Glassmorphism overlay */}
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1483450388369-9ed95738483c?q=80&w=1600" 
            alt="Aeroporto Internacional" 
            className="w-full h-full object-cover select-none pointer-events-none"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-tr from-slate-950 via-slate-950/94 to-slate-900/80 backdrop-blur-xs"></div>
        </div>

        {/* Decorative runway green light at bottom */}
        <div className="absolute inset-x-0 bottom-0 h-1 z-0 opacity-30 pointer-events-none">
          <div className="w-full h-full bg-emerald-500 shadow-[0_0_15px_#10b981]"></div>
        </div>

        {/* Main interactive split-screen grid */}
        <div className="relative z-10 flex-1 flex flex-col lg:flex-row max-w-7xl w-full mx-auto p-4 md:p-8 lg:p-12 items-center justify-center gap-8 lg:gap-16">
          
          {/* LADO ESQUERDO: Branding / Informação Institucional */}
          <div className="flex-1 text-left space-y-6 max-w-xl lg:pr-6 py-6 animate-fade-in">
            
            {/* Header Logotipo */}
            <div className="flex items-center space-x-2">
              <Logo size="lg" variant="white" showSlogan={true} />
            </div>

            <div className="space-y-4">
              {/* Institutional Tag */}
              <div className="inline-flex items-center space-x-2 bg-sky-500/10 border border-sky-500/25 px-3 py-1 rounded-full text-[10px] text-sky-400 font-extrabold uppercase tracking-widest">
                <span>Plataforma Oficial ATO & OC</span>
              </div>
              
              <h1 className="text-4xl md:text-5xl font-black text-white tracking-tight uppercase leading-tight font-mono">
                SIGO-DFS
              </h1>
              
              {/* Elegant Blue Accent Divider */}
              <div className="w-16 h-1 bg-sky-500 rounded-full"></div>
              
              <p className="text-sm md:text-base text-slate-200 font-bold leading-relaxed">
                Sistema Integrado de Gestão Operacional da Direção de Facilitação e Segurança
              </p>
              
              <p className="text-xs text-slate-400 font-medium leading-relaxed max-w-lg">
                Plataforma institucional corporativa dedicada à recolha, consolidação e acompanhamento em tempo real das atividades, indicadores de segurança e balanços operacionais das divisões da DFS.
              </p>
            </div>

            {/* List of Key Enterprise Capabilities */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-5 border-t border-white/10">
              
              {/* Capability 1 */}
              <div className="flex items-start space-x-3 group">
                <div className="p-2.5 rounded-xl bg-sky-500/10 border border-sky-500/15 text-sky-400 shrink-0 group-hover:bg-sky-500/20 transition-all duration-200">
                  <Shield className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-extrabold text-slate-200 uppercase tracking-wider">Segurança</h4>
                  <p className="text-[11px] text-slate-400 mt-0.5">Proteção avançada de dados corporativos.</p>
                </div>
              </div>

              {/* Capability 2 */}
              <div className="flex items-start space-x-3 group">
                <div className="p-2.5 rounded-xl bg-sky-500/10 border border-sky-500/15 text-sky-400 shrink-0 group-hover:bg-sky-500/20 transition-all duration-200">
                  <Building className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-extrabold text-slate-200 uppercase tracking-wider">Gestão Integrada</h4>
                  <p className="text-[11px] text-slate-400 mt-0.5">Informações DFS centralizadas e auditáveis.</p>
                </div>
              </div>

              {/* Capability 3 */}
              <div className="flex items-start space-x-3 group">
                <div className="p-2.5 rounded-xl bg-sky-500/10 border border-sky-500/15 text-sky-400 shrink-0 group-hover:bg-sky-500/20 transition-all duration-200">
                  <Info className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-extrabold text-slate-200 uppercase tracking-wider">Inteligência</h4>
                  <p className="text-[11px] text-slate-400 mt-0.5">Métricas, relatórios automáticos e BI.</p>
                </div>
              </div>

              {/* Capability 4 */}
              <div className="flex items-start space-x-3 group">
                <div className="p-2.5 rounded-xl bg-sky-500/10 border border-sky-500/15 text-sky-400 shrink-0 group-hover:bg-sky-500/20 transition-all duration-200">
                  <UserPlus className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-extrabold text-slate-200 uppercase tracking-wider">Colaboração</h4>
                  <p className="text-[11px] text-slate-400 mt-0.5">Trabalho fluido e processos coordenados.</p>
                </div>
              </div>

            </div>

          </div>

          {/* LADO DIREITO: Form Card (Transitions gracefully) */}
          <div className="w-full max-w-md shrink-0">
            <div className="bg-white rounded-2xl border border-slate-100 shadow-2xl overflow-hidden">
              
              {/* Form Body based on Auth Screen */}
              {authScreen === 'login' && (
                <div className="p-6 md:p-8 space-y-6">
                  <div className="flex items-center space-x-3 pb-4 border-b border-slate-100">
                    <div className="p-2.5 rounded-xl bg-sky-500/10 text-sky-600">
                      <UserIcon className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-lg font-black text-slate-800 uppercase tracking-tight">Iniciar Sessão</h3>
                      <p className="text-xs text-slate-400">Insira as suas credenciais operacionais.</p>
                    </div>
                  </div>

                  {loginError && (
                    <div className="bg-rose-50 border border-rose-100 text-rose-800 p-3 rounded-xl flex items-start gap-2.5 text-xs font-semibold">
                      <AlertCircle className="w-4.5 h-4.5 text-rose-600 shrink-0 mt-0.5" />
                      <p className="leading-relaxed">{loginError}</p>
                    </div>
                  )}

                  <form onSubmit={handleLoginSubmit} className="space-y-4 text-xs font-bold text-slate-600">
                    <div className="space-y-1">
                      <label className="uppercase block text-slate-400 text-[10px] tracking-wider">Endereço de E-mail ou Nome de Utilizador</label>
                      <div className="relative">
                        <UserIcon className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
                        <input 
                          type="text"
                          placeholder={settings.registrationPolicy === 'ONLY_INSTITUTIONAL' ? `Ex: jose@${settings.allowedDomain} ou jose` : "Ex: jose@exemplo.com ou jose"}
                          value={username}
                          onChange={(e) => setUsername(e.target.value)}
                          className="w-full pl-9 pr-3.5 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-1 focus:ring-sky-500 focus:bg-white text-slate-800 font-semibold text-xs"
                          required
                        />
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="uppercase block text-slate-400 text-[10px] tracking-wider">Palavra-passe</label>
                      <div className="relative">
                        <LockKeyhole className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
                        <input 
                          type={showPassword ? "text" : "password"}
                          placeholder="A sua palavra-passe"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          className="w-full pl-9 pr-10 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-1 focus:ring-sky-500 focus:bg-white text-slate-800 font-semibold text-xs"
                          required
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-3.5 text-sky-600 hover:text-sky-700 font-bold focus:outline-hidden text-[10px] uppercase"
                        >
                          {showPassword ? "Ocultar" : "Mostrar"}
                        </button>
                      </div>
                    </div>

                    <div className="flex justify-between items-center pt-1">
                      <label className="flex items-center space-x-2 text-slate-500 text-xs font-semibold cursor-pointer">
                        <input 
                          type="checkbox"
                          checked={rememberMe}
                          onChange={(e) => setRememberMe(e.target.checked)}
                          className="rounded border-slate-300 text-sky-600 focus:ring-sky-500 w-4 h-4 cursor-pointer"
                        />
                        <span>Lembrar-me</span>
                      </label>
                      
                      <button 
                        type="button"
                        onClick={() => { setRecoveryError(null); setRecoverySuccess(null); setAuthScreen('recovery'); }}
                        className="text-xs text-sky-600 hover:underline font-bold"
                      >
                        Esqueci-me da senha?
                      </button>
                    </div>

                    <button
                      type="submit"
                      className="w-full py-3 bg-sky-600 hover:bg-sky-700 text-white font-black rounded-xl shadow-md border border-sky-700 hover:scale-101 active:scale-99 transition-all flex items-center justify-center gap-2 text-xs uppercase cursor-pointer"
                    >
                      <LogIn className="w-4 h-4" /> Entrar no SIGO-DFS
                    </button>
                  </form>

                  <div className="relative flex py-2 items-center">
                    <div className="flex-grow border-t border-slate-150"></div>
                    <span className="flex-shrink mx-4 text-slate-400 text-[10px] font-bold uppercase tracking-widest">ou</span>
                    <div className="flex-grow border-t border-slate-150"></div>
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-start space-x-2.5">
                      <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600 shrink-0">
                        <UserPlus className="w-4 h-4" />
                      </div>
                      <div>
                        <h4 className="text-xs font-extrabold text-slate-700 uppercase tracking-tight">Não tem uma conta institucional?</h4>
                        <p className="text-[10px] text-slate-400 font-normal">Submeta o registo profissional e solicite a devida aprovação.</p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => { setSignupError(null); setSignupSuccess(null); setAuthScreen('signup'); }}
                      className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black rounded-xl border border-emerald-700 hover:scale-101 active:scale-99 transition-all flex items-center justify-center gap-1.5 text-xs uppercase cursor-pointer"
                    >
                      <UserPlus className="w-4 h-4" /> Criar Conta DFS
                    </button>
                  </div>
                </div>
              )}

              {authScreen === 'signup' && (
                <div className="p-6 md:p-8 space-y-5">
                  <div className="flex items-center gap-2 pb-4 border-b border-slate-100">
                    <button 
                      onClick={() => setAuthScreen('login')}
                      className="p-1.5 hover:bg-slate-100 text-slate-500 rounded-lg transition-all"
                    >
                      <ArrowLeft className="w-4 h-4" />
                    </button>
                    <div className="space-y-0.5">
                      <h3 className="text-lg font-black text-slate-800 uppercase tracking-tight">Criar Conta DFS</h3>
                      <p className="text-xs text-slate-400">Insira os seus dados profissionais.</p>
                    </div>
                  </div>

                  {signupError && (
                    <div className="bg-rose-50 border border-rose-100 text-rose-800 p-3 rounded-xl flex items-start gap-2 text-xs font-semibold">
                      <AlertCircle className="w-4.5 h-4.5 text-rose-600 shrink-0 mt-0.5" />
                      <p className="leading-relaxed">{signupError}</p>
                    </div>
                  )}

                  {signupSuccess ? (
                    <div className="bg-emerald-50 border border-emerald-100 text-emerald-800 p-4 rounded-xl flex items-start gap-3 text-xs font-semibold leading-relaxed">
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                      <div>
                        <p className="font-bold uppercase tracking-tight">Registo Submetido!</p>
                        <p className="text-emerald-700 font-medium mt-1">{signupSuccess}</p>
                        <button 
                          onClick={() => { setSignupSuccess(null); setAuthScreen('login'); }}
                          className="mt-3 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold uppercase text-[10px] tracking-wide"
                        >
                          Ir para o Login
                        </button>
                      </div>
                    </div>
                  ) : (
                    <form onSubmit={handleSignupSubmit} className="space-y-3.5 text-xs font-bold text-slate-600">
                      <div className="space-y-1">
                        <label className="uppercase block text-slate-400 text-[10px] tracking-wider">Nome Completo</label>
                        <input 
                          type="text"
                          placeholder="Ex: António Agostinho"
                          value={signupName}
                          onChange={(e) => setSignupName(e.target.value)}
                          className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-1 focus:ring-sky-500 text-slate-800 font-semibold"
                          required
                        />
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <label className="uppercase block text-slate-400 text-[10px] tracking-wider">Endereço de E-mail</label>
                          <input 
                            type="email"
                            placeholder={settings.registrationPolicy === 'ONLY_INSTITUTIONAL' ? `Ex: jose@${settings.allowedDomain}` : "Ex: jose@exemplo.com"}
                            value={signupEmail}
                            onChange={(e) => setSignupEmail(e.target.value)}
                            className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-1 focus:ring-sky-500 text-slate-800 font-semibold"
                            required
                          />
                          <span className="block text-[9px] text-slate-400 font-medium">
                            {settings.registrationPolicy === 'ONLY_INSTITUTIONAL' 
                              ? 'Apenas e-mails corporativos autorizados.' 
                              : 'Pode registar-se com qualquer endereço de e-mail válido.'}
                          </span>
                        </div>

                        <div className="space-y-1">
                          <label className="uppercase block text-slate-400 text-[10px] tracking-wider">Contacto Telefónico</label>
                          <input 
                            type="text"
                            placeholder="Ex: +244 923 000 000"
                            value={signupPhone}
                            onChange={(e) => setSignupPhone(e.target.value)}
                            className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-1 focus:ring-sky-500 text-slate-800 font-semibold font-mono"
                            required
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <label className="uppercase block text-slate-400 text-[10px] tracking-wider">Divisão Operacional</label>
                          <select 
                            value={signupDivisionId}
                            onChange={(e) => setSignupDivisionId(e.target.value)}
                            className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden text-slate-800 font-bold"
                            required
                          >
                            <option value="DOS">DOS (Divisão de Operações e Segurança)</option>
                            <option value="DFC">DFC (Divisão de Facilitação e Controle)</option>
                            <option value="FAL">FAL (Divisão de Facilitação / Regulamentação)</option>
                            <option value="DRCQ">DRCQ (Divisão de Regulação e Qualidade)</option>
                            <option value="Secretariado">Secretariado DFS (Administração)</option>
                            <option value="Diretor">Diretor Geral DFS (Direção)</option>
                          </select>
                        </div>

                        <div className="space-y-1">
                          <label className="uppercase block text-slate-400 text-[10px] tracking-wider">Cargo / Função</label>
                          <input 
                            type="text"
                            placeholder="Ex: Técnico de Facilitação"
                            value={signupPosition}
                            onChange={(e) => setSignupPosition(e.target.value)}
                            className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-1 focus:ring-sky-500 text-slate-800 font-semibold"
                            required
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pb-2">
                        <div className="space-y-1">
                          <label className="uppercase block text-slate-400 text-[10px] tracking-wider">Palavra-passe</label>
                          <input 
                            type="password"
                            placeholder="••••••••"
                            value={signupPassword}
                            onChange={(e) => setSignupPassword(e.target.value)}
                            className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-1 focus:ring-sky-500 text-slate-800 font-mono"
                            required
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="uppercase block text-slate-400 text-[10px] tracking-wider">Confirmar Senha</label>
                          <input 
                            type="password"
                            placeholder="••••••••"
                            value={signupConfirmPassword}
                            onChange={(e) => setSignupConfirmPassword(e.target.value)}
                            className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-1 focus:ring-sky-500 text-slate-800 font-mono"
                            required
                          />
                        </div>
                      </div>

                      <button
                        type="submit"
                        className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-black rounded-xl shadow-md border border-emerald-700 hover:scale-101 active:scale-99 transition-all flex items-center justify-center gap-2 text-xs uppercase cursor-pointer"
                      >
                        <UserPlus className="w-4 h-4" /> Submeter Registo
                      </button>
                    </form>
                  )}
                </div>
              )}

              {authScreen === 'recovery' && (
                <div className="p-6 md:p-8 space-y-5">
                  <div className="flex items-center gap-2 pb-4 border-b border-slate-100">
                    <button 
                      onClick={() => setAuthScreen('login')}
                      className="p-1.5 hover:bg-slate-100 text-slate-500 rounded-lg transition-all"
                    >
                      <ArrowLeft className="w-4 h-4" />
                    </button>
                    <div className="space-y-0.5">
                      <h3 className="text-lg font-black text-slate-800 uppercase tracking-tight">Recuperar Palavra-passe</h3>
                      <p className="text-xs text-slate-400">Recupere o acesso à sua conta corporativa.</p>
                    </div>
                  </div>

                  {recoveryError && (
                    <div className="bg-rose-50 border border-rose-100 text-rose-800 p-3 rounded-xl flex items-start gap-2 text-xs font-semibold">
                      <AlertCircle className="w-4.5 h-4.5 text-rose-600 shrink-0 mt-0.5" />
                      <p className="leading-relaxed">{recoveryError}</p>
                    </div>
                  )}

                  {recoverySuccess ? (
                    <div className="bg-emerald-50 border border-emerald-100 text-emerald-800 p-4 rounded-xl flex flex-col gap-4 text-xs font-semibold leading-relaxed">
                      <div className="flex items-start gap-2.5">
                        <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                        <div>
                          <p className="font-bold uppercase tracking-tight">E-mail Enviado!</p>
                          <p className="text-emerald-700 font-medium mt-1">{recoverySuccess}</p>
                        </div>
                      </div>
                      
                      <div className="pt-3 border-t border-emerald-150 space-y-2.5">
                        <span className="text-[9px] uppercase tracking-wider font-extrabold text-slate-500 block">Ambiente Sandbox (Simulador de Link Seguro):</span>
                        <button 
                          type="button"
                          onClick={() => handleSimulateResetClick(recoveryEmail)}
                          className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-black flex items-center justify-center gap-1.5 shadow-sm transition-colors cursor-pointer text-xs uppercase"
                        >
                          <Sparkles className="w-4 h-4" /> Simular Clique no Link
                        </button>
                        <button 
                          type="button"
                          onClick={() => { setRecoverySuccess(null); setAuthScreen('login'); }}
                          className="w-full py-2 bg-white border border-slate-250 hover:bg-slate-50 text-slate-700 rounded-lg font-bold transition-colors cursor-pointer text-xs"
                        >
                          Voltar ao Login
                        </button>
                      </div>
                    </div>
                  ) : (
                    <form onSubmit={handleRecoverySubmit} className="space-y-4 text-xs font-bold text-slate-600">
                      <div className="space-y-1">
                        <label className="uppercase block text-slate-400 text-[10px] tracking-wider">Endereço de E-mail</label>
                        <div className="relative">
                          <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
                          <input 
                            type="email"
                            placeholder={settings.registrationPolicy === 'ONLY_INSTITUTIONAL' ? `Ex: seu-nome@${settings.allowedDomain}` : "Ex: seu-nome@exemplo.com"}
                            value={recoveryEmail}
                            onChange={(e) => setRecoveryEmail(e.target.value)}
                            className="w-full pl-9 pr-3.5 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-1 focus:ring-sky-500 focus:bg-white text-slate-800 font-semibold text-xs"
                            required
                          />
                        </div>
                      </div>

                      <button
                        type="submit"
                        className="w-full py-3 bg-sky-600 hover:bg-sky-700 text-white font-black rounded-xl shadow-md border border-sky-700 hover:scale-101 active:scale-99 transition-all flex items-center justify-center gap-2 text-xs uppercase cursor-pointer"
                      >
                        <Mail className="w-4 h-4" /> Solicitar Instruções
                      </button>
                    </form>
                  )}
                </div>
              )}

              {authScreen === 'reset' && (
                <div className="p-6 md:p-8 space-y-5">
                  <div className="flex items-center gap-2 pb-4 border-b border-slate-100">
                    <button 
                      onClick={() => setAuthScreen('login')}
                      className="p-1.5 hover:bg-slate-100 text-slate-500 rounded-lg transition-all"
                    >
                      <ArrowLeft className="w-4 h-4" />
                    </button>
                    <div className="space-y-0.5">
                      <h3 className="text-lg font-black text-slate-800 uppercase tracking-tight">Redefinir Palavra-passe</h3>
                      <p className="text-xs text-slate-400">Insira a sua nova palavra-passe de acesso.</p>
                    </div>
                  </div>

                  {resetError && (
                    <div className="bg-rose-50 border border-rose-100 text-rose-800 p-3 rounded-xl flex items-start gap-2 text-xs font-semibold">
                      <AlertCircle className="w-4.5 h-4.5 text-rose-600 shrink-0 mt-0.5" />
                      <p className="leading-relaxed">{resetError}</p>
                    </div>
                  )}

                  {resetSuccess ? (
                    <div className="bg-emerald-50 border border-emerald-100 text-emerald-800 p-4 rounded-xl flex items-start gap-2.5 text-xs font-semibold leading-relaxed">
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                      <div>
                        <p className="font-bold uppercase tracking-tight">Senha Atualizada!</p>
                        <p className="text-emerald-700 font-medium mt-1">{resetSuccess}</p>
                        <button 
                          onClick={() => { setResetSuccess(null); setAuthScreen('login'); }}
                          className="mt-3 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold uppercase text-[10px]"
                        >
                          Ir para o Login
                        </button>
                      </div>
                    </div>
                  ) : (
                    <form onSubmit={handleResetSubmit} className="space-y-4 text-xs font-bold text-slate-600">
                      <div className="space-y-1">
                        <label className="uppercase block text-slate-400 text-[10px] tracking-wider">Endereço de E-mail</label>
                        <input 
                          type="text"
                          value={resetEmail}
                          className="w-full px-3.5 py-2.5 bg-slate-100 border border-slate-200 rounded-xl text-slate-500 font-bold outline-hidden cursor-not-allowed text-xs"
                          readOnly
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="uppercase block text-slate-400 text-[10px] tracking-wider">Nova Palavra-passe</label>
                        <input 
                          type="password"
                          placeholder="A sua nova senha"
                          value={resetPasswordVal}
                          onChange={(e) => setResetPasswordVal(e.target.value)}
                          className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-1 focus:ring-sky-500 text-slate-800 font-mono text-xs"
                          required
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="uppercase block text-slate-400 text-[10px] tracking-wider">Confirmar Nova Palavra-passe</label>
                        <input 
                          type="password"
                          placeholder="Confirme a nova senha"
                          value={resetConfirmPassword}
                          onChange={(e) => setResetConfirmPassword(e.target.value)}
                          className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-1 focus:ring-sky-500 text-slate-800 font-mono text-xs"
                          required
                        />
                      </div>

                      <button
                        type="submit"
                        className="w-full py-3 bg-sky-600 hover:bg-sky-700 text-white font-black rounded-xl shadow-md border border-sky-700 hover:scale-101 active:scale-99 transition-all flex items-center justify-center gap-2 text-xs uppercase cursor-pointer"
                      >
                        <KeyRound className="w-4 h-4" /> Redefinir Palavra-passe
                      </button>
                    </form>
                  )}
                </div>
              )}

              {/* Secure warnings footer of the form card */}
              <div className="bg-slate-50 border-t border-slate-100 px-6 py-4 flex items-start space-x-2.5">
                <Shield className="w-5 h-5 text-sky-600 shrink-0 mt-0.5" />
                <p className="text-[10px] text-slate-500 font-medium leading-relaxed">
                  Acesso seguro e restrito. Utilize apenas o seu e-mail institucional para garantir a segurança das informações operacionais e estratégicas da ATO & OC, SA.
                </p>
              </div>

            </div>
          </div>

        </div>

        {/* RODAPÉ INSTITUCIONAL PORTAL */}
        <footer className="relative z-10 w-full max-w-7xl mx-auto px-4 md:px-8 border-t border-white/10 py-6 text-slate-400 text-[11px] font-medium flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex flex-col md:flex-row items-center gap-2 md:gap-4 text-center md:text-left">
            <span className="font-extrabold text-slate-200">ATO & OC, SA</span>
            <span className="hidden md:inline text-white/20">|</span>
            <span>Aeroporto Internacional Dr. António Agostinho Neto</span>
            <span className="hidden md:inline text-white/20">|</span>
            <span>Luanda – Angola</span>
          </div>
          
          <div className="flex flex-wrap items-center justify-center gap-3 text-xs font-bold">
            <a href="#privacidade" onClick={(e) => { e.preventDefault(); alert('Política de Privacidade da ATO & OC, SA (SIGO-DFS)'); }} className="hover:text-slate-200 transition-colors">Política de Privacidade</a>
            <span className="text-white/20">|</span>
            <a href="#termos" onClick={(e) => { e.preventDefault(); alert('Termos de Utilização da Plataforma SIGO-DFS'); }} className="hover:text-slate-200 transition-colors">Termos de Utilização</a>
            <span className="text-white/20">|</span>
            <a href="#suporte" onClick={(e) => { e.preventDefault(); alert('Suporte Técnico DFS: suporte.dfs@ato-oc.co.ao'); }} className="hover:text-slate-200 transition-colors">Suporte Técnico</a>
          </div>

          <div className="font-mono text-slate-500 text-[10px] tracking-wide font-bold">
            VERSÃO DO SISTEMA: 1.0.0
          </div>
        </footer>

      </div>
    );
  }

  // --- 2. LOGGED IN DASHBOARD LAYOUT ---
  return (
    <div className="min-h-screen bg-slate-50 flex font-sans overflow-hidden">
      
      {/* PERSISTENT SIDEBAR MENU */}
      <Sidebar 
        user={currentUser} 
        activeView={activeView} 
        setView={setView} 
        selectedSubView={selectedSubView}
        setSelectedSubView={setSelectedSubView}
        onLogout={handleLogout} 
      />

      {/* RIGHT WORKSPACE */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden">
        
        {/* PERSISTENT HEADER */}
        <Header 
          user={currentUser} 
          notifications={notifications} 
          onRefreshNotifications={refreshAppData} 
          setView={setView}
        />

        {/* INDIVIDUAL SCROLL CONTENT CONTAINER */}
        <main className="flex-1 overflow-y-auto p-6 md:p-8 space-y-6">
          
          {renderActiveView()}

          {/* Institutional Footer */}
          <footer className="pt-8 pb-4 border-t border-slate-200/50 text-slate-400 text-[10px] font-bold uppercase tracking-widest flex flex-col sm:flex-row justify-between items-center gap-4 print:hidden">
            <div className="flex items-center gap-3">
              <Logo size="sm" variant="light" showSlogan={false} className="opacity-75" />
              <span className="text-slate-300">|</span>
              <span>Direção de Facilitação e Segurança (DFS)</span>
            </div>
            <div className="flex items-center gap-2 font-mono">
              <span>SIGO-DFS • Luanda, Angola</span>
            </div>
          </footer>

        </main>

      </div>

    </div>
  );
}
