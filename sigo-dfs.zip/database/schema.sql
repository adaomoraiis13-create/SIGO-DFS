-- ==========================================
-- SIGO-DFS - Esquema da Base de Dados PostgreSQL Relacional
-- Produção - Direção de Facilitação e Segurança
-- Aeroporto Internacional Dr. António Agostinho Neto (ATO & OC Angola)
-- ==========================================

-- Extensões recomendadas para UUID e indexação avançada
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Tabela de Divisões
CREATE TABLE IF NOT EXISTS divisoes (
    id VARCHAR(10) PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    sigla VARCHAR(10) NOT NULL UNIQUE,
    descricao TEXT,
    criado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Semeando Divisões
INSERT INTO divisoes (id, nome, sigla, descricao) VALUES
('DFS', 'Direção de Facilitação e Segurança', 'DFS', 'Direção Geral da Unidade'),
('DOS', 'Divisão de Operações de Segurança', 'DOS', 'Rondas, pista, terminais e inspeções de segurança (AVSEC)'),
('DFC', 'Divisão de Facilitação Comercial', 'DFC', 'Processamento de bagagens, PMR e fluxos comerciais'),
('FAL', 'Divisão de Facilitação Geral', 'FAL', 'Acessibilidade, assistência médica e coordenação normativa'),
('DRCQ', 'Divisão de Regulamentação e Controlo de Qualidade', 'DRCQ', 'Auditorias, prevenção de risco e monitoria de conformidade')
ON CONFLICT (id) DO NOTHING;

-- 2. Tabela de Perfis de Utilizador (Roles)
CREATE TYPE perfil_usuario AS ENUM ('ADMIN', 'DIRETOR', 'CHEFE_DIVISAO', 'SECRETARIADO', 'TECNICO');

-- 3. Tabela de Utilizadores
CREATE TABLE IF NOT EXISTS utilizadores (
    id VARCHAR(50) PRIMARY KEY DEFAULT 'usr-' || uuid_generate_v4(),
    username VARCHAR(100) NOT NULL UNIQUE,
    name VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    phone VARCHAR(30) DEFAULT '+244 923 000 000',
    role VARCHAR(50) NOT NULL,
    division_id VARCHAR(10) REFERENCES divisoes(id) ON DELETE SET NULL,
    position VARCHAR(100) DEFAULT 'Técnico de Operações',
    status VARCHAR(50) DEFAULT 'Ativa',
    password_hash VARCHAR(255) NOT NULL,
    failures INT DEFAULT 0,
    locked_until TIMESTAMP WITH TIME ZONE,
    criado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Índices para pesquisa rápida de utilizadores
CREATE INDEX IF NOT EXISTS idx_utilizadores_username ON utilizadores(username);
CREATE INDEX IF NOT EXISTS idx_utilizadores_email ON utilizadores(email);

-- 4. Tabela de Balanços Operacionais
CREATE TABLE IF NOT EXISTS balancos_operacionais (
    id VARCHAR(50) PRIMARY KEY DEFAULT 'bal-' || uuid_generate_v4(),
    numero VARCHAR(50) NOT NULL UNIQUE,
    data DATE NOT NULL,
    hora VARCHAR(10) NOT NULL,
    estado VARCHAR(50) DEFAULT 'EM_ELABORACAO',
    resumo_geral TEXT,
    criado_por VARCHAR(150) NOT NULL,
    dados_dos JSONB DEFAULT '{}'::jsonb,
    dados_dfc JSONB DEFAULT '{}'::jsonb,
    dados_fal JSONB DEFAULT '{}'::jsonb,
    dados_drcq JSONB DEFAULT '{}'::jsonb,
    criado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_balancos_data ON balancos_operacionais(data);
CREATE INDEX IF NOT EXISTS idx_balancos_estado ON balancos_operacionais(estado);

-- 5. Tabela de Documentos
CREATE TABLE IF NOT EXISTS documentos (
    id VARCHAR(50) PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    tipo VARCHAR(50) NOT NULL,
    divisao_id VARCHAR(10) REFERENCES divisoes(id) ON DELETE SET NULL,
    carregado_por VARCHAR(150) NOT NULL,
    tamanho VARCHAR(30) NOT NULL,
    url VARCHAR(500) NOT NULL,
    balance_id VARCHAR(50),
    versao INT DEFAULT 1,
    is_current BOOLEAN DEFAULT TRUE,
    data_carregamento TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_documentos_divisao ON documentos(divisao_id);

-- 6. Tabela de Planos de Ação (Ações Corretivas)
CREATE TABLE IF NOT EXISTS planos_acao (
    id VARCHAR(50) PRIMARY KEY,
    codigo VARCHAR(50) NOT NULL UNIQUE,
    titulo VARCHAR(255) NOT NULL,
    descricao TEXT NOT NULL,
    categoria VARCHAR(100) DEFAULT 'Operações',
    divisao_id VARCHAR(10) REFERENCES divisoes(id) ON DELETE CASCADE,
    responsavel VARCHAR(150) NOT NULL,
    prioridade VARCHAR(50) NOT NULL,
    estado VARCHAR(50) NOT NULL,
    progresso INT DEFAULT 0,
    percentagem_execucao INT DEFAULT 0,
    data_criacao DATE NOT NULL,
    data_inicio DATE NOT NULL,
    data_limite DATE,
    data_conclusao DATE,
    observacoes TEXT,
    balance_id VARCHAR(50) REFERENCES balancos_operacionais(id) ON DELETE SET NULL,
    historico JSONB DEFAULT '[]'::jsonb,
    comentarios JSONB DEFAULT '[]'::jsonb,
    evidencias JSONB DEFAULT '[]'::jsonb,
    criado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_planos_acao_divisao ON planos_acao(divisao_id);
CREATE INDEX IF NOT EXISTS idx_planos_acao_estado ON planos_acao(estado);

-- 7. Tabela de Logs de Auditoria
CREATE TABLE IF NOT EXISTS audit_logs (
    id SERIAL PRIMARY KEY,
    utilizador VARCHAR(150) NOT NULL,
    perfil VARCHAR(50) NOT NULL,
    acao VARCHAR(100) NOT NULL,
    detalhe TEXT NOT NULL,
    data TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_audit_logs_data ON audit_logs(data);
CREATE INDEX IF NOT EXISTS idx_audit_logs_utilizador ON audit_logs(utilizador);

-- 8. Tabela de Notificações
CREATE TABLE IF NOT EXISTS notificacoes (
    id VARCHAR(50) PRIMARY KEY,
    utilizador_id VARCHAR(50),
    role VARCHAR(50),
    titulo VARCHAR(255) NOT NULL,
    mensagem TEXT NOT NULL,
    lida BOOLEAN DEFAULT FALSE,
    link VARCHAR(255),
    data_criacao TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 9. Tabela de Conversas IA (Copilot)
CREATE TABLE IF NOT EXISTS conversas_ia (
    id VARCHAR(50) PRIMARY KEY,
    utilizador_id VARCHAR(50) NOT NULL,
    modelo_utilizado VARCHAR(50) DEFAULT 'gemini-3.5-flash',
    data_criacao TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS mensagens_ia (
    id VARCHAR(50) PRIMARY KEY,
    conversa_id VARCHAR(50) REFERENCES conversas_ia(id) ON DELETE CASCADE,
    tipo VARCHAR(30) NOT NULL, -- 'utilizador' ou 'assistente'
    conteudo TEXT NOT NULL,
    referencias JSONB DEFAULT '[]'::jsonb,
    data_criacao TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- ==========================================
-- Triggers para atualização automática de timestamps
-- ==========================================
CREATE OR REPLACE FUNCTION update_modified_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.atualizado_em = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_utilizadores_modtime BEFORE UPDATE ON utilizadores FOR EACH ROW EXECUTE PROCEDURE update_modified_column();
CREATE TRIGGER update_balancos_modtime BEFORE UPDATE ON balancos_operacionais FOR EACH ROW EXECUTE PROCEDURE update_modified_column();
CREATE TRIGGER update_planos_modtime BEFORE UPDATE ON planos_acao FOR EACH ROW EXECUTE PROCEDURE update_modified_column();
