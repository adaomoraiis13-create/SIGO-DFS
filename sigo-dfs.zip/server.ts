import express from 'express';
import path from 'path';
import fs from 'fs';
import multer from 'multer';
import { createServer as createViteServer } from 'vite';
import { JsonDB } from './server-db.js';
import { UserRole, DivisionId, BalanceStatus, ActionPlanStatus, ActionPlanPriority, DocType, OperationalBalance, DivisionContributionStatus, DivisionContribution, ProcessStatus, DocumentCategory } from './src/types.js';
import { GoogleGenAI } from "@google/genai";

let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error('A chave de API do Gemini (GEMINI_API_KEY) não está configurada nos segredos.');
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// Configuração robusta do Multer para armazenamento corporativo estruturado (Etapa 7)
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const now = new Date();
    const year = String(now.getFullYear());
    const month = String(now.getMonth() + 1).padStart(2, '0');
    
    // Obter divisão e categoria a partir dos parâmetros de envio
    const division = String(req.body.divisionId || req.query.divisionId || 'DFS').toUpperCase();
    const category = String(req.body.category || req.query.category || 'Outros').replace(/[^a-zA-Z0-9]/g, '_');
    
    const targetDir = path.join(process.cwd(), 'uploads', year, month, division, category);
    
    // Garantir que a diretoria estruturada existe em produção
    fs.mkdirSync(targetDir, { recursive: true });
    cb(null, targetDir);
  },
  filename: (req, file, cb) => {
    const timestamp = Date.now();
    const cleanName = file.originalname.replace(/[^a-zA-Z0-9.-]/g, '_');
    cb(null, `v1_${timestamp}_${cleanName}`);
  }
});

const fileFilter = (req: any, file: any, cb: any) => {
  const allowedExtensions = ['.pptx', '.pdf', '.docx', '.xlsx', '.png', '.jpg', '.jpeg', '.zip'];
  const ext = path.extname(file.originalname).toLowerCase();
  if (allowedExtensions.includes(ext)) {
    cb(null, true);
  } else {
    cb(new Error('Formato de ficheiro não suportado.'));
  }
};

const upload = multer({ 
  storage, 
  fileFilter,
  limits: { fileSize: 50 * 1024 * 1024 } // limite corporativo de 50MB
});

async function startServer() {
  // Initialize Database (Local File or PostgreSQL depending on environment)
  await JsonDB.initDb();

  const app = express();
  const PORT = 3000;

  // Body parser
  app.use(express.json({ limit: '10mb' }));

  // Request logger middleware
  app.use((req, res, next) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
    next();
  });

  // CORS configuration
  app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    if (req.method === 'OPTIONS') {
      return res.sendStatus(200);
    }
    next();
  });

  // Security Headers (Helmet alternative)
  app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    next();
  });

  // Simple Rate Limiting in memory to protect the app
  const ipRequests = new Map<string, { count: number, firstRequest: number }>();
  app.use((req, res, next) => {
    const ip = req.ip || '127.0.0.1';
    const now = Date.now();
    const timeframe = 60 * 1000; // 1 minute
    const maxRequests = 300; // max 300 requests per minute per IP

    const record = ipRequests.get(ip);
    if (!record) {
      ipRequests.set(ip, { count: 1, firstRequest: now });
    } else {
      if (now - record.firstRequest > timeframe) {
        record.count = 1;
        record.firstRequest = now;
      } else {
        record.count++;
        if (record.count > maxRequests) {
          return res.status(429).json({ error: 'Demasiadas requisições. Por favor, aguarde um momento.' });
        }
      }
    }
    next();
  });

  // --- API ROUTES ---

  // Active sessions in memory
  let activeSessions: { sessionId: string; userId: string; username: string; name: string; email: string; divisionId: string; role: string; ip: string; loginTime: string }[] = [];

  // Settings Endpoints
  app.get('/api/settings', (req, res) => {
    res.json(JsonDB.getSettings());
  });

  app.put('/api/settings', (req, res) => {
    const { settings } = req.body;
    const updated = JsonDB.updateSettings(settings);
    res.json(updated);
  });

  // Sessions list
  app.get('/api/sessions', (req, res) => {
    res.json(activeSessions);
  });

  app.delete('/api/sessions/:id', (req, res) => {
    const { id } = req.params;
    activeSessions = activeSessions.filter(s => s.sessionId !== id);
    res.json({ success: true });
  });

  // Auth: Password Recovery
  app.post('/api/auth/recover', (req, res) => {
    const { email } = req.body;
    if (!email) {
      return res.status(400).json({ error: 'E-mail é obrigatório.' });
    }
    const db = JsonDB.getUsers();
    // find if user exists
    const user = db.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (!user) {
      return res.status(404).json({ error: 'E-mail institucional não registado.' });
    }

    // Generate or log recovery event
    JsonDB.createAuditLog({
      utilizador: user.name,
      perfil: user.role,
      acao: 'Recuperação de Senha',
      detalhe: `Solicitada recuperação de senha para ${user.email}. Link de redefinição enviado.`
    });

    res.json({ success: true, message: `Instruções de redefinição de palavra-passe enviadas com sucesso para ${email}.` });
  });

  // Auth: Redefine Password
  app.post('/api/auth/reset-password', (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'E-mail e nova palavra-passe são obrigatórios.' });
    }
    const allUsers = JsonDB['load']().users;
    const user = allUsers.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (!user) {
      return res.status(404).json({ error: 'E-mail institucional não registado.' });
    }

    JsonDB.updateUser(user.id, { passwordHash: password, failures: 0, lockedUntil: undefined });

    JsonDB.createAuditLog({
      utilizador: user.name,
      perfil: user.role,
      acao: 'Redefinição de Senha',
      detalhe: `Palavra-passe redefinida com sucesso para o utilizador ${user.email}.`
    });

    res.json({ success: true, message: 'Palavra-passe redefinida com sucesso!' });
  });

  // Auth: Signup/Register
  app.post('/api/auth/signup', (req, res) => {
    const { name, email, phone, divisionId, position, password } = req.body;
    if (!name || !email || !phone || !divisionId || !position || !password) {
      return res.status(400).json({ error: 'Todos os campos obrigatórios devem ser preenchidos.' });
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({ error: 'O endereço de e-mail introduzido possui um formato inválido.' });
    }

    const settings = JsonDB.getSettings();
    const policy = settings.registrationPolicy || 'ANY_VALID_EMAIL';

    if (policy === 'ONLY_INSTITUTIONAL') {
      const domain = settings.allowedDomain;
      if (!email.endsWith(`@${domain}`)) {
        return res.status(400).json({ error: `O e-mail deve pertencer ao domínio institucional da ATO & OC (@${domain}).` });
      }
    }

    // Check if email already exists
    const allUsers = JsonDB['load']().users;
    const emailExists = allUsers.some(u => u.email.toLowerCase() === email.toLowerCase());
    if (emailExists) {
      return res.status(400).json({ error: 'Este endereço de e-mail já se encontra registado no sistema.' });
    }

    // Generate unique username based on email
    let baseUsername = email.split('@')[0].toLowerCase();
    let username = baseUsername;
    let counter = 1;
    while (allUsers.some(u => u.username === username)) {
      username = `${baseUsername}${counter}`;
      counter++;
    }

    // Set role based on divisionId
    let role = UserRole.CHEFE_DIVISAO;
    if (divisionId === 'Secretariado') {
      role = UserRole.SECRETARIADO;
    } else if (divisionId === 'Diretor') {
      role = UserRole.DIRETOR;
    }

    // Create user with Pendente de Aprovação status
    const newUser = JsonDB.createUser({
      username,
      name,
      email,
      phone,
      divisionId: divisionId === 'Secretariado' || divisionId === 'Diretor' ? DivisionId.DFS : divisionId,
      position,
      role,
      status: 'Pendente de Aprovação',
      passwordHash: password
    });

    // Notify Secretariado about the new registration
    JsonDB.createNotification({
      titulo: 'Novo Utilizador Pendente',
      mensagem: `O colaborador ${name} (${position} - ${divisionId}) solicita acesso ao SIGO-DFS.`,
      role: UserRole.SECRETARIADO,
      link: '/administracao'
    });

    // Log the audit
    JsonDB.createAuditLog({
      utilizador: name,
      perfil: role,
      acao: 'Registo de Conta',
      detalhe: `Conta criada com estado 'Pendente de Aprovação'.`
    });

    res.status(201).json({ success: true, user: newUser });
  });

  // Auth: Login with states and brute force protection
  app.post('/api/auth/login', (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: 'Utilizador e palavra-passe são obrigatórios.' });
    }

    // Resolve user by username or email
    const allUsers = JsonDB['load']().users;
    let userWithHash = allUsers.find(u => u.username === username || u.email.toLowerCase() === username.toLowerCase()) || null;

    if (!userWithHash) {
      return res.status(401).json({ error: 'Utilizador não registado.' });
    }

    // Check lock status
    if (userWithHash.lockedUntil) {
      const lockTime = new Date(userWithHash.lockedUntil).getTime();
      if (Date.now() < lockTime) {
        const remainingSec = Math.ceil((lockTime - Date.now()) / 1000);
        return res.status(403).json({ 
          error: `Conta temporariamente bloqueada por múltiplas tentativas falhadas. Tente novamente em ${remainingSec} segundos.` 
        });
      } else {
        // lock expired, reset failures
        JsonDB.updateUser(userWithHash.id, { failures: 0, lockedUntil: undefined });
        userWithHash.failures = 0;
        userWithHash.lockedUntil = undefined;
      }
    }

    // Validate account status (Pendente, Ativa, Suspensa, Desativada)
    const userStatus = userWithHash.status || 'Ativa';
    if (userStatus === 'Pendente de Aprovação') {
      return res.status(401).json({ 
        error: 'A sua conta foi registada com sucesso, mas encontra-se Pendente de Aprovação por parte do Secretariado. Por favor, aguarde pela ativação.' 
      });
    } else if (userStatus === 'Suspensa') {
      return res.status(401).json({ 
        error: 'A sua conta encontra-se temporariamente Suspensa. Entre em contacto com o Secretariado.' 
      });
    } else if (userStatus === 'Desativada') {
      return res.status(401).json({ 
        error: 'A sua conta foi Desativada. Não possui autorização para aceder ao sistema.' 
      });
    }

    // Check password
    if (userWithHash.passwordHash !== password) {
      const currentFailures = (userWithHash.failures || 0) + 1;
      let updates: any = { failures: currentFailures };
      let errorMsg = 'Palavra-passe incorreta.';
      
      if (currentFailures >= 3) {
        const lockDuration = 60 * 1000; // 1 minute
        const lockUntilTime = new Date(Date.now() + lockDuration).toISOString();
        updates.lockedUntil = lockUntilTime;
        errorMsg = 'Conta temporariamente bloqueada por múltiplas tentativas falhadas (3 tentativas). Tente novamente em 60 segundos.';
        
        JsonDB.createAuditLog({
          utilizador: userWithHash.name,
          perfil: userWithHash.role,
          acao: 'Conta Bloqueada',
          detalhe: `Conta bloqueada devido a 3 falhas seguidas de login.`
        });
      } else {
        errorMsg += ` Tentativa ${currentFailures} de 3 antes de bloqueio temporário.`;
      }
      
      JsonDB.updateUser(userWithHash.id, updates);
      
      JsonDB.createAuditLog({
        utilizador: userWithHash.name,
        perfil: userWithHash.role,
        acao: 'Falha de Login',
        detalhe: `Tentativa falhada de login para o utilizador: ${username}.`
      });

      return res.status(401).json({ error: errorMsg });
    }

    // Success login: clear failures
    if (userWithHash.failures && userWithHash.failures > 0) {
      JsonDB.updateUser(userWithHash.id, { failures: 0, lockedUntil: undefined });
    }

    // Return user data (safely excluding password hash)
    const { passwordHash, failures, lockedUntil, ...user } = userWithHash;

    // Track in memory session
    const sessionId = `sess-${Date.now()}`;
    activeSessions.push({
      sessionId,
      userId: user.id,
      username: user.username,
      name: user.name,
      email: user.email,
      divisionId: user.divisionId,
      role: user.role,
      ip: req.ip || '127.0.0.1',
      loginTime: new Date().toISOString()
    });

    // Log the audit
    JsonDB.createAuditLog({
      utilizador: user.name,
      perfil: user.role,
      acao: 'Sessão Iniciada',
      detalhe: `Utilizador ${user.username} iniciou sessão com sucesso.`
    });

    res.json({ user, sessionId });
  });

  // Users: Get all
  app.get('/api/users', (req, res) => {
    res.json(JsonDB.getUsers());
  });

  // Users: update/edit (Secretariado)
  app.put('/api/users/:id', (req, res) => {
    const { id } = req.params;
    const { name, email, phone, divisionId, role, status, position, password } = req.body;
    
    const originalUser = JsonDB.getUserById(id);
    if (!originalUser) {
      return res.status(404).json({ error: 'Utilizador não encontrado.' });
    }

    const updates: any = {};
    if (name !== undefined) updates.name = name;
    if (email !== undefined) updates.email = email;
    if (phone !== undefined) updates.phone = phone;
    if (divisionId !== undefined) updates.divisionId = divisionId;
    if (role !== undefined) updates.role = role;
    if (status !== undefined) updates.status = status;
    if (position !== undefined) updates.position = position;
    if (password !== undefined && password !== '') updates.passwordHash = password;

    const updated = JsonDB.updateUser(id, updates);

    // If account was pending and is now active, notify user
    if (originalUser.status === 'Pendente de Aprovação' && status === 'Ativa') {
      JsonDB.createNotification({
        utilizadorId: id,
        titulo: 'Conta Ativada',
        mensagem: 'A sua conta foi ativada com sucesso pelo Secretariado. Pode agora efetuar o seu login.',
        link: '/'
      });
    }

    // Log the audit
    JsonDB.createAuditLog({
      utilizador: 'Administrador (Secretariado)',
      perfil: UserRole.SECRETARIADO,
      acao: 'Gestão de Utilizador',
      detalhe: `Conta de ${originalUser.name} atualizada. Novos dados: status=${status}, perfil=${role}, divisao=${divisionId}.`
    });

    res.json(updated);
  });

  // Users: delete (Secretariado)
  app.delete('/api/users/:id', (req, res) => {
    const { id } = req.params;
    const originalUser = JsonDB.getUserById(id);
    if (!originalUser) {
      return res.status(404).json({ error: 'Utilizador não encontrado.' });
    }

    JsonDB.deleteUser(id);

    // Log the audit
    JsonDB.createAuditLog({
      utilizador: 'Administrador (Secretariado)',
      perfil: UserRole.SECRETARIADO,
      acao: 'Eliminar Utilizador',
      detalhe: `Conta de ${originalUser.name} foi eliminada do sistema.`
    });

    res.json({ success: true });
  });

  // Users: create from management panel
  app.post('/api/users', (req, res) => {
    const { name, email, phone, divisionId, role, status, position, password } = req.body;
    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Nome, e-mail e palavra-passe são obrigatórios.' });
    }

    const username = email.split('@')[0];
    const existing = JsonDB.getUserByUsername(username);
    if (existing) {
      return res.status(400).json({ error: 'E-mail ou utilizador já registado.' });
    }

    const newUser = JsonDB.createUser({
      username,
      name,
      email,
      phone: phone || '+244 923 000 000',
      divisionId: divisionId || DivisionId.DFS,
      role: role || UserRole.CHEFE_DIVISAO,
      status: status || 'Ativa',
      position: position || 'Técnico de Operações',
      passwordHash: password
    });

    JsonDB.createAuditLog({
      utilizador: 'Administrador (Secretariado)',
      perfil: UserRole.SECRETARIADO,
      acao: 'Criar Utilizador',
      detalhe: `Criada nova conta para ${name} com perfil ${role}.`
    });

    res.status(201).json(newUser);
  });

  // Balances: Get all
  app.get('/api/balances', (req, res) => {
    res.json(JsonDB.getBalances());
  });

  // Balances: Get by ID
  app.get('/api/balances/:id', (req, res) => {
    const balance = JsonDB.getBalanceById(req.params.id);
    if (!balance) {
      return res.status(404).json({ error: 'Balanço não encontrado.' });
    }
    res.json(balance);
  });

  // Balances: Create new
  app.post('/api/balances', (req, res) => {
    const { user, balanceData } = req.body;
    if (!user) {
      return res.status(401).json({ error: 'Não autorizado.' });
    }

    const newBalance = JsonDB.createBalance({
      numero: balanceData.numero,
      hora: balanceData.hora,
      observacoes: balanceData.observacoes,
      data: balanceData.data,
      criadoPor: user.name,
      estado: BalanceStatus.EM_ELABORACAO,
      resumoGeral: balanceData.resumoGeral || '',
      dos: balanceData.dos || {
        ocorrenciasSeguranca: '',
        estadoPistaTaxiways: '',
        atividadesFauna: '',
        statusTerminaisEquipamentos: '',
        incidentesRelatados: ''
      },
      dfc: balanceData.dfc || {
        controleFronteiras: '',
        reclamacoesBagagens: '',
        filasCheckIn: '',
        tempoEsperaSeguranca: '',
        incidentesFacilitacao: ''
      },
      fal: balanceData.fal || {
        acessibilidadePMR: '',
        conformidadeNormativa: '',
        assistenciaMedica: '',
        feedbackPassageiros: ''
      },
      drcq: balanceData.drcq || {
        auditoriasInspecoes: '',
        naoConformidadesDetetadas: '',
        avaliacaoRiscoOperacional: '',
        acoesPreventivasRecomendadas: ''
      }
    });

    // Create workflow log
    JsonDB.createWorkflowLog({
      balanceId: newBalance.id,
      utilizador: user.name,
      deEstado: BalanceStatus.EM_ELABORACAO,
      paraEstado: BalanceStatus.EM_ELABORACAO,
      comentario: 'Criação inicial do balanço operacional.'
    });

    // Create audit log
    JsonDB.createAuditLog({
      utilizador: user.name,
      perfil: user.role,
      acao: 'Criar Balanço',
      detalhe: `Balanço operacional criado para a data ${newBalance.data}.`
    });

    res.status(201).json(newBalance);
  });

  // Balances: Update
  app.put('/api/balances/:id', (req, res) => {
    const { user, updates } = req.body;
    if (!user) {
      return res.status(401).json({ error: 'Não autorizado.' });
    }

    const oldBalance = JsonDB.getBalanceById(req.params.id);
    if (!oldBalance) {
      return res.status(404).json({ error: 'Balanço não encontrado.' });
    }

    // Role verification (Chefes de divisao can only update their sections, secretariat can update all)
    let finalUpdates = { ...updates };
    if (user.role === UserRole.CHEFE_DIVISAO) {
      // Limit updates based on division
      finalUpdates = {};
      if (user.divisionId === DivisionId.DOS) finalUpdates.dos = updates.dos;
      if (user.divisionId === DivisionId.DFC) finalUpdates.dfc = updates.dfc;
      if (user.divisionId === DivisionId.FAL) finalUpdates.fal = updates.fal;
      if (user.divisionId === DivisionId.DRCQ) finalUpdates.drcq = updates.drcq;
    }

    const updated = JsonDB.updateBalance(req.params.id, finalUpdates);

    // Create audit log
    JsonDB.createAuditLog({
      utilizador: user.name,
      perfil: user.role,
      acao: 'Atualizar Balanço',
      detalhe: `Atualizado balanço para a data ${oldBalance.data}. Seções modificadas.`
    });

    res.json(updated);
  });

  // Balances: Workflow transition (Aprovar, Recusar, Corrigir)
  app.post('/api/balances/:id/workflow', (req, res) => {
    const { user, nextStatus, comment } = req.body;
    if (!user) {
      return res.status(401).json({ error: 'Não autorizado.' });
    }

    const balance = JsonDB.getBalanceById(req.params.id);
    if (!balance) {
      return res.status(404).json({ error: 'Balanço não encontrado.' });
    }

    const currentStatus = balance.estado;
    const updates: Partial<OperationalBalance> = { estado: nextStatus };

    if (nextStatus === BalanceStatus.APROVADO) {
      updates.aprovadoPor = user.name;
    } else if (nextStatus === BalanceStatus.EM_REVISAO) {
      updates.revisadoPor = user.name;
    } else if (nextStatus === BalanceStatus.CORRECAO_SOLICITADA) {
      updates.comentariosRevisao = comment;
    }

    const updated = JsonDB.updateBalance(req.params.id, updates);

    // Create workflow log
    JsonDB.createWorkflowLog({
      balanceId: balance.id,
      utilizador: user.name,
      deEstado: currentStatus,
      paraEstado: nextStatus,
      comentario: comment || `Transição de estado para ${nextStatus}.`
    });

    // Create notification to alert relevant users
    if (nextStatus === BalanceStatus.EM_REVISAO) {
      // Notify Director
      JsonDB.createNotification({
        role: UserRole.DIRETOR,
        titulo: 'Balanço para Aprovação',
        mensagem: `O Balanço de ${balance.data} foi submetido para a sua aprovação final.`,
        link: `/balancos/${balance.id}`
      });
    } else if (nextStatus === BalanceStatus.CORRECAO_SOLICITADA) {
      // Notify Secretariat & Chiefs
      JsonDB.createNotification({
        role: UserRole.SECRETARIADO,
        titulo: 'Correção de Balanço Solicitada',
        mensagem: `O Diretor solicitou correções para o Balanço de ${balance.data}: "${comment}"`,
        link: `/balancos/${balance.id}`
      });
    } else if (nextStatus === BalanceStatus.APROVADO) {
      // Notify all
      JsonDB.createNotification({
        titulo: 'Balanço Operacional Aprovado',
        mensagem: `O Balanço Operacional das últimas 24 horas (${balance.data}) foi aprovado pelo Diretor.`,
        link: `/balancos/${balance.id}`
      });
    }

    // Create audit log
    JsonDB.createAuditLog({
      utilizador: user.name,
      perfil: user.role,
      acao: 'Alteração Workflow',
      detalhe: `Balanço de ${balance.data} transitou de ${currentStatus} para ${nextStatus}.`
    });

    res.json(updated);
  });

  // Action Plans: Get all
  app.get('/api/action-plans', (req, res) => {
    res.json(JsonDB.getActionPlans());
  });

  // Action Plans: Create new
  app.post('/api/action-plans', (req, res) => {
    const { user, item } = req.body;
    if (!user) {
      return res.status(401).json({ error: 'Não autorizado.' });
    }

    const newItem = JsonDB.createActionPlan({
      titulo: item.titulo,
      descricao: item.descricao,
      categoria: item.categoria || 'Operações',
      divisaoId: item.divisaoId,
      responsavel: item.responsavel,
      prioridade: item.prioridade || ActionPlanPriority.MEDIA,
      estado: item.estado || ActionPlanStatus.PENDENTE,
      progresso: item.progresso !== undefined ? Number(item.progresso) : 0,
      dataInicio: item.dataInicio || new Date().toISOString().split('T')[0],
      dataLimite: item.dataLimite,
      observacoes: item.observacoes || '',
      balanceId: item.balanceId
    });

    // Notify division chief
    JsonDB.createNotification({
      divisaoId: item.divisaoId,
      titulo: 'Nova Ação Corretiva Atribuída',
      mensagem: `Ação: "${item.titulo}". Código: ${newItem.codigo}. Prazo: ${item.dataLimite}. Responsável: ${item.responsavel}.`,
      link: '/plano-acao'
    });

    // Create audit log
    JsonDB.createAuditLog({
      utilizador: user.name,
      perfil: user.role,
      acao: 'Criar Ação Corretiva',
      detalhe: `Criada ação "${newItem.titulo}" (${newItem.codigo}) para a divisão ${newItem.divisaoId}.`
    });

    res.status(201).json(newItem);
  });

  // Action Plans: Update item
  app.put('/api/action-plans/:id', (req, res) => {
    const { user, updates } = req.body;
    if (!user) {
      return res.status(401).json({ error: 'Não autorizado.' });
    }

    const oldItem = JsonDB.getActionPlanById(req.params.id);
    if (!oldItem) {
      return res.status(404).json({ error: 'Item do Plano de Ação não encontrado.' });
    }

    if (updates.estado === ActionPlanStatus.CONCLUIDO && oldItem.estado !== ActionPlanStatus.CONCLUIDO) {
      updates.dataConclusao = new Date().toISOString().split('T')[0];
    }

    const updated = JsonDB.updateActionPlan(req.params.id, updates, user.name);

    // Create audit log
    JsonDB.createAuditLog({
      utilizador: user.name,
      perfil: user.role,
      acao: 'Atualizar Ação Corretiva',
      detalhe: `Ação "${oldItem.titulo}" (${oldItem.codigo}) atualizada para o estado: ${updates.estado || oldItem.estado}.`
    });

    res.json(updated);
  });

  // Action Plans: Add Comment
  app.post('/api/action-plans/:id/comments', (req, res) => {
    const { user, comment } = req.body;
    if (!user) {
      return res.status(401).json({ error: 'Não autorizado.' });
    }

    const updated = JsonDB.addActionPlanComment(req.params.id, comment, user.name);
    if (!updated) {
      return res.status(404).json({ error: 'Ação não encontrada.' });
    }

    JsonDB.createAuditLog({
      utilizador: user.name,
      perfil: user.role,
      acao: 'Comentar Ação',
      detalhe: `Adicionado comentário na ação "${updated.titulo}" (${updated.codigo}).`
    });

    res.json(updated);
  });

  // Action Plans: Add Evidence
  app.post('/api/action-plans/:id/evidences', (req, res) => {
    const { user, file, type } = req.body;
    if (!user) {
      return res.status(401).json({ error: 'Não autorizado.' });
    }

    const updated = JsonDB.addActionPlanEvidence(req.params.id, file, type, user.name);
    if (!updated) {
      return res.status(404).json({ error: 'Ação não encontrada.' });
    }

    JsonDB.createAuditLog({
      utilizador: user.name,
      perfil: user.role,
      acao: 'Anexar Evidência',
      detalhe: `Adicionada evidência "${file}" na ação "${updated.titulo}" (${updated.codigo}).`
    });

    res.json(updated);
  });

  // Action Plans: Delete item
  app.delete('/api/action-plans/:id', (req, res) => {
    const { user } = req.body; // or passed in query or header; let's check body or fallback to check auth
    // Let's allow checking from query or body
    const authUser = user || req.query.user ? JSON.parse(req.query.user as string) : null;
    if (!authUser || (authUser.role !== UserRole.ADMIN && authUser.role !== UserRole.SECRETARIADO)) {
      return res.status(401).json({ error: 'Não autorizado ou sem permissões de administrador/secretariado.' });
    }

    const item = JsonDB.getActionPlanById(req.params.id);
    if (!item) {
      return res.status(404).json({ error: 'Item do Plano de Ação não encontrado.' });
    }

    JsonDB.deleteActionPlan(req.params.id);

    JsonDB.createAuditLog({
      utilizador: authUser.name,
      perfil: authUser.role,
      acao: 'Eliminar Ação',
      detalhe: `Eliminada ação "${item.titulo}" (${item.codigo}).`
    });

    res.json({ success: true });
  });

  // Documents: Get all
  app.get('/api/documents', (req, res) => {
    res.json(JsonDB.getDocuments());
  });

  // Documents: Real Multipart Upload (Etapa 7)
  app.post('/api/documents/upload', upload.single('file'), (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: 'Nenhum ficheiro recebido.' });
      }

      // Deserializar utilizador corporativo
      let user = { name: 'Utilizador Corporativo', role: UserRole.CHEFE_DIVISAO, divisionId: 'DFS' };
      if (req.body.user) {
        try {
          user = JSON.parse(req.body.user);
        } catch {
          // ignorar falhas
        }
      }

      const balanceId = req.body.balanceId || undefined;
      const divisionId = req.body.divisionId || user.divisionId || 'DFS';
      
      const fileExt = path.extname(req.file.originalname).toUpperCase();
      let docType = DocType.PPTX;
      if (fileExt === '.PDF') docType = DocType.PDF;
      else if (fileExt === '.DOCX' || fileExt === '.DOC') docType = DocType.DOCX;
      else if (fileExt === '.XLSX' || fileExt === '.XLS') docType = DocType.XLSX;
      else docType = DocType.OUTRO;

      const sizeBytes = req.file.size;
      const sizeMb = (sizeBytes / (1024 * 1024)).toFixed(2);
      const sizeStr = `${sizeMb} MB`;

      // Formatar URL relativa segura de download
      const destPathParts = req.file.path.split(path.join('uploads' + path.sep));
      const relativePath = destPathParts.length > 1 ? destPathParts[1] : req.file.filename;
      const fileUrl = `/uploads/${relativePath.replace(/\\/g, '/')}`;

      const newDoc = JsonDB.createDocument({
        nome: req.file.originalname,
        tipo: docType,
        divisaoId: divisionId as DivisionId,
        carregadoPor: user.name,
        tamanho: sizeStr,
        url: fileUrl,
        balanceId: balanceId
      });

      // Processamento inteligente do relatório
      try {
        JsonDB.processUploadedDocument(newDoc, user.name);
      } catch (err) {
        console.error('[SIGO-DFS UPLOAD] Erro ao auto-processar:', err);
      }

      // Criar auditoria
      JsonDB.createAuditLog({
        utilizador: user.name,
        perfil: user.role,
        acao: 'Carregar Ficheiro Real',
        detalhe: `Upload do ficheiro real "${req.file.originalname}" (${sizeStr}) armazenado de forma estruturada em uploads/.`
      });

      res.status(201).json(newDoc);
    } catch (err: any) {
      console.error('[SIGO-DFS UPLOAD] Falha no upload do ficheiro:', err);
      res.status(500).json({ error: err.message || 'Falha no processamento do ficheiro.' });
    }
  });

  // Documents: Upload (simulated document storage, returns a metadata entry)
  app.post('/api/documents', (req, res) => {
    const { user, doc } = req.body;
    if (!user) {
      return res.status(401).json({ error: 'Não autorizado.' });
    }

    const newDoc = JsonDB.createDocument({
      nome: doc.nome,
      tipo: doc.tipo || DocType.PPTX,
      divisaoId: doc.divisaoId,
      carregadoPor: user.name,
      tamanho: doc.tamanho || '1.5 MB',
      url: `/uploads/${doc.nome}`,
      balanceId: doc.balanceId
    });

    // Auto process the document via Document Intelligence Engine
    try {
      JsonDB.processUploadedDocument(newDoc, user.name);
    } catch (err) {
      console.error('Failed auto processing document:', err);
    }

    // Notify Secretariat if uploaded by Division
    if (user.role === UserRole.CHEFE_DIVISAO) {
      JsonDB.createNotification({
        role: UserRole.SECRETARIADO,
        titulo: 'Relatório Operacional Recebido',
        mensagem: `A divisão ${user.divisionId} submeteu o documento "${newDoc.nome}".`,
        link: '/documentos'
      });
    }

    // Create audit log
    JsonDB.createAuditLog({
      utilizador: user.name,
      perfil: user.role,
      acao: 'Carregar Documento',
      detalhe: `Carregado documento "${newDoc.nome}" da divisão ${newDoc.divisaoId}.`
    });

    res.status(201).json(newDoc);
  });

  // Documents: Delete
  app.delete('/api/documents/:id', (req, res) => {
    const { user } = req.body; // Pass user in query or body for safety
    if (!user || user.role === UserRole.CHEFE_DIVISAO) {
      return res.status(403).json({ error: 'Apenas Administradores ou Secretariado podem apagar documentos.' });
    }

    JsonDB.deleteDocument(req.params.id);

    // Create audit log
    JsonDB.createAuditLog({
      utilizador: user.name,
      perfil: user.role,
      acao: 'Eliminar Documento',
      detalhe: `Documento ID ${req.params.id} removido.`
    });

    res.json({ success: true });
  });

  // Documents: Restore version
  app.post('/api/documents/:id/restore', (req, res) => {
    const { user } = req.body;
    if (!user) {
      return res.status(401).json({ error: 'Não autorizado.' });
    }

    const restoredDoc = JsonDB.restoreDocumentVersion(req.params.id);
    if (!restoredDoc) {
      return res.status(404).json({ error: 'Documento não encontrado.' });
    }

    // Create audit log
    JsonDB.createAuditLog({
      utilizador: user.name,
      perfil: user.role,
      acao: 'Restaurar Versão',
      detalhe: `Restaurada versão ${restoredDoc.versao} do documento "${restoredDoc.nome}".`
    });

    res.json(restoredDoc);
  });

  // Balances: Update contribution status (independent area workflow)
  app.post('/api/balances/:id/contribution', (req, res) => {
    const { user, divisaoId, estado, observacoes } = req.body;
    if (!user) {
      return res.status(401).json({ error: 'Não autorizado.' });
    }

    const balance = JsonDB.getBalanceById(req.params.id);
    if (!balance) {
      return res.status(404).json({ error: 'Balanço não encontrado.' });
    }

    const contribuicoes = balance.contribuicoes || [];
    const index = contribuicoes.findIndex(c => c.divisaoId === divisaoId);
    if (index === -1) {
      return res.status(404).json({ error: 'Contribuição da divisão não encontrada.' });
    }

    const oldEstado = contribuicoes[index].estado;
    contribuicoes[index] = {
      ...contribuicoes[index],
      estado,
      observacoes: observacoes !== undefined ? observacoes : contribuicoes[index].observacoes,
      enviadoPor: user.name,
      enviadoEm: new Date().toISOString()
    };

    const updated = JsonDB.updateBalance(req.params.id, { contribuicoes });

    // Send notifications based on transition
    if (estado === DivisionContributionStatus.EM_VALIDACAO) {
      JsonDB.createNotification({
        role: UserRole.SECRETARIADO,
        titulo: `Validação Necessária - ${divisaoId}`,
        mensagem: `A divisão ${divisaoId} submeteu a sua contribuição para validação no Balanço nº ${balance.numero}.`,
        link: `/balancos/${balance.id}`
      });
    } else if (estado === DivisionContributionStatus.CORRIGIR_DOCUMENTO) {
      JsonDB.createNotification({
        divisaoId,
        titulo: 'Correção Solicitada pelo Secretariado',
        mensagem: `Foi solicitada correção na contribuição da divisão ${divisaoId}: "${observacoes}"`,
        link: `/balancos/${balance.id}`
      });
    } else if (estado === DivisionContributionStatus.VALIDADO) {
      JsonDB.createNotification({
        role: UserRole.SECRETARIADO,
        titulo: `Contribuição Validada - ${divisaoId}`,
        mensagem: `A contribuição de ${divisaoId} foi com sucesso marcada como validada.`,
        link: `/balancos/${balance.id}`
      });
    }

    // Create audit log
    JsonDB.createAuditLog({
      utilizador: user.name,
      perfil: user.role,
      acao: 'Workflow Contribuição',
      detalhe: `Divisão ${divisaoId} no Balanço ${balance.numero} passou de ${oldEstado} para ${estado}.`
    });

    res.json(updated);
  });

  // Workflow Logs: Get for a balance
  app.get('/api/workflow-logs/:balanceId', (req, res) => {
    res.json(JsonDB.getWorkflowLogs(req.params.balanceId));
  });

  // Notifications: Get all
  app.get('/api/notifications', (req, res) => {
    res.json(JsonDB.getNotifications());
  });

  // Notifications: Mark as read
  app.post('/api/notifications/:id/read', (req, res) => {
    JsonDB.markNotificationAsRead(req.params.id);
    res.json({ success: true });
  });

  // Notifications: Mark all as read
  app.post('/api/notifications/read-all', (req, res) => {
    JsonDB.markAllNotificationsAsRead();
    res.json({ success: true });
  });

  // Audit Logs: Get all
  app.get('/api/audit-logs', (req, res) => {
    res.json(JsonDB.getAuditLogs());
  });

  // --- DOCUMENT INTELLIGENCE ENGINE ENDPOINTS ---

  // Get all processed documents
  app.get('/api/processed-documents', (req, res) => {
    const { role, divisionId } = req.query;
    let docs = JsonDB.getProcessedDocuments();

    // Enforce permissions: Chefes de Divisão only view their respective division's documents
    if (role === UserRole.CHEFE_DIVISAO) {
      docs = docs.filter(d => d.divisaoId === divisionId);
    }

    res.json(docs);
  });

  // Get a specific processed document with slides and fields
  app.get('/api/processed-documents/:id', (req, res) => {
    const doc = JsonDB.getProcessedDocumentById(req.params.id);
    if (!doc) {
      return res.status(404).json({ error: 'Documento processado não encontrado.' });
    }

    const slides = JsonDB.getSlides(req.params.id);
    const fields = JsonDB.getExtractedFields(req.params.id);

    res.json({
      processedDoc: doc,
      slides,
      extractedFields: fields
    });
  });

  // Correct a document category (Secretariat or Admin only)
  app.post('/api/processed-documents/:id/category', (req, res) => {
    const { user, category } = req.body;
    if (!user || (user.role !== UserRole.SECRETARIADO && user.role !== UserRole.ADMIN)) {
      return res.status(403).json({ error: 'Permissão negada. Apenas Secretariado ou Administradores podem corrigir classificações.' });
    }

    const updated = JsonDB.updateProcessedCategory(req.params.id, category as DocumentCategory, user.name, user.role);
    if (!updated) {
      return res.status(404).json({ error: 'Documento processado não encontrado.' });
    }

    res.json(updated);
  });

  // Approve or reject processed document results
  app.post('/api/processed-documents/:id/approve', (req, res) => {
    const { user, approved } = req.body;
    if (!user || (user.role !== UserRole.SECRETARIADO && user.role !== UserRole.ADMIN)) {
      return res.status(403).json({ error: 'Permissão negada. Apenas Secretariado ou Administradores podem aprovar resultados.' });
    }

    const updated = JsonDB.approveProcessedDocument(req.params.id, approved, user.name, user.role);
    if (!updated) {
      return res.status(404).json({ error: 'Documento processado não encontrado.' });
    }

    res.json(updated);
  });

  // Manually reprocess a document
  app.post('/api/processed-documents/:id/reprocess', (req, res) => {
    const { user } = req.body;
    if (!user || (user.role !== UserRole.SECRETARIADO && user.role !== UserRole.ADMIN)) {
      return res.status(403).json({ error: 'Permissão negada. Apenas Secretariado ou Administradores podem reprocessar documentos.' });
    }

    const updated = JsonDB.reprocessDocument(req.params.id, user.name, user.role);
    if (!updated) {
      return res.status(404).json({ error: 'Documento ou processamento associado não encontrado.' });
    }

    res.json(updated);
  });

  // Validate or reject an individual extracted field
  app.post('/api/extracted-fields/:id/validate', (req, res) => {
    const { user, validado } = req.body;
    if (!user || (user.role !== UserRole.SECRETARIADO && user.role !== UserRole.ADMIN)) {
      return res.status(403).json({ error: 'Permissão negada. Apenas Secretariado ou Administradores podem validar campos.' });
    }

    const updated = JsonDB.validateExtractedField(req.params.id, validado, user.name, user.role);
    if (!updated) {
      return res.status(404).json({ error: 'Campo extraído não encontrado.' });
    }

    res.json(updated);
  });

  // Perform multi-criteria indexed search
  app.get('/api/indexed-search', (req, res) => {
    const { query, divisaoId, categoria, tipoDoc, balanceId } = req.query;
    const results = JsonDB.searchIndexed(
      (query as string) || '',
      divisaoId as string,
      categoria as string,
      tipoDoc as string,
      balanceId as string
    );
    res.json(results);
  });

  // Get potential duplicate groups for a balance
  app.get('/api/balances/:id/duplicates', (req, res) => {
    const results = JsonDB.getPotentialDuplicates(req.params.id);
    res.json(results);
  });

  // Resolve potential duplicate group
  app.post('/api/duplicate-groups/:id/resolve', (req, res) => {
    const { user, estado } = req.body;
    if (!user || (user.role !== UserRole.SECRETARIADO && user.role !== UserRole.ADMIN)) {
      return res.status(403).json({ error: 'Apenas Secretariado ou Administradores podem resolver duplicações.' });
    }

    const resolved = JsonDB.resolveDuplicateGroup(req.params.id, estado, user.name, user.role);
    if (!resolved) {
      return res.status(404).json({ error: 'Grupo de duplicação não encontrado.' });
    }

    res.json(resolved);
  });

  // Consolidate balance automatically from contributions
  app.post('/api/balances/:id/consolidate', (req, res) => {
    const { user } = req.body;
    if (!user || (user.role !== UserRole.SECRETARIADO && user.role !== UserRole.ADMIN)) {
      return res.status(403).json({ error: 'Apenas Secretariado ou Administradores podem executar a consolidação automática.' });
    }

    const consolidated = JsonDB.consolidateBalance(req.params.id, user.name, user.role);
    if (!consolidated) {
      return res.status(404).json({ error: 'Balanço operacional não encontrado ou sem dados.' });
    }

    res.json(consolidated);
  });

  // Export balance to official report (markdown representation)
  app.get('/api/balances/:id/export', (req, res) => {
    const balance = JsonDB.getBalanceById(req.params.id);
    if (!balance) {
      return res.status(404).json({ error: 'Balanço operacional não encontrado.' });
    }

    const reportText = `
# BALANÇO OPERACIONAL CONSOLIDADO - SIGO-DFS
## CÓDIGO DO RELATÓRIO: ${balance.numero}
### DATA DE REFERÊNCIA: ${balance.data} | HORA: ${balance.hora}
### EMISSOR: Ministério dos Transportes - ATO & OC
---

## 1. RESUMO EXECUTIVO GERAL
${balance.resumoGeral || 'Pendente de consolidação.'}

---

## 2. DOS - DIVISÃO DE OPERAÇÕES EM PISTA E TERMINAIS
* **Ocorrências de Segurança:** ${balance.dos?.ocorrenciasSeguranca || 'Sem ocorrências.'}
* **Estado de Pistas e Taxiways:** ${balance.dos?.estadoPistaTaxiways || 'Operando regularmente.'}
* **Atividades de Fauna (AVSEC):** ${balance.dos?.atividadesFauna || 'Sem incidentes.'}
* **Equipamentos e Infraestruturas:** ${balance.dos?.statusTerminaisEquipamentos || 'Operando regularmente.'}

---

## 3. DFC - DIVISÃO DE FACILITAÇÃO E FLUXO
* **Controlo de Fronteiras (SME):** ${balance.dfc?.controleFronteiras || 'Regular.'}
* **Reclamações de Bagagens (Sistemas):** ${balance.dfc?.reclamacoesBagagens || 'Sem interrupções.'}
* **Filas e Tempos de Check-In:** ${balance.dfc?.filasCheckIn || 'Regular.'}
* **Tempos de Espera (Segurança):** ${balance.dfc?.tempoEsperaSeguranca || 'Regular.'}

---

## 4. FAL - DIVISÃO DE ACESSIBILIDADE E APOIO MÉDICO
* **Assistência PMR:** ${balance.fal?.acessibilidadePMR || 'Assistência regular.'}
* **Conformidade de Facilitação:** ${balance.fal?.conformidadeNormativa || 'Conformidade ICAO.'}
* **Serviços de Saúde e Apoio Médico:** ${balance.fal?.assistenciaMedica || 'Sem ocorrências.'}
* **Feedback de Passageiros:** ${balance.fal?.feedbackPassageiros || 'Sem queixas adicionais.'}

---

## 5. DRCQ - DIVISÃO DE QUALIDADE E RISCO OPERACIONAL
* **Auditorias e Inspeções Técnicas:** ${balance.drcq?.auditoriasInspecoes || 'Realizadas.'}
* **Não Conformidades Detetadas:** ${balance.drcq?.naoConformidadesDetetadas || 'Sem registos.'}
* **Avaliação de Risco:** ${balance.drcq?.avaliacaoRiscoOperacional || 'Classificação: BAIXO.'}
* **Ações Preventivas Recomendadas:** ${balance.drcq?.acoesPreventivasRecomendadas || 'Manter rotinas vigentes.'}

---
*Relatório emitido eletronicamente pela plataforma SIGO-DFS às ${new Date().toLocaleTimeString()} de ${new Date().toLocaleDateString()}.*
`;

    res.setHeader('Content-Type', 'text/markdown');
    res.setHeader('Content-Disposition', `attachment; filename="Relatorio_Consolidado_${balance.numero}.md"`);
    res.send(reportText);
  });

  // ==========================================
  // --- BUSINESS INTELLIGENCE ENDPOINTS ---
  // ==========================================

  app.get('/api/bi/kpis', (req, res) => {
    try {
      res.json(JsonDB.getKPIs());
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/bi/kpis', (req, res) => {
    try {
      const kpi = req.body;
      const newKpi = JsonDB.addKPI(kpi);
      res.status(201).json(newKpi);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get('/api/bi/configs', (req, res) => {
    try {
      res.json(JsonDB.getDashboardConfigs());
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/bi/configs', (req, res) => {
    try {
      const config = req.body;
      const saved = JsonDB.saveDashboardConfig(config);
      res.json(saved);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get('/api/bi/reports', (req, res) => {
    try {
      res.json(JsonDB.getRelatoriosAnaliticos());
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/bi/reports', (req, res) => {
    try {
      const { tipo, periodo, gerado_por } = req.body;
      const newReport = JsonDB.createRelatorioAnalitico(tipo, periodo, gerado_por);
      res.status(201).json(newReport);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get('/api/bi/statistics', (req, res) => {
    try {
      res.json(JsonDB.getEstatisticas());
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ==========================================
  // --- AI COPILOT ENDPOINTS ---
  // ==========================================

  app.get('/api/copilot/chats/:userId', (req, res) => {
    try {
      res.json(JsonDB.getConversasIA(req.params.userId));
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get('/api/copilot/chats/:conversaId/messages', (req, res) => {
    try {
      res.json(JsonDB.getMensagensIA(req.params.conversaId));
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/copilot/chats', (req, res) => {
    try {
      const { utilizador_id, modelo_utilizado } = req.body;
      const newChat = JsonDB.createConversaIA(utilizador_id, modelo_utilizado || 'gemini-3.5-flash');
      res.status(201).json(newChat);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete('/api/copilot/chats/:conversaId', (req, res) => {
    try {
      JsonDB.clearConversaIA(req.params.conversaId);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get('/api/copilot/config', (req, res) => {
    try {
      res.json(JsonDB.getConfiguracaoIA());
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.put('/api/copilot/config', (req, res) => {
    try {
      const saved = JsonDB.updateConfiguracaoIA(req.body);
      res.json(saved);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get('/api/copilot/suggestions', (req, res) => {
    try {
      res.json(JsonDB.getSugestoesIA());
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/copilot/chats/:conversaId/messages', async (req, res) => {
    try {
      const { conversaId } = req.params;
      const { conteudo, userRole, userDivision, username } = req.body;

      if (!conteudo) {
        return res.status(400).json({ error: 'Conteúdo da mensagem é obrigatório.' });
      }

      // 1. Guardar mensagem do utilizador
      const userMsg = JsonDB.createMensagemIA(conversaId, 'utilizador', conteudo);

      // 2. Reunir contexto do SIGO-DFS para o Gemini
      const activeBalances = JsonDB.getBalances();
      const activeActionPlans = JsonDB.getActionPlans();
      const activeKpis = JsonDB.getKPIs();
      const activeEstatisticas = JsonDB.getEstatisticas();
      const activeSugestoes = JsonDB.getSugestoesIA();

      // Aplicar regras de permissão corporativa DFS: Chefe de Divisão só vê dados da sua própria divisão
      let filteredActionPlans = activeActionPlans;
      let filteredKpis = activeKpis;
      let filteredEstatisticas = activeEstatisticas;

      const isChefeDivisao = userRole === 'Chefe de Divisão' || userRole === 'CHEFE_DIVISAO';
      if (isChefeDivisao && userDivision && userDivision !== 'DFS') {
        filteredActionPlans = activeActionPlans.filter(ap => ap.divisaoId === userDivision);
        filteredKpis = activeKpis.filter(k => k.categoria === userDivision || (userDivision === 'DOS' && k.categoria === 'Operações AVSEC') || (userDivision === 'DFC' && k.categoria === 'Facilitação') || (userDivision === 'FAL' && k.categoria === 'Acessibilidade') || (userDivision === 'DRCQ' && k.categoria === 'Qualidade'));
        filteredEstatisticas = activeEstatisticas.filter(e => e.categoria === userDivision);
      }

      // 3. Obter configuração ativa do Copilot
      const configIA = JsonDB.getConfiguracaoIA();

      // 4. Formular as instruções do sistema e o histórico
      const previousMessages = JsonDB.getMensagensIA(conversaId);
      // Filter out the very last user message since we pass it as the active prompt
      const historyMsg = previousMessages.filter(m => m.id !== userMsg.id).slice(-10); // last 10 messages for context

      // Formatar dados estruturados como JSON string simplificado para reduzir tokens
      const contextData = {
        meta: {
          app: "SIGO-DFS (DFS Insight Hub - ATO & OC Angola)",
          utilizador: {
            nome: username || "Utilizador",
            funcao: userRole || "Colaborador",
            divisao: userDivision || "DFS"
          }
        },
        balancosOperacionais: activeBalances.slice(-3).map(b => ({
          numero: b.numero,
          data: b.data,
          estado: b.estado,
          resumo: b.resumoGeral || "Sem resumo."
        })),
        planosDeAcao: filteredActionPlans.slice(-5).map(ap => ({
          id: ap.id,
          descricao: ap.descricao,
          divisao: ap.divisaoId,
          prioridade: ap.prioridade,
          estado: ap.estado,
          responsavel: ap.responsavel
        })),
        indicadoresDesempenho: filteredKpis.slice(0, 15),
        sugestoesMelhoriaIA: activeSugestoes
      };

      const systemInstruction = `
Você é o "DFS Copilot", o assistente corporativo inteligente e agente de IA do SIGO-DFS (Direção de Facilitação e Segurança dos Aeroportos e Terminais de Angola - ATO & OC).
Seu objetivo é auxiliar a Direção, os Chefes de Divisão e o Secretariado a analisar dados, balanços, planos de ação e emitir relatórios ou recomendações operacionais e estratégicas.

Diretrizes importantes:
1. Responda de forma profissional, objetiva, segura e em Português de Angola.
2. Seja humilde, prestativo e institucional. Não invente dados falsos nem cite informações externas confidenciais que não façam sentido no ecossistema do aeroporto.
3. Respeite as restrições de divisão: O utilizador atual pertence à divisão "${userDivision || 'DFS'}" com cargo "${userRole || 'Colaborador'}".
4. Apoie-se estritamente nos dados reais abaixo fornecidos para responder às perguntas:
   ${JSON.stringify(contextData, null, 2)}

Se o utilizador pedir para gerar um relatório ou plano de ação, estruture a resposta usando Markdown profissional bem formatado com tabelas ou listas.
`;

      // 5. Chamar a API do Gemini
      let assistantText = '';
      try {
        const ai = getGeminiClient();
        const chatContents: any[] = [];

        // Build history in the correct parts structure
        historyMsg.forEach(m => {
          chatContents.push({
            role: m.tipo === 'utilizador' ? 'user' : 'model',
            parts: [{ text: m.conteudo }]
          });
        });

        // Add user message to contents
        chatContents.push({
          role: 'user',
          parts: [{ text: conteudo }]
        });

        const response = await ai.models.generateContent({
          model: configIA.modelo || "gemini-3.5-flash",
          contents: chatContents,
          config: {
            systemInstruction: systemInstruction,
            temperature: configIA.temperatura || 0.2,
            maxOutputTokens: configIA.limite_tokens || 2048
          }
        });

        assistantText = response.text || 'Lamento, mas ocorreu um erro ao processar a resposta.';
      } catch (aiError: any) {
        console.error('Gemini API execution failed:', aiError);
        assistantText = `Lamento, mas o serviço de IA do Gemini está temporariamente indisponível. Detalhes: ${aiError.message || aiError}. Por favor, verifique se a chave de API nos Segredos está configurada corretamente.`;
      }

      // 6. Guardar mensagem do assistente
      const assistantMsg = JsonDB.createMensagemIA(conversaId, 'assistente', assistantText);

      // Return both messages
      res.json({
        userMessage: userMsg,
        assistantMessage: assistantMsg
      });

    } catch (error: any) {
      console.error('Error in Copilot message post:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Serve static files in uploads folder structured by Year/Month/Division (Etapa 7)
  app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));

  // --- VITE MIDDLEWARE SETUP ---

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[SIGO-DFS Server] Rodando na porta http://localhost:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Falha ao iniciar o servidor SIGO-DFS:', err);
});
