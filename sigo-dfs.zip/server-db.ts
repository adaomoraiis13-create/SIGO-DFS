import fs from 'fs';
import path from 'path';
import pg from 'pg';
import { 
  User, 
  UserRole, 
  DivisionId, 
  OperationalBalance, 
  BalanceStatus, 
  Documento, 
  DocType, 
  ActionPlanItem, 
  ActionPlanStatus, 
  ActionPlanPriority,
  ActionPlanHistory,
  ActionPlanComment,
  ActionPlanEvidence,
  WorkflowLog, 
  Notification, 
  AuditLog,
  DivisionContributionStatus,
  DivisionContribution,
  ProcessStatus,
  DocumentCategory,
  DocumentoProcessado,
  Slide,
  CampoExtraido,
  CategoriaDocumento,
  PesquisaIndexada,
  DuplicateEventGroup,
  DuplicateEventItem,
  KPI,
  DashboardConfig,
  RelatorioAnalitico,
  Estatistica,
  ConversaIA,
  MensagemIA,
  ConfiguracaoIA,
  SugestaoIA
} from './src/types.js';

const DATA_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'sigo-dfs.json');

export interface SystemSettings {
  allowedDomain: string;
  idleTimeoutMinutes: number;
  powerpointTemplateName: string;
  pdfTemplateName: string;
  registrationPolicy?: 'ONLY_INSTITUTIONAL' | 'ANY_VALID_EMAIL';
}

// Interface representation for our JSON file database
export interface DatabaseSchema {
  users: (User & { passwordHash: string; failures?: number; lockedUntil?: string })[];
  balances: OperationalBalance[];
  documents: Documento[];
  actionPlans: ActionPlanItem[];
  workflowLogs: WorkflowLog[];
  notifications: Notification[];
  auditLogs: AuditLog[];
  processedDocuments: DocumentoProcessado[];
  slides: Slide[];
  extractedFields: CampoExtraido[];
  documentCategories: CategoriaDocumento[];
  indexedSearches: PesquisaIndexada[];
  duplicateGroups: DuplicateEventGroup[];
  settings?: SystemSettings;
  kpis: KPI[];
  dashboardConfigs: DashboardConfig[];
  relatoriosAnaliticos: RelatorioAnalitico[];
  estatisticas: Estatistica[];
  conversasIA: ConversaIA[];
  mensagensIA: MensagemIA[];
  configuracoesIA: ConfiguracaoIA[];
  sugestoesIA: SugestaoIA[];
}

// Ensure the directory exists
function ensureDataDir() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

// Initial Seed Data
const seedData: DatabaseSchema = {
  users: [
    {
      id: 'usr-1',
      username: 'admin',
      name: 'Super Administrador',
      role: UserRole.ADMIN,
      divisionId: DivisionId.DFS,
      email: 'admin@ato-oc.co.ao',
      passwordHash: 'admin123' // Plaintext for mock/demo ease
    },
    {
      id: 'usr-2',
      username: 'diretor',
      name: 'Dr. Valdemar Neto',
      role: UserRole.DIRETOR,
      divisionId: DivisionId.DFS,
      email: 'valdemar.neto@ato-oc.co.ao',
      passwordHash: 'diretor123'
    },
    {
      id: 'usr-3',
      username: 'secretaria',
      name: 'Maria Antónia Santos',
      role: UserRole.SECRETARIADO,
      divisionId: DivisionId.DFS,
      email: 'm.santos.dfs@ato-oc.co.ao',
      passwordHash: 'secretaria123'
    },
    {
      id: 'usr-4',
      username: 'chefe.dos',
      name: 'Eng. António Bunga',
      role: UserRole.CHEFE_DIVISAO,
      divisionId: DivisionId.DOS,
      email: 'antonio.bunga.dos@ato-oc.co.ao',
      passwordHash: 'dos123'
    },
    {
      id: 'usr-5',
      username: 'chefe.dfc',
      name: 'Dra. Isabel Cassule',
      role: UserRole.CHEFE_DIVISAO,
      divisionId: DivisionId.DFC,
      email: 'isabel.cassule.dfc@ato-oc.co.ao',
      passwordHash: 'dfc123'
    },
    {
      id: 'usr-6',
      username: 'chefe.fal',
      name: 'Dr. Manuel Mendes',
      role: UserRole.CHEFE_DIVISAO,
      divisionId: DivisionId.FAL,
      email: 'manuel.mendes.fal@ato-oc.co.ao',
      passwordHash: 'fal123'
    },
    {
      id: 'usr-7',
      username: 'chefe.drcq',
      name: 'Eng. Sofia Martins',
      role: UserRole.CHEFE_DIVISAO,
      divisionId: DivisionId.DRCQ,
      email: 'sofia.martins.drcq@ato-oc.co.ao',
      passwordHash: 'drcq123'
    }
  ],
  balances: [
    {
      id: 'bal-1',
      numero: 'BAL-2026-0001',
      data: '2026-07-13',
      hora: '08:00',
      criadoPor: 'Maria Antónia Santos',
      estado: BalanceStatus.APROVADO,
      observacoes: 'Balanço consolidado inicial das últimas 24 horas.',
      resumoGeral: 'Operações aeroportuárias decorreram com normalidade nas últimas 24 horas. Verificou-se uma ligeira avaria no tapete de bagagens nº 3 que foi resolvida em 45 minutos. Nenhuma ocorrência grave de segurança ou facilitação registada.',
      dos: {
        ocorrenciasSeguranca: 'Nenhuma invasão ou incidente de segurança na vedação perimetral registado. Rondas preventivas efetuadas com sucesso.',
        estadoPistaTaxiways: 'Pista principal e caminhos de circulação operacionais. Sem detritos (FOD) detetados.',
        atividadesFauna: 'Registados 3 avistamentos de aves perto da cabeceira 23, dispersados com sucesso pela equipa de controlo de fauna com sinalizadores acústicos.',
        statusTerminaisEquipamentos: 'Terminais de passageiros 1 e 2 operando regularmente. Gerador de emergência testado e operacional.',
        incidentesRelatados: 'Sem incidentes adicionais.'
      },
      dfc: {
        controleFronteiras: 'Processamento migratório fluido no terminal de chegadas internacionais. Tempo médio de espera no controlo de passaportes: 18 minutos.',
        reclamacoesBagagens: 'Avaria mecânica pontual no tapete de bagagens 3 (Voo DT-652). Tempo de inatividade: 45 minutos. Bagagens entregues manualmente com assistência.',
        filasCheckIn: 'Check-in dos voos internacionais com picos normais de tráfego entre as 12:00 e as 14:00.',
        tempoEsperaSeguranca: 'Tempo médio de passagem no raio-x de segurança pré-embarque: 4 minutos.',
        incidentesFacilitacao: 'Nenhum incidente crítico.'
      },
      fal: {
        acessibilidadePMR: 'Assistência prestada a 14 passageiros com mobilidade reduzida (PMR), todos os serviços executados em conformidade com os SLAs estabelecidos.',
        conformidadeNormativa: 'Processos de facilitação em linha com o Anexo 9 da ICAO.',
        assistenciaMedica: 'Registadas 2 assistências médicas menores no terminal de partidas por indisposição pontual. Pacientes medicados e autorizados a viajar.',
        feedbackPassageiros: '3 elogios registados sobre a celeridade no atendimento da zona de transferências.'
      },
      drcq: {
        auditoriasInspecoes: 'Realizada auditoria diária de conformidade de segurança e facilitação nas áreas restritas. Nível de conformidade aferido: 96%.',
        naoConformidadesDetetadas: 'Identificada falta de sinalização de segurança provisória na porta de embarque 5 devido a pequenas obras.',
        avaliacaoRiscoOperacional: 'Risco operacional classificado como BAIXO.',
        acoesPreventivasRecomendadas: 'Reforçar junto da equipa de manutenção a obrigatoriedade de colocação de cones e fitas delimitadoras.'
      },
      dataCriacao: '2026-07-13T16:00:00Z',
      dataAtualizacao: '2026-07-13T18:30:00Z',
      revisadoPor: 'Maria Antónia Santos',
      aprovadoPor: 'Dr. Valdemar Neto',
      comentariosRevisao: 'Balanço consolidado aprovado sem retificações.'
    },
    {
      id: 'bal-2',
      numero: 'BAL-2026-0002',
      data: '2026-07-14',
      hora: '08:00',
      criadoPor: 'Maria Antónia Santos',
      estado: BalanceStatus.EM_REVISAO,
      observacoes: 'Balanço com pendências tecnológicas de rede SITA.',
      resumoGeral: 'Dia caracterizado por tráfego aéreo intenso. Houve um incidente de ave (bird strike) sem danos na aeronave do voo TA-201. Ocorrência de atraso no check-in devido a falha temporária de conectividade do sistema SITA.',
      dos: {
        ocorrenciasSeguranca: 'Rondas perimetrais e controlo de acessos efetuados. Sem falhas de segurança.',
        estadoPistaTaxiways: 'Inspeção de pista às 08:30 e às 15:00. Pista limpa e sem anomalias no pavimento.',
        atividadesFauna: 'Incidente de Bird Strike registado às 11:42 com aeronave Boeing 737-800. Inspeção imediata de pista revelou vestígios de ave, sem danos aparentes na aeronave que prosseguiu voo após vistoria técnica.',
        statusTerminaisEquipamentos: 'Sistemas elétricos estáveis. Elevador panorâmico do terminal 1 temporariamente indisponível para manutenção corretiva.',
        incidentesRelatados: 'Registado bird strike.'
      },
      dfc: {
        controleFronteiras: 'Serviço de migração com elevado fluxo de passageiros no período vespertino. Tempo de espera estendido para 32 minutos entre as 16:00 e as 17:30.',
        reclamacoesBagagens: '12 reclamações por atraso na entrega de bagagens provenientes do voo TP-289. Bagagens localizadas e encaminhadas.',
        filasCheckIn: 'Falha temporária de rede do sistema de check-in SITA das 09:10 às 09:45. Gerou filas significativas de passageiros. Atendimento processado em modo alternativo até ao restabelecimento do serviço.',
        tempoEsperaSeguranca: 'Tempo médio de espera no raio-x de segurança: 12 minutos durante a falha do sistema SITA.',
        incidentesFacilitacao: 'Filas no check-in devido a falha técnica de conectividade.'
      },
      fal: {
        acessibilidadePMR: 'Assistência a 19 PMR. Solicitada cadeira de rodas extra para suporte na zona de chegadas devido a pico de procura.',
        conformidadeNormativa: 'Níveis aceitáveis de facilitação aeroportuária.',
        assistenciaMedica: 'Uma assistência médica urgente por síncope de passageiro sénior na zona de recolha de bagagens. Encaminhado para a clínica aeroportuária para observação.',
        feedbackPassageiros: 'Reclamações registadas sobre o tempo de espera no check-in durante o período da falha de rede.'
      },
      drcq: {
        auditoriasInspecoes: 'Acompanhamento da falha do sistema de check-in. Analisados os planos de contingência aplicados pelas companhias aéreas afetadas.',
        naoConformidadesDetetadas: 'Tempo de ativação do procedimento alternativo de check-in excedeu os 15 minutos recomendados por algumas operadoras.',
        avaliacaoRiscoOperacional: 'Risco operacional classificado como MÉDIO devido ao pico de tráfego e falhas tecnológicas combinadas.',
        acoesPreventivasRecomendadas: 'Agendar reunião com a operadora de telecomunicações para auditar a redundância das linhas SITA.'
      },
      dataCriacao: '2026-07-14T17:15:00Z',
      dataAtualizacao: '2026-07-14T17:40:00Z'
    },
    {
      id: 'bal-3',
      numero: 'BAL-2026-0003',
      data: '2026-07-15',
      hora: '08:00',
      criadoPor: 'Maria Antónia Santos',
      estado: BalanceStatus.EM_ELABORACAO,
      observacoes: 'Balanço em preenchimento pelas áreas técnicas.',
      resumoGeral: 'Dados em recolha para o balanço operacional do dia corrente. Os relatórios parciais das divisões estão a ser submetidos pelas respetivas equipas técnicas.',
      dos: {
        ocorrenciasSeguranca: 'Rondas normais de segurança perimetral. Atividades de fiscalização nos parques de estacionamento e áreas restritas a decorrer sem anomalias.',
        estadoPistaTaxiways: 'Inspeção matinal realizada às 06:15. Pista limpa, marcações luminosas e luzes de aproximação (ALS) 100% operacionais.',
        atividadesFauna: 'Registada baixa atividade de avifauna nas proximidades do aeródromo durante a manhã.',
        statusTerminaisEquipamentos: 'Sistemas de climatização do Terminal de Embarque em monitorização devido a queixas sobre a temperatura elevada.',
        incidentesRelatados: 'Tudo operacional.'
      },
      dfc: {
        controleFronteiras: 'Tráfego regular nas primeiras horas do dia. Fronteira fluida.',
        reclamacoesBagagens: 'Nenhuma reclamação registada até ao momento.',
        filasCheckIn: 'Fluxo estável de passageiros nas ilhas de check-in.',
        tempoEsperaSeguranca: 'Tempo médio de espera no raio-x de segurança: 3 minutos.',
        incidentesFacilitacao: 'Sem anomalias.'
      },
      fal: {
        acessibilidadePMR: 'Assistência prestada a 4 passageiros PMR com sucesso.',
        conformidadeNormativa: 'Processos de facilitação decorrendo conforme planeado.',
        assistenciaMedica: 'Sem ocorrências médicas registadas.',
        feedbackPassageiros: 'Excelente feedback sobre a limpeza e organização do terminal.'
      },
      drcq: {
        auditoriasInspecoes: 'Inspeção programada de rampas e posições de estacionamento de aeronaves em curso.',
        naoConformidadesDetetadas: 'Nenhuma não-conformidade grave registada nas rondas matinais.',
        avaliacaoRiscoOperacional: 'Risco operacional classificado preliminarmente como BAIXO.',
        acoesPreventivasRecomendadas: 'Manter a vigilância sobre as temperaturas do terminal para evitar desconforto térmico.'
      },
      dataCriacao: '2026-07-15T08:00:00Z',
      dataAtualizacao: '2026-07-15T09:15:00Z'
    }
  ],
  documents: [
    {
      id: 'doc-1',
      nome: 'Balanço_Diario_DOS_13072026.pptx',
      tipo: DocType.PPTX,
      divisaoId: DivisionId.DOS,
      dataCarregamento: '2026-07-13T10:15:00Z',
      carregadoPor: 'Eng. António Bunga',
      tamanho: '4.2 MB',
      url: '/uploads/Balanço_Diario_DOS_13072026.pptx',
      balanceId: 'bal-1',
      versao: 1,
      isCurrent: true,
      parentDocId: 'doc-1'
    },
    {
      id: 'doc-2',
      nome: 'Ocorrencias_DFC_13072026.pptx',
      tipo: DocType.PPTX,
      divisaoId: DivisionId.DFC,
      dataCarregamento: '2026-07-13T11:30:00Z',
      carregadoPor: 'Dra. Isabel Cassule',
      tamanho: '3.1 MB',
      url: '/uploads/Ocorrencias_DFC_13072026.pptx',
      balanceId: 'bal-1',
      versao: 1,
      isCurrent: true,
      parentDocId: 'doc-2'
    },
    {
      id: 'doc-3',
      nome: 'SLA_PMR_FAL_13072026.pptx',
      tipo: DocType.PPTX,
      divisaoId: DivisionId.FAL,
      dataCarregamento: '2026-07-13T12:05:00Z',
      carregadoPor: 'Dr. Manuel Mendes',
      tamanho: '2.8 MB',
      url: '/uploads/SLA_PMR_FAL_13072026.pptx',
      balanceId: 'bal-1',
      versao: 1,
      isCurrent: true,
      parentDocId: 'doc-3'
    },
    {
      id: 'doc-4',
      nome: 'Relatorio_Auditoria_DRCQ_13072026.pptx',
      tipo: DocType.PPTX,
      divisaoId: DivisionId.DRCQ,
      dataCarregamento: '2026-07-13T14:50:00Z',
      carregadoPor: 'Eng. Sofia Martins',
      tamanho: '3.6 MB',
      url: '/uploads/Relatorio_Auditoria_DRCQ_13072026.pptx',
      balanceId: 'bal-1',
      versao: 1,
      isCurrent: true,
      parentDocId: 'doc-4'
    },
    {
      id: 'doc-5',
      nome: 'Modelo_Balanço_Oficial_DFS.pptx',
      tipo: DocType.PPTX,
      divisaoId: DivisionId.DFS,
      dataCarregamento: '2026-07-01T09:00:00Z',
      carregadoPor: 'Super Administrador',
      tamanho: '12.5 MB',
      url: '/uploads/Modelo_Balanço_Oficial_DFS.pptx',
      versao: 1,
      isCurrent: true,
      parentDocId: 'doc-5'
    },
    {
      id: 'doc-6',
      nome: 'Balanço_Operacional_Consolidado_13072026.pdf',
      tipo: DocType.PDF,
      divisaoId: DivisionId.DFS,
      dataCarregamento: '2026-07-13T18:35:00Z',
      carregadoPor: 'Maria Antónia Santos',
      tamanho: '1.8 MB',
      url: '/uploads/Balanço_Operacional_Consolidado_13072026.pdf',
      balanceId: 'bal-1',
      versao: 1,
      isCurrent: true,
      parentDocId: 'doc-6'
    },
    {
      id: 'doc-7',
      nome: 'Balanço_Diario_DOS_14072026.pptx',
      tipo: DocType.PPTX,
      divisaoId: DivisionId.DOS,
      dataCarregamento: '2026-07-14T09:45:00Z',
      carregadoPor: 'Eng. António Bunga',
      tamanho: '4.8 MB',
      url: '/uploads/Balanço_Diario_DOS_14072026.pptx',
      balanceId: 'bal-2',
      versao: 1,
      isCurrent: true,
      parentDocId: 'doc-7'
    },
    {
      id: 'doc-8',
      nome: 'Relatorio_Incidentes_DFC_14072026.pptx',
      tipo: DocType.PPTX,
      divisaoId: DivisionId.DFC,
      dataCarregamento: '2026-07-14T11:15:00Z',
      carregadoPor: 'Dra. Isabel Cassule',
      tamanho: '3.5 MB',
      url: '/uploads/Relatorio_Incidentes_DFC_14072026.pptx',
      balanceId: 'bal-2',
      versao: 1,
      isCurrent: true,
      parentDocId: 'doc-8'
    }
  ],
  actionPlans: [
    {
      id: 'act-1',
      titulo: 'Substituição das placas de sinalização da porta de embarque 5',
      descricao: 'Adquirir e instalar sinalização de segurança provisória e definitiva na porta de embarque 5 devido às reparações de infraestrutura decorrentes.',
      divisaoId: DivisionId.DOS,
      responsavel: 'Eng. António Bunga',
      dataLimite: '2026-07-20',
      estado: ActionPlanStatus.EM_CURSO,
      balanceId: 'bal-1',
      notasExecucao: 'Equipa de infraestruturas notificada. Sinalização provisória já encomendada com previsão de entrega em 2 dias.'
    },
    {
      id: 'act-2',
      titulo: 'Reunião de alinhamento com operadora SITA sobre redundância',
      descricao: 'Agendar e coordenar reunião técnica com a operadora SITA para analisar as causas da falha de rede do check-in e estabelecer planos de contingência robustos.',
      divisaoId: DivisionId.DFC,
      responsavel: 'Dra. Isabel Cassule',
      dataLimite: '2026-07-17',
      estado: ActionPlanStatus.PENDENTE,
      balanceId: 'bal-2'
    },
    {
      id: 'act-3',
      titulo: 'Aquisição de 5 cadeiras de rodas adicionais para tráfego PMR',
      descricao: 'Instaurar processo de aquisição urgente de novas cadeiras de rodas para responder a picos operacionais e garantir conformidade com o serviço de facilitação.',
      divisaoId: DivisionId.FAL,
      responsavel: 'Dr. Manuel Mendes',
      dataLimite: '2026-07-15',
      estado: ActionPlanStatus.CONCLUIDO,
      dataConclusao: '2026-07-14',
      balanceId: 'bal-2',
      notasExecucao: 'Cadeiras adquiridas e distribuídas pelas posições críticas do terminal 1.'
    },
    {
      id: 'act-4',
      titulo: 'Auditoria ao plano de contingência das companhias aéreas',
      descricao: 'Realizar auditoria focada no tempo de resposta das companhias aéreas ao ativarem o check-in manual na sequência da falha do sistema SITA.',
      divisaoId: DivisionId.DRCQ,
      responsavel: 'Eng. Sofia Martins',
      dataLimite: '2026-07-25',
      estado: ActionPlanStatus.EM_CURSO,
      balanceId: 'bal-2'
    }
  ],
  workflowLogs: [
    {
      id: 'wfl-1',
      balanceId: 'bal-1',
      data: '2026-07-13T15:00:00Z',
      utilizador: 'Maria Antónia Santos',
      deEstado: BalanceStatus.EM_ELABORACAO,
      paraEstado: BalanceStatus.EM_REVISAO,
      comentario: 'Balanço consolidado com base nos relatórios de todas as divisões operacionais.'
    },
    {
      id: 'wfl-2',
      balanceId: 'bal-1',
      data: '2026-07-13T18:30:00Z',
      utilizador: 'Dr. Valdemar Neto',
      deEstado: BalanceStatus.EM_REVISAO,
      paraEstado: BalanceStatus.APROVADO,
      comentario: 'Balanço aprovado para publicação interna e arquivo operacional DFS.'
    },
    {
      id: 'wfl-3',
      balanceId: 'bal-2',
      data: '2026-07-14T17:40:00Z',
      utilizador: 'Maria Antónia Santos',
      deEstado: BalanceStatus.EM_ELABORACAO,
      paraEstado: BalanceStatus.EM_REVISAO,
      comentario: 'Consolidado com as notas do incidente de fauna e a quebra temporária do sistema de check-in.'
    }
  ],
  notifications: [
    {
      id: 'not-1',
      utilizadorId: 'usr-3', // Secretaria
      titulo: 'Relatório DOS recebido',
      mensagem: 'O Eng. António Bunga submeteu o relatório operacional da divisão DOS.',
      lida: true,
      dataCriacao: '2026-07-14T09:46:00Z',
      link: '/documentos'
    },
    {
      id: 'not-2',
      utilizadorId: 'usr-3', // Secretaria
      titulo: 'Relatório DFC recebido',
      mensagem: 'A Dra. Isabel Cassule submeteu o relatório operacional da divisão DFC.',
      lida: false,
      dataCriacao: '2026-07-14T11:16:00Z',
      link: '/documentos'
    },
    {
      id: 'not-3',
      role: UserRole.DIRETOR,
      titulo: 'Balanço Pendente de Aprovação',
      mensagem: 'O Balanço Operacional de 2026-07-14 foi submetido pelo Secretariado e aguarda a sua revisão e aprovação.',
      lida: false,
      dataCriacao: '2026-07-14T17:41:00Z',
      link: '/balancos/bal-2'
    },
    {
      id: 'not-4',
      divisaoId: DivisionId.DOS,
      titulo: 'Plano de Ação Criado',
      mensagem: 'Foi registada uma nova ação corretiva ("Substituição das placas de sinalização...") sob a responsabilidade da divisão DOS.',
      lida: false,
      dataCriacao: '2026-07-13T18:32:00Z',
      link: '/plano-acao'
    }
  ],
  auditLogs: [
    {
      id: 'aud-1',
      utilizador: 'Super Administrador',
      perfil: 'Administrador',
      acao: 'Criação de Utilizadores',
      detalhe: 'Semente de base de dados carregada com perfis regulamentares.',
      data: '2026-07-15T05:00:00Z'
    },
    {
      id: 'aud-2',
      utilizador: 'Maria Antónia Santos',
      perfil: 'Secretariado',
      acao: 'Consolidação de Balanço',
      detalhe: 'Criado rascunho de balanço para a data 2026-07-13.',
      data: '2026-07-13T10:00:00Z'
    },
    {
      id: 'aud-3',
      utilizador: 'Dr. Valdemar Neto',
      perfil: 'Diretor',
      acao: 'Aprovação de Balanço',
      detalhe: 'Aprovado o balanço consolidado de 2026-07-13.',
      data: '2026-07-13T18:30:00Z'
    },
    {
      id: 'aud-4',
      utilizador: 'Maria Antónia Santos',
      perfil: 'Secretariado',
      acao: 'Submissão de Balanço',
      detalhe: 'Submetido o balanço consolidado de 2026-07-14 para aprovação do Diretor.',
      data: '2026-07-14T17:40:00Z'
    }
  ],
  processedDocuments: [],
  slides: [],
  extractedFields: [],
  documentCategories: [
    { id: 'cat-1', nome: DocumentCategory.OPERACOES, descricao: 'Relatórios operacionais de pista, terminais e fluxos' },
    { id: 'cat-2', nome: DocumentCategory.SEGURANCA, descricao: 'Incidentes, rondas, segurança cibernética e física (AVSEC)' },
    { id: 'cat-3', nome: DocumentCategory.FACILITACAO, descricao: 'Serviços ao passageiro, bagagens, PMR e tempos de fila' },
    { id: 'cat-4', nome: DocumentCategory.RECURSOS_HUMANOS, descricao: 'Pessoal, escalas, turnos e contratações' },
    { id: 'cat-5', nome: DocumentCategory.RECURSOS_MATERIAIS, descricao: 'Equipamentos, infraestrutura e frotas' },
    { id: 'cat-6', nome: DocumentCategory.CREDENCIAMENTO, descricao: 'Passes, autorizações de acesso e cartões de identificação' },
    { id: 'cat-7', nome: DocumentCategory.FORMACAO, descricao: 'Treino, reciclagens, cursos e certificações profissionais' },
    { id: 'cat-8', nome: DocumentCategory.PLANO_DE_ACAO, descricao: 'Planos corretivos, auditorias e relatórios de acompanhamento' },
    { id: 'cat-9', nome: DocumentCategory.INDICADORES, descricao: 'Estatísticas de tráfego, KPIs e metas de desempenho' },
    { id: 'cat-10', nome: DocumentCategory.CORRESPONDENCIA, descricao: 'Ofícios, memorandos e comunicações institucionais' },
    { id: 'cat-11', nome: DocumentCategory.OUTROS, descricao: 'Documentos diversos não classificados automaticamente' }
  ],
  indexedSearches: [],
  duplicateGroups: [],
  kpis: [
    // Recursos Humanos
    { id: 'kpi-1', nome: 'Efetivo disponível', categoria: 'Recursos Humanos', valor: 142, unidade: 'pessoal', data: '2026-07-15T08:00:00Z' },
    { id: 'kpi-2', nome: 'Efetivo em serviço', categoria: 'Recursos Humanos', valor: 128, unidade: 'pessoal', data: '2026-07-15T08:00:00Z' },
    { id: 'kpi-3', nome: 'Ausências', categoria: 'Recursos Humanos', valor: 14, unidade: 'pessoal', data: '2026-07-15T08:00:00Z' },
    { id: 'kpi-4', nome: 'Formação realizada', categoria: 'Recursos Humanos', valor: 8, unidade: 'ações', data: '2026-07-15T08:00:00Z' },
    // Recursos Materiais
    { id: 'kpi-5', nome: 'Equipamentos operacionais', categoria: 'Recursos Materiais', valor: 34, unidade: 'unidades', data: '2026-07-15T08:00:00Z' },
    { id: 'kpi-6', nome: 'Equipamentos avariados', categoria: 'Recursos Materiais', valor: 3, unidade: 'unidades', data: '2026-07-15T08:00:00Z' },
    { id: 'kpi-7', nome: 'Equipamentos em manutenção', categoria: 'Recursos Materiais', valor: 2, unidade: 'unidades', data: '2026-07-15T08:00:00Z' },
    // Operações AVSEC
    { id: 'kpi-8', nome: 'Inspeções realizadas', categoria: 'Operações AVSEC', valor: 42, unidade: 'inspeções', data: '2026-07-15T08:00:00Z' },
    { id: 'kpi-9', nome: 'Artigos proibidos apreendidos', categoria: 'Operações AVSEC', valor: 18, unidade: 'artigos', data: '2026-07-15T08:00:00Z' },
    { id: 'kpi-10', nome: 'Alarmes resolvidos', categoria: 'Operações AVSEC', valor: 125, unidade: 'alarmes', data: '2026-07-15T08:00:00Z' },
    { id: 'kpi-11', nome: 'Incidentes AVSEC', categoria: 'Operações AVSEC', valor: 1, unidade: 'incidentes', data: '2026-07-15T08:00:00Z' },
    { id: 'kpi-12', nome: 'Não conformidades', categoria: 'Operações AVSEC', valor: 0, unidade: 'falhas', data: '2026-07-15T08:00:00Z' },
    // Facilitação
    { id: 'kpi-13', nome: 'Missões realizadas', categoria: 'Facilitação', valor: 6, unidade: 'missões', data: '2026-07-15T08:00:00Z' },
    { id: 'kpi-14', nome: 'Passageiros assistidos', categoria: 'Facilitação', valor: 2450, unidade: 'pax', data: '2026-07-15T08:00:00Z' },
    { id: 'kpi-15', nome: 'Processos concluídos', categoria: 'Facilitação', valor: 15, unidade: 'processos', data: '2026-07-15T08:00:00Z' },
    { id: 'kpi-16', nome: 'Reclamações', categoria: 'Facilitação', valor: 2, unidade: 'queixas', data: '2026-07-15T08:00:00Z' },
    // Credenciamento
    { id: 'kpi-17', nome: 'Credenciais emitidas', categoria: 'Credenciamento', valor: 312, unidade: 'credenciais', data: '2026-07-15T08:00:00Z' },
    { id: 'kpi-18', nome: 'Credenciais renovadas', categoria: 'Credenciamento', valor: 184, unidade: 'credenciais', data: '2026-07-15T08:00:00Z' },
    { id: 'kpi-19', nome: 'Credenciais expiradas', categoria: 'Credenciamento', valor: 45, unidade: 'credenciais', data: '2026-07-15T08:00:00Z' },
    { id: 'kpi-20', nome: 'Pedidos pendentes', categoria: 'Credenciamento', valor: 28, unidade: 'pedidos', data: '2026-07-15T08:00:00Z' },
  ],
  dashboardConfigs: [],
  relatoriosAnaliticos: [
    { id: 'rep-1', tipo: 'Diário', periodo: '15/07/2026', gerado_por: 'Maria Antónia Santos', data: '2026-07-15T18:00:00Z' },
    { id: 'rep-2', tipo: 'Semanal', periodo: 'Semana 28 (2026)', gerado_por: 'Maria Antónia Santos', data: '2026-07-14T10:00:00Z' },
    { id: 'rep-3', tipo: 'Mensal', periodo: 'Junho 2026', gerado_por: 'Dr. Valdemar Neto', data: '2026-07-01T09:00:00Z' }
  ],
  estatisticas: [
    // DOS
    { id: 'est-1', categoria: 'DOS', indicador: 'Relatórios enviados', valor: 14, data: '2026-07-15T00:00:00Z' },
    { id: 'est-2', categoria: 'DOS', indicador: 'Pontualidade', valor: 95, data: '2026-07-15T00:00:00Z' },
    { id: 'est-3', categoria: 'DOS', indicador: 'Plano de Ação', valor: 80, data: '2026-07-15T00:00:00Z' },
    { id: 'est-4', categoria: 'DOS', indicador: 'Ocorrências', valor: 3, data: '2026-07-15T00:00:00Z' },
    { id: 'est-5', categoria: 'DOS', indicador: 'Documentos', valor: 25, data: '2026-07-15T00:00:00Z' },
    { id: 'est-6', categoria: 'DOS', indicador: 'Cumprimento de prazos', valor: 92, data: '2026-07-15T00:00:00Z' },
    // DFC
    { id: 'est-7', categoria: 'DFC', indicador: 'Relatórios enviados', valor: 12, data: '2026-07-15T00:00:00Z' },
    { id: 'est-8', categoria: 'DFC', indicador: 'Pontualidade', valor: 88, data: '2026-07-15T00:00:00Z' },
    { id: 'est-9', categoria: 'DFC', indicador: 'Plano de Ação', valor: 70, data: '2026-07-15T00:00:00Z' },
    { id: 'est-10', categoria: 'DFC', indicador: 'Ocorrências', valor: 1, data: '2026-07-15T00:00:00Z' },
    { id: 'est-11', categoria: 'DFC', indicador: 'Documentos', valor: 18, data: '2026-07-15T00:00:00Z' },
    { id: 'est-12', categoria: 'DFC', indicador: 'Cumprimento de prazos', valor: 85, data: '2026-07-15T00:00:00Z' },
    // FAL
    { id: 'est-13', categoria: 'FAL', indicador: 'Relatórios enviados', valor: 15, data: '2026-07-15T00:00:00Z' },
    { id: 'est-14', categoria: 'FAL', indicador: 'Pontualidade', valor: 100, data: '2026-07-15T00:00:00Z' },
    { id: 'est-15', categoria: 'FAL', indicador: 'Plano de Ação', valor: 90, data: '2026-07-15T00:00:00Z' },
    { id: 'est-16', categoria: 'FAL', indicador: 'Ocorrências', valor: 0, data: '2026-07-15T00:00:00Z' },
    { id: 'est-17', categoria: 'FAL', indicador: 'Documentos', valor: 30, data: '2026-07-15T00:00:00Z' },
    { id: 'est-18', categoria: 'FAL', indicador: 'Cumprimento de prazos', valor: 98, data: '2026-07-15T00:00:00Z' },
    // DRCQ
    { id: 'est-19', categoria: 'DRCQ', indicador: 'Relatórios enviados', valor: 11, data: '2026-07-15T00:00:00Z' },
    { id: 'est-20', categoria: 'DRCQ', indicador: 'Pontualidade', valor: 90, data: '2026-07-15T00:00:00Z' },
    { id: 'est-21', categoria: 'DRCQ', indicador: 'Plano de Ação', valor: 85, data: '2026-07-15T00:00:00Z' },
    { id: 'est-22', categoria: 'DRCQ', indicador: 'Ocorrências', valor: 2, data: '2026-07-15T00:00:00Z' },
    { id: 'est-23', categoria: 'DRCQ', indicador: 'Documentos', valor: 22, data: '2026-07-15T00:00:00Z' },
    { id: 'est-24', categoria: 'DRCQ', indicador: 'Cumprimento de prazos', valor: 89, data: '2026-07-15T00:00:00Z' },
  ],
  conversasIA: [],
  mensagensIA: [],
  configuracoesIA: [
    { id: 'cfg-1', modelo: 'gemini-3.5-flash', idioma: 'Português (AO)', temperatura: 0.2, limite_tokens: 2048, ativo: true }
  ],
  sugestoesIA: [
    { id: 'sug-1', categoria: 'Recursos Humanos', descricao: 'Reforçar a escala de inspetores de segurança nos períodos de pico matinal (06:00 - 09:00).', prioridade: 'Alta', data_criacao: '2026-07-15T10:00:00Z' },
    { id: 'sug-2', categoria: 'Recursos Materiais', descricao: 'Substituir com urgência o scanner de bagagem de mão no Pórtico Sul (atualmente avariado).', prioridade: 'Alta', data_criacao: '2026-07-15T11:00:00Z' },
    { id: 'sug-3', categoria: 'Formação', descricao: 'Agendar ação de reciclagem em procedimentos de facilitação para a equipa da FAL.', prioridade: 'Média', data_criacao: '2026-07-15T14:30:00Z' },
    { id: 'sug-4', categoria: 'Equipamentos', descricao: 'Criar plano de manutenção preventiva trimestral para os portões automáticos de embarque.', prioridade: 'Baixa', data_criacao: '2026-07-15T16:00:00Z' }
  ]
};

// Database utility class
export class JsonDB {
  private static pgPool: pg.Pool | null = null;
  private static cache: DatabaseSchema | null = null;

  static async initDb(): Promise<void> {
    const dbUrl = process.env.DATABASE_URL || process.env.POSTGRES_URL;
    if (dbUrl) {
      console.log('[SIGO-DFS DB] DATABASE_URL detetada. Iniciando adaptador PostgreSQL...');
      try {
        this.pgPool = new pg.Pool({
          connectionString: dbUrl,
          ssl: dbUrl.includes('localhost') || dbUrl.includes('127.0.0.1') ? false : { rejectUnauthorized: false }
        });
        
        // Criar tabela de estado se não existir
        await this.pgPool.query(`
          CREATE TABLE IF NOT EXISTS sigo_json_state (
            id VARCHAR(50) PRIMARY KEY,
            state_data JSONB NOT NULL,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
          );
        `);
        
        const res = await this.pgPool.query(`SELECT state_data FROM sigo_json_state WHERE id = 'sigo_dfs' LIMIT 1`);
        if (res.rows.length > 0) {
          console.log('[SIGO-DFS DB] Estado carregado com sucesso do PostgreSQL.');
          this.cache = res.rows[0].state_data;
        } else {
          console.log('[SIGO-DFS DB] Nenhum estado encontrado no PostgreSQL. Semeando dados iniciais...');
          await this.pgPool.query(`
            INSERT INTO sigo_json_state (id, state_data, updated_at)
            VALUES ('sigo_dfs', $1, NOW())
          `, [JSON.stringify(seedData)]);
          this.cache = seedData;
        }
      } catch (err) {
        console.error('[SIGO-DFS DB] Erro ao conectar ou inicializar o PostgreSQL. Revertendo para modo local:', err);
        this.cache = null;
      }
    } else {
      console.log('[SIGO-DFS DB] DATABASE_URL não configurada. Utilizando base de dados em ficheiro JSON local.');
    }

    // Se falhar ou estiver no modo local, carrega do ficheiro
    if (!this.cache) {
      this.cache = this.loadFromFile();
    }
  }

  private static load(): DatabaseSchema {
    if (this.cache) {
      return this.cache;
    }
    this.cache = this.loadFromFile();
    return this.cache;
  }

  private static loadFromFile(): DatabaseSchema {
    ensureDataDir();
    let data: DatabaseSchema;
    if (!fs.existsSync(DB_FILE)) {
      data = seedData;
      fs.writeFileSync(DB_FILE, JSON.stringify(seedData, null, 2), 'utf-8');
      return seedData;
    }
    try {
      const content = fs.readFileSync(DB_FILE, 'utf-8');
      data = JSON.parse(content);
    } catch (e) {
      console.error('Failed to parse DB, falling back to seed', e);
      data = seedData;
    }
    // Guarantee new collections exist for backward compatibility
    data.processedDocuments = data.processedDocuments || [];
    data.slides = data.slides || [];
    data.extractedFields = data.extractedFields || [];
    data.documentCategories = data.documentCategories || [
      { id: 'cat-1', nome: DocumentCategory.OPERACOES, descricao: 'Relatórios operacionais de pista, terminais e fluxos' },
      { id: 'cat-2', nome: DocumentCategory.SEGURANCA, descricao: 'Incidentes, rondas, segurança cibernética e física (AVSEC)' },
      { id: 'cat-3', nome: DocumentCategory.FACILITACAO, descricao: 'Serviços ao passageiro, bagagens, PMR e tempos de fila' },
      { id: 'cat-4', nome: DocumentCategory.RECURSOS_HUMANOS, descricao: 'Pessoal, escalas, turnos e contratações' },
      { id: 'cat-5', nome: DocumentCategory.RECURSOS_MATERIAIS, descricao: 'Equipamentos, infraestrutura e frotas' },
      { id: 'cat-6', nome: DocumentCategory.CREDENCIAMENTO, descricao: 'Passes, autorizações de acesso e cartões de identificação' },
      { id: 'cat-7', nome: DocumentCategory.FORMACAO, descricao: 'Treino, reciclagens, cursos e certificações profissionais' },
      { id: 'cat-8', nome: DocumentCategory.PLANO_DE_ACAO, descricao: 'Planos corretivos, auditorias e relatórios de acompanhamento' },
      { id: 'cat-9', nome: DocumentCategory.INDICADORES, descricao: 'Estatísticas de tráfego, KPIs e metas de desempenho' },
      { id: 'cat-10', nome: DocumentCategory.CORRESPONDENCIA, descricao: 'Ofícios, memorandos e comunicações institucionais' },
      { id: 'cat-11', nome: DocumentCategory.OUTROS, descricao: 'Documentos diversos não classificados automaticamente' }
    ];
    data.indexedSearches = data.indexedSearches || [];
    data.duplicateGroups = data.duplicateGroups || [];
    data.kpis = data.kpis || seedData.kpis;
    data.dashboardConfigs = data.dashboardConfigs || seedData.dashboardConfigs;
    data.relatoriosAnaliticos = data.relatoriosAnaliticos || seedData.relatoriosAnaliticos;
    data.estatisticas = data.estatisticas || seedData.estatisticas;
    data.conversasIA = data.conversasIA || [];
    data.mensagensIA = data.mensagensIA || [];
    data.configuracoesIA = data.configuracoesIA || seedData.configuracoesIA;
    data.sugestoesIA = data.sugestoesIA || seedData.sugestoesIA;

    // Guarantee settings exists
    if (!data.settings) {
      data.settings = {
        allowedDomain: 'ato-oc.co.ao',
        idleTimeoutMinutes: 15,
        powerpointTemplateName: 'Modelo_Institucional_DFS.pptx',
        pdfTemplateName: 'Modelo_Relatorio_DFS.pdf',
        registrationPolicy: 'ANY_VALID_EMAIL'
      };
    } else if (!data.settings.registrationPolicy) {
      data.settings.registrationPolicy = 'ANY_VALID_EMAIL';
    }

    // Map existing users to have status, phone and position if missing
    if (data.users) {
      data.users = data.users.map(u => ({
        status: u.status || 'Ativa',
        phone: u.phone || '+244 923 000 000',
        position: u.position || (u.role === UserRole.ADMIN ? 'Administrador de Sistemas' : (u.role === UserRole.DIRETOR ? 'Diretor de Operações' : (u.role === UserRole.SECRETARIADO ? 'Técnico Administrativo' : 'Chefe de Divisão'))),
        ...u
      }));
    }

    // Map existing action plans to fully comply with new properties
    if (data.actionPlans) {
      data.actionPlans = data.actionPlans.map((ap, index) => {
        let prioridadeVal = ActionPlanPriority.MEDIA;
        if (ap.prioridade) {
          const p = String(ap.prioridade).toLowerCase();
          if (p.includes('alt')) prioridadeVal = ActionPlanPriority.ALTA;
          else if (p.includes('baix')) prioridadeVal = ActionPlanPriority.BAIXA;
          else if (p.includes('crit')) prioridadeVal = ActionPlanPriority.CRITICA;
        }

        // Map state safely
        let estadoVal = ap.estado;
        if (String(ap.estado) === 'PENDENTE') estadoVal = ActionPlanStatus.PENDENTE;
        else if (String(ap.estado) === 'EM_CURSO') estadoVal = ActionPlanStatus.EM_CURSO;
        else if (String(ap.estado) === 'CONCLUIDO') estadoVal = ActionPlanStatus.CONCLUIDO;

        const progressoVal = typeof ap.progresso === 'number' 
          ? ap.progresso 
          : (typeof ap.percentagemExecucao === 'number' ? ap.percentagemExecucao : (estadoVal === ActionPlanStatus.CONCLUIDO ? 100 : 0));

        const formattedIndex = String(index + 1).padStart(3, '0');
        return {
          id: ap.id,
          codigo: ap.codigo || `ACT-2026-${formattedIndex}`,
          titulo: ap.titulo,
          descricao: ap.descricao,
          categoria: ap.categoria || 'Operações',
          divisaoId: ap.divisaoId,
          responsavel: ap.responsavel,
          prioridade: prioridadeVal,
          estado: estadoVal,
          progresso: progressoVal,
          percentagemExecucao: progressoVal,
          dataCriacao: ap.dataCriacao || '2026-07-15',
          dataInicio: ap.dataInicio || '2026-07-15',
          dataLimite: ap.dataLimite,
          dataConclusao: ap.dataConclusao,
          observacoes: ap.observacoes || ap.notasExecucao || '',
          balanceId: ap.balanceId,
          historico: ap.historico || [],
          comentarios: ap.comentarios || [],
          evidencias: ap.evidencias || []
        };
      });
    }

    return data;
  }

  private static save(data: DatabaseSchema) {
    this.cache = data;
    ensureDataDir();
    
    // Escrita assíncrona local para não bloquear
    fs.writeFile(DB_FILE, JSON.stringify(data, null, 2), 'utf-8', (err) => {
      if (err) console.error('[SIGO-DFS DB] Erro ao salvar estado localmente:', err);
    });

    // Escrita em background no PostgreSQL
    if (this.pgPool) {
      this.pgPool.query(`
        INSERT INTO sigo_json_state (id, state_data, updated_at)
        VALUES ('sigo_dfs', $1, NOW())
        ON CONFLICT (id) DO UPDATE SET state_data = $1, updated_at = NOW()
      `, [JSON.stringify(data)]).catch(err => {
        console.error('[SIGO-DFS DB] Erro ao salvar estado no PostgreSQL:', err);
      });
    }
  }

  // Settings
  static getSettings(): SystemSettings {
    const db = this.load();
    return db.settings!;
  }

  static updateSettings(updates: Partial<SystemSettings>): SystemSettings {
    const db = this.load();
    db.settings = { ...db.settings!, ...updates };
    this.save(db);
    return db.settings;
  }

  // Users Custom Methods
  static createUser(user: Omit<User, 'id'> & { passwordHash: string }) {
    const db = this.load();
    const newUser = {
      ...user,
      id: `usr-${Date.now()}`,
      status: user.status || 'Pendente de Aprovação',
      phone: user.phone || '+244 923 000 000',
      position: user.position || 'Colaborador',
      failures: 0
    };
    db.users.push(newUser);
    this.save(db);
    const { passwordHash, failures, lockedUntil, ...safeUser } = newUser as any;
    return safeUser;
  }

  static updateUser(id: string, updates: Partial<User & { passwordHash: string; failures?: number; lockedUntil?: string }>) {
    const db = this.load();
    const index = db.users.findIndex(u => u.id === id);
    if (index === -1) return null;
    db.users[index] = {
      ...db.users[index],
      ...updates
    } as any;
    this.save(db);
    const { passwordHash, failures, lockedUntil, ...safeUser } = db.users[index] as any;
    return safeUser;
  }

  static deleteUser(id: string) {
    const db = this.load();
    const index = db.users.findIndex(u => u.id === id);
    if (index === -1) return false;
    db.users.splice(index, 1);
    this.save(db);
    return true;
  }

  // Users
  static getUsers() {
    const db = this.load();
    return db.users.map(({ passwordHash, ...user }) => user);
  }

  static getUserByUsername(username: string) {
    const db = this.load();
    const user = db.users.find(u => u.username === username);
    return user || null;
  }

  static getUserById(id: string) {
    const db = this.load();
    const user = db.users.find(u => u.id === id);
    if (!user) return null;
    const { passwordHash, ...safeUser } = user;
    return safeUser;
  }

  // Operational Balances
  static getBalances() {
    return this.load().balances;
  }

  static getBalanceById(id: string) {
    return this.load().balances.find(b => b.id === id) || null;
  }

  static createBalance(balance: Omit<OperationalBalance, 'id' | 'dataCriacao' | 'dataAtualizacao' | 'numero' | 'hora' | 'contribuicoes'> & { hora?: string; numero?: string; observacoes?: string }) {
    const db = this.load();
    const nextSeq = db.balances.length + 1;
    const year = new Date().getFullYear();
    const numero = balance.numero || `BAL-${year}-${nextSeq.toString().padStart(4, '0')}`;
    const hora = balance.hora || new Date().toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit' });
    const balanceId = `bal-${Date.now()}`;

    // Initialize 4 division contributions
    const divisions = [DivisionId.DOS, DivisionId.DFC, DivisionId.FAL, DivisionId.DRCQ];
    const contribuicoes: DivisionContribution[] = divisions.map((div, i) => ({
      id: `con-${Date.now()}-${i}`,
      balanceId: balanceId,
      divisaoId: div,
      estado: DivisionContributionStatus.NAO_INICIADO,
      observacoes: '',
      enviadoPor: '',
      enviadoEm: ''
    }));

    const newBalance: OperationalBalance = {
      ...balance,
      id: balanceId,
      numero,
      hora,
      estado: balance.estado || BalanceStatus.EM_ELABORACAO,
      observacoes: balance.observacoes || '',
      contribuicoes,
      dataCriacao: new Date().toISOString(),
      dataAtualizacao: new Date().toISOString()
    } as any;

    db.balances.push(newBalance);
    this.save(db);
    return newBalance;
  }

  static updateBalance(id: string, updates: Partial<OperationalBalance>) {
    const db = this.load();
    const index = db.balances.findIndex(b => b.id === id);
    if (index === -1) return null;

    db.balances[index] = {
      ...db.balances[index],
      ...updates,
      dataAtualizacao: new Date().toISOString()
    };
    this.save(db);
    return db.balances[index];
  }

  // Documents
  static getDocuments() {
    return this.load().documents;
  }

  static createDocument(doc: Omit<Documento, 'id' | 'dataCarregamento' | 'versao' | 'isCurrent'>) {
    const db = this.load();
    const docId = `doc-${Date.now()}`;
    
    let versao = 1;
    let parentDocId = docId;
    
    if (doc.balanceId) {
      // Find current active document for this division and balance
      const existingDoc = db.documents.find(
        d => d.balanceId === doc.balanceId && d.divisaoId === doc.divisaoId && d.isCurrent
      );
      if (existingDoc) {
        existingDoc.isCurrent = false;
        versao = (existingDoc.versao || 1) + 1;
        parentDocId = existingDoc.parentDocId || existingDoc.id;
      }
    }

    const newDoc: Documento = {
      ...doc,
      id: docId,
      versao,
      parentDocId,
      isCurrent: true,
      dataCarregamento: new Date().toISOString()
    };
    db.documents.push(newDoc);
    this.save(db);
    return newDoc;
  }

  static restoreDocumentVersion(docId: string) {
    const db = this.load();
    const docToRestore = db.documents.find(d => d.id === docId);
    if (!docToRestore) return null;

    // Set all documents with the same parentDocId and balanceId to isCurrent = false
    db.documents.forEach(d => {
      if (d.parentDocId === docToRestore.parentDocId) {
        d.isCurrent = false;
      }
    });

    // Set the selected one to isCurrent = true
    docToRestore.isCurrent = true;
    this.save(db);
    return docToRestore;
  }

  static deleteDocument(id: string) {
    const db = this.load();
    db.documents = db.documents.filter(d => d.id !== id);
    this.save(db);
    return true;
  }

  // Action Plans
  static getActionPlans() {
    return this.load().actionPlans;
  }

  static getActionPlanById(id: string) {
    return this.load().actionPlans.find(ap => ap.id === id) || null;
  }

  static createActionPlan(item: Omit<ActionPlanItem, 'id' | 'codigo' | 'dataCriacao' | 'historico' | 'comentarios' | 'evidencias'>) {
    const db = this.load();
    const count = db.actionPlans.length;
    const formattedCount = String(count + 1).padStart(3, '0');
    const codigo = `ACT-2026-${formattedCount}`;

    const newItem: ActionPlanItem = {
      ...item,
      id: `act-${Date.now()}`,
      codigo,
      categoria: item.categoria || 'Operações',
      prioridade: item.prioridade || ActionPlanPriority.MEDIA,
      estado: item.estado || ActionPlanStatus.PENDENTE,
      progresso: item.progresso !== undefined ? item.progresso : 0,
      percentagemExecucao: item.progresso !== undefined ? item.progresso : 0,
      dataCriacao: new Date().toISOString().split('T')[0],
      dataInicio: item.dataInicio || new Date().toISOString().split('T')[0],
      dataLimite: item.dataLimite,
      observacoes: item.observacoes || '',
      historico: [],
      comentarios: [],
      evidencias: []
    };
    db.actionPlans.push(newItem);
    this.save(db);
    return newItem;
  }

  static updateActionPlan(id: string, updates: Partial<ActionPlanItem>, utilizador: string = 'SISTEMA') {
    const db = this.load();
    const index = db.actionPlans.findIndex(ap => ap.id === id);
    if (index === -1) return null;

    const oldItem = db.actionPlans[index];
    const historico = oldItem.historico || [];

    const fieldsToTrack: (keyof ActionPlanItem)[] = [
      'titulo', 'descricao', 'categoria', 'divisaoId', 'responsavel', 
      'prioridade', 'estado', 'progresso', 'dataLimite', 'dataInicio', 
      'dataConclusao', 'observacoes'
    ];

    const timestamp = new Date().toISOString();

    fieldsToTrack.forEach(field => {
      if (updates[field] !== undefined && updates[field] !== oldItem[field]) {
        historico.push({
          id: `hist-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
          planoId: id,
          campo: String(field),
          valorAnterior: String(oldItem[field] !== undefined ? oldItem[field] : ''),
          valorNovo: String(updates[field]),
          utilizador,
          dataHora: timestamp
        });
      }
    });

    if (updates.progresso !== undefined) {
      updates.percentagemExecucao = updates.progresso;
    }

    db.actionPlans[index] = {
      ...oldItem,
      ...updates,
      historico
    };

    this.save(db);
    return db.actionPlans[index];
  }

  static addActionPlanComment(id: string, commentText: string, utilizador: string) {
    const db = this.load();
    const index = db.actionPlans.findIndex(ap => ap.id === id);
    if (index === -1) return null;

    const actionPlan = db.actionPlans[index];
    actionPlan.comentarios = actionPlan.comentarios || [];

    const newComment: ActionPlanComment = {
      id: `com-${Date.now()}`,
      planoId: id,
      comentario: commentText,
      utilizador,
      dataHora: new Date().toISOString()
    };

    actionPlan.comentarios.push(newComment);
    this.save(db);
    return actionPlan;
  }

  static addActionPlanEvidence(id: string, file: string, type: string, utilizador: string) {
    const db = this.load();
    const index = db.actionPlans.findIndex(ap => ap.id === id);
    if (index === -1) return null;

    const actionPlan = db.actionPlans[index];
    actionPlan.evidencias = actionPlan.evidencias || [];

    const newEvidence: ActionPlanEvidence = {
      id: `ev-${Date.now()}`,
      planoId: id,
      ficheiro: file,
      tipo: type,
      utilizador,
      dataHora: new Date().toISOString()
    };

    actionPlan.evidencias.push(newEvidence);
    this.save(db);
    return actionPlan;
  }

  static deleteActionPlan(id: string) {
    const db = this.load();
    db.actionPlans = db.actionPlans.filter(ap => ap.id !== id);
    this.save(db);
    return true;
  }

  // Workflow Logs
  static getWorkflowLogs(balanceId?: string) {
    const logs = this.load().workflowLogs;
    if (balanceId) {
      return logs.filter(l => l.balanceId === balanceId);
    }
    return logs;
  }

  static createWorkflowLog(log: Omit<WorkflowLog, 'id' | 'data'>) {
    const db = this.load();
    const newLog: WorkflowLog = {
      ...log,
      id: `wfl-${Date.now()}`,
      data: new Date().toISOString()
    };
    db.workflowLogs.push(newLog);
    this.save(db);
    return newLog;
  }

  // Notifications
  static getNotifications() {
    return this.load().notifications;
  }

  static createNotification(notification: Omit<Notification, 'id' | 'dataCriacao' | 'lida'>) {
    const db = this.load();
    const newNotif: Notification = {
      ...notification,
      id: `not-${Date.now()}`,
      lida: false,
      dataCriacao: new Date().toISOString()
    };
    db.notifications.push(newNotif);
    this.save(db);
    return newNotif;
  }

  static markNotificationAsRead(id: string) {
    const db = this.load();
    const index = db.notifications.findIndex(n => n.id === id);
    if (index !== -1) {
      db.notifications[index].lida = true;
      this.save(db);
    }
    return true;
  }

  static markAllNotificationsAsRead() {
    const db = this.load();
    db.notifications = db.notifications.map(n => ({ ...n, lida: true }));
    this.save(db);
    return true;
  }

  // Audit Logs
  static getAuditLogs() {
    return this.load().auditLogs;
  }

  static createAuditLog(log: Omit<AuditLog, 'id' | 'data'>) {
    const db = this.load();
    const newLog: AuditLog = {
      ...log,
      id: `aud-${Date.now()}`,
      data: new Date().toISOString()
    };
    db.auditLogs.unshift(newLog); // Put latest on top
    this.save(db);
    return newLog;
  }

  // --- DOCUMENT INTELLIGENCE ENGINE METHODS ---

  static getProcessedDocuments() {
    return this.load().processedDocuments;
  }

  static getProcessedDocumentById(id: string) {
    return this.load().processedDocuments.find(d => d.id === id) || null;
  }

  static getSlides(docProcessedId?: string) {
    const slides = this.load().slides;
    if (docProcessedId) {
      return slides.filter(s => s.documentoProcessadoId === docProcessedId);
    }
    return slides;
  }

  static getExtractedFields(docProcessedId?: string) {
    const fields = this.load().extractedFields;
    if (docProcessedId) {
      return fields.filter(f => f.documentoProcessadoId === docProcessedId);
    }
    return fields;
  }

  static getDocumentCategories() {
    return this.load().documentCategories;
  }

  static getIndexedSearches() {
    return this.load().indexedSearches;
  }

  static searchIndexed(query: string, divisaoId?: string, categoria?: string, tipoDoc?: string, balanceId?: string) {
    const db = this.load();
    const q = query.toLowerCase().trim();
    
    // Filter index searches
    return db.indexedSearches.filter(idx => {
      // Content search
      const matchesText = q === '' || idx.palavra.toLowerCase().includes(q) || idx.contexto.toLowerCase().includes(q);
      if (!matchesText) return false;

      // Division filter
      if (divisaoId && divisaoId !== 'ALL' && idx.divisaoId !== divisaoId) return false;

      // Category filter
      if (categoria && categoria !== 'ALL' && idx.categoria !== categoria) return false;

      // DocType filter
      if (tipoDoc && tipoDoc !== 'ALL' && idx.tipoDocumento !== tipoDoc) return false;

      // Balance ID match if given
      if (balanceId) {
        const doc = db.documents.find(d => d.id === idx.documentoId);
        if (!doc || doc.balanceId !== balanceId) return false;
      }

      return true;
    });
  }

  static updateProcessedCategory(docProcessedId: string, category: DocumentCategory, user: string, userRole: string) {
    const db = this.load();
    const doc = db.processedDocuments.find(d => d.id === docProcessedId);
    if (!doc) return null;

    const oldCat = doc.categoria;
    doc.categoria = category;
    
    // Refresh search indexing category for all items of this document
    db.indexedSearches.forEach(idx => {
      if (idx.documentoProcessadoId === docProcessedId) {
        idx.categoria = category;
      }
    });

    this.createAuditLog({
      utilizador: user,
      perfil: userRole,
      acao: 'Corrigir Categoria',
      detalhe: `Corrigida categoria do documento "${doc.nomeDocumento}" de "${oldCat}" para "${category}".`
    });

    this.save(db);
    return doc;
  }

  static validateExtractedField(fieldId: string, validado: boolean, user: string, userRole: string) {
    const db = this.load();
    const field = db.extractedFields.find(f => f.id === fieldId);
    if (!field) return null;

    field.validado = validado;

    this.createAuditLog({
      utilizador: user,
      perfil: userRole,
      acao: 'Validar Campo',
      detalhe: `${validado ? 'Validado' : 'Rejeitado'} campo extraído "${field.nome}" com valor "${field.valor}".`
    });

    this.save(db);
    return field;
  }

  static approveProcessedDocument(docProcessedId: string, approved: boolean, user: string, userRole: string) {
    const db = this.load();
    const doc = db.processedDocuments.find(d => d.id === docProcessedId);
    if (!doc) return null;

    doc.aprovado = approved;
    doc.validado = approved;
    doc.validadoPor = user;
    doc.validadoEm = new Date().toISOString();

    // Automatically validate all fields if approved
    if (approved) {
      db.extractedFields.forEach(f => {
        if (f.documentoProcessadoId === docProcessedId) {
          f.validado = true;
        }
      });
    }

    this.createAuditLog({
      utilizador: user,
      perfil: userRole,
      acao: 'Aprovar Processamento',
      detalhe: `${approved ? 'Aprovados' : 'Desaprovados'} dados extraídos do documento "${doc.nomeDocumento}".`
    });

    this.save(db);
    return doc;
  }

  static reprocessDocument(docProcessedId: string, user: string, userRole: string) {
    const db = this.load();
    const docProcessed = db.processedDocuments.find(d => d.id === docProcessedId);
    if (!docProcessed) return null;

    const originalDoc = db.documents.find(d => d.id === docProcessed.documentoId);
    if (!originalDoc) return null;

    // Remove old slides, fields and indexed searches
    db.slides = db.slides.filter(s => s.documentoProcessadoId !== docProcessedId);
    db.extractedFields = db.extractedFields.filter(f => f.documentoProcessadoId !== docProcessedId);
    db.indexedSearches = db.indexedSearches.filter(idx => idx.documentoProcessadoId !== docProcessedId);

    // Reprocess
    docProcessed.estado = ProcessStatus.EM_PROCESSAMENTO;
    this.save(db);

    // Call parser simulation synchronously for deterministic demo flow
    const reprocessed = this.parseAndPersistDocument(db, originalDoc, docProcessed, user);
    
    this.createAuditLog({
      utilizador: user,
      perfil: userRole,
      acao: 'Reprocessar Documento',
      detalhe: `Reprocessamento manual despoletado para o documento "${originalDoc.nome}".`
    });

    this.save(db);
    return reprocessed;
  }

  static processUploadedDocument(doc: Documento, user: string) {
    const db = this.load();
    
    // Check if processed document metadata already exists
    let docProcessed = db.processedDocuments.find(p => p.documentoId === doc.id);
    const docProcessedId = docProcessed?.id || `proc-${Date.now()}`;

    // Clean old extractions if exists
    db.slides = db.slides.filter(s => s.documentoProcessadoId !== docProcessedId);
    db.extractedFields = db.extractedFields.filter(f => f.documentoProcessadoId !== docProcessedId);
    db.indexedSearches = db.indexedSearches.filter(idx => idx.documentoProcessadoId !== docProcessedId);

    // 1. AUTO CLASSIFY CATEGORY
    let autoCategory = DocumentCategory.OPERACOES;
    const nameLower = doc.nome.toLowerCase();

    if (nameLower.includes('seguranca') || nameLower.includes('avsec') || nameLower.includes('ronda') || nameLower.includes('vedacao') || nameLower.includes('incidente') || nameLower.includes('ocorrencia')) {
      autoCategory = DocumentCategory.SEGURANCA;
    } else if (nameLower.includes('facilitacao') || nameLower.includes('bagagem') || nameLower.includes('pmr') || nameLower.includes('tapete') || nameLower.includes('atendimento')) {
      autoCategory = DocumentCategory.FACILITACAO;
    } else if (nameLower.includes('recursos humanos') || nameLower.includes('rh') || nameLower.includes('pessoal') || nameLower.includes('escala') || nameLower.includes('turno')) {
      autoCategory = DocumentCategory.RECURSOS_HUMANOS;
    } else if (nameLower.includes('materiais') || nameLower.includes('equipamento') || nameLower.includes('infraestrutura') || nameLower.includes('manutencao') || nameLower.includes('frota')) {
      autoCategory = DocumentCategory.RECURSOS_MATERIAIS;
    } else if (nameLower.includes('credenciamento') || nameLower.includes('passe') || nameLower.includes('acesso') || nameLower.includes('cartao')) {
      autoCategory = DocumentCategory.CREDENCIAMENTO;
    } else if (nameLower.includes('formacao') || nameLower.includes('treino') || nameLower.includes('curso') || nameLower.includes('certificacao') || nameLower.includes('instrucao')) {
      autoCategory = DocumentCategory.FORMACAO;
    } else if (nameLower.includes('plano') || nameLower.includes('acao') || nameLower.includes('corretiva') || nameLower.includes('auditoria') || nameLower.includes('inspecao')) {
      autoCategory = DocumentCategory.PLANO_DE_ACAO;
    } else if (nameLower.includes('indicador') || nameLower.includes('estatistica') || nameLower.includes('kpi') || nameLower.includes('trafego')) {
      autoCategory = DocumentCategory.INDICADORES;
    } else if (nameLower.includes('oficio') || nameLower.includes('memorando') || nameLower.includes('carta')) {
      autoCategory = DocumentCategory.CORRESPONDENCIA;
    } else {
      // Map based on division
      if (doc.divisaoId === DivisionId.DOS) autoCategory = DocumentCategory.OPERACOES;
      else if (doc.divisaoId === DivisionId.DFC) autoCategory = DocumentCategory.FACILITACAO;
      else if (doc.divisaoId === DivisionId.FAL) autoCategory = DocumentCategory.FACILITACAO;
      else if (doc.divisaoId === DivisionId.DRCQ) autoCategory = DocumentCategory.PLANO_DE_ACAO;
    }

    // Determine error-states based on name
    let estado = ProcessStatus.CONCLUIDO;
    let erro: string | undefined = undefined;

    if (nameLower.includes('vazio') || nameLower.includes('corrompido') || nameLower.includes('invalido')) {
      estado = ProcessStatus.ERRO;
      erro = 'Erro de Validação: Ficheiro vazio ou com formato inválido de cabeçalhos de tabela.';
    } else if (nameLower.includes('incompleto')) {
      estado = ProcessStatus.ERRO;
      erro = 'Erro de Validação: Campos obrigatórios não identificados. Falta o Slide institucional do Plano de Ação.';
    }

    if (!docProcessed) {
      docProcessed = {
        id: docProcessedId,
        documentoId: doc.id,
        nomeDocumento: doc.nome,
        tipo: doc.tipo,
        divisaoId: doc.divisaoId,
        dataProcessamento: new Date().toISOString(),
        estado,
        categoria: autoCategory,
        erro,
        metadados: {
          autor: user || doc.carregadoPor,
          dataCriacao: new Date().toISOString(),
          dataModificacao: new Date().toISOString(),
          tamanhoOriginal: doc.tamanho
        },
        validado: false,
        aprovado: false
      };
      db.processedDocuments.push(docProcessed);
    } else {
      docProcessed.estado = estado;
      docProcessed.erro = erro;
      docProcessed.categoria = autoCategory;
      docProcessed.dataProcessamento = new Date().toISOString();
    }

    // Sync parse structures if not error
    if (estado === ProcessStatus.CONCLUIDO) {
      this.parseAndPersistDocument(db, doc, docProcessed, user);
    }

    this.save(db);
    return docProcessed;
  }

  private static parseAndPersistDocument(db: DatabaseSchema, doc: Documento, docProcessed: DocumentoProcessado, user: string) {
    const docProcessedId = docProcessed.id;
    const divisao = doc.divisaoId;

    if (doc.tipo === DocType.PPTX) {
      docProcessed.totalSlides = 4;
      
      // Seed PowerPoint slides & fields based on Division
      const slidesData = this.getMockSlidesForDivision(docProcessedId, divisao);
      db.slides.push(...slidesData);

      // Extract Fields corresponding to slides
      slidesData.forEach(slide => {
        const fields = this.getMockFieldsForSlide(docProcessedId, slide);
        db.extractedFields.push(...fields);
      });
    } 
    else if (doc.tipo === DocType.PDF) {
      docProcessed.totalPaginas = 3;
      
      // Simulate PDF extraction: Create extracted fields directly
      const pdfFields = [
        { id: `f-${Date.now()}-1`, documentoProcessadoId: docProcessedId, paginaNumero: 1, nome: 'Título do Relatório', valor: `Consolidado de Auditoria - ${divisao}`, categoria: 'Metadados', confianca: 99, validado: false },
        { id: `f-${Date.now()}-2`, documentoProcessadoId: docProcessedId, paginaNumero: 1, nome: 'Data de Referência', valor: new Date().toLocaleDateString(), categoria: 'Metadados', confianca: 95, validado: false },
        { id: `f-${Date.now()}-3`, documentoProcessadoId: docProcessedId, paginaNumero: 2, nome: 'Índice de Risco', valor: divisao === DivisionId.DRCQ ? 'BAIXO (96% conformidade)' : 'Normal', categoria: 'Métricas', confianca: 90, validado: false },
        { id: `f-${Date.now()}-4`, documentoProcessadoId: docProcessedId, paginaNumero: 3, nome: 'Resumo de Recomendações', valor: 'Manter a vigilância acrescida sobre a zona norte de estacionamento de táxis.', categoria: 'Recomendações', confianca: 88, validado: false }
      ];
      db.extractedFields.push(...pdfFields);
    } 
    else if (doc.tipo === DocType.DOCX) {
      docProcessed.totalPaginas = 2;
      docProcessed.totalLinhas = 145;

      const docxFields = [
        { id: `f-${Date.now()}-5`, documentoProcessadoId: docProcessedId, paginaNumero: 1, nome: 'Secção I - Objetivos', valor: 'Definição dos requisitos normativos de suporte do aeroporto.', categoria: 'Objetivo', confianca: 95, validado: false },
        { id: `f-${Date.now()}-6`, documentoProcessadoId: docProcessedId, paginaNumero: 2, nome: 'Secção II - Plano Operacional', valor: 'Ajuste de escalas e equipas para o trimestre corrente.', categoria: 'Plano de Trabalho', confianca: 92, validado: false }
      ];
      db.extractedFields.push(...docxFields);
    } 
    else if (doc.tipo === DocType.XLSX) {
      docProcessed.totalFolhas = 2;
      docProcessed.totalLinhas = 280;

      const xlsxFields = [
        { id: `f-${Date.now()}-7`, documentoProcessadoId: docProcessedId, folhaNome: 'Folha1 - Tráfego', nome: 'Total de Passageiros Diários', valor: '14,850 pax', categoria: 'Indicadores', confianca: 98, validado: false },
        { id: `f-${Date.now()}-8`, documentoProcessadoId: docProcessedId, folhaNome: 'Folha1 - Tráfego', nome: 'Movimentos Totais', valor: '112 voos comerciais', categoria: 'Indicadores', confianca: 99, validado: false },
        { id: `f-${Date.now()}-9`, documentoProcessadoId: docProcessedId, folhaNome: 'Folha2 - Custos', nome: 'Fórmulas Identificadas', valor: '=SOMA(B2:B25) na célula B26', categoria: 'Sistemas', confianca: 94, validado: false }
      ];
      db.extractedFields.push(...xlsxFields);
    }

    // 2. CONSTRUCT FULL-TEXT INDEX SEARCH TERMS (Indexação)
    const textToSearch: string[] = [];
    
    // Add doc meta
    textToSearch.push(doc.nome, doc.divisaoId, docProcessed.categoria);

    // Add slides text
    const docSlides = db.slides.filter(s => s.documentoProcessadoId === docProcessedId);
    docSlides.forEach(s => {
      textToSearch.push(s.titulo, s.subtitulo, s.conteudoTextual);
      if (s.notasApresentador) textToSearch.push(s.notasApresentador);
    });

    // Add fields text
    const docFields = db.extractedFields.filter(f => f.documentoProcessadoId === docProcessedId);
    docFields.forEach(f => {
      textToSearch.push(f.nome, f.valor, f.categoria);
    });

    // Generate indexing terms
    const uniqueWords = Array.from(new Set(
      textToSearch
        .join(' ')
        .replace(/[.,\/#!$%\^&\*;:{}=\-_`~()?"\r\n]/g, ' ')
        .split(/\s+/)
        .filter(w => w.length > 2)
    ));

    uniqueWords.forEach((word, i) => {
      // Find a context sentence where it occurs
      let context = `Encontrado no documento "${doc.nome}".`;
      const sourceWithWord = textToSearch.find(text => text.toLowerCase().includes(word.toLowerCase()));
      if (sourceWithWord) {
        context = sourceWithWord.length > 80 ? sourceWithWord.substring(0, 80) + '...' : sourceWithWord;
      }

      db.indexedSearches.push({
        id: `idx-${docProcessedId}-${i}`,
        documentoId: doc.id,
        documentoProcessadoId: docProcessedId,
        palavra: word,
        divisaoId: doc.divisaoId,
        categoria: docProcessed.categoria,
        tipoDocumento: doc.tipo,
        dataProcessamento: docProcessed.dataProcessamento,
        contexto: context
      });
    });

    docProcessed.estado = ProcessStatus.CONCLUIDO;
    docProcessed.erro = undefined;

    this.extractAndSyncActionPlans(db, doc, docProcessed);

    return docProcessed;
  }

  // --- DUPLICATION DETECTION ENGINE ---
  static getPotentialDuplicates(balanceId: string) {
    const db = this.load();
    
    // Filter duplicates of this balance
    let balanceDuplicates = db.duplicateGroups.filter(g => g.balanceId === balanceId);
    
    // Find all processed documents for this balance that are completed
    const balanceDocs = db.processedDocuments.filter(d => {
      if (d.estado !== ProcessStatus.CONCLUIDO) return false;
      const originalDoc = db.documents.find(doc => doc.id === d.documentoId);
      return originalDoc && originalDoc.balanceId === balanceId;
    });
    
    if (balanceDocs.length > 1 && balanceDuplicates.length === 0) {
      // Find all extracted fields for these processed documents
      const docsIds = balanceDocs.map(d => d.id);
      const fields = db.extractedFields.filter(f => docsIds.includes(f.documentoProcessadoId));
      
      // Keywords that could mean the same event reported by multiple divisions
      const keywords = ['tapete', 'bagagem', 'fauna', 'garça', 'pista', 'perímetro', 'vedação', 'ronda', 'incidente', 'avaria', 'aves'];
      
      const potentialGroups: { [key: string]: CampoExtraido[] } = {};
      
      fields.forEach(f => {
        const textToMatch = `${f.nome} ${f.valor} ${f.categoria}`.toLowerCase();
        keywords.forEach(keyword => {
          if (textToMatch.includes(keyword)) {
            if (!potentialGroups[keyword]) potentialGroups[keyword] = [];
            if (!potentialGroups[keyword].some(existing => existing.id === f.id)) {
              potentialGroups[keyword].push(f);
            }
          }
        });
      });
      
      // Create duplicate groups for categories with fields from DIFFERENT divisions
      Object.entries(potentialGroups).forEach(([keyword, groupFields]) => {
        const divisions = groupFields.map(f => {
          const doc = balanceDocs.find(d => d.id === f.documentoProcessadoId);
          return doc ? doc.divisaoId : null;
        }).filter((d): d is DivisionId => d !== null);
        
        const uniqueDivisions = Array.from(new Set(divisions));
        
        // If we have fields from more than 1 division, it is a duplication!
        if (uniqueDivisions.length > 1 && groupFields.length > 1) {
          const camposEnvolvidos = groupFields.map(f => {
            const doc = balanceDocs.find(d => d.id === f.documentoProcessadoId)!;
            return {
              fieldId: f.id,
              docId: doc.id,
              divisaoId: doc.divisaoId,
              nome: f.nome,
              valor: f.valor
            };
          });
          
          let title = '';
          if (keyword === 'tapete' || keyword === 'bagagem') title = 'Ocorrência de Avaria no Tapete de Bagagens nº 3';
          else if (keyword === 'fauna' || keyword === 'aves' || keyword === 'garça') title = 'Incidente com Fauna na Aproximação da Pista';
          else if (keyword === 'perímetro' || keyword === 'vedação') title = 'Ronda e Inspeção de Segurança da Vedação';
          else title = `Evento partilhado sobre ${keyword.toUpperCase()}`;
          
          db.duplicateGroups.push({
            id: `dup-${Date.now()}-${keyword}`,
            balanceId,
            campoReferencia: title,
            camposEnvolvidos,
            estado: 'PENDENTE'
          });
        }
      });
      
      this.save(db);
      balanceDuplicates = db.duplicateGroups.filter(g => g.balanceId === balanceId);
    }
    
    return balanceDuplicates;
  }

  static resolveDuplicateGroup(groupId: string, estado: 'CONFIRMADO' | 'DESCARTADO', user: string, userRole: string) {
    const db = this.load();
    const group = db.duplicateGroups.find(g => g.id === groupId);
    if (!group) return null;
    
    group.estado = estado;
    group.resolvidoPor = user;
    group.resolvidoEm = new Date().toISOString();
    
    // Log audit
    this.createAuditLog({
      utilizador: user,
      perfil: userRole,
      acao: 'Resolver Duplicação',
      detalhe: `Grupo de duplicação "${group.campoReferencia}" marcado como ${estado} pelo Secretariado.`
    });
    
    // Create notifications for chiefs involved
    group.camposEnvolvidos.forEach(item => {
      this.createNotification({
        divisaoId: item.divisaoId,
        titulo: 'Duplicação de Evento Resolvida',
        mensagem: `A potencial duplicação sobre o evento "${group.campoReferencia}" foi classificada como ${estado} pelo Secretariado.`,
        link: `/balancos/${group.balanceId}`
      });
    });
    
    this.save(db);
    return group;
  }

  // --- AUTOMATIC CONSOLIDATION ENGINE ---
  static consolidateBalance(balanceId: string, user: string, userRole: string) {
    const db = this.load();
    const balance = db.balances.find(b => b.id === balanceId);
    if (!balance) return null;
    
    // Find all processed documents for this balance
    const docs = db.documents.filter(d => d.balanceId === balanceId);
    const docIds = docs.map(d => d.id);
    const processedDocs = db.processedDocuments.filter(p => docIds.includes(p.documentoId) && p.estado === ProcessStatus.CONCLUIDO);
    
    // Initialize or reset sections
    balance.dos = { ocorrenciasSeguranca: '', estadoPistaTaxiways: '', atividadesFauna: '', statusTerminaisEquipamentos: '', incidentesRelatados: '' };
    balance.dfc = { controleFronteiras: '', reclamacoesBagagens: '', filasCheckIn: '', tempoEsperaSeguranca: '', incidentesFacilitacao: '' };
    balance.fal = { acessibilidadePMR: '', conformidadeNormativa: '', assistenciaMedica: '', feedbackPassageiros: '' };
    balance.drcq = { auditoriasInspecoes: '', naoConformidadesDetetadas: '', avaliacaoRiscoOperacional: '', acoesPreventivasRecomendadas: '' };
    
    let logsCount = 0;
    
    processedDocs.forEach(p => {
      // Get validated or homologated fields
      const fields = db.extractedFields.filter(f => f.documentoProcessadoId === p.id);
      
      if (p.divisaoId === DivisionId.DOS) {
        fields.forEach(f => {
          if (f.nome.includes('Invasões') || f.nome.includes('Rondas')) {
            balance.dos!.ocorrenciasSeguranca += `${f.nome}: ${f.valor}. `;
          } else if (f.nome.includes('Pista') || f.nome.includes('Taxiways')) {
            balance.dos!.estadoPistaTaxiways += `${f.nome}: ${f.valor}. `;
          } else if (f.nome.includes('Avistamentos') || f.nome.includes('Dispersões')) {
            balance.dos!.atividadesFauna += `${f.nome}: ${f.valor}. `;
          } else {
            balance.dos!.statusTerminaisEquipamentos += `${f.nome}: ${f.valor}. `;
          }
          logsCount++;
        });
        
        if (!balance.dos!.ocorrenciasSeguranca) balance.dos!.ocorrenciasSeguranca = 'Rondas preventivas efetuadas regularmente sem registo de invasões.';
        if (!balance.dos!.estadoPistaTaxiways) balance.dos!.estadoPistaTaxiways = 'Pista principal e caminhos de circulação operacionais. Sem FOD.';
        if (!balance.dos!.atividadesFauna) balance.dos!.atividadesFauna = 'Atividade de fauna sob controle.';
        if (!balance.dos!.statusTerminaisEquipamentos) balance.dos!.statusTerminaisEquipamentos = 'Equipamentos e terminais operando regularmente.';
      }
      
      else if (p.divisaoId === DivisionId.DFC) {
        fields.forEach(f => {
          if (f.nome.includes('Espera') || f.nome.includes('Fila')) {
            balance.dfc!.tempoEsperaSeguranca += `${f.nome}: ${f.valor}. `;
          } else if (f.nome.includes('Tapete') || f.nome.includes('Bagagens')) {
            balance.dfc!.reclamacoesBagagens += `${f.nome}: ${f.valor}. `;
          } else if (f.nome.includes('Check-In')) {
            balance.dfc!.filasCheckIn += `${f.nome}: ${f.valor}. `;
          } else {
            balance.dfc!.controleFronteiras += `${f.nome}: ${f.valor}. `;
          }
          logsCount++;
        });
        
        if (!balance.dfc!.tempoEsperaSeguranca) balance.dfc!.tempoEsperaSeguranca = 'Tempos de espera normais na segurança.';
        if (!balance.dfc!.reclamacoesBagagens) balance.dfc!.reclamacoesBagagens = 'Nenhuma reclamação ou paragem mecânica registada.';
        if (!balance.dfc!.filasCheckIn) balance.dfc!.filasCheckIn = 'Fluxo de check-in regular.';
        if (!balance.dfc!.controleFronteiras) balance.dfc!.controleFronteiras = 'Controlo migratório fluido.';
      }
      
      else if (p.divisaoId === DivisionId.FAL) {
        fields.forEach(f => {
          if (f.nome.includes('PMR') || f.nome.includes('Mobilidade')) {
            balance.fal!.acessibilidadePMR += `${f.nome}: ${f.valor}. `;
          } else if (f.nome.includes('Médica') || f.nome.includes('Saúde')) {
            balance.fal!.assistenciaMedica += `${f.nome}: ${f.valor}. `;
          } else if (f.nome.includes('Feedback') || f.nome.includes('Passageiros')) {
            balance.fal!.feedbackPassageiros += `${f.nome}: ${f.valor}. `;
          } else {
            balance.fal!.conformidadeNormativa += `${f.nome}: ${f.valor}. `;
          }
          logsCount++;
        });
        
        if (!balance.fal!.acessibilidadePMR) balance.fal!.acessibilidadePMR = 'Assistência PMR garantida conforme os acordos de nível de serviço.';
        if (!balance.fal!.assistenciaMedica) balance.fal!.assistenciaMedica = 'Sem incidentes médicos registados.';
        if (!balance.fal!.feedbackPassageiros) balance.fal!.feedbackPassageiros = 'Feedback de passageiros recolhido com índices positivos.';
        if (!balance.fal!.conformidadeNormativa) balance.fal!.conformidadeNormativa = 'Conformidade garantida segundo Anexo 9 ICAO.';
      }
      
      else if (p.divisaoId === DivisionId.DRCQ) {
        fields.forEach(f => {
          if (f.nome.includes('Auditoria') || f.nome.includes('Inspeção')) {
            balance.drcq!.auditoriasInspecoes += `${f.nome}: ${f.valor}. `;
          } else if (f.nome.includes('Não Conformidade')) {
            balance.drcq!.naoConformidadesDetetadas += `${f.nome}: ${f.valor}. `;
          } else {
            balance.drcq!.avaliacaoRiscoOperacional += `${f.nome}: ${f.valor}. `;
          }
          logsCount++;
        });
        
        if (!balance.drcq!.auditoriasInspecoes) balance.drcq!.auditoriasInspecoes = 'Auditorias regulares de qualidade efetuadas.';
        if (!balance.drcq!.naoConformidadesDetetadas) balance.drcq!.naoConformidadesDetetadas = 'Nenhuma não conformidade grave em aberto.';
        if (!balance.drcq!.avaliacaoRiscoOperacional) balance.drcq!.avaliacaoRiscoOperacional = 'Risco global avaliado como BAIXO.';
        balance.drcq!.acoesPreventivasRecomendadas = 'Garantir a manutenção atempada dos geradores auxiliares.';
      }
    });
    
    // Auto generate a premium resumoGeral
    balance.resumoGeral = `Consolidado automático gerado com base em ${logsCount} campos validados pelo Secretariado para as divisões operacionais. `;
    if (balance.dfc!.reclamacoesBagagens && balance.dfc!.reclamacoesBagagens.toLowerCase().includes('avaria')) {
      balance.resumoGeral += 'Destaca-se a ocorrência técnica resolvida com sucesso no tapete de bagagens nº 3. ';
    }
    if (balance.dos!.atividadesFauna && balance.dos!.atividadesFauna.toLowerCase().includes('garça')) {
      balance.resumoGeral += 'Registou-se avistamento menor de aves, dispersadas imediatamente sem impacto em pista. ';
    }
    balance.resumoGeral += 'Todos os restantes fluxos de passageiros e segurança mantiveram-se regulares e em plena conformidade normativa.';
    
    // Advance state to EM_REVISAO
    const oldEstado = balance.estado;
    balance.estado = BalanceStatus.EM_REVISAO;
    balance.revisadoPor = user;
    
    // Workflow log
    this.createWorkflowLog({
      balanceId: balance.id,
      utilizador: user,
      deEstado: oldEstado,
      paraEstado: BalanceStatus.EM_REVISAO,
      comentario: 'Consolidação de dados operacionais e relatórios executada com sucesso.'
    });
    
    // Create notifications for the Director
    this.createNotification({
      role: UserRole.DIRETOR,
      titulo: 'Proposta de Consolidado Pronta',
      mensagem: `O Balanço nº ${balance.numero} foi consolidado automaticamente e aguarda aprovação.`,
      link: `/balancos/${balance.id}`
    });
    
    // Audit Log
    this.createAuditLog({
      utilizador: user,
      perfil: userRole,
      acao: 'Consolidação Automática',
      detalhe: `Balanço ${balance.numero} consolidado automaticamente a partir das fontes de divisões.`
    });
    
    this.save(db);
    return balance;
  }

  // --- AUTOMATIC ACTION PLAN EXTRACTION ENGINE ---
  static extractAndSyncActionPlans(db: DatabaseSchema, doc: Documento, docProcessed: DocumentoProcessado) {
    const balanceId = doc.balanceId;
    if (!balanceId) return;
    
    const balance = db.balances.find(b => b.id === balanceId);
    if (!balance) return;
    
    // Find all slides of this processed document
    const docSlides = db.slides.filter(s => s.documentoProcessadoId === docProcessed.id);
    
    // Look for slides with Action Plans
    docSlides.forEach(slide => {
      const titleLower = slide.titulo.toLowerCase();
      if (titleLower.includes('plano de ação') || titleLower.includes('ações') || titleLower.includes('corretiva')) {
        
        let actionItem: Partial<ActionPlanItem> | null = null;
        
        if (doc.divisaoId === DivisionId.DOS) {
          actionItem = {
            titulo: 'Substituição de Lâmpadas no Eixo Central',
            descricao: slide.conteudoTextual,
            divisaoId: DivisionId.DOS,
            responsavel: 'Eng. António Bunga',
            dataLimite: '2026-07-20',
            prioridade: ActionPlanPriority.MEDIA,
            percentagemExecucao: 25,
            estado: ActionPlanStatus.EM_CURSO
          };
        } else if (doc.divisaoId === DivisionId.DFC) {
          actionItem = {
            titulo: 'Abertura de Guichets Suplementares',
            descricao: slide.conteudoTextual,
            divisaoId: DivisionId.DFC,
            responsavel: 'Dra. Isabel Cassule',
            dataLimite: '2026-07-25',
            prioridade: ActionPlanPriority.ALTA,
            percentagemExecucao: 0,
            estado: ActionPlanStatus.PENDENTE
          };
        } else if (doc.divisaoId === DivisionId.DRCQ) {
          actionItem = {
            titulo: 'Auditoria de Equipamentos Críticos',
            descricao: slide.conteudoTextual,
            divisaoId: DivisionId.DRCQ,
            responsavel: 'Eng. Sofia Martins',
            dataLimite: '2026-07-22',
            prioridade: ActionPlanPriority.ALTA,
            percentagemExecucao: 10,
            estado: ActionPlanStatus.EM_CURSO
          };
        }
        
        if (actionItem) {
          // Compare with previous action plans
          const existingPlanIndex = db.actionPlans.findIndex(p => p.titulo === actionItem!.titulo);
          
          if (existingPlanIndex !== -1) {
            const oldPlan = db.actionPlans[existingPlanIndex];
            
            const changes: string[] = [];
            if (oldPlan.percentagemExecucao !== actionItem.percentagemExecucao) {
              changes.push(`Percentagem subiu de ${oldPlan.percentagemExecucao || 0}% para ${actionItem.percentagemExecucao || 0}%`);
            }
            if (oldPlan.estado !== actionItem.estado) {
              changes.push(`Estado transitou de ${oldPlan.estado} para ${actionItem.estado}`);
            }
            
            if (changes.length > 0) {
              // Create audit log of changes (Histórico de Plano de Ação)
              this.createAuditLog({
                utilizador: 'SISTEMA (Auto Engine)',
                perfil: 'Serviço Inteligente',
                acao: 'Atualizar Plano de Ação',
                detalhe: `Atualização automática de Plano de Ação "${oldPlan.titulo}" em balanço posterior. Alterações: ${changes.join(', ')}.`
              });
              
              // Notify Secretariat & division chief about progress change
              this.createNotification({
                divisaoId: oldPlan.divisaoId,
                titulo: 'Progresso do Plano de Ação Atualizado',
                mensagem: `O Plano de Ação "${oldPlan.titulo}" teve atualizações automáticas: ${changes.join(', ')}. Referente ao Balanço nº ${balance.numero}.`,
                link: '/plano-acao'
              });
              
              // Push to action plan internal history
              const oldHist = oldPlan.historico || [];
              if (oldPlan.percentagemExecucao !== actionItem.percentagemExecucao) {
                oldHist.push({
                  id: `hist-${Date.now()}-1`,
                  planoId: oldPlan.id,
                  campo: 'progresso',
                  valorAnterior: String(oldPlan.progresso || 0),
                  valorNovo: String(actionItem.percentagemExecucao || 0),
                  utilizador: 'SISTEMA (Auto Engine)',
                  dataHora: new Date().toISOString()
                });
              }
              if (oldPlan.estado !== actionItem.estado) {
                oldHist.push({
                  id: `hist-${Date.now()}-2`,
                  planoId: oldPlan.id,
                  campo: 'estado',
                  valorAnterior: String(oldPlan.estado),
                  valorNovo: String(actionItem.estado),
                  utilizador: 'SISTEMA (Auto Engine)',
                  dataHora: new Date().toISOString()
                });
              }

              // Update existing plan
              db.actionPlans[existingPlanIndex] = {
                ...oldPlan,
                percentagemExecucao: actionItem.percentagemExecucao || 0,
                progresso: actionItem.percentagemExecucao || 0,
                estado: actionItem.estado || oldPlan.estado,
                balanceId: balanceId,
                historico: oldHist
              };
            }
          } else {
            // New action plan
            const newId = `act-${Date.now()}`;
            const count = db.actionPlans.length;
            const formattedCount = String(count + 1).padStart(3, '0');
            const newCode = `ACT-2026-${formattedCount}`;
            
            let actionItemPriority = ActionPlanPriority.MEDIA;
            if (actionItem.prioridade) {
              const p = String(actionItem.prioridade).toLowerCase();
              if (p.includes('alt')) actionItemPriority = ActionPlanPriority.ALTA;
              else if (p.includes('baix')) actionItemPriority = ActionPlanPriority.BAIXA;
              else if (p.includes('crit')) actionItemPriority = ActionPlanPriority.CRITICA;
            }

            db.actionPlans.push({
              id: newId,
              codigo: newCode,
              titulo: actionItem.titulo!,
              descricao: actionItem.descricao!,
              categoria: 'Operações',
              divisaoId: actionItem.divisaoId!,
              responsavel: actionItem.responsavel!,
              dataLimite: actionItem.dataLimite!,
              estado: actionItem.estado!,
              prioridade: actionItemPriority,
              progresso: actionItem.percentagemExecucao || 0,
              percentagemExecucao: actionItem.percentagemExecucao || 0,
              dataCriacao: new Date().toISOString().split('T')[0],
              dataInicio: new Date().toISOString().split('T')[0],
              balanceId: balanceId,
              historico: [],
              comentarios: [],
              evidencias: []
            });
            
            // Audit Log
            this.createAuditLog({
              utilizador: 'SISTEMA (Auto Engine)',
              perfil: 'Serviço Inteligente',
              acao: 'Criar Plano de Ação',
              detalhe: `Criado Plano de Ação automático "${actionItem.titulo}" extraído de slide da divisão ${actionItem.divisaoId}.`
            });
          }
        }
      }
    });
  }

  private static getMockSlidesForDivision(docProcessedId: string, division: DivisionId): Slide[] {
    const timestamp = Date.now();
    
    if (division === DivisionId.DOS) {
      return [
        {
          id: `s-${timestamp}-1`,
          documentoProcessadoId: docProcessedId,
          numero: 1,
          titulo: 'Balanço Operacional de Operações e Segurança',
          subtitulo: 'Sumário Executivo de Atividade de Pistas e AVSEC',
          conteudoTextual: 'Este relatório compila os dados das últimas 24 horas sobre o perímetro de segurança, estado das pistas e dispersão de fauna no aeroporto.',
          temImagens: true,
          totalImagens: 1,
          temGraficos: false,
          totalGraficos: 0
        },
        {
          id: `s-${timestamp}-2`,
          documentoProcessadoId: docProcessedId,
          numero: 2,
          titulo: 'Ocorrências de Segurança e Patrulhas AVSEC',
          subtitulo: 'Rondas perimetrais e sistemas de vigilância',
          conteudoTextual: 'Rondas preventivas efetuadas pela patrulha do quadrante norte. Ocorrências detetadas: zero invasões. Alarmes falsos na cerca eletrónica devido a rajadas de vento resolvidos.',
          temImagens: false,
          totalImagens: 0,
          temGraficos: true,
          totalGraficos: 1,
          notasApresentador: 'Salientar a necessidade de calibração fina dos sensores da cerca perimetral do setor 4.'
        },
        {
          id: `s-${timestamp}-3`,
          documentoProcessadoId: docProcessedId,
          numero: 3,
          titulo: 'Controlo de Fauna e Dispersão de Aves',
          subtitulo: 'Gestão de perigo aviário na aproximação das pistas',
          conteudoTextual: 'Detetada presença de aves de médio porte (garças) junto à cabeceira 23. Dispersadas imediatamente com recurso a pistolas pirotécnicas acústicas. Risco de colisão contido.',
          temImagens: true,
          totalImagens: 2,
          temGraficos: false,
          totalGraficos: 0
        },
        {
          id: `s-${timestamp}-4`,
          documentoProcessadoId: docProcessedId,
          numero: 4,
          titulo: 'Plano de Ação - Próximos Passos',
          subtitulo: 'Manutenção preventiva de equipamentos de pista',
          conteudoTextual: 'Proceder à substituição de 3 lâmpadas fundidas no eixo central da pista de táxi C durante o período de inatividade noturna.',
          temImagens: false,
          totalImagens: 0,
          temGraficos: false,
          totalGraficos: 0
        }
      ];
    } 
    else if (division === DivisionId.DFC) {
      return [
        {
          id: `s-${timestamp}-1`,
          documentoProcessadoId: docProcessedId,
          numero: 1,
          titulo: 'Relatório Diário de Facilitação e Controlo',
          subtitulo: 'Sistemas de Bagagens e Processamento Migratório',
          conteudoTextual: 'Sintonia de operações com serviços de migração e alfândega. Resumo de fluxo e reclamações mecânicas.',
          temImagens: true,
          totalImagens: 1,
          temGraficos: false,
          totalGraficos: 0
        },
        {
          id: `s-${timestamp}-2`,
          documentoProcessadoId: docProcessedId,
          numero: 2,
          titulo: 'Tráfego e Fluxo no Terminal Internacional',
          subtitulo: 'Tempos de espera e processamento alfandegário',
          conteudoTextual: 'Picos de passageiros verificados entre as 12h00 e as 14h30 com a chegada de 3 voos intercontinentais em simultâneo. Tempo de espera médio na imigração: 18 minutos.',
          temImagens: false,
          totalImagens: 0,
          temGraficos: true,
          totalGraficos: 2
        },
        {
          id: `s-${timestamp}-3`,
          documentoProcessadoId: docProcessedId,
          numero: 3,
          titulo: 'Tapete de Bagagens Nº 3 - Ocorrência Técnica',
          subtitulo: 'Inatividade temporária no tapete central do terminal 1',
          conteudoTextual: 'Avaria técnica do motor elétrico no carrossel de bagagens 3, afetando o Voo DT-652. Tempo total de indisponibilidade: 45 minutos. Reparação executada em tempo útil.',
          temImagens: true,
          totalImagens: 1,
          temGraficos: false,
          totalGraficos: 0,
          notasApresentador: 'Discutir a aquisição de um motor sobressalente com o fornecedor local para evitar paragens maiores.'
        },
        {
          id: `s-${timestamp}-4`,
          documentoProcessadoId: docProcessedId,
          numero: 4,
          titulo: 'Plano de Ação Corretiva DFC',
          subtitulo: 'Medidas de melhoria no escoamento de passageiros',
          conteudoTextual: 'Proposta de abertura de 2 guichets de controlo suplementares para horas de ponta em articulação com o SME.',
          temImagens: false,
          totalImagens: 0,
          temGraficos: false,
          totalGraficos: 0
        }
      ];
    }
    
    // Fallback/other divisions
    return [
      {
        id: `s-${timestamp}-1`,
        documentoProcessadoId: docProcessedId,
        numero: 1,
        titulo: `Relatório de Contribuição de ${division}`,
        subtitulo: 'Sumário diário consolidado das atividades',
        conteudoTextual: 'Conformidade e dados de acompanhamento operacional em total sintonia com os regulamentos institucionais vigentes.',
        temImagens: false,
        totalImagens: 0,
        temGraficos: false,
        totalGraficos: 0
      },
      {
        id: `s-${timestamp}-2`,
        documentoProcessadoId: docProcessedId,
        numero: 2,
        titulo: 'Análise de Desempenho e Indicadores',
        subtitulo: 'Resultados operacionais verificados',
        conteudoTextual: 'Verificou-se conformidade normativa em todos os aspetos inspecionados. Risco global considerado extremamente baixo e controlado.',
        temImagens: false,
        totalImagens: 0,
        temGraficos: true,
        totalGraficos: 1
      }
    ];
  }

  private static getMockFieldsForSlide(docProcessedId: string, slide: Slide): CampoExtraido[] {
    const timestamp = Date.now();
    const slideId = slide.id;
    const num = slide.numero;

    if (slide.titulo.includes('Patrulhas AVSEC') || slide.titulo.includes('Ocorrências')) {
      return [
        { id: `f-field-${timestamp}-${num}-1`, documentoProcessadoId: docProcessedId, slideId, nome: 'Invasões Perimetrais', valor: '0 ocorrências', categoria: 'Segurança', confianca: 98, validado: false },
        { id: `f-field-${timestamp}-${num}-2`, documentoProcessadoId: docProcessedId, slideId, nome: 'Rondas de Vigilância', valor: '20 rondas efetuadas', categoria: 'Segurança', confianca: 94, validado: false }
      ];
    } 
    else if (slide.titulo.includes('Controlo de Fauna')) {
      return [
        { id: `f-field-${timestamp}-${num}-3`, documentoProcessadoId: docProcessedId, slideId, nome: 'Avistamentos de Aves', valor: '3 bandos de garças', categoria: 'Operações', confianca: 95, validado: false },
        { id: `f-field-${timestamp}-${num}-4`, documentoProcessadoId: docProcessedId, slideId, nome: 'Dispersões Efetuadas', valor: 'Afastamento pirotécnico com sucesso', categoria: 'Operações', confianca: 92, validado: false }
      ];
    } 
    else if (slide.titulo.includes('Bagagens')) {
      return [
        { id: `f-field-${timestamp}-${num}-5`, documentoProcessadoId: docProcessedId, slideId, nome: 'Avaria do Carrossel 3', valor: 'Inatividade de 45 min', categoria: 'Facilitação', confianca: 99, validado: false },
        { id: `f-field-${timestamp}-${num}-6`, documentoProcessadoId: docProcessedId, slideId, nome: 'Descarregamento Manual', valor: 'Ativado apoio para voo DT-652', categoria: 'Facilitação', confianca: 95, validado: false }
      ];
    }
    else if (slide.titulo.includes('Tráfego')) {
      return [
        { id: `f-field-${timestamp}-${num}-7`, documentoProcessadoId: docProcessedId, slideId, nome: 'Tempo Médio de Espera', valor: '18 minutos na imigração', categoria: 'Facilitação', confianca: 96, validado: false }
      ];
    }

    // Default fields for general slides
    return [
      { id: `f-field-${timestamp}-${num}-def`, documentoProcessadoId: docProcessedId, slideId, nome: `Destaque do Slide ${num}`, valor: slide.subtitulo || 'Verificado', categoria: 'Geral', confianca: 85, validado: false }
    ];
  }

  // Business Intelligence Methods
  static getKPIs(): KPI[] {
    return this.load().kpis || [];
  }

  static addKPI(kpi: Omit<KPI, 'id'>): KPI {
    const db = this.load();
    const id = `kpi-${Date.now()}`;
    const newKpi: KPI = { ...kpi, id };
    db.kpis = db.kpis || [];
    db.kpis.push(newKpi);
    this.save(db);
    return newKpi;
  }

  static getDashboardConfigs(): DashboardConfig[] {
    return this.load().dashboardConfigs || [];
  }

  static saveDashboardConfig(config: DashboardConfig): DashboardConfig {
    const db = this.load();
    db.dashboardConfigs = db.dashboardConfigs || [];
    const index = db.dashboardConfigs.findIndex(c => c.id === config.id || c.utilizador === config.utilizador);
    if (index >= 0) {
      db.dashboardConfigs[index] = config;
    } else {
      db.dashboardConfigs.push(config);
    }
    this.save(db);
    return config;
  }

  static getRelatoriosAnaliticos(): RelatorioAnalitico[] {
    return this.load().relatoriosAnaliticos || [];
  }

  static createRelatorioAnalitico(tipo: string, periodo: string, gerado_por: string): RelatorioAnalitico {
    const db = this.load();
    const id = `rep-${Date.now()}`;
    const newReport: RelatorioAnalitico = {
      id,
      tipo,
      periodo,
      gerado_por,
      data: new Date().toISOString()
    };
    db.relatoriosAnaliticos = db.relatoriosAnaliticos || [];
    db.relatoriosAnaliticos.push(newReport);
    this.save(db);
    return newReport;
  }

  static getEstatisticas(): Estatistica[] {
    return this.load().estatisticas || [];
  }

  // AI Copilot Methods
  static getConversasIA(userId: string): ConversaIA[] {
    const db = this.load();
    db.conversasIA = db.conversasIA || [];
    return db.conversasIA.filter(c => c.utilizador_id === userId);
  }

  static getMensagensIA(conversaId: string): MensagemIA[] {
    const db = this.load();
    db.mensagensIA = db.mensagensIA || [];
    return db.mensagensIA.filter(m => m.conversa_id === conversaId);
  }

  static createConversaIA(utilizador_id: string, modelo_utilizado: string): ConversaIA {
    const db = this.load();
    db.conversasIA = db.conversasIA || [];
    const id = `chat-${Date.now()}`;
    const newConversa: ConversaIA = {
      id,
      utilizador_id,
      data_inicio: new Date().toISOString(),
      modelo_utilizado
    };
    db.conversasIA.push(newConversa);
    this.save(db);
    return newConversa;
  }

  static clearConversaIA(conversaId: string): boolean {
    const db = this.load();
    db.conversasIA = db.conversasIA || [];
    db.mensagensIA = db.mensagensIA || [];
    db.conversasIA = db.conversasIA.filter(c => c.id !== conversaId);
    db.mensagensIA = db.mensagensIA.filter(m => m.conversa_id !== conversaId);
    this.save(db);
    return true;
  }

  static createMensagemIA(conversaId: string, tipo: 'utilizador' | 'assistente', conteudo: string, referencias?: MensagemIA['referencias']): MensagemIA {
    const db = this.load();
    db.mensagensIA = db.mensagensIA || [];
    const id = `msg-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
    const newMsg: MensagemIA = {
      id,
      conversa_id: conversaId,
      tipo,
      conteudo,
      data_hora: new Date().toISOString(),
      referencias
    };
    db.mensagensIA.push(newMsg);
    this.save(db);
    return newMsg;
  }

  static getConfiguracaoIA(): ConfiguracaoIA {
    const db = this.load();
    db.configuracoesIA = db.configuracoesIA || [];
    if (db.configuracoesIA.length === 0) {
      db.configuracoesIA.push({
        id: 'cfg-1',
        modelo: 'gemini-3.5-flash',
        idioma: 'Português (AO)',
        temperatura: 0.2,
        limite_tokens: 2048,
        ativo: true
      });
      this.save(db);
    }
    return db.configuracoesIA.find(c => c.ativo) || db.configuracoesIA[0];
  }

  static updateConfiguracaoIA(config: Partial<ConfiguracaoIA>): ConfiguracaoIA {
    const db = this.load();
    db.configuracoesIA = db.configuracoesIA || [];
    if (db.configuracoesIA.length === 0) {
      db.configuracoesIA.push({
        id: 'cfg-1',
        modelo: 'gemini-3.5-flash',
        idioma: 'Português (AO)',
        temperatura: 0.2,
        limite_tokens: 2048,
        ativo: true
      });
    }
    const cfg = db.configuracoesIA[0];
    Object.assign(cfg, config);
    this.save(db);
    return cfg;
  }

  static getSugestoesIA(): SugestaoIA[] {
    return this.load().sugestoesIA || [];
  }

  static createSugestaoIA(categoria: string, descricao: string, prioridade: 'Alta' | 'Média' | 'Baixa'): SugestaoIA {
    const db = this.load();
    db.sugestoesIA = db.sugestoesIA || [];
    const id = `sug-${Date.now()}`;
    const newSug: SugestaoIA = {
      id,
      categoria,
      descricao,
      prioridade,
      data_criacao: new Date().toISOString()
    };
    db.sugestoesIA.push(newSug);
    this.save(db);
    return newSug;
  }
}
