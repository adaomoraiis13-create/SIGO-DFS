#!/bin/sh
# ==========================================
# SIGO-DFS - Script de Cópia de Segurança (Backup Automatizado)
# Desenvolvido para execução via CRON (DevOps / SysAdmin)
# ==========================================

# Parar imediatamente em caso de erro grave
set -e

# Configurações de diretórios
BACKUP_DIR="/usr/src/app/backups"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
UPLOADS_DIR="/usr/src/app/uploads"
STATE_DIR="/usr/src/app/data"

# Nomes dos arquivos de backup
DB_BACKUP_NAME="sigo_dfs_db_backup_${TIMESTAMP}.sql"
UPLOADS_BACKUP_NAME="sigo_dfs_uploads_backup_${TIMESTAMP}.tar.gz"
CONFIGS_BACKUP_NAME="sigo_dfs_configs_backup_${TIMESTAMP}.tar.gz"

echo "[SIGO-DFS BACKUP] Iniciando rotina de cópia de segurança em $(date)..."

# Garantir que a pasta de cópias de segurança existe
mkdir -p "${BACKUP_DIR}"

# 1. Backup da Base de Dados PostgreSQL (se configurada)
if [ -n "${DATABASE_URL}" ]; then
  echo "[SIGO-DFS BACKUP] Efetuando dump do banco PostgreSQL..."
  # Usar pg_dump a partir da URL de conexão
  pg_dump "${DATABASE_URL}" -f "${BACKUP_DIR}/${DB_BACKUP_NAME}"
  echo "[SIGO-DFS BACKUP] Cópia do banco PostgreSQL concluída: ${DB_BACKUP_NAME}"
else
  echo "[SIGO-DFS BACKUP] DATABASE_URL não configurada. Efetuando cópia de segurança do ficheiro JSON de estado..."
  if [ -d "${STATE_DIR}" ]; then
    tar -czf "${BACKUP_DIR}/sigo_dfs_json_state_${TIMESTAMP}.tar.gz" -C "${STATE_DIR}" .
    echo "[SIGO-DFS BACKUP] Cópia do estado JSON concluída."
  fi
fi

# 2. Backup do Armazenamento de Documentos (/uploads)
if [ -d "${UPLOADS_DIR}" ] && [ "$(ls -A ${UPLOADS_DIR} 2>/dev/null)" ]; then
  echo "[SIGO-DFS BACKUP] Comprimindo pasta estruturada de uploads (/uploads)..."
  tar -czf "${BACKUP_DIR}/${UPLOADS_BACKUP_NAME}" -C "${UPLOADS_DIR}" .
  echo "[SIGO-DFS BACKUP] Cópia dos ficheiros/documentos concluída: ${UPLOADS_BACKUP_NAME}"
else
  echo "[SIGO-DFS BACKUP] Pasta /uploads vazia ou inexistente. Ignorando."
fi

# 3. Backup de Configurações (.env e metadata.json)
echo "[SIGO-DFS BACKUP] Efetuando cópia das configurações..."
tar -czf "${BACKUP_DIR}/${CONFIGS_BACKUP_NAME}" -C "/usr/src/app" .env.example metadata.json package.json 2>/dev/null || true
echo "[SIGO-DFS BACKUP] Cópia das configurações concluída: ${CONFIGS_BACKUP_NAME}"

# 4. Limpeza de cópias antigas (Retenção de 7 dias)
echo "[SIGO-DFS BACKUP] Removendo cópias de segurança com mais de 7 dias para otimização de disco..."
find "${BACKUP_DIR}" -type f -name "sigo_dfs_*" -mtime +7 -delete

echo "[SIGO-DFS BACKUP] Rotina de cópia de segurança finalizada com absoluto sucesso!"
exit 0
